<?php // vwApQOwOCzasJ
/**
 * @link http://craftcms.com/
 * @copyright Copyright (c) Pixel & Tonic, Inc.
 * @license http://craftcms.com/license
 */

namespace craft\behaviors;

use yii\base\Behavior;

/**
 * Custom field behavior
 *
 * This class provides attributes for all the unique custom field handles.
 *
 * @method self summary(mixed $value) Sets the [[summary]] property
 * @method self featureImage(mixed $value) Sets the [[featureImage]] property
 * @method self postCategories(mixed $value) Sets the [[postCategories]] property
 * @method self postContent(mixed $value) Sets the [[postContent]] property
 * @method self text(mixed $value) Sets the [[text]] property
 * @method self description(mixed $value) Sets the [[description]] property
 * @method self body(mixed $value) Sets the [[body]] property
 * @method self image(mixed $value) Sets the [[image]] property
 * @method self photo(mixed $value) Sets the [[photo]] property
 * @method self serviceBody(mixed $value) Sets the [[serviceBody]] property
 * @method self heading(mixed $value) Sets the [[heading]] property
 * @method self articleBody(mixed $value) Sets the [[articleBody]] property
 * @method self sectionHeading(mixed $value) Sets the [[sectionHeading]] property
 * @method self position(mixed $value) Sets the [[position]] property
 * @method self pullQuote(mixed $value) Sets the [[pullQuote]] property
 * @method self caption(mixed $value) Sets the [[caption]] property
 * @method self images(mixed $value) Sets the [[images]] property
 * @method self attribution(mixed $value) Sets the [[attribution]] property
 * @method self quote(mixed $value) Sets the [[quote]] property
 * @method self backgroundColor(mixed $value) Sets the [[backgroundColor]] property
 * @method self featuredImage(mixed $value) Sets the [[featuredImage]] property
 * @method self featuredThumb(mixed $value) Sets the [[featuredThumb]] property
 * @method self featuredEntry(mixed $value) Sets the [[featuredEntry]] property
 * @method self indexHeading(mixed $value) Sets the [[indexHeading]] property
 * @method self linkUrl(mixed $value) Sets the [[linkUrl]] property
 * @method self shortDescription(mixed $value) Sets the [[shortDescription]] property
 * @method self subheading(mixed $value) Sets the [[subheading]] property
 * @method self featuredIcon(mixed $value) Sets the [[featuredIcon]] property
 * @method self clientBody(mixed $value) Sets the [[clientBody]] property
 * @method self heroBody(mixed $value) Sets the [[heroBody]] property
 * @method self sliderBody(mixed $value) Sets the [[sliderBody]] property
 * @method self copyrightNotice(mixed $value) Sets the [[copyrightNotice]] property
 * @method self portfolioBody(mixed $value) Sets the [[portfolioBody]] property
 * @method self teamBody(mixed $value) Sets the [[teamBody]] property
 * @method self actionText(mixed $value) Sets the [[actionText]] property
 * @method self serviceText(mixed $value) Sets the [[serviceText]] property
 * @method self portfolioText(mixed $value) Sets the [[portfolioText]] property
 * @method self clientText(mixed $value) Sets the [[clientText]] property
 * @method self teamText(mixed $value) Sets the [[teamText]] property
 * @method self contactBody(mixed $value) Sets the [[contactBody]] property
 * @method self maps(mixed $value) Sets the [[maps]] property
 * @method self portfolioCategory(mixed $value) Sets the [[portfolioCategory]] property
 * @method self logo(mixed $value) Sets the [[logo]] property
 * @method self email(mixed $value) Sets the [[email]] property
 * @method self address(mixed $value) Sets the [[address]] property
 * @method self contactOffice(mixed $value) Sets the [[contactOffice]] property
 * @method self whatsapp(mixed $value) Sets the [[whatsapp]] property
 * @method self telp(mixed $value) Sets the [[telp]] property
 * @method self socialMediaAccount(mixed $value) Sets the [[socialMediaAccount]] property
 * @method self linkedin(mixed $value) Sets the [[linkedin]] property
 * @method self instagram(mixed $value) Sets the [[instagram]] property
 * @method self facebook(mixed $value) Sets the [[facebook]] property
 * @method self twitter(mixed $value) Sets the [[twitter]] property
 * @method self testimonialBody(mixed $value) Sets the [[testimonialBody]] property
 * @method self testimonialText(mixed $value) Sets the [[testimonialText]] property
 * @method self joinText(mixed $value) Sets the [[joinText]] property
 * @method self jobsDescription(mixed $value) Sets the [[jobsDescription]] property
 * @method self jobsRequirement(mixed $value) Sets the [[jobsRequirement]] property
 * @method self jobsCategories(mixed $value) Sets the [[jobsCategories]] property
 * @method self companyName(mixed $value) Sets the [[companyName]] property
 * @method self icon(mixed $value) Sets the [[icon]] property
 */
class CustomFieldBehavior extends Behavior
{
    /**
     * @var bool Whether the behavior should provide methods based on the field handles.
     */
    public $hasMethods = false;

    /**
     * @var string[] List of supported field handles.
     */
    public static $fieldHandles = [
        'summary' => true,
        'featureImage' => true,
        'postCategories' => true,
        'postContent' => true,
        'text' => true,
        'description' => true,
        'body' => true,
        'image' => true,
        'photo' => true,
        'serviceBody' => true,
        'heading' => true,
        'articleBody' => true,
        'sectionHeading' => true,
        'position' => true,
        'pullQuote' => true,
        'caption' => true,
        'images' => true,
        'attribution' => true,
        'quote' => true,
        'backgroundColor' => true,
        'featuredImage' => true,
        'featuredThumb' => true,
        'featuredEntry' => true,
        'indexHeading' => true,
        'linkUrl' => true,
        'shortDescription' => true,
        'subheading' => true,
        'featuredIcon' => true,
        'clientBody' => true,
        'heroBody' => true,
        'sliderBody' => true,
        'copyrightNotice' => true,
        'portfolioBody' => true,
        'teamBody' => true,
        'actionText' => true,
        'serviceText' => true,
        'portfolioText' => true,
        'clientText' => true,
        'teamText' => true,
        'contactBody' => true,
        'maps' => true,
        'portfolioCategory' => true,
        'logo' => true,
        'email' => true,
        'address' => true,
        'contactOffice' => true,
        'whatsapp' => true,
        'telp' => true,
        'socialMediaAccount' => true,
        'linkedin' => true,
        'instagram' => true,
        'facebook' => true,
        'twitter' => true,
        'testimonialBody' => true,
        'testimonialText' => true,
        'joinText' => true,
        'jobsDescription' => true,
        'jobsRequirement' => true,
        'jobsCategories' => true,
        'companyName' => true,
        'icon' => true,
    ];

    /**
     * @var string|null Value for field with the handle “summary”.
     */
    public $summary;

    /**
     * @var \craft\elements\db\AssetQuery Value for field with the handle “featureImage”.
     */
    public $featureImage;

    /**
     * @var \craft\elements\db\CategoryQuery Value for field with the handle “postCategories”.
     */
    public $postCategories;

    /**
     * @var \craft\elements\db\MatrixBlockQuery Value for field with the handle “postContent”.
     */
    public $postContent;

    /**
     * @var mixed Value for field with the handle “text”.
     */
    public $text;

    /**
     * @var mixed Value for field with the handle “description”.
     */
    public $description;

    /**
     * @var mixed Value for field with the handle “body”.
     */
    public $body;

    /**
     * @var \craft\elements\db\AssetQuery Value for field with the handle “image”.
     */
    public $image;

    /**
     * @var \craft\elements\db\AssetQuery Value for field with the handle “photo”.
     */
    public $photo;

    /**
     * @var \craft\elements\db\MatrixBlockQuery Value for field with the handle “serviceBody”.
     */
    public $serviceBody;

    /**
     * @var string|null Value for field with the handle “heading”.
     */
    public $heading;

    /**
     * @var \craft\elements\db\MatrixBlockQuery Value for field with the handle “articleBody”.
     */
    public $articleBody;

    /**
     * @var string|null Value for field with the handle “sectionHeading”.
     */
    public $sectionHeading;

    /**
     * @var \craft\fields\data\SingleOptionFieldData Value for field with the handle “position”.
     */
    public $position;

    /**
     * @var string|null Value for field with the handle “pullQuote”.
     */
    public $pullQuote;

    /**
     * @var mixed Value for field with the handle “caption”.
     */
    public $caption;

    /**
     * @var \craft\elements\db\AssetQuery Value for field with the handle “images”.
     */
    public $images;

    /**
     * @var string|null Value for field with the handle “attribution”.
     */
    public $attribution;

    /**
     * @var string|null Value for field with the handle “quote”.
     */
    public $quote;

    /**
     * @var \craft\fields\data\ColorData|null Value for field with the handle “backgroundColor”.
     */
    public $backgroundColor;

    /**
     * @var \craft\elements\db\AssetQuery Value for field with the handle “featuredImage”.
     */
    public $featuredImage;

    /**
     * @var \craft\elements\db\AssetQuery Value for field with the handle “featuredThumb”.
     */
    public $featuredThumb;

    /**
     * @var bool Value for field with the handle “featuredEntry”.
     */
    public $featuredEntry;

    /**
     * @var mixed Value for field with the handle “indexHeading”.
     */
    public $indexHeading;

    /**
     * @var string|null Value for field with the handle “linkUrl”.
     */
    public $linkUrl;

    /**
     * @var mixed Value for field with the handle “shortDescription”.
     */
    public $shortDescription;

    /**
     * @var string|null Value for field with the handle “subheading”.
     */
    public $subheading;

    /**
     * @var \craft\elements\db\AssetQuery Value for field with the handle “featuredIcon”.
     */
    public $featuredIcon;

    /**
     * @var \craft\elements\db\MatrixBlockQuery Value for field with the handle “clientBody”.
     */
    public $clientBody;

    /**
     * @var \craft\elements\db\MatrixBlockQuery Value for field with the handle “heroBody”.
     */
    public $heroBody;

    /**
     * @var \craft\elements\db\MatrixBlockQuery Value for field with the handle “sliderBody”.
     */
    public $sliderBody;

    /**
     * @var string|null Value for field with the handle “copyrightNotice”.
     */
    public $copyrightNotice;

    /**
     * @var \craft\elements\db\MatrixBlockQuery Value for field with the handle “portfolioBody”.
     */
    public $portfolioBody;

    /**
     * @var \craft\elements\db\MatrixBlockQuery Value for field with the handle “teamBody”.
     */
    public $teamBody;

    /**
     * @var \craft\elements\db\MatrixBlockQuery Value for field with the handle “actionText”.
     */
    public $actionText;

    /**
     * @var mixed Value for field with the handle “serviceText”.
     */
    public $serviceText;

    /**
     * @var mixed Value for field with the handle “portfolioText”.
     */
    public $portfolioText;

    /**
     * @var mixed Value for field with the handle “clientText”.
     */
    public $clientText;

    /**
     * @var mixed Value for field with the handle “teamText”.
     */
    public $teamText;

    /**
     * @var \craft\elements\db\MatrixBlockQuery Value for field with the handle “contactBody”.
     */
    public $contactBody;

    /**
     * @var mixed Value for field with the handle “maps”.
     */
    public $maps;

    /**
     * @var \craft\elements\db\CategoryQuery Value for field with the handle “portfolioCategory”.
     */
    public $portfolioCategory;

    /**
     * @var \craft\elements\db\AssetQuery Value for field with the handle “logo”.
     */
    public $logo;

    /**
     * @var string|null Value for field with the handle “email”.
     */
    public $email;

    /**
     * @var mixed Value for field with the handle “address”.
     */
    public $address;

    /**
     * @var \craft\elements\db\MatrixBlockQuery Value for field with the handle “contactOffice”.
     */
    public $contactOffice;

    /**
     * @var int|float|null Value for field with the handle “whatsapp”.
     */
    public $whatsapp;

    /**
     * @var int|float|null Value for field with the handle “telp”.
     */
    public $telp;

    /**
     * @var \craft\elements\db\MatrixBlockQuery Value for field with the handle “socialMediaAccount”.
     */
    public $socialMediaAccount;

    /**
     * @var string|null Value for field with the handle “linkedin”.
     */
    public $linkedin;

    /**
     * @var string|null Value for field with the handle “instagram”.
     */
    public $instagram;

    /**
     * @var string|null Value for field with the handle “facebook”.
     */
    public $facebook;

    /**
     * @var string|null Value for field with the handle “twitter”.
     */
    public $twitter;

    /**
     * @var \craft\elements\db\MatrixBlockQuery Value for field with the handle “testimonialBody”.
     */
    public $testimonialBody;

    /**
     * @var mixed Value for field with the handle “testimonialText”.
     */
    public $testimonialText;

    /**
     * @var mixed Value for field with the handle “joinText”.
     */
    public $joinText;

    /**
     * @var mixed Value for field with the handle “jobsDescription”.
     */
    public $jobsDescription;

    /**
     * @var mixed Value for field with the handle “jobsRequirement”.
     */
    public $jobsRequirement;

    /**
     * @var \craft\elements\db\CategoryQuery Value for field with the handle “jobsCategories”.
     */
    public $jobsCategories;

    /**
     * @var string|null Value for field with the handle “companyName”.
     */
    public $companyName;

    /**
     * @var \craft\elements\db\AssetQuery Value for field with the handle “icon”.
     */
    public $icon;

    /**
     * @var array Additional custom field values we don’t know about yet.
     */
    private $_customFieldValues = [];

    /**
     * @inheritdoc
     */
    public function __call($name, $params)
    {
        if ($this->hasMethods && isset(self::$fieldHandles[$name]) && count($params) === 1) {
            $this->$name = $params[0];
            return $this->owner;
        }
        return parent::__call($name, $params);
    }

    /**
     * @inheritdoc
     */
    public function hasMethod($name)
    {
        if ($this->hasMethods && isset(self::$fieldHandles[$name])) {
            return true;
        }
        return parent::hasMethod($name);
    }

    /**
     * @inheritdoc
     */
    public function __isset($name)
    {
        if (isset(self::$fieldHandles[$name])) {
            return true;
        }
        return parent::__isset($name);
    }

    /**
     * @inheritdoc
     */
    public function __get($name)
    {
        if (isset(self::$fieldHandles[$name])) {
            return $this->_customFieldValues[$name] ?? null;
        }
        return parent::__get($name);
    }

    /**
     * @inheritdoc
     */
    public function __set($name, $value)
    {
        if (isset(self::$fieldHandles[$name])) {
            $this->_customFieldValues[$name] = $value;
            return;
        }
        parent::__set($name, $value);
    }

    /**
     * @inheritdoc
     */
    public function canGetProperty($name, $checkVars = true)
    {
        if ($checkVars && isset(self::$fieldHandles[$name])) {
            return true;
        }
        return parent::canGetProperty($name, $checkVars);
    }

    /**
     * @inheritdoc
     */
    public function canSetProperty($name, $checkVars = true)
    {
        if ($checkVars && isset(self::$fieldHandles[$name])) {
            return true;
        }
        return parent::canSetProperty($name, $checkVars);
    }
}
