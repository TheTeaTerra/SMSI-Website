<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* __string_template__abfbe166dca6eb822afccfbdda8a594ceb95d12b452e2d36b17400c32adb1b74 */
class __TwigTemplate_02ff98e6c4f545351d6195f8203429db66f7d5248e88fe4e3e763b8ae5745c6a extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "__string_template__abfbe166dca6eb822afccfbdda8a594ceb95d12b452e2d36b17400c32adb1b74");
        // line 1
        echo "clients/";
        echo (((craft\helpers\Template::attribute($this->env, $this->source, ($context["_variables"] ?? null), "slug", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["_variables"] ?? null), "slug", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["_variables"] ?? null), "slug", [])) : (craft\helpers\Template::attribute($this->env, $this->source, ($context["object"] ?? null), "slug", [])));
        // line 0
        craft\helpers\Template::endProfile("template", "__string_template__abfbe166dca6eb822afccfbdda8a594ceb95d12b452e2d36b17400c32adb1b74");
    }

    public function getTemplateName()
    {
        return "__string_template__abfbe166dca6eb822afccfbdda8a594ceb95d12b452e2d36b17400c32adb1b74";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  41 => 0,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("clients/{{ (_variables.slug ?? object.slug)|raw }}", "__string_template__abfbe166dca6eb822afccfbdda8a594ceb95d12b452e2d36b17400c32adb1b74", "");
    }
}
