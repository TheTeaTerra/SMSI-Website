<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* blog/_entry */
class __TwigTemplate_e1a1612c3d70b795535fdd46077596db04fdc2abea5f69a2493c5f719662cd7c extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "_layouts/basic";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("template", "blog/_entry");
        // line 5
        $context["featureImage"] = ["mode" => "crop", "width" => 900, "height" => 600, "quality" => 90];
        // line 1
        $this->parent = $this->loadTemplate("_layouts/basic", "blog/_entry", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        // line 0
        craft\helpers\Template::endProfile("template", "blog/_entry");
    }

    // line 13
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("block", "content");
        // line 14
        echo "  <h1 class=\"text-4xl text-black font-display my-4\">";
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 14, $this->source); })()), "title", []), "html", null, true);
        echo "</h1>
  <time class=\"text-sm block pb-4\" datetime=\"";
        // line 15
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->dateFilter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 15, $this->source); })()), "postDate", []), "Y-m-d"), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->dateFilter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 15, $this->source); })()), "postDate", []), "d M Y"), "html", null, true);
        echo "</time>

";
        // line 18
        echo "  ";
        if (twig_length_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 18, $this->source); })()), "featureImage", []))) {
            // line 19
            echo "    ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 19, $this->source); })()), "featureImage", []), "all", [], "method"));
            foreach ($context['_seq'] as $context["_key"] => $context["image"]) {
                // line 20
                echo "      <img src=\"";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["image"], "getUrl", [0 => (isset($context["featureImage"]) || array_key_exists("featureImage", $context) ? $context["featureImage"] : (function () { throw new RuntimeError('Variable "featureImage" does not exist.', 20, $this->source); })())], "method"), "html", null, true);
                echo "\" alt=\"";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["image"], "title", []), "html", null, true);
                echo "\" />
    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['image'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 22
            echo "  ";
        }
        // line 23
        echo "
";
        // line 25
        echo "  ";
        $this->loadTemplate("_includes/post-blocks", "blog/_entry", 25)->display(twig_to_array(["blocks" => craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 25, $this->source); })()), "postContent", []), "all", [], "method")]));
        // line 26
        echo "
";
        // line 28
        echo "  ";
        if (twig_length_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 28, $this->source); })()), "postCategories", []))) {
            // line 29
            echo "    <div class=\"border-t py-2 mb-6\">
        ";
            // line 30
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 30, $this->source); })()), "postCategories", []), "all", [], "method"));
            foreach ($context['_seq'] as $context["_key"] => $context["category"]) {
                // line 31
                echo "            <a href=\"";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["category"], "url", []), "html", null, true);
                echo "\" class=\"inline-block border rounded px-2 py-1 text-sm\">";
                // line 32
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["category"], "title", []), "html", null, true);
                // line 33
                echo "</a>
        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['category'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 35
            echo "    </div>
  ";
        }
        // line 37
        echo "
";
        // line 0
        craft\helpers\Template::endProfile("block", "content");
    }

    public function getTemplateName()
    {
        return "blog/_entry";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  132 => 0,  129 => 37,  125 => 35,  118 => 33,  116 => 32,  112 => 31,  108 => 30,  105 => 29,  102 => 28,  99 => 26,  96 => 25,  93 => 23,  90 => 22,  79 => 20,  74 => 19,  71 => 18,  64 => 15,  59 => 14,  57 => 0,  53 => 13,  49 => 0,  46 => 1,  44 => 5,  42 => 0,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends \"_layouts/basic\" %}

{# create settings for image transform #}
{% 
    set featureImage = {
        mode: 'crop',
        width: 900,
        height :600,
        quality : 90
    }
 %}

{% block content %}
  <h1 class=\"text-4xl text-black font-display my-4\">{{ entry.title }}</h1>
  <time class=\"text-sm block pb-4\" datetime=\"{{ entry.postDate | date('Y-m-d') }}\">{{ entry.postDate | date('d M Y') }}</time>

{# output transformed feature image #}
  {% if entry.featureImage|length %}
    {% for image in entry.featureImage.all() %}
      <img src=\"{{ image.getUrl(featureImage) }}\" alt=\"{{ image.title }}\" />
    {% endfor %}
  {% endif %}

{# render matrix block for the Post content field passed as \"Blocks\" #}
  {% include \"_includes/post-blocks\" with { blocks: entry.postContent.all() } only %}

{# display post categories #}
  {% if entry.postCategories|length %}
    <div class=\"border-t py-2 mb-6\">
        {% for category in entry.postCategories.all() %}
            <a href=\"{{ category.url }}\" class=\"inline-block border rounded px-2 py-1 text-sm\">
                {{- category.title  -}}
            </a>
        {% endfor %}
    </div>
  {% endif %}

{% endblock %}", "blog/_entry", "/Applications/MAMP/htdocs/craft/smsi/templates/blog/_entry.twig");
    }
}
