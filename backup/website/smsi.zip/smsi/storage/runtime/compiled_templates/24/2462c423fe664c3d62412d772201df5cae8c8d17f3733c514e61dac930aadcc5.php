<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* settings/globals/_edit */
class __TwigTemplate_ba64458ab2dca50dcdf5d89e3281483bc2e3bad73df1a98c6820b5b9b7314bcd extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "_layouts/cp";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("template", "settings/globals/_edit");
        // line 2
        $context["fullPageForm"] = true;
        // line 4
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms", "settings/globals/_edit", 4)->unwrap();
        // line 50
        if ( !craft\helpers\Template::attribute($this->env, $this->source, (isset($context["globalSet"]) || array_key_exists("globalSet", $context) ? $context["globalSet"] : (function () { throw new RuntimeError('Variable "globalSet" does not exist.', 50, $this->source); })()), "handle", [])) {
            // line 51
            ob_start();
            // line 52
            echo "        new Craft.HandleGenerator('#name', '#handle');
    ";
            Craft::$app->getView()->registerJs(ob_get_clean(), 3);
        }
        // line 1
        $this->parent = $this->loadTemplate("_layouts/cp", "settings/globals/_edit", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        // line 0
        craft\helpers\Template::endProfile("template", "settings/globals/_edit");
    }

    // line 7
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("block", "content");
        // line 8
        echo "    ";
        echo craft\helpers\Html::actionInput("globals/save-set");
        echo "
    ";
        // line 9
        echo craft\helpers\Html::redirectInput("settings/globals");
        echo "

    ";
        // line 11
        if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["globalSet"]) || array_key_exists("globalSet", $context) ? $context["globalSet"] : (function () { throw new RuntimeError('Variable "globalSet" does not exist.', 11, $this->source); })()), "id", [])) {
            echo craft\helpers\Html::hiddenInput("setId", craft\helpers\Template::attribute($this->env, $this->source, (isset($context["globalSet"]) || array_key_exists("globalSet", $context) ? $context["globalSet"] : (function () { throw new RuntimeError('Variable "globalSet" does not exist.', 11, $this->source); })()), "id", []));
        }
        // line 12
        echo "
    <div id=\"set-settings\">
        ";
        // line 14
        echo twig_call_macro($macros["forms"], "macro_textField", [["first" => true, "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Name", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("What this global set will be called in the control panel.", "app"), "id" => "name", "name" => "name", "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 20
(isset($context["globalSet"]) || array_key_exists("globalSet", $context) ? $context["globalSet"] : (function () { throw new RuntimeError('Variable "globalSet" does not exist.', 20, $this->source); })()), "name", []), "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 21
(isset($context["globalSet"]) || array_key_exists("globalSet", $context) ? $context["globalSet"] : (function () { throw new RuntimeError('Variable "globalSet" does not exist.', 21, $this->source); })()), "getErrors", [0 => "name"], "method"), "autofocus" => true, "required" => true]], 14, $context, $this->getSourceContext());
        // line 24
        echo "

        ";
        // line 26
        echo twig_call_macro($macros["forms"], "macro_textField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Handle", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("How you’ll refer to this global set in the templates.", "app"), "id" => "handle", "name" => "handle", "class" => "code", "autocorrect" => false, "autocapitalize" => false, "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 34
(isset($context["globalSet"]) || array_key_exists("globalSet", $context) ? $context["globalSet"] : (function () { throw new RuntimeError('Variable "globalSet" does not exist.', 34, $this->source); })()), "handle", []), "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 35
(isset($context["globalSet"]) || array_key_exists("globalSet", $context) ? $context["globalSet"] : (function () { throw new RuntimeError('Variable "globalSet" does not exist.', 35, $this->source); })()), "getErrors", [0 => "handle"], "method"), "required" => true]], 26, $context, $this->getSourceContext());
        // line 37
        echo "

    </div>

    <div id=\"set-fieldlayout\" class=\"hidden\">
        ";
        // line 42
        $this->loadTemplate("_includes/fieldlayoutdesigner", "settings/globals/_edit", 42)->display(twig_to_array(["fieldLayout" => craft\helpers\Template::attribute($this->env, $this->source,         // line 43
(isset($context["globalSet"]) || array_key_exists("globalSet", $context) ? $context["globalSet"] : (function () { throw new RuntimeError('Variable "globalSet" does not exist.', 43, $this->source); })()), "getFieldLayout", [], "method"), "tab" => "fieldlayout"]));
        // line 46
        echo "    </div>
";
        // line 0
        craft\helpers\Template::endProfile("block", "content");
    }

    public function getTemplateName()
    {
        return "settings/globals/_edit";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  113 => 0,  110 => 46,  108 => 43,  107 => 42,  100 => 37,  98 => 35,  97 => 34,  96 => 26,  92 => 24,  90 => 21,  89 => 20,  88 => 14,  84 => 12,  80 => 11,  75 => 9,  70 => 8,  68 => 0,  64 => 7,  60 => 0,  57 => 1,  52 => 52,  50 => 51,  48 => 50,  46 => 4,  44 => 2,  42 => 0,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends \"_layouts/cp\" %}
{% set fullPageForm = true %}

{% import \"_includes/forms\" as forms %}


{% block content %}
    {{ actionInput('globals/save-set') }}
    {{ redirectInput('settings/globals') }}

    {% if globalSet.id %}{{ hiddenInput('setId', globalSet.id) }}{% endif %}

    <div id=\"set-settings\">
        {{ forms.textField({
            first: true,
            label: \"Name\"|t('app'),
            instructions: \"What this global set will be called in the control panel.\"|t('app'),
            id: 'name',
            name: 'name',
            value: globalSet.name,
            errors: globalSet.getErrors('name'),
            autofocus: true,
            required: true,
        }) }}

        {{ forms.textField({
            label: \"Handle\"|t('app'),
            instructions: \"How you’ll refer to this global set in the templates.\"|t('app'),
            id: 'handle',
            name: 'handle',
            class: 'code',
            autocorrect: false,
            autocapitalize: false,
            value: globalSet.handle,
            errors: globalSet.getErrors('handle'),
            required: true
        }) }}

    </div>

    <div id=\"set-fieldlayout\" class=\"hidden\">
        {% include \"_includes/fieldlayoutdesigner\" with {
            fieldLayout: globalSet.getFieldLayout(),
            tab: 'fieldlayout'
        } only %}
    </div>
{% endblock %}


{% if not globalSet.handle %}
    {% js %}
        new Craft.HandleGenerator('#name', '#handle');
    {% endjs %}
{% endif %}
", "settings/globals/_edit", "/Applications/MAMP/htdocs/craft/smsi/vendor/craftcms/cms/src/templates/settings/globals/_edit.html");
    }
}
