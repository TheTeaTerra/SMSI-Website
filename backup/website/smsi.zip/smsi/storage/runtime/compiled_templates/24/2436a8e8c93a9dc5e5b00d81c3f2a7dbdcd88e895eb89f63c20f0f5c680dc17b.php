<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _singles/contact */
class __TwigTemplate_dcba15787e8bde884a832498cb58e84759daf37db5adf414b7b97cfdab8e85d8 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_singles/contact");
        // line 1
        echo "<section id=\"contact\" class=\"contact\">
";
        // line 2
        $context["contacts"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 2, $this->source); })()), "entries", []), "section", [0 => "contact"], "method"), "all", [], "method");
        // line 3
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["contacts"]) || array_key_exists("contacts", $context) ? $context["contacts"] : (function () { throw new RuntimeError('Variable "contacts" does not exist.', 3, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["contact"]) {
            // line 4
            $context["contactBlock"] = craft\helpers\Template::attribute($this->env, $this->source, $context["contact"], "contactBody", []);
            // line 5
            echo "    ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["contactBlock"]) || array_key_exists("contactBlock", $context) ? $context["contactBlock"] : (function () { throw new RuntimeError('Variable "contactBlock" does not exist.', 5, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["block"]) {
                // line 6
                echo "        ";
                if ((craft\helpers\Template::attribute($this->env, $this->source, $context["block"], "type", []) == "contactPoint")) {
                    // line 7
                    echo "            <div class=\"container\">
                <div class=\"section-title\">
                    <h2>Contact</h2>
                    <p>";
                    // line 10
                    echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["block"], "text", []), "html", null, true);
                    echo " </p>
                </div>
            </div>
            <div>
                ";
                    // line 14
                    echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["block"], "maps", []), "html", null, true);
                    echo "
            </div>
        ";
                }
                // line 17
                echo "    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['block'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['contact'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 19
        echo "

    <div class=\"container\">
        <div class=\"row mt-5\">
            <div class=\"col-lg-4\">
                <div class=\"info\">
                    <div class=\"address\">
                        <i class=\"ri-map-pin-line\"></i>
                        <h4>Location:</h4>
                        <p>";
        // line 28
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["siteInfo"]) || array_key_exists("siteInfo", $context) ? $context["siteInfo"] : (function () { throw new RuntimeError('Variable "siteInfo" does not exist.', 28, $this->source); })()), "address", []), "html", null, true);
        echo "</p>
                    </div>

                    <div class=\"email\">
                        <i class=\"ri-mail-line\"></i>
                        <h4>Email:</h4>
                        <p>";
        // line 34
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["siteInfo"]) || array_key_exists("siteInfo", $context) ? $context["siteInfo"] : (function () { throw new RuntimeError('Variable "siteInfo" does not exist.', 34, $this->source); })()), "email", []), "html", null, true);
        echo "</p>
                    </div>
                    ";
        // line 36
        $context["contactOff"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["siteInfo"]) || array_key_exists("siteInfo", $context) ? $context["siteInfo"] : (function () { throw new RuntimeError('Variable "siteInfo" does not exist.', 36, $this->source); })()), "contactOffice", []);
        // line 37
        echo "                    <div class=\"phone\">
                        <i class=\"ri-phone-line\"></i>
                        <h4>Call:</h4>
                        ";
        // line 40
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["contactOff"]) || array_key_exists("contactOff", $context) ? $context["contactOff"] : (function () { throw new RuntimeError('Variable "contactOff" does not exist.', 40, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["block"]) {
            // line 41
            echo "                            <p>021-";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["block"], "telp", []), "html", null, true);
            echo " </p>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['block'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 43
        echo "                    </div>
                </div>
            </div>

            <div class=\"col-lg-8 mt-5 mt-lg-0\">
                <form action=\"forms/contact.php\" method=\"post\" role=\"form\" class=\"php-email-form\">
                ";
        // line 49
        echo craft\helpers\Html::csrfInput();
        echo "
                ";
        // line 50
        echo craft\helpers\Html::actionInput("entries/save-entry");
        echo "
                ";
        // line 51
        echo craft\helpers\Html::redirectInput("viewentry/{slug}");
        echo "
                ";
        // line 52
        echo craft\helpers\Html::hiddenInput("sectionId", "2");
        echo "
                ";
        // line 53
        echo craft\helpers\Html::hiddenInput("enabled", "1");
        echo "
                    <div class=\"form-row\">
                        <div class=\"col-md-6 form-group\">
                            <input type=\"text\" name=\"name\" class=\"form-control\" id=\"name\" placeholder=\"Your Name\"
                                data-rule=\"minlen:4\" data-msg=\"Please enter at least 4 chars\" />
                            <div class=\"validate\"></div>
                        </div>
                        <div class=\"col-md-6 form-group\">
                            <input type=\"email\" class=\"form-control\" name=\"email\" id=\"email\" placeholder=\"Your Email\"
                                data-rule=\"email\" data-msg=\"Please enter a valid email\" />
                            <div class=\"validate\"></div>
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <input type=\"text\" class=\"form-control\" name=\"subject\" id=\"subject\" placeholder=\"Subject\"
                            data-rule=\"minlen:4\" data-msg=\"Please enter at least 8 chars of subject\" />
                        <div class=\"validate\"></div>
                    </div>
                    <div class=\"form-group\">
                        <textarea class=\"form-control\" name=\"message\" rows=\"5\" data-rule=\"required\"
                            data-msg=\"Please write something for us\" placeholder=\"Message\"></textarea>
                        <div class=\"validate\"></div>
                    </div>
                    <div class=\"mb-3\">
                        <div class=\"loading\">Loading</div>
                        <div class=\"error-message\"></div>
                        <div class=\"sent-message\">Your message has been sent. Thank you!</div>
                    </div>
                    <div class=\"text-center\"><button type=\"submit\">Send Message</button></div>
                </form>
            </div>
        </div>
    </div>
</section>


";
        // line 0
        craft\helpers\Template::endProfile("template", "_singles/contact");
    }

    public function getTemplateName()
    {
        return "_singles/contact";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  193 => 0,  154 => 53,  150 => 52,  146 => 51,  142 => 50,  138 => 49,  130 => 43,  121 => 41,  117 => 40,  112 => 37,  110 => 36,  105 => 34,  96 => 28,  85 => 19,  75 => 17,  69 => 14,  62 => 10,  57 => 7,  54 => 6,  49 => 5,  47 => 4,  43 => 3,  41 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<section id=\"contact\" class=\"contact\">
{% set contacts = craft.entries.section('contact').all() %}
{% for contact in contacts %}
{% set contactBlock = contact.contactBody %}
    {% for block in contactBlock %}
        {% if block.type == 'contactPoint' %}
            <div class=\"container\">
                <div class=\"section-title\">
                    <h2>Contact</h2>
                    <p>{{ block.text }} </p>
                </div>
            </div>
            <div>
                {{ block.maps }}
            </div>
        {% endif %}
    {% endfor %}
{% endfor %}


    <div class=\"container\">
        <div class=\"row mt-5\">
            <div class=\"col-lg-4\">
                <div class=\"info\">
                    <div class=\"address\">
                        <i class=\"ri-map-pin-line\"></i>
                        <h4>Location:</h4>
                        <p>{{ siteInfo.address }}</p>
                    </div>

                    <div class=\"email\">
                        <i class=\"ri-mail-line\"></i>
                        <h4>Email:</h4>
                        <p>{{ siteInfo.email }}</p>
                    </div>
                    {% set contactOff = siteInfo.contactOffice %}
                    <div class=\"phone\">
                        <i class=\"ri-phone-line\"></i>
                        <h4>Call:</h4>
                        {% for block in contactOff %}
                            <p>021-{{ block.telp }} </p>
                        {% endfor %}
                    </div>
                </div>
            </div>

            <div class=\"col-lg-8 mt-5 mt-lg-0\">
                <form action=\"forms/contact.php\" method=\"post\" role=\"form\" class=\"php-email-form\">
                {{ csrfInput() }}
                {{ actionInput('entries/save-entry') }}
                {{ redirectInput('viewentry/{slug}') }}
                {{ hiddenInput('sectionId', '2') }}
                {{ hiddenInput('enabled', '1') }}
                    <div class=\"form-row\">
                        <div class=\"col-md-6 form-group\">
                            <input type=\"text\" name=\"name\" class=\"form-control\" id=\"name\" placeholder=\"Your Name\"
                                data-rule=\"minlen:4\" data-msg=\"Please enter at least 4 chars\" />
                            <div class=\"validate\"></div>
                        </div>
                        <div class=\"col-md-6 form-group\">
                            <input type=\"email\" class=\"form-control\" name=\"email\" id=\"email\" placeholder=\"Your Email\"
                                data-rule=\"email\" data-msg=\"Please enter a valid email\" />
                            <div class=\"validate\"></div>
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <input type=\"text\" class=\"form-control\" name=\"subject\" id=\"subject\" placeholder=\"Subject\"
                            data-rule=\"minlen:4\" data-msg=\"Please enter at least 8 chars of subject\" />
                        <div class=\"validate\"></div>
                    </div>
                    <div class=\"form-group\">
                        <textarea class=\"form-control\" name=\"message\" rows=\"5\" data-rule=\"required\"
                            data-msg=\"Please write something for us\" placeholder=\"Message\"></textarea>
                        <div class=\"validate\"></div>
                    </div>
                    <div class=\"mb-3\">
                        <div class=\"loading\">Loading</div>
                        <div class=\"error-message\"></div>
                        <div class=\"sent-message\">Your message has been sent. Thank you!</div>
                    </div>
                    <div class=\"text-center\"><button type=\"submit\">Send Message</button></div>
                </form>
            </div>
        </div>
    </div>
</section>


", "_singles/contact", "/Applications/MAMP/htdocs/craft/smsi/templates/_singles/contact.twig");
    }
}
