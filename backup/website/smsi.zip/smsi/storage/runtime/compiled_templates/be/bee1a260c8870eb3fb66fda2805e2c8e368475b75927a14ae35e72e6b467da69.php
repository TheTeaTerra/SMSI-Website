<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _singles/home */
class __TwigTemplate_5cb15626fdc406dd163fbf0a6c4297ae5d8272d192e60486c6a3b8b4227f506a extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "_layouts/app";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("template", "_singles/home");
        // line 1
        $this->parent = $this->loadTemplate("_layouts/app", "_singles/home", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        // line 0
        craft\helpers\Template::endProfile("template", "_singles/home");
    }

    // line 3
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("block", "content");
        // line 4
        echo "
    <!-- ======= About Us Section ======= -->
    ";
        // line 6
        $this->loadTemplate("_singles/about", "_singles/home", 6)->display($context);
        // line 7
        echo "    <!-- End About Us Section -->

    <!-- ======= Services Section ======= -->
    <section id=\"services\" class=\"services section-bg-gray\">
      <div class=\"container\" data-aos=\"fade-up\">

        <div class=\"section-title\">
          <h2>Services</h2>
          ";
        // line 15
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 15, $this->source); })()), "serviceText", []), "html", null, true);
        echo "
        </div>

        <div class=\"row\">
        ";
        // line 19
        $context["services"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 19, $this->source); })()), "entries", []), "section", [0 => "services"], "method"), "all", [], "method");
        // line 20
        echo "        ";
        $context["count"] = 0;
        // line 21
        echo "        ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["services"]) || array_key_exists("services", $context) ? $context["services"] : (function () { throw new RuntimeError('Variable "services" does not exist.', 21, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["service"]) {
            // line 22
            echo "          ";
            $context["serviceBody"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, $context["service"], "serviceBody", []), "all", [], "method");
            // line 23
            echo "          ";
            if (twig_length_filter($this->env, (isset($context["serviceBody"]) || array_key_exists("serviceBody", $context) ? $context["serviceBody"] : (function () { throw new RuntimeError('Variable "serviceBody" does not exist.', 23, $this->source); })()))) {
                // line 24
                echo "            ";
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable((isset($context["serviceBody"]) || array_key_exists("serviceBody", $context) ? $context["serviceBody"] : (function () { throw new RuntimeError('Variable "serviceBody" does not exist.', 24, $this->source); })()));
                foreach ($context['_seq'] as $context["_key"] => $context["block"]) {
                    // line 25
                    echo "              ";
                    $context["count"] = ((isset($context["count"]) || array_key_exists("count", $context) ? $context["count"] : (function () { throw new RuntimeError('Variable "count" does not exist.', 25, $this->source); })()) + 1);
                    // line 26
                    echo "              ";
                    if ((craft\helpers\Template::attribute($this->env, $this->source, $context["block"], "type", []) == "servicePoint")) {
                        // line 27
                        echo "                <div class=\"col-lg-6 col-md-6 d-flex align-items-stretch
                  ";
                        // line 28
                        if (((isset($context["count"]) || array_key_exists("count", $context) ? $context["count"] : (function () { throw new RuntimeError('Variable "count" does not exist.', 28, $this->source); })()) == 1)) {
                            // line 29
                            echo "                  ";
                        } elseif (((isset($context["count"]) || array_key_exists("count", $context) ? $context["count"] : (function () { throw new RuntimeError('Variable "count" does not exist.', 29, $this->source); })()) == 2)) {
                            // line 30
                            echo "                    mt-4 mt-lg-0
                  ";
                        } else {
                            // line 32
                            echo "                    mt-4
                  ";
                        }
                        // line 34
                        echo "                \" data-aos=\"zoom-in\" data-aos-delay=\"";
                        echo twig_escape_filter($this->env, (isset($context["count"]) || array_key_exists("count", $context) ? $context["count"] : (function () { throw new RuntimeError('Variable "count" does not exist.', 34, $this->source); })()), "html", null, true);
                        echo "00\">
                  
                  <div class=\"icon-box\">
                    ";
                        // line 38
                        echo "                    <div class=\"image-box\">
                      <img src=\"";
                        // line 39
                        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, $context["block"], "image", []), "one", []), "url", []), "html", null, true);
                        echo "\" alt=\"";
                        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, $context["block"], "image", []), "title", []), "html", null, true);
                        echo "\"/>
                    </div>
                    <h4><a href=\"\">";
                        // line 41
                        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["service"], "title", []), "html", null, true);
                        echo "</a></h4>
                    <p>";
                        // line 42
                        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["block"], "description", []), "html", null, true);
                        echo " </p>
                  </div>
                </div>
              ";
                    }
                    // line 46
                    echo "            ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['block'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 47
                echo "          ";
            }
            // line 48
            echo "        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['service'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 49
        echo "        </div>

      </div>
    </section>
    <!-- End Services Section -->

    <!-- ======= Cta Section ======= -->
    ";
        // line 56
        $context["actions"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 56, $this->source); })()), "actionText", []);
        // line 57
        echo "    ";
        if (twig_length_filter($this->env, (isset($context["actions"]) || array_key_exists("actions", $context) ? $context["actions"] : (function () { throw new RuntimeError('Variable "actions" does not exist.', 57, $this->source); })()))) {
            // line 58
            echo "      ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["actions"]) || array_key_exists("actions", $context) ? $context["actions"] : (function () { throw new RuntimeError('Variable "actions" does not exist.', 58, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["action"]) {
                // line 59
                echo "        ";
                if ((craft\helpers\Template::attribute($this->env, $this->source, $context["action"], "type", []) == "actionPoint")) {
                    // line 60
                    echo "          <section id=\"cta\" class=\"cta\" 
            style=\"
              background: linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)), url(";
                    // line 62
                    echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, $context["action"], "image", []), "one", []), "url", [], "method"), "html", null, true);
                    echo ") fixed center center;
              background-size: cover;
            \">
            <div class=\"container\" data-aos=\"zoom-in\">

              <div class=\"row\">
                <div class=\"col-lg-9 text-center text-lg-left\">
                  <h3>";
                    // line 69
                    echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["action"], "heading", []), "html", null, true);
                    echo "</h3>
                  <p> ";
                    // line 70
                    echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["action"], "text", []), "html", null, true);
                    echo " </p>
                </div>
                <div class=\"col-lg-3 cta-btn-container text-center\">
                  <a class=\"cta-btn align-middle\" href=\"#\">";
                    // line 73
                    echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["action"], "heading", []), "html", null, true);
                    echo "</a>
                </div>
              </div>

            </div>
          </section
        ";
                }
                // line 80
                echo "      ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['action'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 81
            echo "    ";
        }
        // line 82
        echo "    ><!-- End Cta Section -->

    <!-- ======= Features Section ======= -->
    ";
        // line 116
        echo "    <!-- End Features Section -->

    <!-- ======= Clients Section ======= -->
    <section id=\"clients\" class=\"clients\">
      <div class=\"container\" data-aos=\"fade-up\">
        <div class=\"section-title\">
          <h2>Our Clients</h2>
          <p> ";
        // line 123
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 123, $this->source); })()), "portfolioText", []), "html", null, true);
        echo " </p>
        </div>

        <div id=\"clientCarousel\" class=\"carousel slide\" data-ride=\"carousel\">
          <div class=\"carousel-inner\">
            ";
        // line 128
        $context["clients"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 128, $this->source); })()), "entries", []), "section", [0 => "clients"], "method");
        // line 129
        echo "            ";
        $context["count"] = 0;
        // line 130
        echo "            ";
        if (twig_length_filter($this->env, (isset($context["clients"]) || array_key_exists("clients", $context) ? $context["clients"] : (function () { throw new RuntimeError('Variable "clients" does not exist.', 130, $this->source); })()))) {
            // line 131
            echo "              ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["clients"]) || array_key_exists("clients", $context) ? $context["clients"] : (function () { throw new RuntimeError('Variable "clients" does not exist.', 131, $this->source); })()));
            $context['loop'] = [
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            ];
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["client"]) {
                // line 132
                echo "                ";
                $context["count"] = ((isset($context["count"]) || array_key_exists("count", $context) ? $context["count"] : (function () { throw new RuntimeError('Variable "count" does not exist.', 132, $this->source); })()) + 1);
                // line 133
                echo "                ";
                if (((isset($context["count"]) || array_key_exists("count", $context) ? $context["count"] : (function () { throw new RuntimeError('Variable "count" does not exist.', 133, $this->source); })()) == 1)) {
                    // line 134
                    echo "                <div class=\"carousel-item ";
                    echo (((craft\helpers\Template::attribute($this->env, $this->source, $context["loop"], "index", []) == 1)) ? ("active") : (""));
                    echo "\">
                  <div class=\"row no-gutters clients-wrap clearfix wow fadeInUp\">
                ";
                }
                // line 137
                echo "                
                ";
                // line 138
                $context["blocks"] = craft\helpers\Template::attribute($this->env, $this->source, $context["client"], "clientBody", []);
                // line 139
                echo "                ";
                if (twig_length_filter($this->env, (isset($context["blocks"]) || array_key_exists("blocks", $context) ? $context["blocks"] : (function () { throw new RuntimeError('Variable "blocks" does not exist.', 139, $this->source); })()))) {
                    // line 140
                    echo "                  ";
                    $context['_parent'] = $context;
                    $context['_seq'] = twig_ensure_traversable((isset($context["blocks"]) || array_key_exists("blocks", $context) ? $context["blocks"] : (function () { throw new RuntimeError('Variable "blocks" does not exist.', 140, $this->source); })()));
                    foreach ($context['_seq'] as $context["_key"] => $context["block"]) {
                        // line 141
                        echo "                    ";
                        if ((craft\helpers\Template::attribute($this->env, $this->source, $context["block"], "type", []) == "clientPoint")) {
                            // line 142
                            echo "                      <div class=\"col-lg-3 col-md-4 col-xs-6\">
                        <div class=\"client-logo\">
                          <img src=\"";
                            // line 144
                            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, $context["block"], "image", []), "one", []), "url", [], "method"), "html", null, true);
                            echo "\" class=\"img-fluid\" alt=\"\">
                        </div>
                      </div>
                    ";
                        }
                        // line 148
                        echo "                  ";
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['_iterated'], $context['_key'], $context['block'], $context['_parent'], $context['loop']);
                    $context = array_intersect_key($context, $_parent) + $_parent;
                    // line 149
                    echo "                ";
                }
                // line 150
                echo "                ";
                if (((isset($context["count"]) || array_key_exists("count", $context) ? $context["count"] : (function () { throw new RuntimeError('Variable "count" does not exist.', 150, $this->source); })()) == 8)) {
                    // line 151
                    echo "                    </div>
                  </div>
                  ";
                    // line 153
                    $context["count"] = 0;
                    // line 154
                    echo "                ";
                }
                // line 155
                echo "                
              ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['length'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['client'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 157
            echo "            ";
        }
        // line 158
        echo "          </div>
          <a class=\"carousel-control-prev\" href=\"#clientCarousel\" role=\"button\" data-slide=\"prev\">
            <span class=\"carousel-control-prev-icon\" aria-hidden=\"true\"></span>
            <span class=\"sr-only\">Previous</span>
          </a>
          <a class=\"carousel-control-next\" href=\"#clientCarousel\" role=\"button\" data-slide=\"next\">
            <span class=\"carousel-control-next-icon\" aria-hidden=\"true\"></span>
            <span class=\"sr-only\">Next</span>
          </a>

          <ol class=\"carousel-indicators\" id=\"client-carousel-indicators\"></ol>
        </div>
      </div>
    </section>
    <!-- End Clients Section -->



    <!-- ======= Counts Section ======= -->
    <section id=\"counts\" class=\"counts\" data-aos=\"fade-up\">
      <div class=\"container\">

        <div class=\"text-center title\">
          <h3>What we have achieved so far</h3>
          <p>Iusto et labore modi qui sapiente xpedita tempora et aut non ipsum consequatur illo.</p>
        </div>

        <div class=\"row counters\">

          <div class=\"col-lg-3 col-6 text-center\">
            <span data-toggle=\"counter-up\">232</span>
            <p>Clients</p>
          </div>

          <div class=\"col-lg-3 col-6 text-center\">
            <span data-toggle=\"counter-up\">521</span>
            <p>Projects</p>
          </div>

          <div class=\"col-lg-3 col-6 text-center\">
            <span data-toggle=\"counter-up\">1,463</span>
            <p>Hours Of Support</p>
          </div>

          <div class=\"col-lg-3 col-6 text-center\">
            <span data-toggle=\"counter-up\">15</span>
            <p>Hard Workers</p>
          </div>

        </div>

      </div>
    </section>
    <!-- End Counts Section -->

    <!-- ======= Portfolio Section ======= -->
    <section id=\"portfolio\" class=\"portfolio section-bg-gray\">
      <div class=\"container\" data-aos=\"fade-up\">
        <div class=\"section-title\">
          <h2>Portfolio</h2>
          <p> ";
        // line 218
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 218, $this->source); })()), "portfolioText", []), "html", null, true);
        echo " </p>
        </div>
        
        ";
        // line 221
        $context["portCategories"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 221, $this->source); })()), "categories", [], "method"), "group", [0 => "portfolioCategories"], "method");
        // line 222
        echo "        <div class=\"row\">
          <div class=\"col-lg-12 d-flex justify-content-center\">
            <ul id=\"portfolio-flters\">
              <li data-filter=\"*\" class=\"filter-active\">All</li>
              ";
        // line 226
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["portCategories"]) || array_key_exists("portCategories", $context) ? $context["portCategories"] : (function () { throw new RuntimeError('Variable "portCategories" does not exist.', 226, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["portCategory"]) {
            // line 227
            echo "                <li data-filter=\".filter-";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["portCategory"], "slug", []), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["portCategory"], "title", []), "html", null, true);
            echo "</li>
              ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['portCategory'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 229
        echo "            </ul>
          </div>
        </div>


        ";
        // line 251
        echo "
        <div class=\"row portfolio-container\">
          ";
        // line 253
        $context["portfolios"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 253, $this->source); })()), "entries", []), "section", [0 => "portfolio"], "method");
        // line 254
        echo "          ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["portfolios"]) || array_key_exists("portfolios", $context) ? $context["portfolios"] : (function () { throw new RuntimeError('Variable "portfolios" does not exist.', 254, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["portfolio"]) {
            // line 255
            echo "            ";
            $context["portfolioBlock"] = craft\helpers\Template::attribute($this->env, $this->source, $context["portfolio"], "portfolioBody", []);
            // line 256
            echo "            ";
            $context["i"] = 0;
            // line 257
            echo "            ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["portfolioBlock"]) || array_key_exists("portfolioBlock", $context) ? $context["portfolioBlock"] : (function () { throw new RuntimeError('Variable "portfolioBlock" does not exist.', 257, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["block"]) {
                // line 258
                echo "                
                ";
                // line 259
                if ((craft\helpers\Template::attribute($this->env, $this->source, $context["block"], "type", []) == "portfolioPoint")) {
                    // line 260
                    echo "                  ";
                    $context["relatedCats"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 260, $this->source); })()), "categories", []), "relatedTo", [0 => $context["portfolio"]], "method");
                    // line 261
                    echo "                  <div class=\"col-lg-4 col-md-6 portfolio-item
                    ";
                    // line 262
                    $context['_parent'] = $context;
                    $context['_seq'] = twig_ensure_traversable((isset($context["relatedCats"]) || array_key_exists("relatedCats", $context) ? $context["relatedCats"] : (function () { throw new RuntimeError('Variable "relatedCats" does not exist.', 262, $this->source); })()));
                    foreach ($context['_seq'] as $context["_key"] => $context["category"]) {
                        // line 263
                        echo "                        filter-";
                        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["category"], "slug", []), "html", null, true);
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['_iterated'], $context['_key'], $context['category'], $context['_parent'], $context['loop']);
                    $context = array_intersect_key($context, $_parent) + $_parent;
                    // line 265
                    echo "                  \">
                    <img src=\"";
                    // line 266
                    echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, $context["block"], "image", []), "one", []), "url", [], "method"), "html", null, true);
                    echo "\" class=\"img-fluid\" alt=\"\">
                    <div class=\"portfolio-info\">
                      <h4>";
                    // line 268
                    echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["block"], "heading", []), "html", null, true);
                    echo "</h4>
                      <p>";
                    // line 269
                    echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["block"], "text", []), "html", null, true);
                    echo "</p>
                      <a href=\"";
                    // line 270
                    echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, $context["block"], "image", []), "one", []), "url", [], "method"), "html", null, true);
                    echo "\" data-gall=\"portfolioGallery\" class=\"venobox preview-link\" title=\"App ";
                    echo twig_escape_filter($this->env, ((isset($context["i"]) || array_key_exists("i", $context) ? $context["i"] : (function () { throw new RuntimeError('Variable "i" does not exist.', 270, $this->source); })()) + 1), "html", null, true);
                    echo "\"><i class=\"bx bx-plus\"></i></a>
                      <a href=\"portfolio-details.html\" class=\"details-link\" title=\"More Details\"><i class=\"bx bx-link\"></i></a>
                    </div>
                  </div>
                ";
                }
                // line 275
                echo "            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['block'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 276
            echo "          ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['portfolio'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 277
        echo "        </div>
      </div>
    </section>
    <!-- End Portfolio Section -->

    <!-- ======= Testimonials Section ======= -->
    <section id=\"testimonials\" class=\"testimonials\">
      <div class=\"container\" data-aos=\"fade-up\">

        <div class=\"section-title\">
          <h2>Testimonials</h2>
          <p>";
        // line 288
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 288, $this->source); })()), "testimonialText", []), "html", null, true);
        echo "</p>
        </div>

        ";
        // line 291
        $context["testimonials"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 291, $this->source); })()), "entries", []), "section", [0 => "testimonials"], "method");
        // line 292
        echo "        <div class=\"owl-carousel testimonials-carousel\">
        ";
        // line 293
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["testimonials"]) || array_key_exists("testimonials", $context) ? $context["testimonials"] : (function () { throw new RuntimeError('Variable "testimonials" does not exist.', 293, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["testimonial"]) {
            // line 294
            echo "          <div class=\"testimonial-wrap\">
            <div class=\"testimonial-item\">
              ";
            // line 296
            $context["blocks"] = craft\helpers\Template::attribute($this->env, $this->source, $context["testimonial"], "testimonialBody", []);
            // line 297
            echo "              ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["blocks"]) || array_key_exists("blocks", $context) ? $context["blocks"] : (function () { throw new RuntimeError('Variable "blocks" does not exist.', 297, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["block"]) {
                // line 298
                echo "                <img src=\"";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, $context["block"], "image", []), "one", []), "url", []), "html", null, true);
                echo "\" class=\"testimonial-img\" alt=\"";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["block"], "title", []), "html", null, true);
                echo "\">
                <h3>";
                // line 299
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["testimonial"], "title", []), "html", null, true);
                echo "</h3>
                <h4>";
                // line 300
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["block"], "subheading", []), "html", null, true);
                echo "</h4>
                <p>
                  <i class=\"bx bxs-quote-alt-left quote-icon-left\"></i>
                    ";
                // line 303
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["block"], "text", []), "html", null, true);
                echo "
                  <i class=\"bx bxs-quote-alt-right quote-icon-right\"></i>
                </p>
              ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['block'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 307
            echo "            </div>
          </div>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['testimonial'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 310
        echo "        </div>
      </div>
    </section>
    <!-- End Testimonials Section -->


    <!-- ======= Pricing Section ======= -->
    <!--
    <section id=\"pricing\" class=\"pricing\">
      <div class=\"container\">

        <div class=\"section-title\">
          <h2>Pricing</h2>
          <p>Magnam dolores commodi suscipit. Necessitatibus eius consequatur ex aliquid fuga eum quidem. Sit sint consectetur velit. Quisquam quos quisquam cupiditate. Et nemo qui impedit suscipit alias ea. Quia fugiat sit in iste officiis commodi quidem hic quas.</p>
        </div>

        <div class=\"row\">

          <div class=\"col-lg-4 col-md-6\">
            <div class=\"box\">
              <h3>Free</h3>
              <h4><sup>\$</sup>0<span> / month</span></h4>
              <ul>
                <li>Aida dere</li>
                <li>Nec feugiat nisl</li>
                <li>Nulla at volutpat dola</li>
                <li class=\"na\">Pharetra massa</li>
                <li class=\"na\">Massa ultricies mi</li>
              </ul>
              <div class=\"btn-wrap\">
                <a href=\"#\" class=\"btn-buy\">Buy Now</a>
              </div>
            </div>
          </div>

          <div class=\"col-lg-4 col-md-6 mt-4 mt-md-0\">
            <div class=\"box recommended\">
              <span class=\"recommended-badge\">Recommended</span>
              <h3>Business</h3>
              <h4><sup>\$</sup>19<span> / month</span></h4>
              <ul>
                <li>Aida dere</li>
                <li>Nec feugiat nisl</li>
                <li>Nulla at volutpat dola</li>
                <li>Pharetra massa</li>
                <li class=\"na\">Massa ultricies mi</li>
              </ul>
              <div class=\"btn-wrap\">
                <a href=\"#\" class=\"btn-buy\">Buy Now</a>
              </div>
            </div>
          </div>

          <div class=\"col-lg-4 col-md-6 mt-4 mt-lg-0\">
            <div class=\"box\">
              <h3>Developer</h3>
              <h4><sup>\$</sup>29<span> / month</span></h4>
              <ul>
                <li>Aida dere</li>
                <li>Nec feugiat nisl</li>
                <li>Nulla at volutpat dola</li>
                <li>Pharetra massa</li>
                <li>Massa ultricies mi</li>
              </ul>
              <div class=\"btn-wrap\">
                <a href=\"#\" class=\"btn-buy\">Buy Now</a>
              </div>
            </div>
          </div>

        </div>

      </div>
    </section>
    -->
    <!-- End Pricing Section -->

    <!-- ======= Team Section ======= -->
    <section id=\"team\" class=\"team section-bg-gray\">
      <div class=\"container\" data-aos=\"fade-up\">
        <div class=\"section-title\">
          <h2>Our Team</h2>
          <p>";
        // line 392
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 392, $this->source); })()), "teamText", []), "html", null, true);
        echo "</p>
        </div>
        
        <div id=\"teamCarousel\" class=\"carousel slide\" data-ride=\"carousel\">
          <div class=\"carousel-inner\">
            ";
        // line 397
        $context["teams"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 397, $this->source); })()), "entries", []), "section", [0 => "teams"], "method");
        // line 398
        echo "            ";
        $context["count"] = 0;
        // line 399
        echo "            ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["teams"]) || array_key_exists("teams", $context) ? $context["teams"] : (function () { throw new RuntimeError('Variable "teams" does not exist.', 399, $this->source); })()));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["team"]) {
            // line 400
            echo "              ";
            $context["count"] = ((isset($context["count"]) || array_key_exists("count", $context) ? $context["count"] : (function () { throw new RuntimeError('Variable "count" does not exist.', 400, $this->source); })()) + 1);
            // line 401
            echo "              ";
            if (((isset($context["count"]) || array_key_exists("count", $context) ? $context["count"] : (function () { throw new RuntimeError('Variable "count" does not exist.', 401, $this->source); })()) == 1)) {
                // line 402
                echo "                <div class=\"carousel-item ";
                echo (((craft\helpers\Template::attribute($this->env, $this->source, $context["loop"], "index", []) == 1)) ? ("active") : (""));
                echo "\">
                  <div class=\"row\">
              ";
            }
            // line 405
            echo "                          
                  <div class=\"col-lg-6 ";
            // line 406
            if (((isset($context["count"]) || array_key_exists("count", $context) ? $context["count"] : (function () { throw new RuntimeError('Variable "count" does not exist.', 406, $this->source); })()) > 1)) {
                echo " mt-4 ";
                if (((isset($context["count"]) || array_key_exists("count", $context) ? $context["count"] : (function () { throw new RuntimeError('Variable "count" does not exist.', 406, $this->source); })()) == 2)) {
                    echo " mt-lg-0 ";
                }
            }
            echo "\" 
                    
                    ";
            // line 408
            if (((isset($context["count"]) || array_key_exists("count", $context) ? $context["count"] : (function () { throw new RuntimeError('Variable "count" does not exist.', 408, $this->source); })()) > 1)) {
                // line 409
                echo "                      data-wow-delay=\"0.";
                echo twig_escape_filter($this->env, (isset($context["count"]) || array_key_exists("count", $context) ? $context["count"] : (function () { throw new RuntimeError('Variable "count" does not exist.', 409, $this->source); })()), "html", null, true);
                echo "s\"
                    ";
            }
            // line 411
            echo "                  >
                    
                    <div class=\"member d-flex align-items-start\" data-aos=\"zoom-in\" data-aos-delay=\"";
            // line 413
            echo twig_escape_filter($this->env, (isset($context["count"]) || array_key_exists("count", $context) ? $context["count"] : (function () { throw new RuntimeError('Variable "count" does not exist.', 413, $this->source); })()), "html", null, true);
            echo "00\">
                    ";
            // line 414
            $context["blocks"] = craft\helpers\Template::attribute($this->env, $this->source, $context["team"], "teamBody", []);
            // line 415
            echo "                    ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["blocks"]) || array_key_exists("blocks", $context) ? $context["blocks"] : (function () { throw new RuntimeError('Variable "blocks" does not exist.', 415, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["block"]) {
                // line 416
                echo "                      ";
                if (twig_length_filter($this->env, $context["block"])) {
                    // line 417
                    echo "                      <div class=\"pic\"><img src=\"";
                    echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, $context["block"], "image", []), "one", []), "url", []), "html", null, true);
                    echo "\" class=\"img-fluid\" alt=\"\"></div>
                      <div class=\"member-info\">
                        <h4>";
                    // line 419
                    echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["team"], "title", []), "html", null, true);
                    echo "</h4>
                        <span>";
                    // line 420
                    echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["block"], "heading", []), "html", null, true);
                    echo "</span>
                        <p>";
                    // line 421
                    echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["block"], "text", []), "html", null, true);
                    echo "</p>
                        ";
                }
                // line 423
                echo "                      ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['block'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 424
            echo "                      ";
            $context["sosmedAccounts"] = craft\helpers\Template::attribute($this->env, $this->source, $context["team"], "socialMediaAccount", []);
            // line 425
            echo "                        <div class=\"social\">
                        ";
            // line 426
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["sosmedAccounts"]) || array_key_exists("sosmedAccounts", $context) ? $context["sosmedAccounts"] : (function () { throw new RuntimeError('Variable "sosmedAccounts" does not exist.', 426, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["sosmed"]) {
                // line 427
                echo "                          <a href=\" ";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["sosmed"], "twitter", []), "html", null, true);
                echo " \"><i class=\"ri-twitter-fill\"></i></a>
                          <a href=\" ";
                // line 428
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["sosmed"], "facebook", []), "html", null, true);
                echo " \"><i class=\"ri-facebook-fill\"></i></a>
                          <a href=\" ";
                // line 429
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["sosmed"], "instagram", []), "html", null, true);
                echo " \"><i class=\"ri-instagram-fill\"></i></a>
                          <a href=\" ";
                // line 430
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["sosmed"], "linkedin", []), "html", null, true);
                echo " \"> <i class=\"ri-linkedin-box-fill\"></i> </a>
                        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['sosmed'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 432
            echo "                        </div>
                      </div>
                    </div>
                  </div>
              ";
            // line 436
            if (((isset($context["count"]) || array_key_exists("count", $context) ? $context["count"] : (function () { throw new RuntimeError('Variable "count" does not exist.', 436, $this->source); })()) == 4)) {
                // line 437
                echo "                  </div>
                </div>
                ";
                // line 439
                $context["count"] = 0;
                echo "  
              ";
            }
            // line 441
            echo "            ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['team'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 442
        echo "          </div>
          <a class=\"carousel-control-prev\" href=\"#teamCarousel\" role=\"button\" data-slide=\"prev\">
            <span class=\"carousel-control-prev-icon\" aria-hidden=\"true\"></span>
            <span class=\"sr-only\">Previous</span>
          </a>
          <a class=\"carousel-control-next\" href=\"#teamCarousel\" role=\"button\" data-slide=\"next\">
            <span class=\"carousel-control-next-icon\" aria-hidden=\"true\"></span>
            <span class=\"sr-only\">Next</span>
          </a>
        </div>
        
      </div>
    </section>

    <!-- End Team Section -->

    <!-- ======= Faq Section ======= -->
    <section id=\"faq\" class=\"faq\">
      <div class=\"container-fluid\" data-aos=\"fade-up\">
        <div class=\"row\">
          <div class=\"col-lg-7 d-flex flex-column justify-content-center align-items-stretch  order-2 order-lg-1\">
            <div class=\"content\">
              <h3>Join With<strong> Us</strong></h3>
              <p>";
        // line 465
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 465, $this->source); })()), "joinText", []), "html", null, true);
        echo "</p>
            </div>

            <div class=\"accordion-list\">
              <ul>
                ";
        // line 470
        $context["cariers"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 470, $this->source); })()), "entries", []), "section", [0 => "cariers"], "method");
        // line 471
        echo "                ";
        $context["count"] = 0;
        // line 472
        echo "                ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["cariers"]) || array_key_exists("cariers", $context) ? $context["cariers"] : (function () { throw new RuntimeError('Variable "cariers" does not exist.', 472, $this->source); })()));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["carier"]) {
            // line 473
            echo "                ";
            $context["count"] = ((isset($context["count"]) || array_key_exists("count", $context) ? $context["count"] : (function () { throw new RuntimeError('Variable "count" does not exist.', 473, $this->source); })()) + 1);
            // line 474
            echo "                <li>
                  <a data-toggle=\"collapse\" class=\" ";
            // line 475
            echo (((craft\helpers\Template::attribute($this->env, $this->source, $context["loop"], "index", []) == 1)) ? ("collapse") : ("collapsed"));
            echo " \" href=\"#accordion-list-";
            echo twig_escape_filter($this->env, (isset($context["count"]) || array_key_exists("count", $context) ? $context["count"] : (function () { throw new RuntimeError('Variable "count" does not exist.', 475, $this->source); })()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["carier"], "title", []), "html", null, true);
            echo " <i class=\"bx bx-chevron-down icon-show\"></i><i class=\"bx bx-chevron-up icon-close\"></i></a>
                  <div id=\"accordion-list-";
            // line 476
            echo twig_escape_filter($this->env, (isset($context["count"]) || array_key_exists("count", $context) ? $context["count"] : (function () { throw new RuntimeError('Variable "count" does not exist.', 476, $this->source); })()), "html", null, true);
            echo "\" class=\"collapse ";
            echo (((craft\helpers\Template::attribute($this->env, $this->source, $context["loop"], "index", []) == 1)) ? ("show") : (""));
            echo " \" data-parent=\".accordion-list\">
                    <p>";
            // line 477
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["carier"], "jobsDescription", []), "html", null, true);
            echo "</p>
                    <p>";
            // line 478
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["carier"], "jobsRequirement", []), "html", null, true);
            echo " </p>
                  </div>
                </li>
                ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['carier'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 482
        echo "              </ul>
            </div>
          </div>

          <div class=\"col-lg-5 align-items-stretch order-1 order-lg-2 img\" style='background-image: url(\"assets/img/faq.jpg\");'>&nbsp;</div>
        </div>

      </div>
    </section>
    <!-- End Faq Section -->

    <!-- ======= Contact Section ======= -->
    ";
        // line 494
        $this->loadTemplate("_singles/contact", "_singles/home", 494)->display($context);
        // line 495
        echo "    <!-- End Contact Section -->
";
        // line 0
        craft\helpers\Template::endProfile("block", "content");
    }

    public function getTemplateName()
    {
        return "_singles/home";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  983 => 0,  980 => 495,  978 => 494,  964 => 482,  946 => 478,  942 => 477,  936 => 476,  928 => 475,  925 => 474,  922 => 473,  904 => 472,  901 => 471,  899 => 470,  891 => 465,  866 => 442,  852 => 441,  847 => 439,  843 => 437,  841 => 436,  835 => 432,  827 => 430,  823 => 429,  819 => 428,  814 => 427,  810 => 426,  807 => 425,  804 => 424,  798 => 423,  793 => 421,  789 => 420,  785 => 419,  779 => 417,  776 => 416,  771 => 415,  769 => 414,  765 => 413,  761 => 411,  755 => 409,  753 => 408,  743 => 406,  740 => 405,  733 => 402,  730 => 401,  727 => 400,  709 => 399,  706 => 398,  704 => 397,  696 => 392,  612 => 310,  604 => 307,  594 => 303,  588 => 300,  584 => 299,  577 => 298,  572 => 297,  570 => 296,  566 => 294,  562 => 293,  559 => 292,  557 => 291,  551 => 288,  538 => 277,  532 => 276,  526 => 275,  516 => 270,  512 => 269,  508 => 268,  503 => 266,  500 => 265,  493 => 263,  489 => 262,  486 => 261,  483 => 260,  481 => 259,  478 => 258,  473 => 257,  470 => 256,  467 => 255,  462 => 254,  460 => 253,  456 => 251,  449 => 229,  438 => 227,  434 => 226,  428 => 222,  426 => 221,  420 => 218,  358 => 158,  355 => 157,  340 => 155,  337 => 154,  335 => 153,  331 => 151,  328 => 150,  325 => 149,  319 => 148,  312 => 144,  308 => 142,  305 => 141,  300 => 140,  297 => 139,  295 => 138,  292 => 137,  285 => 134,  282 => 133,  279 => 132,  261 => 131,  258 => 130,  255 => 129,  253 => 128,  245 => 123,  236 => 116,  231 => 82,  228 => 81,  222 => 80,  212 => 73,  206 => 70,  202 => 69,  192 => 62,  188 => 60,  185 => 59,  180 => 58,  177 => 57,  175 => 56,  166 => 49,  160 => 48,  157 => 47,  151 => 46,  144 => 42,  140 => 41,  133 => 39,  130 => 38,  123 => 34,  119 => 32,  115 => 30,  112 => 29,  110 => 28,  107 => 27,  104 => 26,  101 => 25,  96 => 24,  93 => 23,  90 => 22,  85 => 21,  82 => 20,  80 => 19,  73 => 15,  63 => 7,  61 => 6,  57 => 4,  55 => 0,  51 => 3,  47 => 0,  44 => 1,  42 => 0,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends \"_layouts/app\" %}

{% block content %}

    <!-- ======= About Us Section ======= -->
    {% include \"_singles/about\" %}
    <!-- End About Us Section -->

    <!-- ======= Services Section ======= -->
    <section id=\"services\" class=\"services section-bg-gray\">
      <div class=\"container\" data-aos=\"fade-up\">

        <div class=\"section-title\">
          <h2>Services</h2>
          {{ entry.serviceText }}
        </div>

        <div class=\"row\">
        {% set services = craft.entries.section('services').all() %}
        {% set count = 0 %}
        {% for service in services %}
          {% set serviceBody = service.serviceBody.all() %}
          {% if serviceBody | length %}
            {% for block in serviceBody %}
              {% set count = count + 1 %}
              {% if block.type == 'servicePoint' %}
                <div class=\"col-lg-6 col-md-6 d-flex align-items-stretch
                  {% if count == 1 %}
                  {% elseif count == 2 %}
                    mt-4 mt-lg-0
                  {% else %}
                    mt-4
                  {% endif %}
                \" data-aos=\"zoom-in\" data-aos-delay=\"{{ count }}00\">
                  
                  <div class=\"icon-box\">
                    {# <div class=\"icon\"><i class=\"bx bxl-dribbble\"></i></div> #}
                    <div class=\"image-box\">
                      <img src=\"{{ block.image.one.url }}\" alt=\"{{ block.image.title }}\"/>
                    </div>
                    <h4><a href=\"\">{{ service.title }}</a></h4>
                    <p>{{ block.description }} </p>
                  </div>
                </div>
              {% endif %}
            {% endfor %}
          {% endif %}
        {% endfor %}
        </div>

      </div>
    </section>
    <!-- End Services Section -->

    <!-- ======= Cta Section ======= -->
    {% set actions = entry.actionText %}
    {% if actions | length %}
      {% for action in actions %}
        {% if action.type == \"actionPoint\" %}
          <section id=\"cta\" class=\"cta\" 
            style=\"
              background: linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)), url({{ action.image.one.url() }}) fixed center center;
              background-size: cover;
            \">
            <div class=\"container\" data-aos=\"zoom-in\">

              <div class=\"row\">
                <div class=\"col-lg-9 text-center text-lg-left\">
                  <h3>{{ action.heading }}</h3>
                  <p> {{ action.text }} </p>
                </div>
                <div class=\"col-lg-3 cta-btn-container text-center\">
                  <a class=\"cta-btn align-middle\" href=\"#\">{{ action.heading }}</a>
                </div>
              </div>

            </div>
          </section
        {% endif %}
      {% endfor %}
    {% endif %}
    ><!-- End Cta Section -->

    <!-- ======= Features Section ======= -->
    {# <section id=\"features\" class=\"features\">
      <div class=\"container\">

        <div class=\"row\">
          <div class=\"col-lg-6 order-2 order-lg-1\">
            <div class=\"icon-box mt-5 mt-lg-0\">
              <i class=\"bx bx-receipt\"></i>
              <h4>Est labore ad</h4>
              <p>Consequuntur sunt aut quasi enim aliquam quae harum pariatur laboris nisi ut aliquip</p>
            </div>
            <div class=\"icon-box mt-5\">
              <i class=\"bx bx-cube-alt\"></i>
              <h4>Harum esse qui</h4>
              <p>Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt</p>
            </div>
            <div class=\"icon-box mt-5\">
              <i class=\"bx bx-images\"></i>
              <h4>Aut occaecati</h4>
              <p>Aut suscipit aut cum nemo deleniti aut omnis. Doloribus ut maiores omnis facere</p>
            </div>
            <div class=\"icon-box mt-5\">
              <i class=\"bx bx-shield\"></i>
              <h4>Beatae veritatis</h4>
              <p>Expedita veritatis consequuntur nihil tempore laudantium vitae denat pacta</p>
            </div>
          </div>
          <div class=\"image col-lg-6 order-1 order-lg-2\" style='background-image: url(\"assets/img/features.jpg\");'></div>
        </div>

      </div>
    </section #}
    <!-- End Features Section -->

    <!-- ======= Clients Section ======= -->
    <section id=\"clients\" class=\"clients\">
      <div class=\"container\" data-aos=\"fade-up\">
        <div class=\"section-title\">
          <h2>Our Clients</h2>
          <p> {{ entry.portfolioText }} </p>
        </div>

        <div id=\"clientCarousel\" class=\"carousel slide\" data-ride=\"carousel\">
          <div class=\"carousel-inner\">
            {% set clients = craft.entries.section('clients') %}
            {% set count = 0 %}
            {% if clients | length %}
              {% for client in clients %}
                {% set count = count + 1 %}
                {% if count == 1 %}
                <div class=\"carousel-item {{ loop.index == 1 ? 'active' : '' }}\">
                  <div class=\"row no-gutters clients-wrap clearfix wow fadeInUp\">
                {% endif %}
                
                {% set blocks = client.clientBody %}
                {% if blocks | length %}
                  {% for block in blocks %}
                    {% if block.type == 'clientPoint' %}
                      <div class=\"col-lg-3 col-md-4 col-xs-6\">
                        <div class=\"client-logo\">
                          <img src=\"{{ block.image.one.url() }}\" class=\"img-fluid\" alt=\"\">
                        </div>
                      </div>
                    {% endif %}
                  {% endfor %}
                {% endif %}
                {% if count == 8 %}
                    </div>
                  </div>
                  {% set count = 0 %}
                {% endif %}
                
              {% endfor %}
            {% endif %}
          </div>
          <a class=\"carousel-control-prev\" href=\"#clientCarousel\" role=\"button\" data-slide=\"prev\">
            <span class=\"carousel-control-prev-icon\" aria-hidden=\"true\"></span>
            <span class=\"sr-only\">Previous</span>
          </a>
          <a class=\"carousel-control-next\" href=\"#clientCarousel\" role=\"button\" data-slide=\"next\">
            <span class=\"carousel-control-next-icon\" aria-hidden=\"true\"></span>
            <span class=\"sr-only\">Next</span>
          </a>

          <ol class=\"carousel-indicators\" id=\"client-carousel-indicators\"></ol>
        </div>
      </div>
    </section>
    <!-- End Clients Section -->



    <!-- ======= Counts Section ======= -->
    <section id=\"counts\" class=\"counts\" data-aos=\"fade-up\">
      <div class=\"container\">

        <div class=\"text-center title\">
          <h3>What we have achieved so far</h3>
          <p>Iusto et labore modi qui sapiente xpedita tempora et aut non ipsum consequatur illo.</p>
        </div>

        <div class=\"row counters\">

          <div class=\"col-lg-3 col-6 text-center\">
            <span data-toggle=\"counter-up\">232</span>
            <p>Clients</p>
          </div>

          <div class=\"col-lg-3 col-6 text-center\">
            <span data-toggle=\"counter-up\">521</span>
            <p>Projects</p>
          </div>

          <div class=\"col-lg-3 col-6 text-center\">
            <span data-toggle=\"counter-up\">1,463</span>
            <p>Hours Of Support</p>
          </div>

          <div class=\"col-lg-3 col-6 text-center\">
            <span data-toggle=\"counter-up\">15</span>
            <p>Hard Workers</p>
          </div>

        </div>

      </div>
    </section>
    <!-- End Counts Section -->

    <!-- ======= Portfolio Section ======= -->
    <section id=\"portfolio\" class=\"portfolio section-bg-gray\">
      <div class=\"container\" data-aos=\"fade-up\">
        <div class=\"section-title\">
          <h2>Portfolio</h2>
          <p> {{ entry.portfolioText }} </p>
        </div>
        
        {% set portCategories = craft.categories().group('portfolioCategories') %}
        <div class=\"row\">
          <div class=\"col-lg-12 d-flex justify-content-center\">
            <ul id=\"portfolio-flters\">
              <li data-filter=\"*\" class=\"filter-active\">All</li>
              {% for portCategory in portCategories %}
                <li data-filter=\".filter-{{ portCategory.slug }}\">{{ portCategory.title }}</li>
              {% endfor %}
            </ul>
          </div>
        </div>


        {# Get the categories related to my \"entrySection\" entries in structure order #
        {% set portfolios = craft.entries.section('portfolio') %}
        {% set relatedCats = craft.categories.relatedTo(portfolios) %}
        
        {# Loop the categories #
        {% for category in relatedCats %}
          {{ category.title }}

          {# Get and loop through entries related to this cat #
          {% set relatedEntries = craft.entries.relatedTo(category) %}
          {% for entry in relatedEntries %}
            <pre>
              {{ dump(entry.title) }}
            </pre>
          {% endfor %}
        {% endfor %}
        #}

        <div class=\"row portfolio-container\">
          {% set portfolios = craft.entries.section('portfolio') %}
          {% for portfolio in portfolios %}
            {% set portfolioBlock = portfolio.portfolioBody %}
            {% set i = 0 %}
            {% for block in portfolioBlock %}
                
                {% if block.type == 'portfolioPoint' %}
                  {% set relatedCats = craft.categories.relatedTo(portfolio) %}
                  <div class=\"col-lg-4 col-md-6 portfolio-item
                    {% for category in relatedCats %}
                        filter-{{- category.slug  -}}
                    {% endfor %}
                  \">
                    <img src=\"{{ block.image.one.url() }}\" class=\"img-fluid\" alt=\"\">
                    <div class=\"portfolio-info\">
                      <h4>{{ block.heading }}</h4>
                      <p>{{ block.text }}</p>
                      <a href=\"{{ block.image.one.url() }}\" data-gall=\"portfolioGallery\" class=\"venobox preview-link\" title=\"App {{ i + 1 }}\"><i class=\"bx bx-plus\"></i></a>
                      <a href=\"portfolio-details.html\" class=\"details-link\" title=\"More Details\"><i class=\"bx bx-link\"></i></a>
                    </div>
                  </div>
                {% endif %}
            {% endfor %}
          {% endfor %}
        </div>
      </div>
    </section>
    <!-- End Portfolio Section -->

    <!-- ======= Testimonials Section ======= -->
    <section id=\"testimonials\" class=\"testimonials\">
      <div class=\"container\" data-aos=\"fade-up\">

        <div class=\"section-title\">
          <h2>Testimonials</h2>
          <p>{{ entry.testimonialText }}</p>
        </div>

        {% set testimonials = craft.entries.section('testimonials') %}
        <div class=\"owl-carousel testimonials-carousel\">
        {% for testimonial in testimonials %}
          <div class=\"testimonial-wrap\">
            <div class=\"testimonial-item\">
              {% set blocks = testimonial.testimonialBody %}
              {% for block in blocks %}
                <img src=\"{{ block.image.one.url }}\" class=\"testimonial-img\" alt=\"{{ block.title }}\">
                <h3>{{ testimonial.title }}</h3>
                <h4>{{ block.subheading }}</h4>
                <p>
                  <i class=\"bx bxs-quote-alt-left quote-icon-left\"></i>
                    {{ block.text }}
                  <i class=\"bx bxs-quote-alt-right quote-icon-right\"></i>
                </p>
              {% endfor %}
            </div>
          </div>
        {% endfor %}
        </div>
      </div>
    </section>
    <!-- End Testimonials Section -->


    <!-- ======= Pricing Section ======= -->
    <!--
    <section id=\"pricing\" class=\"pricing\">
      <div class=\"container\">

        <div class=\"section-title\">
          <h2>Pricing</h2>
          <p>Magnam dolores commodi suscipit. Necessitatibus eius consequatur ex aliquid fuga eum quidem. Sit sint consectetur velit. Quisquam quos quisquam cupiditate. Et nemo qui impedit suscipit alias ea. Quia fugiat sit in iste officiis commodi quidem hic quas.</p>
        </div>

        <div class=\"row\">

          <div class=\"col-lg-4 col-md-6\">
            <div class=\"box\">
              <h3>Free</h3>
              <h4><sup>\$</sup>0<span> / month</span></h4>
              <ul>
                <li>Aida dere</li>
                <li>Nec feugiat nisl</li>
                <li>Nulla at volutpat dola</li>
                <li class=\"na\">Pharetra massa</li>
                <li class=\"na\">Massa ultricies mi</li>
              </ul>
              <div class=\"btn-wrap\">
                <a href=\"#\" class=\"btn-buy\">Buy Now</a>
              </div>
            </div>
          </div>

          <div class=\"col-lg-4 col-md-6 mt-4 mt-md-0\">
            <div class=\"box recommended\">
              <span class=\"recommended-badge\">Recommended</span>
              <h3>Business</h3>
              <h4><sup>\$</sup>19<span> / month</span></h4>
              <ul>
                <li>Aida dere</li>
                <li>Nec feugiat nisl</li>
                <li>Nulla at volutpat dola</li>
                <li>Pharetra massa</li>
                <li class=\"na\">Massa ultricies mi</li>
              </ul>
              <div class=\"btn-wrap\">
                <a href=\"#\" class=\"btn-buy\">Buy Now</a>
              </div>
            </div>
          </div>

          <div class=\"col-lg-4 col-md-6 mt-4 mt-lg-0\">
            <div class=\"box\">
              <h3>Developer</h3>
              <h4><sup>\$</sup>29<span> / month</span></h4>
              <ul>
                <li>Aida dere</li>
                <li>Nec feugiat nisl</li>
                <li>Nulla at volutpat dola</li>
                <li>Pharetra massa</li>
                <li>Massa ultricies mi</li>
              </ul>
              <div class=\"btn-wrap\">
                <a href=\"#\" class=\"btn-buy\">Buy Now</a>
              </div>
            </div>
          </div>

        </div>

      </div>
    </section>
    -->
    <!-- End Pricing Section -->

    <!-- ======= Team Section ======= -->
    <section id=\"team\" class=\"team section-bg-gray\">
      <div class=\"container\" data-aos=\"fade-up\">
        <div class=\"section-title\">
          <h2>Our Team</h2>
          <p>{{ entry.teamText }}</p>
        </div>
        
        <div id=\"teamCarousel\" class=\"carousel slide\" data-ride=\"carousel\">
          <div class=\"carousel-inner\">
            {% set teams = craft.entries.section('teams') %}
            {% set count = 0 %}
            {% for team in teams %}
              {% set count = count + 1 %}
              {% if count == 1 %}
                <div class=\"carousel-item {{ loop.index == 1 ? 'active' : '' }}\">
                  <div class=\"row\">
              {% endif %}
                          
                  <div class=\"col-lg-6 {% if count > 1 %} mt-4 {% if count == 2 %} mt-lg-0 {% endif %}{% endif %}\" 
                    
                    {% if count > 1 %}
                      data-wow-delay=\"0.{{ count }}s\"
                    {% endif %}
                  >
                    
                    <div class=\"member d-flex align-items-start\" data-aos=\"zoom-in\" data-aos-delay=\"{{ count }}00\">
                    {% set blocks = team.teamBody %}
                    {% for block in blocks %}
                      {% if block | length %}
                      <div class=\"pic\"><img src=\"{{ block.image.one.url }}\" class=\"img-fluid\" alt=\"\"></div>
                      <div class=\"member-info\">
                        <h4>{{ team.title }}</h4>
                        <span>{{ block.heading }}</span>
                        <p>{{ block.text }}</p>
                        {% endif %}
                      {% endfor %}
                      {% set sosmedAccounts = team.socialMediaAccount %}
                        <div class=\"social\">
                        {% for sosmed in sosmedAccounts %}
                          <a href=\" {{ sosmed.twitter }} \"><i class=\"ri-twitter-fill\"></i></a>
                          <a href=\" {{ sosmed.facebook }} \"><i class=\"ri-facebook-fill\"></i></a>
                          <a href=\" {{ sosmed.instagram }} \"><i class=\"ri-instagram-fill\"></i></a>
                          <a href=\" {{ sosmed.linkedin }} \"> <i class=\"ri-linkedin-box-fill\"></i> </a>
                        {% endfor %}
                        </div>
                      </div>
                    </div>
                  </div>
              {% if count == 4 %}
                  </div>
                </div>
                {% set count = 0 %}  
              {% endif %}
            {% endfor %}
          </div>
          <a class=\"carousel-control-prev\" href=\"#teamCarousel\" role=\"button\" data-slide=\"prev\">
            <span class=\"carousel-control-prev-icon\" aria-hidden=\"true\"></span>
            <span class=\"sr-only\">Previous</span>
          </a>
          <a class=\"carousel-control-next\" href=\"#teamCarousel\" role=\"button\" data-slide=\"next\">
            <span class=\"carousel-control-next-icon\" aria-hidden=\"true\"></span>
            <span class=\"sr-only\">Next</span>
          </a>
        </div>
        
      </div>
    </section>

    <!-- End Team Section -->

    <!-- ======= Faq Section ======= -->
    <section id=\"faq\" class=\"faq\">
      <div class=\"container-fluid\" data-aos=\"fade-up\">
        <div class=\"row\">
          <div class=\"col-lg-7 d-flex flex-column justify-content-center align-items-stretch  order-2 order-lg-1\">
            <div class=\"content\">
              <h3>Join With<strong> Us</strong></h3>
              <p>{{ entry.joinText }}</p>
            </div>

            <div class=\"accordion-list\">
              <ul>
                {% set cariers = craft.entries.section('cariers') %}
                {% set count = 0 %}
                {% for carier in cariers %}
                {% set count = count + 1 %}
                <li>
                  <a data-toggle=\"collapse\" class=\" {{ loop.index == 1 ? 'collapse' : 'collapsed' }} \" href=\"#accordion-list-{{ count }}\">{{ carier.title }} <i class=\"bx bx-chevron-down icon-show\"></i><i class=\"bx bx-chevron-up icon-close\"></i></a>
                  <div id=\"accordion-list-{{ count }}\" class=\"collapse {{ loop.index == 1 ? 'show' : '' }} \" data-parent=\".accordion-list\">
                    <p>{{ carier.jobsDescription }}</p>
                    <p>{{ carier.jobsRequirement }} </p>
                  </div>
                </li>
                {% endfor %}
              </ul>
            </div>
          </div>

          <div class=\"col-lg-5 align-items-stretch order-1 order-lg-2 img\" style='background-image: url(\"assets/img/faq.jpg\");'>&nbsp;</div>
        </div>

      </div>
    </section>
    <!-- End Faq Section -->

    <!-- ======= Contact Section ======= -->
    {% include \"_singles/contact\" %}
    <!-- End Contact Section -->
{% endblock %}", "_singles/home", "/Applications/MAMP/htdocs/craft/smsi/templates/_singles/home.twig");
    }
}
