<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* __string_template__373f519c28f2eef1bf9239048b32a2996b5865e612585eb82ac0b2931f8f1100 */
class __TwigTemplate_df610424f1bf7a7588fe130a23524b6b4f2bb5f13fce6a2946d74ac590679b3d extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "__string_template__373f519c28f2eef1bf9239048b32a2996b5865e612585eb82ac0b2931f8f1100");
        // line 1
        echo "services/";
        echo (((craft\helpers\Template::attribute($this->env, $this->source, ($context["_variables"] ?? null), "slug", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["_variables"] ?? null), "slug", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["_variables"] ?? null), "slug", [])) : (craft\helpers\Template::attribute($this->env, $this->source, ($context["object"] ?? null), "slug", [])));
        // line 0
        craft\helpers\Template::endProfile("template", "__string_template__373f519c28f2eef1bf9239048b32a2996b5865e612585eb82ac0b2931f8f1100");
    }

    public function getTemplateName()
    {
        return "__string_template__373f519c28f2eef1bf9239048b32a2996b5865e612585eb82ac0b2931f8f1100";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  41 => 0,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("services/{{ (_variables.slug ?? object.slug)|raw }}", "__string_template__373f519c28f2eef1bf9239048b32a2996b5865e612585eb82ac0b2931f8f1100", "");
    }
}
