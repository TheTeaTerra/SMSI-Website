<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* contact-form/_settings */
class __TwigTemplate_8dfd22f7590d81a21b8b4a6d9e61d75f5474e383b55e7a18a4cc5a934ccdf227 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "contact-form/_settings");
        // line 1
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms", "contact-form/_settings", 1)->unwrap();
        // line 2
        echo "
";
        // line 10
        echo "
";
        // line 11
        $macros["__internal_261a90e15b75c804bd14bced78aa4f72c8b2b7036dbb7ce91a220045c9f7666e"] = $this->macros["__internal_261a90e15b75c804bd14bced78aa4f72c8b2b7036dbb7ce91a220045c9f7666e"] = $this;
        // line 12
        echo "
";
        // line 13
        echo twig_call_macro($macros["forms"], "macro_autosuggestField", [["first" => true, "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("To Email", "contact-form"), "required" => true, "id" => "toEmail", "name" => "toEmail", "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("The email address(es) that the contact form will send to. Separate multiple email addresses with commas.", "contact-form"), "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 20
(isset($context["settings"]) || array_key_exists("settings", $context) ? $context["settings"] : (function () { throw new RuntimeError('Variable "settings" does not exist.', 20, $this->source); })()), "toEmail", []), "suggestEnvVars" => true, "autofocus" => true, "disabled" => twig_in_filter("toEmail",         // line 23
(isset($context["overrides"]) || array_key_exists("overrides", $context) ? $context["overrides"] : (function () { throw new RuntimeError('Variable "overrides" does not exist.', 23, $this->source); })())), "warning" => ((twig_in_filter("toEmail",         // line 24
(isset($context["overrides"]) || array_key_exists("overrides", $context) ? $context["overrides"] : (function () { throw new RuntimeError('Variable "overrides" does not exist.', 24, $this->source); })()))) ? (twig_call_macro($macros["__internal_261a90e15b75c804bd14bced78aa4f72c8b2b7036dbb7ce91a220045c9f7666e"], "macro_configWarning", ["toEmail"], 24, $context, $this->getSourceContext())) : ("")), "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 25
(isset($context["settings"]) || array_key_exists("settings", $context) ? $context["settings"] : (function () { throw new RuntimeError('Variable "settings" does not exist.', 25, $this->source); })()), "getErrors", [0 => "toEmail"], "method")]], 13, $context, $this->getSourceContext());
        // line 26
        echo "

";
        // line 28
        echo twig_call_macro($macros["forms"], "macro_textField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Sender Text", "contact-form"), "id" => "prependSender", "name" => "prependSender", "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Text that will be prepended to the email’s From Name to inform who the Contact Form actually was sent by.", "contact-form"), "value" => ((craft\helpers\Template::attribute($this->env, $this->source,         // line 33
(isset($context["settings"]) || array_key_exists("settings", $context) ? $context["settings"] : (function () { throw new RuntimeError('Variable "settings" does not exist.', 33, $this->source); })()), "prependSender", [])) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["settings"]) || array_key_exists("settings", $context) ? $context["settings"] : (function () { throw new RuntimeError('Variable "settings" does not exist.', 33, $this->source); })()), "prependSender", [])) : ("")), "disabled" => twig_in_filter("prependSender",         // line 34
(isset($context["overrides"]) || array_key_exists("overrides", $context) ? $context["overrides"] : (function () { throw new RuntimeError('Variable "overrides" does not exist.', 34, $this->source); })())), "warning" => ((twig_in_filter("prependSender",         // line 35
(isset($context["overrides"]) || array_key_exists("overrides", $context) ? $context["overrides"] : (function () { throw new RuntimeError('Variable "overrides" does not exist.', 35, $this->source); })()))) ? (twig_call_macro($macros["__internal_261a90e15b75c804bd14bced78aa4f72c8b2b7036dbb7ce91a220045c9f7666e"], "macro_configWarning", ["prependSender"], 35, $context, $this->getSourceContext())) : ("")), "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 36
(isset($context["settings"]) || array_key_exists("settings", $context) ? $context["settings"] : (function () { throw new RuntimeError('Variable "settings" does not exist.', 36, $this->source); })()), "getErrors", [0 => "prependSender"], "method")]], 28, $context, $this->getSourceContext());
        // line 37
        echo "

";
        // line 39
        echo twig_call_macro($macros["forms"], "macro_textField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Subject Text", "contact-form"), "id" => "prependSubject", "name" => "prependSubject", "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Text that will be prepended to the email’s Subject to flag that it comes from the Contact Form.", "contact-form"), "value" => ((craft\helpers\Template::attribute($this->env, $this->source,         // line 44
(isset($context["settings"]) || array_key_exists("settings", $context) ? $context["settings"] : (function () { throw new RuntimeError('Variable "settings" does not exist.', 44, $this->source); })()), "prependSubject", [])) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["settings"]) || array_key_exists("settings", $context) ? $context["settings"] : (function () { throw new RuntimeError('Variable "settings" does not exist.', 44, $this->source); })()), "prependSubject", [])) : ("")), "disabled" => twig_in_filter("prependSubject",         // line 45
(isset($context["overrides"]) || array_key_exists("overrides", $context) ? $context["overrides"] : (function () { throw new RuntimeError('Variable "overrides" does not exist.', 45, $this->source); })())), "warning" => ((twig_in_filter("prependSubject",         // line 46
(isset($context["overrides"]) || array_key_exists("overrides", $context) ? $context["overrides"] : (function () { throw new RuntimeError('Variable "overrides" does not exist.', 46, $this->source); })()))) ? (twig_call_macro($macros["__internal_261a90e15b75c804bd14bced78aa4f72c8b2b7036dbb7ce91a220045c9f7666e"], "macro_configWarning", ["prependSubject"], 46, $context, $this->getSourceContext())) : ("")), "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 47
(isset($context["settings"]) || array_key_exists("settings", $context) ? $context["settings"] : (function () { throw new RuntimeError('Variable "settings" does not exist.', 47, $this->source); })()), "getErrors", [0 => "prependSubject"], "method")]], 39, $context, $this->getSourceContext());
        // line 48
        echo "

";
        // line 50
        echo twig_call_macro($macros["forms"], "macro_lightswitchField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Allow attachments?", "contact-form"), "id" => "allowAttachments", "name" => "allowAttachments", "on" => craft\helpers\Template::attribute($this->env, $this->source,         // line 54
(isset($context["settings"]) || array_key_exists("settings", $context) ? $context["settings"] : (function () { throw new RuntimeError('Variable "settings" does not exist.', 54, $this->source); })()), "allowAttachments", []), "disabled" => twig_in_filter("allowAttachments",         // line 55
(isset($context["overrides"]) || array_key_exists("overrides", $context) ? $context["overrides"] : (function () { throw new RuntimeError('Variable "overrides" does not exist.', 55, $this->source); })())), "warning" => ((twig_in_filter("allowAttachments",         // line 56
(isset($context["overrides"]) || array_key_exists("overrides", $context) ? $context["overrides"] : (function () { throw new RuntimeError('Variable "overrides" does not exist.', 56, $this->source); })()))) ? (twig_call_macro($macros["__internal_261a90e15b75c804bd14bced78aa4f72c8b2b7036dbb7ce91a220045c9f7666e"], "macro_configWarning", ["allowAttachments"], 56, $context, $this->getSourceContext())) : ("")), "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 57
(isset($context["settings"]) || array_key_exists("settings", $context) ? $context["settings"] : (function () { throw new RuntimeError('Variable "settings" does not exist.', 57, $this->source); })()), "getErrors", [0 => "allowAttachments"], "method")]], 50, $context, $this->getSourceContext());
        // line 58
        echo "

";
        // line 60
        echo twig_call_macro($macros["forms"], "macro_textField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Success Flash Message", "contact-form"), "id" => "successFlashMessage", "name" => "successFlashMessage", "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("The flash message displayed after successfully sending a message.", "contact-form"), "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 65
(isset($context["settings"]) || array_key_exists("settings", $context) ? $context["settings"] : (function () { throw new RuntimeError('Variable "settings" does not exist.', 65, $this->source); })()), "successFlashMessage", []), "disabled" => twig_in_filter("successFlashMessage",         // line 66
(isset($context["overrides"]) || array_key_exists("overrides", $context) ? $context["overrides"] : (function () { throw new RuntimeError('Variable "overrides" does not exist.', 66, $this->source); })())), "warning" => ((twig_in_filter("successFlashMessage",         // line 67
(isset($context["overrides"]) || array_key_exists("overrides", $context) ? $context["overrides"] : (function () { throw new RuntimeError('Variable "overrides" does not exist.', 67, $this->source); })()))) ? (twig_call_macro($macros["__internal_261a90e15b75c804bd14bced78aa4f72c8b2b7036dbb7ce91a220045c9f7666e"], "macro_configWarning", ["successFlashMessage"], 67, $context, $this->getSourceContext())) : ("")), "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 68
(isset($context["settings"]) || array_key_exists("settings", $context) ? $context["settings"] : (function () { throw new RuntimeError('Variable "settings" does not exist.', 68, $this->source); })()), "getErrors", [0 => "successFlashMessage"], "method")]], 60, $context, $this->getSourceContext());
        // line 69
        echo "
";
        // line 0
        craft\helpers\Template::endProfile("template", "contact-form/_settings");
    }

    // line 3
    public function macro_configWarning($__setting__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "setting" => $__setting__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            // line 0
            craft\helpers\Template::beginProfile("macro", "configWarning");
            // line 4
            $context["setting"] = (("<code>" . (isset($context["setting"]) || array_key_exists("setting", $context) ? $context["setting"] : (function () { throw new RuntimeError('Variable "setting" does not exist.', 4, $this->source); })())) . "</code>");
            // line 5
            echo "    ";
            echo $this->extensions['craft\web\twig\Extension']->translateFilter("This is being overridden by the {setting} config setting in your {file} config file.", "contact-form", ["setting" =>             // line 6
(isset($context["setting"]) || array_key_exists("setting", $context) ? $context["setting"] : (function () { throw new RuntimeError('Variable "setting" does not exist.', 6, $this->source); })()), "file" => "contact-form.php"]);
            // line 0
            craft\helpers\Template::endProfile("macro", "configWarning");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    public function getTemplateName()
    {
        return "contact-form/_settings";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  125 => 0,  123 => 6,  121 => 5,  119 => 4,  117 => 0,  104 => 3,  100 => 0,  97 => 69,  95 => 68,  94 => 67,  93 => 66,  92 => 65,  91 => 60,  87 => 58,  85 => 57,  84 => 56,  83 => 55,  82 => 54,  81 => 50,  77 => 48,  75 => 47,  74 => 46,  73 => 45,  72 => 44,  71 => 39,  67 => 37,  65 => 36,  64 => 35,  63 => 34,  62 => 33,  61 => 28,  57 => 26,  55 => 25,  54 => 24,  53 => 23,  52 => 20,  51 => 13,  48 => 12,  46 => 11,  43 => 10,  40 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% import \"_includes/forms\" as forms %}

{% macro configWarning(setting) -%}
    {% set setting = '<code>'~setting~'</code>' %}
    {{ \"This is being overridden by the {setting} config setting in your {file} config file.\"|t('contact-form', {
        setting: setting,
        file: 'contact-form.php'
    })|raw }}
{%- endmacro %}

{% from _self import configWarning %}

{{ forms.autosuggestField({
    first:        true,
    label:        \"To Email\"|t('contact-form'),
    required:     true,
    id:           'toEmail',
    name:         'toEmail',
    instructions: \"The email address(es) that the contact form will send to. Separate multiple email addresses with commas.\"|t('contact-form'),
    value:        settings.toEmail,
    suggestEnvVars: true,
    autofocus:    true,
    disabled:     'toEmail' in overrides,
    warning:      'toEmail' in overrides ? configWarning('toEmail'),
    errors:       settings.getErrors('toEmail')
}) }}

{{ forms.textField({
    label:        \"Sender Text\"|t('contact-form'),
    id:           'prependSender',
    name:         'prependSender',
    instructions: \"Text that will be prepended to the email’s From Name to inform who the Contact Form actually was sent by.\"|t('contact-form'),
    value:        (settings.prependSender ? settings.prependSender : \"\"),
    disabled:     'prependSender' in overrides,
    warning:      'prependSender' in overrides ? configWarning('prependSender'),
    errors:       settings.getErrors('prependSender')
}) }}

{{ forms.textField({
    label:        \"Subject Text\"|t('contact-form'),
    id:           'prependSubject',
    name:         'prependSubject',
    instructions: \"Text that will be prepended to the email’s Subject to flag that it comes from the Contact Form.\"|t('contact-form'),
    value:        (settings.prependSubject ? settings.prependSubject : \"\"),
    disabled:     'prependSubject' in overrides,
    warning:      'prependSubject' in overrides ? configWarning('prependSubject'),
    errors:       settings.getErrors('prependSubject')
}) }}

{{ forms.lightswitchField({
    label:        \"Allow attachments?\"|t('contact-form'),
    id:           'allowAttachments',
    name:         'allowAttachments',
    on:           settings.allowAttachments,
    disabled:     'allowAttachments' in overrides,
    warning:      'allowAttachments' in overrides ? configWarning('allowAttachments'),
    errors:       settings.getErrors('allowAttachments')
}) }}

{{ forms.textField({
    label:        \"Success Flash Message\"|t('contact-form'),
    id:           \"successFlashMessage\",
    name:         \"successFlashMessage\",
    instructions: \"The flash message displayed after successfully sending a message.\"|t('contact-form'),
    value:        settings.successFlashMessage,
    disabled:     'successFlashMessage' in overrides,
    warning:      'successFlashMessage' in overrides ? configWarning('successFlashMessage'),
    errors:       settings.getErrors('successFlashMessage')
}) }}
", "contact-form/_settings", "/Applications/MAMP/htdocs/craft/smsi/vendor/craftcms/contact-form/src/templates/_settings.twig");
    }
}
