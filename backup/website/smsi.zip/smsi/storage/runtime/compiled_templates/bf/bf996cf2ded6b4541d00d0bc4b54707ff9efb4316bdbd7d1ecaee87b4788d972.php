<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* settings/assets/volumes/_edit */
class __TwigTemplate_5bf83c609af6340958ca703bc3faebc3b3d1fd6223b410a00993059941a22068 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "_layouts/cp";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("template", "settings/assets/volumes/_edit");
        // line 3
        $context["fullPageForm"] = true;
        // line 5
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms", "settings/assets/volumes/_edit", 5)->unwrap();
        // line 100
        if (( !(isset($context["volume"]) || array_key_exists("volume", $context)) ||  !craft\helpers\Template::attribute($this->env, $this->source, (isset($context["volume"]) || array_key_exists("volume", $context) ? $context["volume"] : (function () { throw new RuntimeError('Variable "volume" does not exist.', 100, $this->source); })()), "handle", []))) {
            // line 101
            ob_start();
            // line 102
            echo "        new Craft.HandleGenerator('#name', '#handle');
    ";
            Craft::$app->getView()->registerJs(ob_get_clean(), 3);
        }
        // line 1
        $this->parent = $this->loadTemplate("_layouts/cp", "settings/assets/volumes/_edit", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        // line 0
        craft\helpers\Template::endProfile("template", "settings/assets/volumes/_edit");
    }

    // line 8
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("block", "content");
        // line 9
        echo "        ";
        echo craft\helpers\Html::actionInput("volumes/save-volume");
        echo "
        ";
        // line 10
        echo craft\helpers\Html::redirectInput("settings/assets");
        echo "
        ";
        // line 11
        if ( !(isset($context["isNewVolume"]) || array_key_exists("isNewVolume", $context) ? $context["isNewVolume"] : (function () { throw new RuntimeError('Variable "isNewVolume" does not exist.', 11, $this->source); })())) {
            echo craft\helpers\Html::hiddenInput("volumeId", craft\helpers\Template::attribute($this->env, $this->source, (isset($context["volume"]) || array_key_exists("volume", $context) ? $context["volume"] : (function () { throw new RuntimeError('Variable "volume" does not exist.', 11, $this->source); })()), "id", []));
        }
        // line 12
        echo "
        <div id=\"assetvolume-settings\">
            ";
        // line 14
        echo twig_call_macro($macros["forms"], "macro_textField", [["first" => true, "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Name", "app"), "id" => "name", "name" => "name", "value" => ((        // line 19
(isset($context["volume"]) || array_key_exists("volume", $context))) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["volume"]) || array_key_exists("volume", $context) ? $context["volume"] : (function () { throw new RuntimeError('Variable "volume" does not exist.', 19, $this->source); })()), "name", [])) : (null)), "errors" => ((        // line 20
(isset($context["volume"]) || array_key_exists("volume", $context))) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["volume"]) || array_key_exists("volume", $context) ? $context["volume"] : (function () { throw new RuntimeError('Variable "volume" does not exist.', 20, $this->source); })()), "getErrors", [0 => "name"], "method")) : (null)), "autofocus" => true, "required" => true]], 14, $context, $this->getSourceContext());
        // line 23
        echo "

            ";
        // line 25
        echo twig_call_macro($macros["forms"], "macro_textField", [["first" => true, "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Handle", "app"), "id" => "handle", "name" => "handle", "class" => "code", "autocorrect" => false, "autocapitalize" => false, "value" => ((        // line 33
(isset($context["volume"]) || array_key_exists("volume", $context))) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["volume"]) || array_key_exists("volume", $context) ? $context["volume"] : (function () { throw new RuntimeError('Variable "volume" does not exist.', 33, $this->source); })()), "handle", [])) : (null)), "errors" => ((        // line 34
(isset($context["volume"]) || array_key_exists("volume", $context))) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["volume"]) || array_key_exists("volume", $context) ? $context["volume"] : (function () { throw new RuntimeError('Variable "volume" does not exist.', 34, $this->source); })()), "getErrors", [0 => "handle"], "method")) : (null)), "required" => true]], 25, $context, $this->getSourceContext());
        // line 36
        echo "

            ";
        // line 38
        echo twig_call_macro($macros["forms"], "macro_lightswitchField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Assets in this volume have public URLs", "app"), "name" => "hasUrls", "on" => craft\helpers\Template::attribute($this->env, $this->source,         // line 41
(isset($context["volume"]) || array_key_exists("volume", $context) ? $context["volume"] : (function () { throw new RuntimeError('Variable "volume" does not exist.', 41, $this->source); })()), "hasUrls", []), "toggle" => "url-field"]], 38, $context, $this->getSourceContext());
        // line 43
        echo "

            <div id=\"url-field\" class=\"";
        // line 45
        if ( !craft\helpers\Template::attribute($this->env, $this->source, (isset($context["volume"]) || array_key_exists("volume", $context) ? $context["volume"] : (function () { throw new RuntimeError('Variable "volume" does not exist.', 45, $this->source); })()), "hasUrls", [])) {
            echo "hidden";
        }
        echo "\">
                ";
        // line 46
        echo twig_call_macro($macros["forms"], "macro_autosuggestField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Base URL", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("The base URL to the assets in this volume.", "app"), "id" => "url", "class" => "ltr volume-url", "name" => "url", "suggestEnvVars" => true, "suggestAliases" => true, "value" => ((        // line 54
(isset($context["volume"]) || array_key_exists("volume", $context))) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["volume"]) || array_key_exists("volume", $context) ? $context["volume"] : (function () { throw new RuntimeError('Variable "volume" does not exist.', 54, $this->source); })()), "url", [])) : (null)), "errors" => ((        // line 55
(isset($context["volume"]) || array_key_exists("volume", $context))) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["volume"]) || array_key_exists("volume", $context) ? $context["volume"] : (function () { throw new RuntimeError('Variable "volume" does not exist.', 55, $this->source); })()), "getErrors", [0 => "url"], "method")) : (null)), "required" => true, "placeholder" => "//example.com/path/to/folder"]], 46, $context, $this->getSourceContext());
        // line 58
        echo "
            </div>

            <hr>

            ";
        // line 63
        echo twig_call_macro($macros["forms"], "macro_selectField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Volume Type", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("What type of volume is this?", "app"), "id" => "type", "name" => "type", "options" =>         // line 68
(isset($context["volumeTypeOptions"]) || array_key_exists("volumeTypeOptions", $context) ? $context["volumeTypeOptions"] : (function () { throw new RuntimeError('Variable "volumeTypeOptions" does not exist.', 68, $this->source); })()), "value" => get_class(        // line 69
(isset($context["volume"]) || array_key_exists("volume", $context) ? $context["volume"] : (function () { throw new RuntimeError('Variable "volume" does not exist.', 69, $this->source); })())), "toggle" => true]], 63, $context, $this->getSourceContext());
        // line 71
        echo "

            ";
        // line 73
        echo (isset($context["missingVolumePlaceholder"]) || array_key_exists("missingVolumePlaceholder", $context) ? $context["missingVolumePlaceholder"] : (function () { throw new RuntimeError('Variable "missingVolumePlaceholder" does not exist.', 73, $this->source); })());
        echo "

            ";
        // line 75
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["volumeTypes"]) || array_key_exists("volumeTypes", $context) ? $context["volumeTypes"] : (function () { throw new RuntimeError('Variable "volumeTypes" does not exist.', 75, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["volumeType"]) {
            // line 76
            echo "                ";
            $context["isCurrent"] = ($context["volumeType"] == get_class((isset($context["volume"]) || array_key_exists("volume", $context) ? $context["volume"] : (function () { throw new RuntimeError('Variable "volume" does not exist.', 76, $this->source); })())));
            // line 77
            echo "
                <div id=\"";
            // line 78
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFilter('id')->getCallable(), [$context["volumeType"]]), "html", null, true);
            echo "\"";
            if ( !(isset($context["isCurrent"]) || array_key_exists("isCurrent", $context) ? $context["isCurrent"] : (function () { throw new RuntimeError('Variable "isCurrent" does not exist.', 78, $this->source); })())) {
                echo " class=\"hidden\"";
            }
            echo ">
                    ";
            // line 79
            $_namespace = (("types[" . $context["volumeType"]) . "]");
            if ($_namespace) {
                $_originalNamespace = Craft::$app->getView()->getNamespace();
                Craft::$app->getView()->setNamespace(Craft::$app->getView()->namespaceInputName($_namespace));
                ob_start();
                try {
                    // line 80
                    echo "                        ";
                    if ((isset($context["isCurrent"]) || array_key_exists("isCurrent", $context) ? $context["isCurrent"] : (function () { throw new RuntimeError('Variable "isCurrent" does not exist.', 80, $this->source); })())) {
                        // line 81
                        echo "                            ";
                        echo craft\helpers\Template::attribute($this->env, $this->source, (isset($context["volume"]) || array_key_exists("volume", $context) ? $context["volume"] : (function () { throw new RuntimeError('Variable "volume" does not exist.', 81, $this->source); })()), "getSettingsHtml", [], "method");
                        echo "
                        ";
                    } else {
                        // line 83
                        echo "                            ";
                        echo craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["volumeInstances"]) || array_key_exists("volumeInstances", $context) ? $context["volumeInstances"] : (function () { throw new RuntimeError('Variable "volumeInstances" does not exist.', 83, $this->source); })()), $context["volumeType"], [], "array"), "getSettingsHtml", [], "method");
                        echo "
                        ";
                    }
                    // line 85
                    echo "                    ";
                } catch (Exception $e) {
                    ob_end_clean();

                    throw $e;
                }
                echo Craft::$app->getView()->namespaceInputs(ob_get_clean(), $_namespace);
                Craft::$app->getView()->setNamespace($_originalNamespace);
            } else {
                // line 80
                echo "                        ";
                if ((isset($context["isCurrent"]) || array_key_exists("isCurrent", $context) ? $context["isCurrent"] : (function () { throw new RuntimeError('Variable "isCurrent" does not exist.', 80, $this->source); })())) {
                    // line 81
                    echo "                            ";
                    echo craft\helpers\Template::attribute($this->env, $this->source, (isset($context["volume"]) || array_key_exists("volume", $context) ? $context["volume"] : (function () { throw new RuntimeError('Variable "volume" does not exist.', 81, $this->source); })()), "getSettingsHtml", [], "method");
                    echo "
                        ";
                } else {
                    // line 83
                    echo "                            ";
                    echo craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["volumeInstances"]) || array_key_exists("volumeInstances", $context) ? $context["volumeInstances"] : (function () { throw new RuntimeError('Variable "volumeInstances" does not exist.', 83, $this->source); })()), $context["volumeType"], [], "array"), "getSettingsHtml", [], "method");
                    echo "
                        ";
                }
                // line 85
                echo "                    ";
            }
            unset($_originalNamespace, $_namespace);
            // line 86
            echo "                </div>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['volumeType'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 88
        echo "        </div>

        <div id=\"assetvolume-fieldlayout\" class=\"hidden\">
            ";
        // line 91
        $this->loadTemplate("_includes/fieldlayoutdesigner", "settings/assets/volumes/_edit", 91)->display(twig_to_array(["fieldLayout" => craft\helpers\Template::attribute($this->env, $this->source,         // line 92
(isset($context["volume"]) || array_key_exists("volume", $context) ? $context["volume"] : (function () { throw new RuntimeError('Variable "volume" does not exist.', 92, $this->source); })()), "getFieldLayout", [], "method"), "customizableTabs" => true, "tab" => "fieldlayout"]));
        // line 96
        echo "        </div>
";
        // line 0
        craft\helpers\Template::endProfile("block", "content");
    }

    public function getTemplateName()
    {
        return "settings/assets/volumes/_edit";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  227 => 0,  224 => 96,  222 => 92,  221 => 91,  216 => 88,  209 => 86,  205 => 85,  199 => 83,  193 => 81,  190 => 80,  180 => 85,  174 => 83,  168 => 81,  165 => 80,  158 => 79,  150 => 78,  147 => 77,  144 => 76,  140 => 75,  135 => 73,  131 => 71,  129 => 69,  128 => 68,  127 => 63,  120 => 58,  118 => 55,  117 => 54,  116 => 46,  110 => 45,  106 => 43,  104 => 41,  103 => 38,  99 => 36,  97 => 34,  96 => 33,  95 => 25,  91 => 23,  89 => 20,  88 => 19,  87 => 14,  83 => 12,  79 => 11,  75 => 10,  70 => 9,  68 => 0,  64 => 8,  60 => 0,  57 => 1,  52 => 102,  50 => 101,  48 => 100,  46 => 5,  44 => 3,  42 => 0,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends \"_layouts/cp\" %}

{% set fullPageForm = true %}

{% import \"_includes/forms\" as forms %}


{% block content %}
        {{ actionInput('volumes/save-volume') }}
        {{ redirectInput('settings/assets') }}
        {% if not isNewVolume %}{{ hiddenInput('volumeId', volume.id) }}{% endif %}

        <div id=\"assetvolume-settings\">
            {{ forms.textField({
                first: true,
                label: \"Name\"|t('app'),
                id: 'name',
                name: 'name',
                value: (volume is defined ? volume.name : null),
                errors: (volume is defined ? volume.getErrors('name') : null),
                autofocus: true,
                required: true,
            }) }}

            {{ forms.textField({
                first: true,
                label: \"Handle\"|t('app'),
                id: 'handle',
                name: 'handle',
                class: 'code',
                autocorrect: false,
                autocapitalize: false,
                value: (volume is defined ? volume.handle : null),
                errors: (volume is defined ? volume.getErrors('handle') : null),
                required: true,
            }) }}

            {{ forms.lightswitchField({
                label: \"Assets in this volume have public URLs\"|t('app'),
                name: 'hasUrls',
                on:   volume.hasUrls,
                toggle: \"url-field\"
            }) }}

            <div id=\"url-field\" class=\"{% if not volume.hasUrls %}hidden{% endif %}\">
                {{ forms.autosuggestField({
                    label: \"Base URL\"|t('app'),
                    instructions: \"The base URL to the assets in this volume.\"|t('app'),
                    id: 'url',
                    class: 'ltr volume-url',
                    name: 'url',
                    suggestEnvVars: true,
                    suggestAliases: true,
                    value: (volume is defined ? volume.url : null),
                    errors: (volume is defined ? volume.getErrors('url') : null),
                    required: true,
                    placeholder: \"//example.com/path/to/folder\"
                }) }}
            </div>

            <hr>

            {{ forms.selectField({
                label: \"Volume Type\"|t('app'),
                instructions: \"What type of volume is this?\"|t('app'),
                id: 'type',
                name: 'type',
                options: volumeTypeOptions,
                value: className(volume),
                toggle: true
            }) }}

            {{ missingVolumePlaceholder|raw }}

            {% for volumeType in volumeTypes %}
                {% set isCurrent = (volumeType == className(volume)) %}

                <div id=\"{{ volumeType|id }}\"{% if not isCurrent %} class=\"hidden\"{% endif %}>
                    {% namespace 'types['~volumeType~']' %}
                        {% if isCurrent %}
                            {{ volume.getSettingsHtml()|raw }}
                        {% else %}
                            {{ volumeInstances[volumeType].getSettingsHtml()|raw }}
                        {% endif %}
                    {% endnamespace %}
                </div>
            {% endfor %}
        </div>

        <div id=\"assetvolume-fieldlayout\" class=\"hidden\">
            {% include \"_includes/fieldlayoutdesigner\" with {
                fieldLayout: volume.getFieldLayout(),
                customizableTabs: true,
                tab: 'fieldlayout'
            } only %}
        </div>
{% endblock %}


{% if volume is not defined or not volume.handle %}
    {% js %}
        new Craft.HandleGenerator('#name', '#handle');
    {% endjs %}
{% endif %}
", "settings/assets/volumes/_edit", "/Applications/MAMP/htdocs/craft/smsi/vendor/craftcms/cms/src/templates/settings/assets/volumes/_edit.html");
    }
}
