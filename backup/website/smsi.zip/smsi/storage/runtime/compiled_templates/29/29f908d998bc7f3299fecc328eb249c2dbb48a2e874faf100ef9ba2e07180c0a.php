<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* settings/assets/transforms/_settings */
class __TwigTemplate_9b51b8f92c1cda8e4f0e38aed762a11dddc4d193b60706ecf17d80d7932922ec extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "_layouts/cp";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("template", "settings/assets/transforms/_settings");
        // line 3
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms", "settings/assets/transforms/_settings", 3)->unwrap();
        // line 5
        $context["crumbs"] = [0 => ["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Settings", "app"), "url" => craft\helpers\UrlHelper::url("settings")], 1 => ["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Assets", "app"), "url" => craft\helpers\UrlHelper::url("settings/assets")], 2 => ["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Image Transforms", "app"), "url" => craft\helpers\UrlHelper::url("settings/assets/transforms")]];
        // line 11
        $context["fullPageForm"] = true;
        // line 155
        ob_start();
        // line 156
        echo "    ";
        if (( !(isset($context["transform"]) || array_key_exists("transform", $context)) ||  !craft\helpers\Template::attribute($this->env, $this->source, (isset($context["transform"]) || array_key_exists("transform", $context) ? $context["transform"] : (function () { throw new RuntimeError('Variable "transform" does not exist.', 156, $this->source); })()), "handle", []))) {
            echo "new Craft.HandleGenerator('#name', '#handle');";
        }
        // line 157
        echo "
    \$('#mode input').change(function()
    {
        if (\$(this).val() == 'crop')
        {
            \$('#position-container').removeClass('hidden');
        }
        else
        {
            \$('#position-container').addClass('hidden');
        }
    })
";
        Craft::$app->getView()->registerJs(ob_get_clean(), 3);
        // line 1
        $this->parent = $this->loadTemplate("_layouts/cp", "settings/assets/transforms/_settings", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        // line 0
        craft\helpers\Template::endProfile("template", "settings/assets/transforms/_settings");
    }

    // line 14
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("block", "content");
        // line 15
        echo "        ";
        echo craft\helpers\Html::actionInput("asset-transforms/save-transform");
        echo "
        ";
        // line 16
        echo craft\helpers\Html::redirectInput("settings/assets/transforms");
        echo "

        ";
        // line 18
        if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["transform"]) || array_key_exists("transform", $context) ? $context["transform"] : (function () { throw new RuntimeError('Variable "transform" does not exist.', 18, $this->source); })()), "id", [])) {
            echo craft\helpers\Html::hiddenInput("transformId", craft\helpers\Template::attribute($this->env, $this->source, (isset($context["transform"]) || array_key_exists("transform", $context) ? $context["transform"] : (function () { throw new RuntimeError('Variable "transform" does not exist.', 18, $this->source); })()), "id", []));
        }
        // line 19
        echo "
        ";
        // line 20
        echo twig_call_macro($macros["forms"], "macro_textField", [["first" => true, "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Name", "app"), "id" => "name", "name" => "name", "value" => ((        // line 25
(isset($context["transform"]) || array_key_exists("transform", $context))) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["transform"]) || array_key_exists("transform", $context) ? $context["transform"] : (function () { throw new RuntimeError('Variable "transform" does not exist.', 25, $this->source); })()), "name", [])) : (null)), "errors" => ((        // line 26
(isset($context["transform"]) || array_key_exists("transform", $context))) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["transform"]) || array_key_exists("transform", $context) ? $context["transform"] : (function () { throw new RuntimeError('Variable "transform" does not exist.', 26, $this->source); })()), "getErrors", [0 => "name"], "method")) : (null)), "autofocus" => true, "required" => true]], 20, $context, $this->getSourceContext());
        // line 29
        echo "

        ";
        // line 31
        echo twig_call_macro($macros["forms"], "macro_textField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Handle", "app"), "id" => "handle", "name" => "handle", "class" => "code", "autocorrect" => false, "autocapitalize" => false, "value" => ((        // line 38
(isset($context["transform"]) || array_key_exists("transform", $context))) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["transform"]) || array_key_exists("transform", $context) ? $context["transform"] : (function () { throw new RuntimeError('Variable "transform" does not exist.', 38, $this->source); })()), "handle", [])) : (null)), "errors" => ((        // line 39
(isset($context["transform"]) || array_key_exists("transform", $context))) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["transform"]) || array_key_exists("transform", $context) ? $context["transform"] : (function () { throw new RuntimeError('Variable "transform" does not exist.', 39, $this->source); })()), "getErrors", [0 => "handle"], "method")) : (null)), "required" => true]], 31, $context, $this->getSourceContext());
        // line 41
        echo "

        ";
        // line 43
        ob_start();
        // line 44
        echo "            <div id=\"mode\">
                <label id=\"mode-crop\">
                    <input type=\"radio\" name=\"mode\" value=\"crop\"";
        // line 46
        if (( !(isset($context["transform"]) || array_key_exists("transform", $context)) || (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["transform"]) || array_key_exists("transform", $context) ? $context["transform"] : (function () { throw new RuntimeError('Variable "transform" does not exist.', 46, $this->source); })()), "mode", []) == "crop"))) {
            echo " checked";
        }
        echo ">
                    ";
        // line 47
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Crop", "app"), "html", null, true);
        echo "
                </label>

                <label id=\"mode-fit\">
                    <input type=\"radio\" name=\"mode\" value=\"fit\"";
        // line 51
        if (((isset($context["transform"]) || array_key_exists("transform", $context)) && (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["transform"]) || array_key_exists("transform", $context) ? $context["transform"] : (function () { throw new RuntimeError('Variable "transform" does not exist.', 51, $this->source); })()), "mode", []) == "fit"))) {
            echo " checked";
        }
        echo ">
                    ";
        // line 52
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Fit", "app"), "html", null, true);
        echo "
                </label>

                <label id=\"mode-stretch\">
                    <input type=\"radio\" name=\"mode\" value=\"stretch\"";
        // line 56
        if (((isset($context["transform"]) || array_key_exists("transform", $context)) && (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["transform"]) || array_key_exists("transform", $context) ? $context["transform"] : (function () { throw new RuntimeError('Variable "transform" does not exist.', 56, $this->source); })()), "mode", []) == "stretch"))) {
            echo " checked";
        }
        echo ">
                    ";
        // line 57
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Stretch", "app"), "html", null, true);
        echo "
                </label>
            </div>
        ";
        $context["modeInput"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 61
        echo "
        ";
        // line 62
        echo twig_call_macro($macros["forms"], "macro_field", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Mode", "app")],         // line 64
(isset($context["modeInput"]) || array_key_exists("modeInput", $context) ? $context["modeInput"] : (function () { throw new RuntimeError('Variable "modeInput" does not exist.', 64, $this->source); })())], 62, $context, $this->getSourceContext());
        echo "

        <div id=\"position-container\"";
        // line 66
        if (((isset($context["transform"]) || array_key_exists("transform", $context)) && (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["transform"]) || array_key_exists("transform", $context) ? $context["transform"] : (function () { throw new RuntimeError('Variable "transform" does not exist.', 66, $this->source); })()), "mode", []) != "crop"))) {
            echo " class=\"hidden\"";
        }
        echo ">
            ";
        // line 67
        echo twig_call_macro($macros["forms"], "macro_selectField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Default Focal Point", "app"), "id" => "position", "name" => "position", "options" => ["top-left" => $this->extensions['craft\web\twig\Extension']->translateFilter("Top-Left", "app"), "top-center" => $this->extensions['craft\web\twig\Extension']->translateFilter("Top-Center", "app"), "top-right" => $this->extensions['craft\web\twig\Extension']->translateFilter("Top-Right", "app"), "center-left" => $this->extensions['craft\web\twig\Extension']->translateFilter("Center-Left", "app"), "center-center" => $this->extensions['craft\web\twig\Extension']->translateFilter("Center-Center", "app"), "center-right" => $this->extensions['craft\web\twig\Extension']->translateFilter("Center-Right", "app"), "bottom-left" => $this->extensions['craft\web\twig\Extension']->translateFilter("Bottom-Left", "app"), "bottom-center" => $this->extensions['craft\web\twig\Extension']->translateFilter("Bottom-Center", "app"), "bottom-right" => $this->extensions['craft\web\twig\Extension']->translateFilter("Bottom-Right", "app")], "value" => (((        // line 82
(isset($context["transform"]) || array_key_exists("transform", $context)) && (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["transform"]) || array_key_exists("transform", $context) ? $context["transform"] : (function () { throw new RuntimeError('Variable "transform" does not exist.', 82, $this->source); })()), "mode", []) == "crop"))) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["transform"]) || array_key_exists("transform", $context) ? $context["transform"] : (function () { throw new RuntimeError('Variable "transform" does not exist.', 82, $this->source); })()), "position", [])) : ("center-center"))]], 67, $context, $this->getSourceContext());
        // line 83
        echo "
        </div>

        ";
        // line 86
        echo twig_call_macro($macros["forms"], "macro_textField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Width", "app"), "id" => "width", "name" => "width", "size" => 5, "value" => ((        // line 91
(isset($context["transform"]) || array_key_exists("transform", $context))) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["transform"]) || array_key_exists("transform", $context) ? $context["transform"] : (function () { throw new RuntimeError('Variable "transform" does not exist.', 91, $this->source); })()), "width", [])) : (null)), "errors" => ((        // line 92
(isset($context["transform"]) || array_key_exists("transform", $context))) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["transform"]) || array_key_exists("transform", $context) ? $context["transform"] : (function () { throw new RuntimeError('Variable "transform" does not exist.', 92, $this->source); })()), "getErrors", [0 => "width"], "method")) : (null))]], 86, $context, $this->getSourceContext());
        // line 93
        echo "

        ";
        // line 95
        echo twig_call_macro($macros["forms"], "macro_textField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Height", "app"), "id" => "height", "name" => "height", "size" => 5, "value" => ((        // line 100
(isset($context["transform"]) || array_key_exists("transform", $context))) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["transform"]) || array_key_exists("transform", $context) ? $context["transform"] : (function () { throw new RuntimeError('Variable "transform" does not exist.', 100, $this->source); })()), "height", [])) : (null)), "errors" => ((        // line 101
(isset($context["transform"]) || array_key_exists("transform", $context))) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["transform"]) || array_key_exists("transform", $context) ? $context["transform"] : (function () { throw new RuntimeError('Variable "transform" does not exist.', 101, $this->source); })()), "getErrors", [0 => "height"], "method")) : (null))]], 95, $context, $this->getSourceContext());
        // line 102
        echo "

        ";
        // line 104
        echo twig_call_macro($macros["forms"], "macro_selectField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Quality", "app"), "id" => "quality", "name" => "quality", "options" => ["0" => $this->extensions['craft\web\twig\Extension']->translateFilter("Auto", "app"), "10" => $this->extensions['craft\web\twig\Extension']->translateFilter("Low", "app"), "30" => $this->extensions['craft\web\twig\Extension']->translateFilter("Medium", "app"), "60" => $this->extensions['craft\web\twig\Extension']->translateFilter("High", "app"), "82" => $this->extensions['craft\web\twig\Extension']->translateFilter("Very High (Recommended)", "app"), "100" => $this->extensions['craft\web\twig\Extension']->translateFilter("Maximum", "app")], "value" => ((        // line 116
(isset($context["transform"]) || array_key_exists("transform", $context))) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["transform"]) || array_key_exists("transform", $context) ? $context["transform"] : (function () { throw new RuntimeError('Variable "transform" does not exist.', 116, $this->source); })()), "quality", [])) : (82)), "errors" => ((        // line 117
(isset($context["transform"]) || array_key_exists("transform", $context))) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["transform"]) || array_key_exists("transform", $context) ? $context["transform"] : (function () { throw new RuntimeError('Variable "transform" does not exist.', 117, $this->source); })()), "getErrors", [0 => "quality"], "method")) : (null))]], 104, $context, $this->getSourceContext());
        // line 118
        echo "

        ";
        // line 120
        echo twig_call_macro($macros["forms"], "macro_selectField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Interlacing", "app"), "id" => "interlace", "name" => "interlace", "options" => ["none" => $this->extensions['craft\web\twig\Extension']->translateFilter("None", "app"), "line" => $this->extensions['craft\web\twig\Extension']->translateFilter("Line", "app"), "plane" => $this->extensions['craft\web\twig\Extension']->translateFilter("Plane", "app"), "partition" => $this->extensions['craft\web\twig\Extension']->translateFilter("Partition", "app")], "value" => ((        // line 130
(isset($context["transform"]) || array_key_exists("transform", $context))) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["transform"]) || array_key_exists("transform", $context) ? $context["transform"] : (function () { throw new RuntimeError('Variable "transform" does not exist.', 130, $this->source); })()), "interlace", [])) : ("none")), "errors" => ((        // line 131
(isset($context["transform"]) || array_key_exists("transform", $context))) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["transform"]) || array_key_exists("transform", $context) ? $context["transform"] : (function () { throw new RuntimeError('Variable "transform" does not exist.', 131, $this->source); })()), "getErrors", [0 => "interlace"], "method")) : (null))]], 120, $context, $this->getSourceContext());
        // line 132
        echo "

        ";
        // line 134
        $context["formatOptions"] = [0 => ["label" => "Auto", "value" => null], 1 => ["label" => "jpg", "value" => "jpg"], 2 => ["label" => "png", "value" => "png"], 3 => ["label" => "gif", "value" => "gif"]];
        // line 140
        echo "
        ";
        // line 141
        echo twig_call_macro($macros["forms"], "macro_selectField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Image Format", "app"), "id" => "format", "name" => "format", "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("The image format that transformed images should use.", "app"), "value" => ((        // line 146
(isset($context["transform"]) || array_key_exists("transform", $context))) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["transform"]) || array_key_exists("transform", $context) ? $context["transform"] : (function () { throw new RuntimeError('Variable "transform" does not exist.', 146, $this->source); })()), "format", [])) : (null)), "errors" => ((        // line 147
(isset($context["transform"]) || array_key_exists("transform", $context))) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["transform"]) || array_key_exists("transform", $context) ? $context["transform"] : (function () { throw new RuntimeError('Variable "transform" does not exist.', 147, $this->source); })()), "getErrors", [0 => "format"], "method")) : (null)), "options" =>         // line 148
(isset($context["formatOptions"]) || array_key_exists("formatOptions", $context) ? $context["formatOptions"] : (function () { throw new RuntimeError('Variable "formatOptions" does not exist.', 148, $this->source); })())]], 141, $context, $this->getSourceContext());
        // line 149
        echo "


";
        // line 0
        craft\helpers\Template::endProfile("block", "content");
    }

    public function getTemplateName()
    {
        return "settings/assets/transforms/_settings";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  233 => 0,  228 => 149,  226 => 148,  225 => 147,  224 => 146,  223 => 141,  220 => 140,  218 => 134,  214 => 132,  212 => 131,  211 => 130,  210 => 120,  206 => 118,  204 => 117,  203 => 116,  202 => 104,  198 => 102,  196 => 101,  195 => 100,  194 => 95,  190 => 93,  188 => 92,  187 => 91,  186 => 86,  181 => 83,  179 => 82,  178 => 67,  172 => 66,  167 => 64,  166 => 62,  163 => 61,  156 => 57,  150 => 56,  143 => 52,  137 => 51,  130 => 47,  124 => 46,  120 => 44,  118 => 43,  114 => 41,  112 => 39,  111 => 38,  110 => 31,  106 => 29,  104 => 26,  103 => 25,  102 => 20,  99 => 19,  95 => 18,  90 => 16,  85 => 15,  83 => 0,  79 => 14,  75 => 0,  72 => 1,  57 => 157,  52 => 156,  50 => 155,  48 => 11,  46 => 5,  44 => 3,  42 => 0,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends \"_layouts/cp\" %}

{% import \"_includes/forms\" as forms %}

{% set crumbs = [
    { label: \"Settings\"|t('app'), url: url('settings') },
    { label: \"Assets\"|t('app'), url: url('settings/assets') },
    { label: \"Image Transforms\"|t('app'), url: url('settings/assets/transforms') }
] %}

{% set fullPageForm = true %}


{% block content %}
        {{ actionInput('asset-transforms/save-transform') }}
        {{ redirectInput('settings/assets/transforms') }}

        {% if transform.id %}{{ hiddenInput('transformId', transform.id) }}{% endif %}

        {{ forms.textField({
            first: true,
            label: \"Name\"|t('app'),
            id: 'name',
            name: 'name',
            value: (transform is defined ? transform.name : null),
            errors: (transform is defined ? transform.getErrors('name') : null),
            autofocus: true,
            required: true,
        }) }}

        {{ forms.textField({
            label: \"Handle\"|t('app'),
            id: \"handle\",
            name: \"handle\",
            class: 'code',
            autocorrect: false,
            autocapitalize: false,
            value: (transform is defined ? transform.handle : null),
            errors: (transform is defined ? transform.getErrors('handle') : null),
            required: true,
        }) }}

        {% set modeInput %}
            <div id=\"mode\">
                <label id=\"mode-crop\">
                    <input type=\"radio\" name=\"mode\" value=\"crop\"{% if transform is not defined or transform.mode == 'crop' %} checked{% endif %}>
                    {{ \"Crop\"|t('app') }}
                </label>

                <label id=\"mode-fit\">
                    <input type=\"radio\" name=\"mode\" value=\"fit\"{% if transform is defined and transform.mode == 'fit' %} checked{% endif %}>
                    {{ \"Fit\"|t('app') }}
                </label>

                <label id=\"mode-stretch\">
                    <input type=\"radio\" name=\"mode\" value=\"stretch\"{% if transform is defined and transform.mode == 'stretch' %} checked{% endif %}>
                    {{ \"Stretch\"|t('app') }}
                </label>
            </div>
        {% endset %}

        {{ forms.field({
            label: \"Mode\"|t('app')
        }, modeInput) }}

        <div id=\"position-container\"{% if transform is defined and transform.mode != 'crop' %} class=\"hidden\"{% endif %}>
            {{ forms.selectField({
                label: \"Default Focal Point\"|t('app'),
                id: 'position',
                name: 'position',
                options: {
                    'top-left': \"Top-Left\"|t('app'),
                    'top-center': \"Top-Center\"|t('app'),
                    'top-right': \"Top-Right\"|t('app'),
                    'center-left': \"Center-Left\"|t('app'),
                    'center-center': \"Center-Center\"|t('app'),
                    'center-right': \"Center-Right\"|t('app'),
                    'bottom-left': \"Bottom-Left\"|t('app'),
                    'bottom-center': \"Bottom-Center\"|t('app'),
                    'bottom-right': \"Bottom-Right\"|t('app')
                },
                value: (transform is defined and transform.mode == 'crop' ? transform.position : 'center-center')
            }) }}
        </div>

        {{ forms.textField({
            label: \"Width\"|t('app'),
            id: \"width\",
            name: \"width\",
            size: 5,
            value: (transform is defined ? transform.width : null),
            errors: (transform is defined ? transform.getErrors('width') : null),
        }) }}

        {{ forms.textField({
            label: \"Height\"|t('app'),
            id: \"height\",
            name: \"height\",
            size: 5,
            value: (transform is defined ? transform.height : null),
            errors: (transform is defined ? transform.getErrors('height') : null),
        }) }}

        {{ forms.selectField({
            label: \"Quality\"|t('app'),
            id: \"quality\",
            name: \"quality\",
            options: {
                '0': \"Auto\"|t('app'),
                '10': \"Low\"|t('app'),
                '30': \"Medium\"|t('app'),
                '60': \"High\"|t('app'),
                '82': \"Very High (Recommended)\"|t('app'),
                '100': \"Maximum\"|t('app')
            },
            value: (transform is defined ? transform.quality : 82),
            errors: (transform is defined ? transform.getErrors('quality') : null),
        }) }}

        {{ forms.selectField({
            label: \"Interlacing\"|t('app'),
            id: \"interlace\",
            name: \"interlace\",
            options: {
                'none': \"None\"|t('app'),
                'line': \"Line\"|t('app'),
                'plane': \"Plane\"|t('app'),
                'partition': \"Partition\"|t('app')
            },
            value: (transform is defined ? transform.interlace : 'none'),
            errors: (transform is defined ? transform.getErrors('interlace') : null),
        }) }}

        {% set formatOptions = [
            {label: 'Auto', value: null},
            {label: 'jpg', value: 'jpg'},
            {label: 'png', value: 'png'},
            {label: 'gif', value: 'gif'},
        ] %}

        {{ forms.selectField({
            label: \"Image Format\"|t('app'),
            id: \"format\",
            name: \"format\",
            instructions: \"The image format that transformed images should use.\"|t('app'),
            value: (transform is defined ? transform.format : null),
            errors: (transform is defined ? transform.getErrors('format') : null),
            options: formatOptions,
        }) }}


{% endblock %}


{% js %}
    {% if transform is not defined or not transform.handle %}new Craft.HandleGenerator('#name', '#handle');{% endif %}

    \$('#mode input').change(function()
    {
        if (\$(this).val() == 'crop')
        {
            \$('#position-container').removeClass('hidden');
        }
        else
        {
            \$('#position-container').addClass('hidden');
        }
    })
{% endjs %}
", "settings/assets/transforms/_settings", "/Applications/MAMP/htdocs/craft/smsi/vendor/craftcms/cms/src/templates/settings/assets/transforms/_settings.html");
    }
}
