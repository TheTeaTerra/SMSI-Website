<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* globals/_edit */
class __TwigTemplate_e14e7c476d05f1c0d59b12401befc1995c67033f8aced13bf18e14e501d1bf37 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'contextMenu' => [$this, 'block_contextMenu'],
            'sidebar' => [$this, 'block_sidebar'],
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "_layouts/cp";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("template", "globals/_edit");
        // line 2
        $context["title"] = $this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["globalSet"]) || array_key_exists("globalSet", $context) ? $context["globalSet"] : (function () { throw new RuntimeError('Variable "globalSet" does not exist.', 2, $this->source); })()), "name", []), "site");
        // line 3
        $context["fullPageForm"] = true;
        // line 5
        echo \Craft::$app->getView()->invokeHook("cp.globals.edit", $context);

        // line 1
        $this->parent = $this->loadTemplate("_layouts/cp", "globals/_edit", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        // line 0
        craft\helpers\Template::endProfile("template", "globals/_edit");
    }

    // line 7
    public function block_contextMenu($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("block", "contextMenu");
        // line 8
        echo "    ";
        if (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 8, $this->source); })()), "app", []), "getIsMultiSite", [], "method")) {
            // line 9
            echo "        ";
            $this->loadTemplate("_elements/sitemenu", "globals/_edit", 9)->display(twig_array_merge($context, ["selectedSiteId" => craft\helpers\Template::attribute($this->env, $this->source,             // line 10
(isset($context["globalSet"]) || array_key_exists("globalSet", $context) ? $context["globalSet"] : (function () { throw new RuntimeError('Variable "globalSet" does not exist.', 10, $this->source); })()), "siteId", []), "urlFormat" => ("globals/{handle}/" . craft\helpers\Template::attribute($this->env, $this->source,             // line 11
(isset($context["globalSet"]) || array_key_exists("globalSet", $context) ? $context["globalSet"] : (function () { throw new RuntimeError('Variable "globalSet" does not exist.', 11, $this->source); })()), "handle", []))]));
            // line 13
            echo "    ";
        }
        // line 0
        craft\helpers\Template::endProfile("block", "contextMenu");
    }

    // line 17
    public function block_sidebar($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("block", "sidebar");
        // line 18
        echo "    <nav>
        <ul>
            ";
        // line 20
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["editableGlobalSets"]) || array_key_exists("editableGlobalSets", $context) ? $context["editableGlobalSets"] : (function () { throw new RuntimeError('Variable "editableGlobalSets" does not exist.', 20, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["theGlobalSet"]) {
            // line 21
            echo "                <li><a";
            if ((craft\helpers\Template::attribute($this->env, $this->source, $context["theGlobalSet"], "handle", []) == craft\helpers\Template::attribute($this->env, $this->source, (isset($context["globalSet"]) || array_key_exists("globalSet", $context) ? $context["globalSet"] : (function () { throw new RuntimeError('Variable "globalSet" does not exist.', 21, $this->source); })()), "handle", []))) {
                echo " class=\"sel\"";
            }
            echo " href=\"";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["theGlobalSet"], "getCpEditUrl", [], "method"), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source, $context["theGlobalSet"], "name", []), "site"), "html", null, true);
            echo "</a></li>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['theGlobalSet'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 23
        echo "        </ul>
    </nav>
";
        // line 0
        craft\helpers\Template::endProfile("block", "sidebar");
    }

    // line 28
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("block", "content");
        // line 29
        echo "    ";
        echo craft\helpers\Html::actionInput("globals/save-content");
        echo "
    ";
        // line 30
        echo craft\helpers\Html::hiddenInput("setId", craft\helpers\Template::attribute($this->env, $this->source, (isset($context["globalSet"]) || array_key_exists("globalSet", $context) ? $context["globalSet"] : (function () { throw new RuntimeError('Variable "globalSet" does not exist.', 30, $this->source); })()), "id", []));
        echo "
    ";
        // line 31
        echo craft\helpers\Html::hiddenInput("siteId", craft\helpers\Template::attribute($this->env, $this->source, (isset($context["globalSet"]) || array_key_exists("globalSet", $context) ? $context["globalSet"] : (function () { throw new RuntimeError('Variable "globalSet" does not exist.', 31, $this->source); })()), "siteId", []));
        echo "
    ";
        // line 32
        echo craft\helpers\Html::csrfInput();
        echo "

    ";
        // line 34
        if (twig_length_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["globalSet"]) || array_key_exists("globalSet", $context) ? $context["globalSet"] : (function () { throw new RuntimeError('Variable "globalSet" does not exist.', 34, $this->source); })()), "getFieldLayout", [], "method"), "getFields", [], "method"))) {
            // line 35
            echo "        <div>
            ";
            // line 36
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["globalSet"]) || array_key_exists("globalSet", $context) ? $context["globalSet"] : (function () { throw new RuntimeError('Variable "globalSet" does not exist.', 36, $this->source); })()), "getFieldLayout", [], "method"), "getTabs", [], "method"));
            $context['loop'] = [
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            ];
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["tab"]) {
                // line 37
                echo "                <div id=\"";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["tab"], "getHtmlId", [], "method"), "html", null, true);
                echo "\"";
                if ( !craft\helpers\Template::attribute($this->env, $this->source, $context["loop"], "first", [])) {
                    echo " class=\"hidden\"";
                }
                echo ">
                    ";
                // line 38
                $this->loadTemplate("_includes/fields", "globals/_edit", 38)->display(twig_to_array(["fields" => craft\helpers\Template::attribute($this->env, $this->source,                 // line 39
$context["tab"], "getFields", [], "method"), "element" =>                 // line 40
(isset($context["globalSet"]) || array_key_exists("globalSet", $context) ? $context["globalSet"] : (function () { throw new RuntimeError('Variable "globalSet" does not exist.', 40, $this->source); })())]));
                // line 42
                echo "                </div>
            ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['length'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['tab'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 44
            echo "        </div>
    ";
        } else {
            // line 46
            echo "        ";
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("This global set doesn’t have any fields assigned to it in its field layout.", "app"), "html", null, true);
            echo "
    ";
        }
        // line 48
        echo "
    ";
        // line 50
        echo "    ";
        echo \Craft::$app->getView()->invokeHook("cp.globals.edit.content", $context);

        // line 0
        craft\helpers\Template::endProfile("block", "content");
    }

    public function getTemplateName()
    {
        return "globals/_edit";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  209 => 0,  205 => 50,  202 => 48,  196 => 46,  192 => 44,  177 => 42,  175 => 40,  174 => 39,  173 => 38,  164 => 37,  147 => 36,  144 => 35,  142 => 34,  137 => 32,  133 => 31,  129 => 30,  124 => 29,  122 => 0,  118 => 28,  114 => 0,  110 => 23,  95 => 21,  91 => 20,  87 => 18,  85 => 0,  81 => 17,  77 => 0,  74 => 13,  72 => 11,  71 => 10,  69 => 9,  66 => 8,  64 => 0,  60 => 7,  56 => 0,  53 => 1,  50 => 5,  48 => 3,  46 => 2,  44 => 0,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends \"_layouts/cp\" %}
{% set title = globalSet.name|t('site') %}
{% set fullPageForm = true %}

{% hook \"cp.globals.edit\" %}

{% block contextMenu %}
    {% if craft.app.getIsMultiSite() %}
        {% include \"_elements/sitemenu\" with {
            selectedSiteId: globalSet.siteId,
            urlFormat: \"globals/{handle}/#{globalSet.handle}\"
        } %}
    {% endif %}
{% endblock %}


{% block sidebar %}
    <nav>
        <ul>
            {% for theGlobalSet in editableGlobalSets %}
                <li><a{% if theGlobalSet.handle == globalSet.handle %} class=\"sel\"{% endif %} href=\"{{ theGlobalSet.getCpEditUrl() }}\">{{ theGlobalSet.name|t('site') }}</a></li>
            {% endfor %}
        </ul>
    </nav>
{% endblock %}


{% block content %}
    {{ actionInput('globals/save-content') }}
    {{ hiddenInput('setId', globalSet.id) }}
    {{ hiddenInput('siteId', globalSet.siteId) }}
    {{ csrfInput() }}

    {% if globalSet.getFieldLayout().getFields() | length %}
        <div>
            {% for tab in globalSet.getFieldLayout().getTabs() %}
                <div id=\"{{ tab.getHtmlId() }}\"{% if not loop.first %} class=\"hidden\"{% endif %}>
                    {% include \"_includes/fields\" with {
                        fields:  tab.getFields(),
                        element: globalSet
                    } only %}
                </div>
            {% endfor %}
        </div>
    {% else %}
        {{ \"This global set doesn’t have any fields assigned to it in its field layout.\"|t('app') }}
    {% endif %}

    {# Give plugins a chance to add other things here #}
    {% hook \"cp.globals.edit.content\" %}
{% endblock %}
", "globals/_edit", "/Applications/MAMP/htdocs/craft/smsi/vendor/craftcms/cms/src/templates/globals/_edit.html");
    }
}
