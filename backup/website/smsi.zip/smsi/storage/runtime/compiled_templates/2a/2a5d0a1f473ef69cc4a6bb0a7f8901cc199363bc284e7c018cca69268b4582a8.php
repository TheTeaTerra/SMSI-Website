<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* __string_template__af8d6e2c311375f7973a279c0465f76ef9e52beef2738d374a222bcbb7c08954 */
class __TwigTemplate_b2507135f856a0cee1efb43d0f9d78d30a822da746cbd8c3d1fd8050babc4e06 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "__string_template__af8d6e2c311375f7973a279c0465f76ef9e52beef2738d374a222bcbb7c08954");
        // line 1
        echo "portfolio-category/";
        echo (((craft\helpers\Template::attribute($this->env, $this->source, ($context["_variables"] ?? null), "slug", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["_variables"] ?? null), "slug", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["_variables"] ?? null), "slug", [])) : (craft\helpers\Template::attribute($this->env, $this->source, ($context["object"] ?? null), "slug", [])));
        // line 0
        craft\helpers\Template::endProfile("template", "__string_template__af8d6e2c311375f7973a279c0465f76ef9e52beef2738d374a222bcbb7c08954");
    }

    public function getTemplateName()
    {
        return "__string_template__af8d6e2c311375f7973a279c0465f76ef9e52beef2738d374a222bcbb7c08954";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  41 => 0,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("portfolio-category/{{ (_variables.slug ?? object.slug)|raw }}", "__string_template__af8d6e2c311375f7973a279c0465f76ef9e52beef2738d374a222bcbb7c08954", "");
    }
}
