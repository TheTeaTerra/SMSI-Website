<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _singles/about */
class __TwigTemplate_2834716baf5424157ac887508a50675525fcaedac918c97bc1a65c2289f7c4e9 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_singles/about");
        // line 1
        echo "<section id=\"about\" class=\"about\" data-aos=\"fade-up\">
";
        // line 2
        $context["abouts"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 2, $this->source); })()), "entries", []), "section", [0 => "about"], "method"), "all", [], "method");
        // line 3
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["abouts"]) || array_key_exists("abouts", $context) ? $context["abouts"] : (function () { throw new RuntimeError('Variable "abouts" does not exist.', 3, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["about"]) {
            // line 4
            echo "    <div class=\"container\">
        <div class=\"section-title\">
            <h2>";
            // line 6
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["about"], "title", []), "html", null, true);
            echo "</h2>
            <p>";
            // line 7
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["about"], "body", []), "html", null, true);
            echo "</p>
        </div>
        <div class=\"row content\">
        ";
            // line 10
            $context["aboutBody"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, $context["about"], "postContent", []), "all", [], "method");
            // line 11
            echo "        ";
            if (twig_length_filter($this->env, (isset($context["aboutBody"]) || array_key_exists("aboutBody", $context) ? $context["aboutBody"] : (function () { throw new RuntimeError('Variable "aboutBody" does not exist.', 11, $this->source); })()))) {
                // line 12
                echo "            ";
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable((isset($context["aboutBody"]) || array_key_exists("aboutBody", $context) ? $context["aboutBody"] : (function () { throw new RuntimeError('Variable "aboutBody" does not exist.', 12, $this->source); })()));
                $context['loop'] = [
                  'parent' => $context['_parent'],
                  'index0' => 0,
                  'index'  => 1,
                  'first'  => true,
                ];
                if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
                    $length = count($context['_seq']);
                    $context['loop']['revindex0'] = $length - 1;
                    $context['loop']['revindex'] = $length;
                    $context['loop']['length'] = $length;
                    $context['loop']['last'] = 1 === $length;
                }
                foreach ($context['_seq'] as $context["_key"] => $context["block"]) {
                    // line 13
                    echo "                ";
                    if (((craft\helpers\Template::attribute($this->env, $this->source, $context["block"], "type", []) == "text") && (craft\helpers\Template::attribute($this->env, $this->source, $context["loop"], "index", []) == 1))) {
                        // line 14
                        echo "                    <div class=\"col-lg-6\">
                        ";
                        // line 15
                        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["block"], "text", []), "html", null, true);
                        echo "
                    </div> 
                ";
                    } elseif (((craft\helpers\Template::attribute($this->env, $this->source,                     // line 17
$context["block"], "type", []) == "image") && (craft\helpers\Template::attribute($this->env, $this->source, $context["loop"], "index", []) == 2))) {
                        // line 18
                        echo "                    ";
                        $context['_parent'] = $context;
                        $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, $context["block"], "image", []), "all", [], "method"));
                        foreach ($context['_seq'] as $context["_key"] => $context["image"]) {
                            // line 19
                            echo "                        <div class=\"col-lg-6 pt-4 pt-lg-0\">
                            <img src=\"";
                            // line 20
                            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["image"], "getUrl", [0 => (isset($context["medium"]) || array_key_exists("medium", $context) ? $context["medium"] : (function () { throw new RuntimeError('Variable "medium" does not exist.', 20, $this->source); })())], "method"), "html", null, true);
                            echo "\" height=\"";
                            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["image"], "getHeight", [0 => (isset($context["setImage"]) || array_key_exists("setImage", $context) ? $context["setImage"] : (function () { throw new RuntimeError('Variable "setImage" does not exist.', 20, $this->source); })())], "method"), "html", null, true);
                            echo "\" alt=\"";
                            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["image"], "title", []), "html", null, true);
                            echo "\" data-aos=\"zoom-in\" data-aos-delay=\"100\" />
                        </div>
                    ";
                        }
                        $_parent = $context['_parent'];
                        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['image'], $context['_parent'], $context['loop']);
                        $context = array_intersect_key($context, $_parent) + $_parent;
                        // line 23
                        echo "                ";
                    }
                    // line 24
                    echo "                
            ";
                    ++$context['loop']['index0'];
                    ++$context['loop']['index'];
                    $context['loop']['first'] = false;
                    if (isset($context['loop']['length'])) {
                        --$context['loop']['revindex0'];
                        --$context['loop']['revindex'];
                        $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                    }
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['block'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 26
                echo "        ";
            }
            // line 27
            echo "        </div>
    </div>
";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['about'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 30
        echo "</section>


";
        // line 0
        craft\helpers\Template::endProfile("template", "_singles/about");
    }

    public function getTemplateName()
    {
        return "_singles/about";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  152 => 0,  147 => 30,  139 => 27,  136 => 26,  121 => 24,  118 => 23,  105 => 20,  102 => 19,  97 => 18,  95 => 17,  90 => 15,  87 => 14,  84 => 13,  66 => 12,  63 => 11,  61 => 10,  55 => 7,  51 => 6,  47 => 4,  43 => 3,  41 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<section id=\"about\" class=\"about\" data-aos=\"fade-up\">
{% set abouts = craft.entries.section('about').all()  %}
{% for about in abouts %}
    <div class=\"container\">
        <div class=\"section-title\">
            <h2>{{ about.title }}</h2>
            <p>{{ about.body }}</p>
        </div>
        <div class=\"row content\">
        {% set aboutBody = about.postContent.all() %}
        {% if aboutBody | length %}
            {% for block in aboutBody %}
                {% if block.type == 'text' and loop.index == 1 %}
                    <div class=\"col-lg-6\">
                        {{ block.text  }}
                    </div> 
                {% elseif  block.type == 'image' and loop.index == 2 %}
                    {% for image in block.image.all() %}
                        <div class=\"col-lg-6 pt-4 pt-lg-0\">
                            <img src=\"{{ image.getUrl(medium) }}\" height=\"{{ image.getHeight(setImage)  }}\" alt=\"{{ image.title }}\" data-aos=\"zoom-in\" data-aos-delay=\"100\" />
                        </div>
                    {% endfor %}
                {% endif %}
                
            {% endfor %}
        {% endif %}
        </div>
    </div>
{% endfor %}
</section>


", "_singles/about", "/Applications/MAMP/htdocs/craft/smsi/templates/_singles/about.twig");
    }
}
