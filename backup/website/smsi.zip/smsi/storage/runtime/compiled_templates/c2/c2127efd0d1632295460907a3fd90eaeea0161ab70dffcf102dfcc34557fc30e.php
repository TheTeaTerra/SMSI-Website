<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _partials/hero */
class __TwigTemplate_fcc4019e1455fb84f9c8890a44fac9f414a77ab581c44f9f6f0735cc4b3f1f17 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_partials/hero");
        // line 1
        $context["homepage"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 1, $this->source); })()), "entries", []), "section", [0 => "home"], "method");
        // line 2
        $context["firstSegment"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 2, $this->source); })()), "app", []), "request", []), "getSegment", [0 => 1], "method");
        // line 3
        if (((isset($context["firstSegment"]) || array_key_exists("firstSegment", $context) ? $context["firstSegment"] : (function () { throw new RuntimeError('Variable "firstSegment" does not exist.', 3, $this->source); })()) == "")) {
            // line 4
            echo "  ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["homepage"]) || array_key_exists("homepage", $context) ? $context["homepage"] : (function () { throw new RuntimeError('Variable "homepage" does not exist.', 4, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["home"]) {
                // line 5
                echo "    ";
                $context["sliders"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, $context["home"], "sliderBody", []), "all", [], "method");
                // line 6
                echo "    ";
                if (twig_length_filter($this->env, (isset($context["sliders"]) || array_key_exists("sliders", $context) ? $context["sliders"] : (function () { throw new RuntimeError('Variable "sliders" does not exist.', 6, $this->source); })()))) {
                    // line 7
                    echo "      <section id=\"hero\">
        <div id=\"heroCarousel\" class=\"carousel slide carousel-fade\" data-ride=\"carousel\">
          <div class=\"carousel-inner\" role=\"listbox\">
            ";
                    // line 10
                    $context['_parent'] = $context;
                    $context['_seq'] = twig_ensure_traversable((isset($context["sliders"]) || array_key_exists("sliders", $context) ? $context["sliders"] : (function () { throw new RuntimeError('Variable "sliders" does not exist.', 10, $this->source); })()));
                    $context['loop'] = [
                      'parent' => $context['_parent'],
                      'index0' => 0,
                      'index'  => 1,
                      'first'  => true,
                    ];
                    if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
                        $length = count($context['_seq']);
                        $context['loop']['revindex0'] = $length - 1;
                        $context['loop']['revindex'] = $length;
                        $context['loop']['length'] = $length;
                        $context['loop']['last'] = 1 === $length;
                    }
                    foreach ($context['_seq'] as $context["_key"] => $context["slider"]) {
                        // line 11
                        echo "            ";
                        $context["slideImg"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, $context["slider"], "image", []), "one", []), "url", []);
                        // line 12
                        echo "            <!-- Slide 1 -->
            <div class=\"carousel-item ";
                        // line 13
                        echo (((craft\helpers\Template::attribute($this->env, $this->source, $context["loop"], "index", []) == 1)) ? ("active") : (""));
                        echo "\" style=\"background-image: url( ";
                        echo twig_escape_filter($this->env, (isset($context["slideImg"]) || array_key_exists("slideImg", $context) ? $context["slideImg"] : (function () { throw new RuntimeError('Variable "slideImg" does not exist.', 13, $this->source); })()), "html", null, true);
                        echo " );\">
              <div class=\"carousel-container\">
                <div class=\"carousel-content animated fadeInUp\">
                  <h2>";
                        // line 16
                        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["slider"], "heading", []), "html", null, true);
                        echo "</h2>
                    <p>";
                        // line 17
                        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["slider"], "caption", []), "html", null, true);
                        echo " </p>
                    <div class=\"text-center\"><a href=\"\" class=\"btn-get-started\">Read More</a></div>
                </div>
              </div>
            </div>
            ";
                        ++$context['loop']['index0'];
                        ++$context['loop']['index'];
                        $context['loop']['first'] = false;
                        if (isset($context['loop']['length'])) {
                            --$context['loop']['revindex0'];
                            --$context['loop']['revindex'];
                            $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                        }
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['_iterated'], $context['_key'], $context['slider'], $context['_parent'], $context['loop']);
                    $context = array_intersect_key($context, $_parent) + $_parent;
                    // line 23
                    echo "          </div>

          <a class=\"carousel-control-prev\" href=\"#heroCarousel\" role=\"button\" data-slide=\"prev\">
            <span class=\"carousel-control-prev-icon icofont-simple-left\" aria-hidden=\"true\"></span>
            <span class=\"sr-only\">Previous</span>
          </a>

          <a class=\"carousel-control-next\" href=\"#heroCarousel\" role=\"button\" data-slide=\"next\">
            <span class=\"carousel-control-next-icon icofont-simple-right\" aria-hidden=\"true\"></span>
            <span class=\"sr-only\">Next</span>
          </a>

          <ol class=\"carousel-indicators\" id=\"hero-carousel-indicators\"></ol>

        </div>
      </section>
    ";
                } else {
                    // line 40
                    echo "      ";
                    $context["heroBlocks"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, $context["home"], "heroBody", []), "all", [], "method");
                    // line 41
                    echo "      ";
                    if (twig_length_filter($this->env, (isset($context["heroBlocks"]) || array_key_exists("heroBlocks", $context) ? $context["heroBlocks"] : (function () { throw new RuntimeError('Variable "heroBlocks" does not exist.', 41, $this->source); })()))) {
                        // line 42
                        echo "        ";
                        $context['_parent'] = $context;
                        $context['_seq'] = twig_ensure_traversable((isset($context["heroBlocks"]) || array_key_exists("heroBlocks", $context) ? $context["heroBlocks"] : (function () { throw new RuntimeError('Variable "heroBlocks" does not exist.', 42, $this->source); })()));
                        foreach ($context['_seq'] as $context["_key"] => $context["hero"]) {
                            // line 43
                            echo "        <section id=\"hero\" class=\"d-flex flex-column justify-content-center\" style=\"
                    background: url(";
                            // line 44
                            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, $context["hero"], "image", []), "one", [], "method"), "url", []), "html", null, true);
                            echo ") top center;
                    background-attachment: fixed;
                \">
          <div class=\"container\">
            <div class=\"row justify-content-center\">
              <div class=\"col-xl-8\">
                <h1>";
                            // line 50
                            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["hero"], "heading", []), "html", null, true);
                            echo "</h1>
                <h2>";
                            // line 51
                            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["hero"], "subheading", []), "html", null, true);
                            echo "</h2>
                <a href=\"https://www.youtube.com/watch?v=jDDaplaOz7Q\" class=\"venobox play-btn mb-4\" data-vbtype=\"video\"
                  data-autoplay=\"true\"></a>
              </div>
            </div>
          </div>
        </section>
        ";
                        }
                        $_parent = $context['_parent'];
                        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['hero'], $context['_parent'], $context['loop']);
                        $context = array_intersect_key($context, $_parent) + $_parent;
                        // line 59
                        echo "      ";
                    }
                    // line 60
                    echo "    ";
                }
                // line 61
                echo "  ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['home'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
        }
        // line 0
        craft\helpers\Template::endProfile("template", "_partials/hero");
    }

    public function getTemplateName()
    {
        return "_partials/hero";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  188 => 0,  181 => 61,  178 => 60,  175 => 59,  161 => 51,  157 => 50,  148 => 44,  145 => 43,  140 => 42,  137 => 41,  134 => 40,  115 => 23,  95 => 17,  91 => 16,  83 => 13,  80 => 12,  77 => 11,  60 => 10,  55 => 7,  52 => 6,  49 => 5,  44 => 4,  42 => 3,  40 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% set homepage = craft.entries.section('home') %}
{% set firstSegment = craft.app.request.getSegment(1) %}
{% if firstSegment == '' %}
  {% for home in homepage %}
    {% set sliders = home.sliderBody.all() %}
    {% if sliders | length %}
      <section id=\"hero\">
        <div id=\"heroCarousel\" class=\"carousel slide carousel-fade\" data-ride=\"carousel\">
          <div class=\"carousel-inner\" role=\"listbox\">
            {% for slider in sliders %}
            {% set slideImg = slider.image.one.url %}
            <!-- Slide 1 -->
            <div class=\"carousel-item {{ loop.index == 1 ? 'active' : '' }}\" style=\"background-image: url( {{ slideImg   }} );\">
              <div class=\"carousel-container\">
                <div class=\"carousel-content animated fadeInUp\">
                  <h2>{{ slider.heading }}</h2>
                    <p>{{ slider.caption }} </p>
                    <div class=\"text-center\"><a href=\"\" class=\"btn-get-started\">Read More</a></div>
                </div>
              </div>
            </div>
            {% endfor %}
          </div>

          <a class=\"carousel-control-prev\" href=\"#heroCarousel\" role=\"button\" data-slide=\"prev\">
            <span class=\"carousel-control-prev-icon icofont-simple-left\" aria-hidden=\"true\"></span>
            <span class=\"sr-only\">Previous</span>
          </a>

          <a class=\"carousel-control-next\" href=\"#heroCarousel\" role=\"button\" data-slide=\"next\">
            <span class=\"carousel-control-next-icon icofont-simple-right\" aria-hidden=\"true\"></span>
            <span class=\"sr-only\">Next</span>
          </a>

          <ol class=\"carousel-indicators\" id=\"hero-carousel-indicators\"></ol>

        </div>
      </section>
    {% else %}
      {% set heroBlocks = home.heroBody.all() %}
      {% if heroBlocks | length %}
        {% for hero in heroBlocks %}
        <section id=\"hero\" class=\"d-flex flex-column justify-content-center\" style=\"
                    background: url({{ hero.image.one().url }}) top center;
                    background-attachment: fixed;
                \">
          <div class=\"container\">
            <div class=\"row justify-content-center\">
              <div class=\"col-xl-8\">
                <h1>{{ hero.heading }}</h1>
                <h2>{{ hero.subheading }}</h2>
                <a href=\"https://www.youtube.com/watch?v=jDDaplaOz7Q\" class=\"venobox play-btn mb-4\" data-vbtype=\"video\"
                  data-autoplay=\"true\"></a>
              </div>
            </div>
          </div>
        </section>
        {% endfor %}
      {% endif %}
    {% endif %}
  {% endfor %}
{% endif %}", "_partials/hero", "/Applications/MAMP/htdocs/craft/smsi/templates/_partials/hero.twig");
    }
}
