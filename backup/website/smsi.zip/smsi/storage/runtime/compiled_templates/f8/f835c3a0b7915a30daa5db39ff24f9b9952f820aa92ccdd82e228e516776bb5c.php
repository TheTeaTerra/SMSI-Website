<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* settings/fields/_edit */
class __TwigTemplate_1d9a224e351ef02a876b089e5734cb58fc78428c8261462916267ef020847c59 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "_layouts/cp";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("template", "settings/fields/_edit");
        // line 2
        $context["fullPageForm"] = true;
        // line 4
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms", "settings/fields/_edit", 4)->unwrap();
        // line 126
        if ((twig_test_empty((isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 126, $this->source); })())) || twig_test_empty(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 126, $this->source); })()), "handle", [])))) {
            // line 127
            ob_start();
            // line 128
            echo "        new Craft.HandleGenerator('#name', '#handle');
    ";
            Craft::$app->getView()->registerJs(ob_get_clean(), 3);
        }
        // line 132
        ob_start();
        // line 133
        echo "    Craft.supportedTranslationMethods = ";
        echo $this->extensions['craft\web\twig\Extension']->jsonEncodeFilter((isset($context["supportedTranslationMethods"]) || array_key_exists("supportedTranslationMethods", $context) ? $context["supportedTranslationMethods"] : (function () { throw new RuntimeError('Variable "supportedTranslationMethods" does not exist.', 133, $this->source); })()));
        echo ";

    Craft.updateTranslationMethodSettings = function(type, container) {
        var \$container = \$(container);
        if (!Craft.supportedTranslationMethods[type] || Craft.supportedTranslationMethods[type].length == 1) {
            \$container.addClass('hidden');
        } else {
            \$container.removeClass('hidden');
            // Rebuild the options based on the field type's supported translation methods
            \$container.find('select').html(
                (\$.inArray('none', Craft.supportedTranslationMethods[type]) != -1 ? '<option value=\"none\">";
        // line 143
        echo twig_escape_filter($this->env, twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Not translatable", "app"), "js"), "html", null, true);
        echo "</option>' : '') +
                (\$.inArray('site', Craft.supportedTranslationMethods[type]) != -1 ? '<option value=\"site\">";
        // line 144
        echo twig_escape_filter($this->env, twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Translate for each site", "app"), "js"), "html", null, true);
        echo "</option>' : '') +
                (\$.inArray('siteGroup', Craft.supportedTranslationMethods[type]) != -1 ? '<option value=\"siteGroup\">";
        // line 145
        echo twig_escape_filter($this->env, twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Translate for each site group", "app"), "js"), "html", null, true);
        echo "</option>' : '') +
                (\$.inArray('language', Craft.supportedTranslationMethods[type]) != -1 ? '<option value=\"language\">";
        // line 146
        echo twig_escape_filter($this->env, twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Translate for each language", "app"), "js"), "html", null, true);
        echo "</option>' : '') +
                (\$.inArray('custom', Craft.supportedTranslationMethods[type]) != -1 ? '<option value=\"custom\">";
        // line 147
        echo twig_escape_filter($this->env, twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Custom…", "app"), "js"), "html", null, true);
        echo "</option>' : '')
            );
        }
    }

    var \$fieldTypeInput = \$(\"#";
        // line 152
        echo twig_escape_filter($this->env, twig_escape_filter($this->env, call_user_func_array($this->env->getFilter('namespaceInputId')->getCallable(), ["type"]), "js"), "html", null, true);
        echo "\"),
        \$translationSettings = \$(\"#";
        // line 153
        echo twig_escape_filter($this->env, twig_escape_filter($this->env, call_user_func_array($this->env->getFilter('namespaceInputId')->getCallable(), ["translation-settings"]), "js"), "html", null, true);
        echo "\");

    \$fieldTypeInput.change(function(e) {
        Craft.updateTranslationMethodSettings(\$(this).val(), \$translationSettings);
    });
";
        Craft::$app->getView()->registerJs(ob_get_clean(), 3);
        // line 1
        $this->parent = $this->loadTemplate("_layouts/cp", "settings/fields/_edit", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        // line 0
        craft\helpers\Template::endProfile("template", "settings/fields/_edit");
    }

    // line 6
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("block", "content");
        // line 7
        echo "    ";
        echo craft\helpers\Html::actionInput("fields/save-field");
        echo "
    ";
        // line 8
        echo craft\helpers\Html::redirectInput("settings/fields/{groupId}");
        echo "
    ";
        // line 9
        if (((isset($context["fieldId"]) || array_key_exists("fieldId", $context)) && (isset($context["fieldId"]) || array_key_exists("fieldId", $context) ? $context["fieldId"] : (function () { throw new RuntimeError('Variable "fieldId" does not exist.', 9, $this->source); })()))) {
            // line 10
            echo "        ";
            echo craft\helpers\Html::hiddenInput("fieldId", (isset($context["fieldId"]) || array_key_exists("fieldId", $context) ? $context["fieldId"] : (function () { throw new RuntimeError('Variable "fieldId" does not exist.', 10, $this->source); })()));
            echo "
    ";
        }
        // line 12
        echo "
    ";
        // line 13
        echo twig_call_macro($macros["forms"], "macro_selectField", [["first" => true, "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Group", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Which group should this field be displayed in?", "app"), "id" => "group", "name" => "group", "options" =>         // line 19
(isset($context["groupOptions"]) || array_key_exists("groupOptions", $context) ? $context["groupOptions"] : (function () { throw new RuntimeError('Variable "groupOptions" does not exist.', 19, $this->source); })()), "value" =>         // line 20
(isset($context["groupId"]) || array_key_exists("groupId", $context) ? $context["groupId"] : (function () { throw new RuntimeError('Variable "groupId" does not exist.', 20, $this->source); })())]], 13, $context, $this->getSourceContext());
        // line 21
        echo "

    ";
        // line 23
        echo twig_call_macro($macros["forms"], "macro_textField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Name", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("What this field will be called in the control panel.", "app"), "id" => "name", "name" => "name", "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 28
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 28, $this->source); })()), "name", []), "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 29
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 29, $this->source); })()), "getErrors", [0 => "name"], "method"), "required" => true, "autofocus" => true]], 23, $context, $this->getSourceContext());
        // line 32
        echo "

    ";
        // line 34
        echo twig_call_macro($macros["forms"], "macro_textField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Handle", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("How you’ll refer to this field in the templates.", "app"), "id" => "handle", "name" => "handle", "class" => "code", "autocorrect" => false, "autocapitalize" => false, "maxlength" => 64, "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 43
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 43, $this->source); })()), "handle", []), "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 44
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 44, $this->source); })()), "getErrors", [0 => "handle"], "method"), "required" => true]], 34, $context, $this->getSourceContext());
        // line 46
        echo "

    ";
        // line 48
        echo twig_call_macro($macros["forms"], "macro_textareaField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Instructions", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Helper text to guide the author.", "app"), "id" => "instructions", "class" => "nicetext", "name" => "instructions", "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 54
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 54, $this->source); })()), "instructions", []), "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 55
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 55, $this->source); })()), "getErrors", [0 => "instructions"], "method")]], 48, $context, $this->getSourceContext());
        // line 56
        echo "

    ";
        // line 58
        echo twig_call_macro($macros["forms"], "macro_checkboxField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Use this field’s values as search keywords?", "app"), "id" => "searchable", "name" => "searchable", "checked" => craft\helpers\Template::attribute($this->env, $this->source,         // line 62
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 62, $this->source); })()), "searchable", [])]], 58, $context, $this->getSourceContext());
        // line 63
        echo "

    ";
        // line 65
        echo twig_call_macro($macros["forms"], "macro_selectField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Field Type", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("What type of field is this?", "app"), "warning" => ((( !twig_test_empty(        // line 68
(isset($context["fieldId"]) || array_key_exists("fieldId", $context) ? $context["fieldId"] : (function () { throw new RuntimeError('Variable "fieldId" does not exist.', 68, $this->source); })())) &&  !craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 68, $this->source); })()), "hasErrors", [0 => "type"], "method"))) ? ($this->extensions['craft\web\twig\Extension']->translateFilter("Changing this may result in data loss.", "app")) : ("")), "id" => "type", "name" => "type", "options" =>         // line 71
(isset($context["fieldTypeOptions"]) || array_key_exists("fieldTypeOptions", $context) ? $context["fieldTypeOptions"] : (function () { throw new RuntimeError('Variable "fieldTypeOptions" does not exist.', 71, $this->source); })()), "value" => get_class(        // line 72
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 72, $this->source); })()))]], 65, $context, $this->getSourceContext());
        // line 73
        echo "

    ";
        // line 75
        echo (isset($context["missingFieldPlaceholder"]) || array_key_exists("missingFieldPlaceholder", $context) ? $context["missingFieldPlaceholder"] : (function () { throw new RuntimeError('Variable "missingFieldPlaceholder" does not exist.', 75, $this->source); })());
        echo "

    ";
        // line 77
        if (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 77, $this->source); })()), "app", []), "getIsMultiSite", [], "method")) {
            // line 78
            echo "        ";
            $context["translationMethods"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 78, $this->source); })()), "supportedTranslationMethods", []);
            // line 79
            echo "        ";
            if ((twig_length_filter($this->env, (isset($context["translationMethods"]) || array_key_exists("translationMethods", $context) ? $context["translationMethods"] : (function () { throw new RuntimeError('Variable "translationMethods" does not exist.', 79, $this->source); })())) > 1)) {
                // line 80
                echo "            <div id=\"translation-settings\">
                ";
                // line 81
                echo twig_call_macro($macros["forms"], "macro_selectField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Translation Method", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("How should this field’s values be translated?", "app"), "id" => "translation-method", "name" => "translationMethod", "options" => $this->extensions['craft\web\twig\Extension']->filterFilter([0 => ((twig_in_filter("none",                 // line 87
(isset($context["translationMethods"]) || array_key_exists("translationMethods", $context) ? $context["translationMethods"] : (function () { throw new RuntimeError('Variable "translationMethods" does not exist.', 87, $this->source); })()))) ? (["value" => "none", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Not translatable", "app")]) : ("")), 1 => ((twig_in_filter("site",                 // line 88
(isset($context["translationMethods"]) || array_key_exists("translationMethods", $context) ? $context["translationMethods"] : (function () { throw new RuntimeError('Variable "translationMethods" does not exist.', 88, $this->source); })()))) ? (["value" => "site", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Translate for each site", "app")]) : ("")), 2 => ((twig_in_filter("siteGroup",                 // line 89
(isset($context["translationMethods"]) || array_key_exists("translationMethods", $context) ? $context["translationMethods"] : (function () { throw new RuntimeError('Variable "translationMethods" does not exist.', 89, $this->source); })()))) ? (["value" => "siteGroup", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Translate for each site group", "app")]) : ("")), 3 => ((twig_in_filter("language",                 // line 90
(isset($context["translationMethods"]) || array_key_exists("translationMethods", $context) ? $context["translationMethods"] : (function () { throw new RuntimeError('Variable "translationMethods" does not exist.', 90, $this->source); })()))) ? (["value" => "language", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Translate for each language", "app")]) : ("")), 4 => ((twig_in_filter("custom",                 // line 91
(isset($context["translationMethods"]) || array_key_exists("translationMethods", $context) ? $context["translationMethods"] : (function () { throw new RuntimeError('Variable "translationMethods" does not exist.', 91, $this->source); })()))) ? (["value" => "custom", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Custom…", "app")]) : (""))]), "value" => craft\helpers\Template::attribute($this->env, $this->source,                 // line 93
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 93, $this->source); })()), "translationMethod", []), "toggle" => true, "targetPrefix" => "translation-method-"]], 81, $context, $this->getSourceContext());
                // line 96
                echo "

                ";
                // line 98
                if (twig_in_filter("custom", (isset($context["translationMethods"]) || array_key_exists("translationMethods", $context) ? $context["translationMethods"] : (function () { throw new RuntimeError('Variable "translationMethods" does not exist.', 98, $this->source); })()))) {
                    // line 99
                    echo "                    <div id=\"translation-method-custom\" ";
                    if ((craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 99, $this->source); })()), "translationMethod", []) != "custom")) {
                        echo "class=\"hidden\"";
                    }
                    echo ">
                        ";
                    // line 100
                    echo twig_call_macro($macros["forms"], "macro_textField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Translation Key Format", "app"), "instructions" => "Template that defines the field’s custom “translation key” format. Field values will be copied to all sites that produce the same key. For example, to make the field translatable based on the first two characters of the site handle, you could enter `{site.handle[:2]}`.", "id" => "translation-key-format", "name" => "translationKeyFormat", "value" => craft\helpers\Template::attribute($this->env, $this->source,                     // line 105
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 105, $this->source); })()), "translationKeyFormat", []), "errors" => craft\helpers\Template::attribute($this->env, $this->source,                     // line 106
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 106, $this->source); })()), "getErrors", [0 => "translationKeyFormat"], "method")]], 100, $context, $this->getSourceContext());
                    // line 107
                    echo "
                    </div>
                ";
                }
                // line 110
                echo "            </div>
        ";
            }
            // line 112
            echo "    ";
        }
        // line 113
        echo "
    <hr>

    <div id=\"settings\">
        <div id=\"";
        // line 117
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFilter('id')->getCallable(), [get_class((isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 117, $this->source); })()))]), "html", null, true);
        echo "\">
            ";
        // line 118
        $this->loadTemplate("settings/fields/_type-settings", "settings/fields/_edit", 118)->display(twig_array_merge($context, ["namespace" => (("types[" . get_class(        // line 119
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 119, $this->source); })()))) . "]")]));
        // line 121
        echo "        </div>
    </div>
";
        // line 0
        craft\helpers\Template::endProfile("block", "content");
    }

    public function getTemplateName()
    {
        return "settings/fields/_edit";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  261 => 0,  257 => 121,  255 => 119,  254 => 118,  250 => 117,  244 => 113,  241 => 112,  237 => 110,  232 => 107,  230 => 106,  229 => 105,  228 => 100,  221 => 99,  219 => 98,  215 => 96,  213 => 93,  212 => 91,  211 => 90,  210 => 89,  209 => 88,  208 => 87,  207 => 81,  204 => 80,  201 => 79,  198 => 78,  196 => 77,  191 => 75,  187 => 73,  185 => 72,  184 => 71,  183 => 68,  182 => 65,  178 => 63,  176 => 62,  175 => 58,  171 => 56,  169 => 55,  168 => 54,  167 => 48,  163 => 46,  161 => 44,  160 => 43,  159 => 34,  155 => 32,  153 => 29,  152 => 28,  151 => 23,  147 => 21,  145 => 20,  144 => 19,  143 => 13,  140 => 12,  134 => 10,  132 => 9,  128 => 8,  123 => 7,  121 => 0,  117 => 6,  113 => 0,  110 => 1,  101 => 153,  97 => 152,  89 => 147,  85 => 146,  81 => 145,  77 => 144,  73 => 143,  59 => 133,  57 => 132,  52 => 128,  50 => 127,  48 => 126,  46 => 4,  44 => 2,  42 => 0,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends \"_layouts/cp\" %}
{% set fullPageForm = true %}

{% import \"_includes/forms\" as forms %}

{% block content %}
    {{ actionInput('fields/save-field') }}
    {{ redirectInput('settings/fields/{groupId}') }}
    {% if fieldId is defined and fieldId %}
        {{ hiddenInput('fieldId', fieldId) }}
    {% endif %}

    {{ forms.selectField({
        first: true,
        label: \"Group\"|t('app'),
        instructions: \"Which group should this field be displayed in?\"|t('app'),
        id: 'group',
        name: 'group',
        options: groupOptions,
        value: groupId
    }) }}

    {{ forms.textField({
        label: \"Name\"|t('app'),
        instructions: \"What this field will be called in the control panel.\"|t('app'),
        id: 'name',
        name: 'name',
        value: field.name,
        errors: field.getErrors('name'),
        required: true,
        autofocus: true
    }) }}

    {{ forms.textField({
        label: \"Handle\"|t('app'),
        instructions: \"How you’ll refer to this field in the templates.\"|t('app'),
        id: 'handle',
        name: 'handle',
        class: 'code',
        autocorrect: false,
        autocapitalize: false,
        maxlength: 64,
        value: field.handle,
        errors: field.getErrors('handle'),
        required: true,
    }) }}

    {{ forms.textareaField({
        label: \"Instructions\"|t('app'),
        instructions: \"Helper text to guide the author.\"|t('app'),
        id: 'instructions',
        class: 'nicetext',
        name: 'instructions',
        value: field.instructions,
        errors: field.getErrors('instructions'),
    }) }}

    {{ forms.checkboxField({
        label: \"Use this field’s values as search keywords?\"|t('app'),
        id: 'searchable',
        name: 'searchable',
        checked: field.searchable
    }) }}

    {{ forms.selectField({
        label: \"Field Type\"|t('app'),
        instructions: \"What type of field is this?\"|t('app'),
        warning: (fieldId is not empty and not field.hasErrors('type') ? \"Changing this may result in data loss.\"|t('app')),
        id: 'type',
        name: 'type',
        options: fieldTypeOptions,
        value: className(field),
    }) }}

    {{ missingFieldPlaceholder|raw }}

    {% if craft.app.getIsMultiSite() %}
        {% set translationMethods = field.supportedTranslationMethods %}
        {% if translationMethods|length > 1 %}
            <div id=\"translation-settings\">
                {{ forms.selectField({
                    label: \"Translation Method\"|t('app'),
                    instructions: \"How should this field’s values be translated?\"|t('app'),
                    id: 'translation-method',
                    name: 'translationMethod',
                    options: [
                        'none' in translationMethods ? { value: 'none', label: \"Not translatable\"|t('app') },
                        'site' in translationMethods ? { value: 'site', label: \"Translate for each site\"|t('app') },
                        'siteGroup' in translationMethods ? { value: 'siteGroup', label: \"Translate for each site group\"|t('app') },
                        'language' in translationMethods ? { value: 'language', label: \"Translate for each language\"|t('app') },
                        'custom' in translationMethods ? { value: 'custom', label: \"Custom…\"|t('app') }
                    ]|filter,
                    value: field.translationMethod,
                    toggle: true,
                    targetPrefix: 'translation-method-'
                }) }}

                {% if 'custom' in translationMethods %}
                    <div id=\"translation-method-custom\" {% if field.translationMethod != 'custom' %}class=\"hidden\"{% endif %}>
                        {{ forms.textField({
                            label: \"Translation Key Format\"|t('app'),
                            instructions: \"Template that defines the field’s custom “translation key” format. Field values will be copied to all sites that produce the same key. For example, to make the field translatable based on the first two characters of the site handle, you could enter `{site.handle[:2]}`.\",
                            id: 'translation-key-format',
                            name: 'translationKeyFormat',
                            value: field.translationKeyFormat,
                            errors: field.getErrors('translationKeyFormat')
                        }) }}
                    </div>
                {% endif %}
            </div>
        {% endif %}
    {% endif %}

    <hr>

    <div id=\"settings\">
        <div id=\"{{ className(field)|id }}\">
            {% include 'settings/fields/_type-settings' with {
                namespace: 'types['~className(field)~']'
            } %}
        </div>
    </div>
{% endblock %}


{% if field is empty or field.handle is empty %}
    {% js %}
        new Craft.HandleGenerator('#name', '#handle');
    {% endjs %}
{% endif %}

{% js %}
    Craft.supportedTranslationMethods = {{ supportedTranslationMethods|json_encode|raw }};

    Craft.updateTranslationMethodSettings = function(type, container) {
        var \$container = \$(container);
        if (!Craft.supportedTranslationMethods[type] || Craft.supportedTranslationMethods[type].length == 1) {
            \$container.addClass('hidden');
        } else {
            \$container.removeClass('hidden');
            // Rebuild the options based on the field type's supported translation methods
            \$container.find('select').html(
                (\$.inArray('none', Craft.supportedTranslationMethods[type]) != -1 ? '<option value=\"none\">{{ \"Not translatable\"|t('app')|e('js') }}</option>' : '') +
                (\$.inArray('site', Craft.supportedTranslationMethods[type]) != -1 ? '<option value=\"site\">{{ \"Translate for each site\"|t('app')|e('js') }}</option>' : '') +
                (\$.inArray('siteGroup', Craft.supportedTranslationMethods[type]) != -1 ? '<option value=\"siteGroup\">{{ \"Translate for each site group\"|t('app')|e('js') }}</option>' : '') +
                (\$.inArray('language', Craft.supportedTranslationMethods[type]) != -1 ? '<option value=\"language\">{{ \"Translate for each language\"|t('app')|e('js') }}</option>' : '') +
                (\$.inArray('custom', Craft.supportedTranslationMethods[type]) != -1 ? '<option value=\"custom\">{{ \"Custom…\"|t('app')|e('js') }}</option>' : '')
            );
        }
    }

    var \$fieldTypeInput = \$(\"#{{ 'type'|namespaceInputId|e('js') }}\"),
        \$translationSettings = \$(\"#{{ 'translation-settings'|namespaceInputId|e('js') }}\");

    \$fieldTypeInput.change(function(e) {
        Craft.updateTranslationMethodSettings(\$(this).val(), \$translationSettings);
    });
{% endjs %}
", "settings/fields/_edit", "/Applications/MAMP/htdocs/craft/smsi/vendor/craftcms/cms/src/templates/settings/fields/_edit.html");
    }
}
