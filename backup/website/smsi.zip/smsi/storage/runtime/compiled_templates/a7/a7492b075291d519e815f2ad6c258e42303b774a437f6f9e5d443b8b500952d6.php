<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _components/fieldtypes/Number/settings */
class __TwigTemplate_7f3850dbf0fe8c42f99f1314ca281397a2cf2323fc44fcc67f8f2ea499c15cef extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_components/fieldtypes/Number/settings");
        // line 1
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms", "_components/fieldtypes/Number/settings", 1)->unwrap();
        // line 2
        echo "
";
        // line 3
        echo craft\helpers\Html::hiddenInput("defaultValue[locale]", craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 3, $this->source); })()), "app", []), "language", []));
        echo "
";
        // line 4
        echo craft\helpers\Html::hiddenInput("min[locale]", craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 4, $this->source); })()), "app", []), "language", []));
        echo "
";
        // line 5
        echo craft\helpers\Html::hiddenInput("max[locale]", craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 5, $this->source); })()), "app", []), "language", []));
        echo "

";
        // line 7
        echo twig_call_macro($macros["forms"], "macro_textField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Default Value", "app"), "id" => "defaultValue", "name" => "defaultValue[value]", "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 11
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 11, $this->source); })()), "defaultValue", []), "size" => 5, "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 13
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 13, $this->source); })()), "getErrors", [0 => "defaultValue"], "method")]], 7, $context, $this->getSourceContext());
        // line 14
        echo "

";
        // line 16
        echo twig_call_macro($macros["forms"], "macro_textField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Min Value", "app"), "id" => "min", "name" => "min[value]", "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 20
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 20, $this->source); })()), "min", []), "size" => 5, "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 22
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 22, $this->source); })()), "getErrors", [0 => "min"], "method")]], 16, $context, $this->getSourceContext());
        // line 23
        echo "

";
        // line 25
        echo twig_call_macro($macros["forms"], "macro_textField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Max Value", "app"), "id" => "max", "name" => "max[value]", "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 29
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 29, $this->source); })()), "max", []), "size" => 5, "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 31
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 31, $this->source); })()), "getErrors", [0 => "max"], "method")]], 25, $context, $this->getSourceContext());
        // line 32
        echo "

";
        // line 34
        echo twig_call_macro($macros["forms"], "macro_textField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Decimal Points", "app"), "id" => "decimals", "name" => "decimals", "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 38
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 38, $this->source); })()), "decimals", []), "size" => 1, "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 40
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 40, $this->source); })()), "getErrors", [0 => "decimals"], "method")]], 34, $context, $this->getSourceContext());
        // line 41
        echo "

";
        // line 43
        echo twig_call_macro($macros["forms"], "macro_textField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Size", "app"), "id" => "size", "name" => "size", "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 47
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 47, $this->source); })()), "size", []), "size" => 2, "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 49
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 49, $this->source); })()), "getErrors", [0 => "size"], "method")]], 43, $context, $this->getSourceContext());
        // line 50
        echo "

";
        // line 52
        echo twig_call_macro($macros["forms"], "macro_textField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Prefix Text", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Text that should be shown before the input.", "app"), "id" => "prefix", "name" => "prefix", "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 57
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 57, $this->source); })()), "prefix", []), "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 58
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 58, $this->source); })()), "getErrors", [0 => "prefix"], "method")]], 52, $context, $this->getSourceContext());
        // line 59
        echo "

";
        // line 61
        echo twig_call_macro($macros["forms"], "macro_textField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Suffix Text", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Text that should be shown after the input.", "app"), "id" => "suffix", "name" => "suffix", "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 66
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 66, $this->source); })()), "suffix", []), "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 67
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 67, $this->source); })()), "getErrors", [0 => "suffix"], "method")]], 61, $context, $this->getSourceContext());
        // line 68
        echo "
";
        // line 0
        craft\helpers\Template::endProfile("template", "_components/fieldtypes/Number/settings");
    }

    public function getTemplateName()
    {
        return "_components/fieldtypes/Number/settings";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  111 => 0,  108 => 68,  106 => 67,  105 => 66,  104 => 61,  100 => 59,  98 => 58,  97 => 57,  96 => 52,  92 => 50,  90 => 49,  89 => 47,  88 => 43,  84 => 41,  82 => 40,  81 => 38,  80 => 34,  76 => 32,  74 => 31,  73 => 29,  72 => 25,  68 => 23,  66 => 22,  65 => 20,  64 => 16,  60 => 14,  58 => 13,  57 => 11,  56 => 7,  51 => 5,  47 => 4,  43 => 3,  40 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% import \"_includes/forms\" as forms %}

{{ hiddenInput('defaultValue[locale]', craft.app.language) }}
{{ hiddenInput('min[locale]', craft.app.language) }}
{{ hiddenInput('max[locale]', craft.app.language) }}

{{ forms.textField({
    label: \"Default Value\"|t('app'),
    id: 'defaultValue',
    name: 'defaultValue[value]',
    value: field.defaultValue,
    size: 5,
    errors: field.getErrors('defaultValue')
}) }}

{{ forms.textField({
    label: \"Min Value\"|t('app'),
    id: 'min',
    name: 'min[value]',
    value: field.min,
    size: 5,
    errors: field.getErrors('min')
}) }}

{{ forms.textField({
    label: \"Max Value\"|t('app'),
    id: 'max',
    name: 'max[value]',
    value: field.max,
    size: 5,
    errors: field.getErrors('max')
}) }}

{{ forms.textField({
    label: \"Decimal Points\"|t('app'),
    id: 'decimals',
    name: 'decimals',
    value: field.decimals,
    size: 1,
    errors: field.getErrors('decimals')
}) }}

{{ forms.textField({
    label: \"Size\"|t('app'),
    id: 'size',
    name: 'size',
    value: field.size,
    size: 2,
    errors: field.getErrors('size')
}) }}

{{ forms.textField({
    label: \"Prefix Text\"|t('app'),
    instructions: \"Text that should be shown before the input.\"|t('app'),
    id: 'prefix',
    name: 'prefix',
    value: field.prefix,
    errors: field.getErrors('prefix')
}) }}

{{ forms.textField({
    label: \"Suffix Text\"|t('app'),
    instructions: \"Text that should be shown after the input.\"|t('app'),
    id: 'suffix',
    name: 'suffix',
    value: field.suffix,
    errors: field.getErrors('suffix')
}) }}
", "_components/fieldtypes/Number/settings", "/Applications/MAMP/htdocs/craft/smsi/vendor/craftcms/cms/src/templates/_components/fieldtypes/Number/settings.html");
    }
}
