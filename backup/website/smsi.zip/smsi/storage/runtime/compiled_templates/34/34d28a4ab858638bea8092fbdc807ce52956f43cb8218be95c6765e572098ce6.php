<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _includes/nav */
class __TwigTemplate_a6c7d79be47c4d34c3c8bc7ed6d7672ffe5255925c6050053f364cee1d24ae07 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_includes/nav");
        // line 1
        echo "<nav class=\"container mx-auto py-4 px-4\" role=\"navigation\" aria-label=\"Main\">
  ";
        // line 2
        $context["firstSegment"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 2, $this->source); })()), "app", []), "request", []), "getSegment", [0 => 1], "method");
        // line 3
        echo "  <ul class=\"flex\">
    <li class=\"mr-6\">
      <a class=\"text-blue-600 ";
        // line 5
        echo ((((isset($context["firstSegment"]) || array_key_exists("firstSegment", $context) ? $context["firstSegment"] : (function () { throw new RuntimeError('Variable "firstSegment" does not exist.', 5, $this->source); })()) == "")) ? ("border-b border-blue-400") : (""));
        echo "\" href=\"";
        echo twig_escape_filter($this->env, (isset($context["siteUrl"]) || array_key_exists("siteUrl", $context) ? $context["siteUrl"] : (function () { throw new RuntimeError('Variable "siteUrl" does not exist.', 5, $this->source); })()), "html", null, true);
        echo "\">Home</a>
    </li>
    <li class=\"mr-6\">
      <a class=\"text-blue-600 ";
        // line 8
        echo ((((isset($context["firstSegment"]) || array_key_exists("firstSegment", $context) ? $context["firstSegment"] : (function () { throw new RuntimeError('Variable "firstSegment" does not exist.', 8, $this->source); })()) == "blog")) ? ("border-b border-blue-400") : (""));
        echo "\" href=\"";
        echo twig_escape_filter($this->env, craft\helpers\UrlHelper::url("blog"), "html", null, true);
        echo "\">Blog</a>
    </li>
    <li class=\"mr-6\">
      <a class=\"text-blue-600 ";
        // line 11
        echo ((((isset($context["firstSegment"]) || array_key_exists("firstSegment", $context) ? $context["firstSegment"] : (function () { throw new RuntimeError('Variable "firstSegment" does not exist.', 11, $this->source); })()) == "about")) ? ("border-b border-blue-400") : (""));
        echo "\" href=\"";
        echo twig_escape_filter($this->env, craft\helpers\UrlHelper::url("about"), "html", null, true);
        echo "\">About</a>
    </li>
  </ul>
</nav>
";
        // line 0
        craft\helpers\Template::endProfile("template", "_includes/nav");
    }

    public function getTemplateName()
    {
        return "_includes/nav";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  72 => 0,  63 => 11,  55 => 8,  47 => 5,  43 => 3,  41 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<nav class=\"container mx-auto py-4 px-4\" role=\"navigation\" aria-label=\"Main\">
  {% set firstSegment = craft.app.request.getSegment(1) %}
  <ul class=\"flex\">
    <li class=\"mr-6\">
      <a class=\"text-blue-600 {{ firstSegment == '' ? 'border-b border-blue-400' }}\" href=\"{{ siteUrl }}\">Home</a>
    </li>
    <li class=\"mr-6\">
      <a class=\"text-blue-600 {{ firstSegment == 'blog' ? 'border-b border-blue-400' }}\" href=\"{{ url('blog') }}\">Blog</a>
    </li>
    <li class=\"mr-6\">
      <a class=\"text-blue-600 {{ firstSegment == 'about' ? 'border-b border-blue-400' }}\" href=\"{{ url('about') }}\">About</a>
    </li>
  </ul>
</nav>
", "_includes/nav", "/Applications/MAMP/htdocs/craft/smsi/templates/_includes/nav.twig");
    }
}
