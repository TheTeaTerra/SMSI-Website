<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* settings/categories/index */
class __TwigTemplate_073c3f036ea25b18fd3d7a96f409a41521a83dcc25f7136bda37be1041d116e9 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'actionButton' => [$this, 'block_actionButton'],
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "_layouts/cp";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("template", "settings/categories/index");
        // line 2
        $context["title"] = $this->extensions['craft\web\twig\Extension']->translateFilter("Category Groups", "app");
        // line 4
        craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 4, $this->source); })()), "registerAssetBundle", [0 => "craft\\web\\assets\\admintable\\AdminTableAsset"], "method");
        // line 6
        craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 6, $this->source); })()), "registerTranslations", [0 => "app", 1 => [0 => "Name", 1 => "Handle", 2 => "Manage categories", 3 => "No category groups exist yet."]], "method");
        // line 17
        $context["crumbs"] = [0 => ["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Settings", "app"), "url" => craft\helpers\UrlHelper::url("settings")]];
        // line 25
        $context["tableData"] = [];
        // line 26
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["categoryGroups"]) || array_key_exists("categoryGroups", $context) ? $context["categoryGroups"] : (function () { throw new RuntimeError('Variable "categoryGroups" does not exist.', 26, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["group"]) {
            // line 27
            $context["tableData"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["tableData"]) || array_key_exists("tableData", $context) ? $context["tableData"] : (function () { throw new RuntimeError('Variable "tableData" does not exist.', 27, $this->source); })()), [0 => ["id" => craft\helpers\Template::attribute($this->env, $this->source,             // line 28
$context["group"], "id", []), "title" => $this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source,             // line 29
$context["group"], "name", []), "site"), "url" => craft\helpers\UrlHelper::url(("settings/categories/" . craft\helpers\Template::attribute($this->env, $this->source,             // line 30
$context["group"], "id", []))), "name" => twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source,             // line 31
$context["group"], "name", []), "site")), "handle" => craft\helpers\Template::attribute($this->env, $this->source,             // line 32
$context["group"], "handle", []), "manageCategories" => craft\helpers\UrlHelper::url(("categories/" . craft\helpers\Template::attribute($this->env, $this->source,             // line 33
$context["group"], "handle", [])))]]);
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['group'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 37
        ob_start();
        // line 38
        echo "    var columns = [
        {
            name: '__slot:title',
            title: Craft.t('app', 'Name'),
        },
        {
            name: '__slot:handle',
            title: Craft.t('app', 'Handle'),
        },
        {
            name: 'manageCategories',
            title: \"\",
            callback: function(value) {
                return '<a href=\"'+value+'\">' + Craft.escapeHtml(Craft.t('app', \"Manage categories\")) + '</a>';
            }
        },
    ];

    new Craft.VueAdminTable({
        columns: columns,
        container: '#categorygroups-vue-admin-table',
        deleteAction: 'categories/delete-category-group',
        emptyMessage: Craft.t('app', 'No category groups exist yet.'),
        tableData: ";
        // line 61
        echo $this->extensions['craft\web\twig\Extension']->jsonEncodeFilter((isset($context["tableData"]) || array_key_exists("tableData", $context) ? $context["tableData"] : (function () { throw new RuntimeError('Variable "tableData" does not exist.', 61, $this->source); })()));
        echo "
    });
";
        Craft::$app->getView()->registerJs(ob_get_clean(), 3);
        // line 1
        $this->parent = $this->loadTemplate("_layouts/cp", "settings/categories/index", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        // line 0
        craft\helpers\Template::endProfile("template", "settings/categories/index");
    }

    // line 13
    public function block_actionButton($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("block", "actionButton");
        // line 14
        echo "    <a href=\"";
        echo twig_escape_filter($this->env, craft\helpers\UrlHelper::url("settings/categories/new"), "html", null, true);
        echo "\" class=\"btn submit add icon\">";
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("New category group", "app"), "html", null, true);
        echo "</a>
";
        // line 0
        craft\helpers\Template::endProfile("block", "actionButton");
    }

    // line 21
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("block", "content");
        // line 22
        echo "    <div id=\"categorygroups-vue-admin-table\"></div>
";
        // line 0
        craft\helpers\Template::endProfile("block", "content");
    }

    public function getTemplateName()
    {
        return "settings/categories/index";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  137 => 0,  134 => 22,  132 => 0,  128 => 21,  124 => 0,  117 => 14,  115 => 0,  111 => 13,  107 => 0,  104 => 1,  98 => 61,  73 => 38,  71 => 37,  65 => 33,  64 => 32,  63 => 31,  62 => 30,  61 => 29,  60 => 28,  59 => 27,  55 => 26,  53 => 25,  51 => 17,  49 => 6,  47 => 4,  45 => 2,  43 => 0,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends \"_layouts/cp\" %}
{% set title = \"Category Groups\"|t('app') %}

{% do view.registerAssetBundle('craft\\\\web\\\\assets\\\\admintable\\\\AdminTableAsset') -%}

{% do view.registerTranslations('app', [
    \"Name\",
    \"Handle\",
    \"Manage categories\",
    \"No category groups exist yet.\",
]) %}

{% block actionButton %}
    <a href=\"{{ url('settings/categories/new') }}\" class=\"btn submit add icon\">{{ \"New category group\"|t('app') }}</a>
{% endblock %}

{% set crumbs = [
    { label: \"Settings\"|t('app'), url: url('settings') }
] %}

{% block content %}
    <div id=\"categorygroups-vue-admin-table\"></div>
{% endblock %}

{% set tableData = [] %}
{% for group in categoryGroups %}
    {% set tableData = tableData|merge([{
        id: group.id,
        title: group.name|t('site'),
        url: url('settings/categories/' ~ group.id),
        name: group.name|t('site')|e,
        handle: group.handle,
        manageCategories: url('categories/'~group.handle),
    }]) %}
{% endfor %}

{% js %}
    var columns = [
        {
            name: '__slot:title',
            title: Craft.t('app', 'Name'),
        },
        {
            name: '__slot:handle',
            title: Craft.t('app', 'Handle'),
        },
        {
            name: 'manageCategories',
            title: \"\",
            callback: function(value) {
                return '<a href=\"'+value+'\">' + Craft.escapeHtml(Craft.t('app', \"Manage categories\")) + '</a>';
            }
        },
    ];

    new Craft.VueAdminTable({
        columns: columns,
        container: '#categorygroups-vue-admin-table',
        deleteAction: 'categories/delete-category-group',
        emptyMessage: Craft.t('app', 'No category groups exist yet.'),
        tableData: {{ tableData|json_encode|raw }}
    });
{% endjs %}
", "settings/categories/index", "/Applications/MAMP/htdocs/craft/smsi/vendor/craftcms/cms/src/templates/settings/categories/index.html");
    }
}
