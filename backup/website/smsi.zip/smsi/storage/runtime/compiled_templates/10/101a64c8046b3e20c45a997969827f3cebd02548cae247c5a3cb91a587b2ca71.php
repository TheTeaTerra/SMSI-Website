<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* entries/_fields */
class __TwigTemplate_773feb4c51ea0a34f3d2b9ec3a0620deb4a341213a61ee03398134bdb56b0c37 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "entries/_fields");
        // line 1
        if ((craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entryType"]) || array_key_exists("entryType", $context) ? $context["entryType"] : (function () { throw new RuntimeError('Variable "entryType" does not exist.', 1, $this->source); })()), "hasTitleField", []) || craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 1, $this->source); })()), "hasErrors", [0 => "title"], "method"))) {
            // line 2
            echo "    ";
            $this->loadTemplate("entries/_titlefield", "entries/_fields", 2)->display($context);
        }
        // line 4
        echo "
";
        // line 5
        craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 5, $this->source); })()), "setIsDeltaRegistrationActive", [0 => true], "method");
        // line 6
        echo "
<div>
    ";
        // line 8
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entryType"]) || array_key_exists("entryType", $context) ? $context["entryType"] : (function () { throw new RuntimeError('Variable "entryType" does not exist.', 8, $this->source); })()), "getFieldLayout", [], "method"), "getTabs", [], "method"));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["tab"]) {
            // line 9
            echo "        <div id=\"";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["tab"], "getHtmlId", [], "method"), "html", null, true);
            echo "\"";
            if ( !craft\helpers\Template::attribute($this->env, $this->source, $context["loop"], "first", [])) {
                echo " class=\"hidden\"";
            }
            echo ">
            ";
            // line 10
            $this->loadTemplate("_includes/fields", "entries/_fields", 10)->display(twig_to_array(["fields" => craft\helpers\Template::attribute($this->env, $this->source,             // line 11
$context["tab"], "getFields", [], "method"), "element" =>             // line 12
(isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 12, $this->source); })()), "static" => ((            // line 13
(isset($context["static"]) || array_key_exists("static", $context))) ? ((isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new RuntimeError('Variable "static" does not exist.', 13, $this->source); })())) : (false)), "registerDeltas" => true]));
            // line 16
            echo "        </div>
    ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['tab'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 18
        echo "</div>

";
        // line 20
        craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 20, $this->source); })()), "setIsDeltaRegistrationActive", [0 => false], "method");
        // line 0
        craft\helpers\Template::endProfile("template", "entries/_fields");
    }

    public function getTemplateName()
    {
        return "entries/_fields";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  105 => 0,  103 => 20,  99 => 18,  84 => 16,  82 => 13,  81 => 12,  80 => 11,  79 => 10,  70 => 9,  53 => 8,  49 => 6,  47 => 5,  44 => 4,  40 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% if entryType.hasTitleField or entry.hasErrors('title') %}
    {% include \"entries/_titlefield\" %}
{% endif %}

{% do view.setIsDeltaRegistrationActive(true) %}

<div>
    {% for tab in entryType.getFieldLayout().getTabs() %}
        <div id=\"{{ tab.getHtmlId() }}\"{% if not loop.first %} class=\"hidden\"{% endif %}>
            {% include \"_includes/fields\" with {
                fields:  tab.getFields(),
                element: entry,
                static:  (static is defined ? static : false),
                registerDeltas: true,
            } only %}
        </div>
    {% endfor %}
</div>

{% do view.setIsDeltaRegistrationActive(false) %}
", "entries/_fields", "/Applications/MAMP/htdocs/craft/smsi/vendor/craftcms/cms/src/templates/entries/_fields.html");
    }
}
