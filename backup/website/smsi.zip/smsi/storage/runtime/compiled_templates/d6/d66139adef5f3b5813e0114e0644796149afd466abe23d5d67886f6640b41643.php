<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _layouts/app */
class __TwigTemplate_7903d6d36c4d6f47de42a07715fe3ff579a6277a7e5166fa1b678c0a0e687fa6 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'head' => [$this, 'block_head'],
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_layouts/app");
        // line 1
        echo "
  ";
        // line 2
        $context["siteInfo"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 2, $this->source); })()), "globals", [], "method"), "getSetByHandle", [0 => "siteInformation"], "method");
        // line 3
        echo "  ";
        $context["footer"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 3, $this->source); })()), "globals", [], "method"), "getSetByHandle", [0 => "footer"], "method");
        // line 4
        echo "  ";
        $context["logo"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["siteInfo"]) || array_key_exists("siteInfo", $context) ? $context["siteInfo"] : (function () { throw new RuntimeError('Variable "siteInfo" does not exist.', 4, $this->source); })()), "logo", []), "one", []);
        // line 5
        echo "  ";
        $context["medium"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 5, $this->source); })()), "app", []), "getAssetTransforms", []), "getTransformByHandle", [0 => "medium"], "method");
        // line 6
        echo "  ";
        $context["small"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 6, $this->source); })()), "app", []), "getAssetTransforms", []), "getTransformByHandle", [0 => "smalll"], "method");
        // line 7
        echo "  ";
        $context["thumb"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 7, $this->source); })()), "app", []), "getAssetTransforms", []), "getTransformByHandle", [0 => "thumb"], "method");
        // line 8
        echo "  
<!DOCTYPE html>
<html lang=\"";
        // line 10
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 10, $this->source); })()), "app", []), "language", []), "html", null, true);
        echo "\">

<head>
  ";
        // line 13
        $this->displayBlock('head', $context, $blocks);
        // line 49
        echo "";
        call_user_func_array($this->env->getFunction('head')->getCallable(), []);
        echo "</head>

<body>";
        // line 51
        call_user_func_array($this->env->getFunction('beginBody')->getCallable(), []);
        echo "
  ";
        // line 53
        echo "  ";
        // line 54
        $context["setImage"] = ["mode" => "crop", "width" => 600, "height" => 300, "quality" => 90, "position" => "top-left"];
        // line 62
        echo "  ";
        $context["logoImg"] = ["mode" => "fit", "width" => 200, "height" => 100, "quality" => 90];
        // line 69
        echo "  
  <!-- ======= Header ======= -->
  ";
        // line 71
        $this->loadTemplate("_partials/header", "_layouts/app", 71)->display($context);
        // line 72
        echo "  
  </header><!-- End Header -->

  <!-- ======= Hero Section ======= -->
  ";
        // line 76
        $this->loadTemplate("_partials/hero", "_layouts/app", 76)->display($context);
        // line 77
        echo "  <!-- End Hero -->

  <main id=\"main\">

    ";
        // line 81
        $this->displayBlock('content', $context, $blocks);
        // line 83
        echo "
  </main>
  <!-- End #main -->

  <!-- ======= Footer ======= -->
  ";
        // line 88
        $this->loadTemplate("_partials/footer", "_layouts/app", 88)->display($context);
        // line 89
        echo "  <!-- End Footer -->

  <div id=\"preloader\"></div>
  <a href=\"#\" class=\"back-to-top\"><i class=\"ri-arrow-up-line\"></i></a>

  <!-- Vendor JS Files -->
  <script src=\"";
        // line 95
        echo twig_escape_filter($this->env, (isset($context["siteUrl"]) || array_key_exists("siteUrl", $context) ? $context["siteUrl"] : (function () { throw new RuntimeError('Variable "siteUrl" does not exist.', 95, $this->source); })()), "html", null, true);
        echo "assets/vendor/jquery/jquery.min.js\"></script>
  <script src=\"";
        // line 96
        echo twig_escape_filter($this->env, (isset($context["siteUrl"]) || array_key_exists("siteUrl", $context) ? $context["siteUrl"] : (function () { throw new RuntimeError('Variable "siteUrl" does not exist.', 96, $this->source); })()), "html", null, true);
        echo "assets/vendor/bootstrap/js/bootstrap.bundle.min.js\"></script>
  <script src=\"";
        // line 97
        echo twig_escape_filter($this->env, (isset($context["siteUrl"]) || array_key_exists("siteUrl", $context) ? $context["siteUrl"] : (function () { throw new RuntimeError('Variable "siteUrl" does not exist.', 97, $this->source); })()), "html", null, true);
        echo "assets/vendor/jquery.easing/jquery.easing.min.js\"></script>
  <script src=\"";
        // line 98
        echo twig_escape_filter($this->env, (isset($context["siteUrl"]) || array_key_exists("siteUrl", $context) ? $context["siteUrl"] : (function () { throw new RuntimeError('Variable "siteUrl" does not exist.', 98, $this->source); })()), "html", null, true);
        echo "assets/vendor/php-email-form/validate.js\"></script>
  <script src=\"";
        // line 99
        echo twig_escape_filter($this->env, (isset($context["siteUrl"]) || array_key_exists("siteUrl", $context) ? $context["siteUrl"] : (function () { throw new RuntimeError('Variable "siteUrl" does not exist.', 99, $this->source); })()), "html", null, true);
        echo "assets/vendor/waypoints/jquery.waypoints.min.js\"></script>
  <script src=\"";
        // line 100
        echo twig_escape_filter($this->env, (isset($context["siteUrl"]) || array_key_exists("siteUrl", $context) ? $context["siteUrl"] : (function () { throw new RuntimeError('Variable "siteUrl" does not exist.', 100, $this->source); })()), "html", null, true);
        echo "assets/vendor/counterup/counterup.min.js\"></script>
  <script src=\"";
        // line 101
        echo twig_escape_filter($this->env, (isset($context["siteUrl"]) || array_key_exists("siteUrl", $context) ? $context["siteUrl"] : (function () { throw new RuntimeError('Variable "siteUrl" does not exist.', 101, $this->source); })()), "html", null, true);
        echo "assets/vendor/isotope-layout/isotope.pkgd.min.js\"></script>
  <script src=\"";
        // line 102
        echo twig_escape_filter($this->env, (isset($context["siteUrl"]) || array_key_exists("siteUrl", $context) ? $context["siteUrl"] : (function () { throw new RuntimeError('Variable "siteUrl" does not exist.', 102, $this->source); })()), "html", null, true);
        echo "assets/vendor/venobox/venobox.min.js\"></script>
  <script src=\"";
        // line 103
        echo twig_escape_filter($this->env, (isset($context["siteUrl"]) || array_key_exists("siteUrl", $context) ? $context["siteUrl"] : (function () { throw new RuntimeError('Variable "siteUrl" does not exist.', 103, $this->source); })()), "html", null, true);
        echo "assets/vendor/owl.carousel/owl.carousel.min.js\"></script>
  <script src=\"";
        // line 104
        echo twig_escape_filter($this->env, (isset($context["siteUrl"]) || array_key_exists("siteUrl", $context) ? $context["siteUrl"] : (function () { throw new RuntimeError('Variable "siteUrl" does not exist.', 104, $this->source); })()), "html", null, true);
        echo "assets/vendor/aos/aos.js\"></script>

  <!-- Template Main JS File -->
  <script src=\"";
        // line 107
        echo twig_escape_filter($this->env, (isset($context["siteUrl"]) || array_key_exists("siteUrl", $context) ? $context["siteUrl"] : (function () { throw new RuntimeError('Variable "siteUrl" does not exist.', 107, $this->source); })()), "html", null, true);
        echo "assets/js/main.js\"></script>

";
        // line 109
        call_user_func_array($this->env->getFunction('endBody')->getCallable(), []);
        echo "</body>

</html>";
        // line 0
        craft\helpers\Template::endProfile("template", "_layouts/app");
    }

    // line 13
    public function block_head($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("block", "head");
        // line 14
        echo "  <meta charset=\"utf-8\">
  <meta content=\"width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover\" name=\"viewport\">

  <title>";
        // line 17
        echo twig_escape_filter($this->env, (isset($context["siteName"]) || array_key_exists("siteName", $context) ? $context["siteName"] : (function () { throw new RuntimeError('Variable "siteName" does not exist.', 17, $this->source); })()), "html", null, true);
        echo "</title>
  <meta content=\"\" name=\"descriptison\">
  <meta content=\"\" name=\"keywords\">

  <!-- Favicons -->
  <link href=\" ";
        // line 22
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["siteInfo"]) || array_key_exists("siteInfo", $context) ? $context["siteInfo"] : (function () { throw new RuntimeError('Variable "siteInfo" does not exist.', 22, $this->source); })()), "icon", []), "one", []), "url", []), "html", null, true);
        echo " \" rel=\"icon\">
  <link href=\"";
        // line 23
        echo twig_escape_filter($this->env, (isset($context["siteUrl"]) || array_key_exists("siteUrl", $context) ? $context["siteUrl"] : (function () { throw new RuntimeError('Variable "siteUrl" does not exist.', 23, $this->source); })()), "html", null, true);
        echo "assets/img/apple-touch-icon.png\" rel=\"apple-touch-icon\">

  <!-- Google Fonts -->
  <link href=\"https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i\" rel=\"stylesheet\">

  <!-- Vendor CSS Files -->
  <link href=\"";
        // line 29
        echo twig_escape_filter($this->env, (isset($context["siteUrl"]) || array_key_exists("siteUrl", $context) ? $context["siteUrl"] : (function () { throw new RuntimeError('Variable "siteUrl" does not exist.', 29, $this->source); })()), "html", null, true);
        echo "assets/vendor/bootstrap/css/bootstrap.min.css\" rel=\"stylesheet\">
  <link href=\"";
        // line 30
        echo twig_escape_filter($this->env, (isset($context["siteUrl"]) || array_key_exists("siteUrl", $context) ? $context["siteUrl"] : (function () { throw new RuntimeError('Variable "siteUrl" does not exist.', 30, $this->source); })()), "html", null, true);
        echo "assets/vendor/icofont/icofont.min.css\" rel=\"stylesheet\">
  <link href=\"";
        // line 31
        echo twig_escape_filter($this->env, (isset($context["siteUrl"]) || array_key_exists("siteUrl", $context) ? $context["siteUrl"] : (function () { throw new RuntimeError('Variable "siteUrl" does not exist.', 31, $this->source); })()), "html", null, true);
        echo "assets/vendor/boxicons/css/boxicons.min.css\" rel=\"stylesheet\">
  <link href=\"";
        // line 32
        echo twig_escape_filter($this->env, (isset($context["siteUrl"]) || array_key_exists("siteUrl", $context) ? $context["siteUrl"] : (function () { throw new RuntimeError('Variable "siteUrl" does not exist.', 32, $this->source); })()), "html", null, true);
        echo "assets/vendor/remixicon/remixicon.css\" rel=\"stylesheet\">
  <link href=\"";
        // line 33
        echo twig_escape_filter($this->env, (isset($context["siteUrl"]) || array_key_exists("siteUrl", $context) ? $context["siteUrl"] : (function () { throw new RuntimeError('Variable "siteUrl" does not exist.', 33, $this->source); })()), "html", null, true);
        echo "assets/vendor/venobox/venobox.css\" rel=\"stylesheet\">
  <link href=\"";
        // line 34
        echo twig_escape_filter($this->env, (isset($context["siteUrl"]) || array_key_exists("siteUrl", $context) ? $context["siteUrl"] : (function () { throw new RuntimeError('Variable "siteUrl" does not exist.', 34, $this->source); })()), "html", null, true);
        echo "assets/vendor/owl.carousel/assets/owl.carousel.min.css\" rel=\"stylesheet\">
  <link href=\"";
        // line 35
        echo twig_escape_filter($this->env, (isset($context["siteUrl"]) || array_key_exists("siteUrl", $context) ? $context["siteUrl"] : (function () { throw new RuntimeError('Variable "siteUrl" does not exist.', 35, $this->source); })()), "html", null, true);
        echo "assets/vendor/animate.css/animate.min.css\" rel=\"stylesheet\">

  <link href=\"";
        // line 37
        echo twig_escape_filter($this->env, (isset($context["siteUrl"]) || array_key_exists("siteUrl", $context) ? $context["siteUrl"] : (function () { throw new RuntimeError('Variable "siteUrl" does not exist.', 37, $this->source); })()), "html", null, true);
        echo "assets/vendor/aos/aos.css\" rel=\"stylesheet\">

  <!-- Template Main CSS File -->
  <link href=\"";
        // line 40
        echo twig_escape_filter($this->env, (isset($context["siteUrl"]) || array_key_exists("siteUrl", $context) ? $context["siteUrl"] : (function () { throw new RuntimeError('Variable "siteUrl" does not exist.', 40, $this->source); })()), "html", null, true);
        echo "assets/css/style.css\" rel=\"stylesheet\">

  <!-- =======================================================
  * Template Name: KnightOne - v2.0.0
  * Template URL: https://bootstrapmade.com/knight-simple-one-page-bootstrap-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
  ";
        // line 0
        craft\helpers\Template::endProfile("block", "head");
    }

    // line 81
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("block", "content");
        // line 82
        echo "    ";
        // line 0
        craft\helpers\Template::endProfile("block", "content");
    }

    public function getTemplateName()
    {
        return "_layouts/app";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  274 => 0,  272 => 82,  270 => 0,  266 => 81,  262 => 0,  251 => 40,  245 => 37,  240 => 35,  236 => 34,  232 => 33,  228 => 32,  224 => 31,  220 => 30,  216 => 29,  207 => 23,  203 => 22,  195 => 17,  190 => 14,  188 => 0,  184 => 13,  180 => 0,  175 => 109,  170 => 107,  164 => 104,  160 => 103,  156 => 102,  152 => 101,  148 => 100,  144 => 99,  140 => 98,  136 => 97,  132 => 96,  128 => 95,  120 => 89,  118 => 88,  111 => 83,  109 => 81,  103 => 77,  101 => 76,  95 => 72,  93 => 71,  89 => 69,  86 => 62,  84 => 54,  82 => 53,  78 => 51,  72 => 49,  70 => 13,  64 => 10,  60 => 8,  57 => 7,  54 => 6,  51 => 5,  48 => 4,  45 => 3,  43 => 2,  40 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("
  {% set siteInfo = craft.globals().getSetByHandle('siteInformation') %}
  {% set footer = craft.globals().getSetByHandle('footer') %}
  {% set logo = siteInfo.logo.one %}
  {% set medium = craft.app.getAssetTransforms.getTransformByHandle('medium') %}
  {% set small = craft.app.getAssetTransforms.getTransformByHandle('smalll') %}
  {% set thumb = craft.app.getAssetTransforms.getTransformByHandle('thumb') %}
  
<!DOCTYPE html>
<html lang=\"{{ craft.app.language }}\">

<head>
  {% block head %}
  <meta charset=\"utf-8\">
  <meta content=\"width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover\" name=\"viewport\">

  <title>{{ siteName }}</title>
  <meta content=\"\" name=\"descriptison\">
  <meta content=\"\" name=\"keywords\">

  <!-- Favicons -->
  <link href=\" {{ siteInfo.icon.one.url }} \" rel=\"icon\">
  <link href=\"{{ siteUrl }}assets/img/apple-touch-icon.png\" rel=\"apple-touch-icon\">

  <!-- Google Fonts -->
  <link href=\"https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i\" rel=\"stylesheet\">

  <!-- Vendor CSS Files -->
  <link href=\"{{ siteUrl }}assets/vendor/bootstrap/css/bootstrap.min.css\" rel=\"stylesheet\">
  <link href=\"{{ siteUrl }}assets/vendor/icofont/icofont.min.css\" rel=\"stylesheet\">
  <link href=\"{{ siteUrl }}assets/vendor/boxicons/css/boxicons.min.css\" rel=\"stylesheet\">
  <link href=\"{{ siteUrl }}assets/vendor/remixicon/remixicon.css\" rel=\"stylesheet\">
  <link href=\"{{ siteUrl }}assets/vendor/venobox/venobox.css\" rel=\"stylesheet\">
  <link href=\"{{ siteUrl }}assets/vendor/owl.carousel/assets/owl.carousel.min.css\" rel=\"stylesheet\">
  <link href=\"{{ siteUrl }}assets/vendor/animate.css/animate.min.css\" rel=\"stylesheet\">

  <link href=\"{{ siteUrl }}assets/vendor/aos/aos.css\" rel=\"stylesheet\">

  <!-- Template Main CSS File -->
  <link href=\"{{ siteUrl }}assets/css/style.css\" rel=\"stylesheet\">

  <!-- =======================================================
  * Template Name: KnightOne - v2.0.0
  * Template URL: https://bootstrapmade.com/knight-simple-one-page-bootstrap-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
  {% endblock %}
</head>

<body>
  {# create settings for image transform #}
  {% 
      set setImage = {
          mode: 'crop',
          width: 600,
          height :300,
          quality : 90,
          position : 'top-left'
      }
  %}
  {% set logoImg = {
      mode : 'fit',
      width : 200,
      height : 100,
      quality : 90
    }
  %}
  
  <!-- ======= Header ======= -->
  {% include \"_partials/header\" %}
  
  </header><!-- End Header -->

  <!-- ======= Hero Section ======= -->
  {% include \"_partials/hero\" %}
  <!-- End Hero -->

  <main id=\"main\">

    {% block content %}
    {% endblock %}

  </main>
  <!-- End #main -->

  <!-- ======= Footer ======= -->
  {% include \"_partials/footer\" %}
  <!-- End Footer -->

  <div id=\"preloader\"></div>
  <a href=\"#\" class=\"back-to-top\"><i class=\"ri-arrow-up-line\"></i></a>

  <!-- Vendor JS Files -->
  <script src=\"{{ siteUrl }}assets/vendor/jquery/jquery.min.js\"></script>
  <script src=\"{{ siteUrl }}assets/vendor/bootstrap/js/bootstrap.bundle.min.js\"></script>
  <script src=\"{{ siteUrl }}assets/vendor/jquery.easing/jquery.easing.min.js\"></script>
  <script src=\"{{ siteUrl }}assets/vendor/php-email-form/validate.js\"></script>
  <script src=\"{{ siteUrl }}assets/vendor/waypoints/jquery.waypoints.min.js\"></script>
  <script src=\"{{ siteUrl }}assets/vendor/counterup/counterup.min.js\"></script>
  <script src=\"{{ siteUrl }}assets/vendor/isotope-layout/isotope.pkgd.min.js\"></script>
  <script src=\"{{ siteUrl }}assets/vendor/venobox/venobox.min.js\"></script>
  <script src=\"{{ siteUrl }}assets/vendor/owl.carousel/owl.carousel.min.js\"></script>
  <script src=\"{{ siteUrl }}assets/vendor/aos/aos.js\"></script>

  <!-- Template Main JS File -->
  <script src=\"{{ siteUrl }}assets/js/main.js\"></script>

</body>

</html>", "_layouts/app", "/Applications/MAMP/htdocs/craft/smsi/templates/_layouts/app.twig");
    }
}
