<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _includes/revisionmenu */
class __TwigTemplate_c82a7ba0cbaf737b6308adfe884805517323fa016eaad53886a79022a8c64cc6 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_includes/revisionmenu");
        // line 6
        echo "
";
        // line 7
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms", "_includes/revisionmenu", 7)->unwrap();
        // line 8
        echo "
";
        // line 9
        $context["drafts"] = (((isset($context["canHaveDrafts"]) || array_key_exists("canHaveDrafts", $context) ? $context["canHaveDrafts"] : (function () { throw new RuntimeError('Variable "canHaveDrafts" does not exist.', 9, $this->source); })())) ? (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 9, $this->source); })()), "find", [], "method"), "draftOf", [0 =>         // line 10
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 10, $this->source); })())], "method"), "siteId", [0 => craft\helpers\Template::attribute($this->env, $this->source,         // line 11
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 11, $this->source); })()), "siteId", [])], "method"), "anyStatus", [], "method"), "orderBy", [0 => ["dateUpdated" =>         // line 13
(isset($context["SORT_DESC"]) || array_key_exists("SORT_DESC", $context) ? $context["SORT_DESC"] : (function () { throw new RuntimeError('Variable "SORT_DESC" does not exist.', 13, $this->source); })())]], "method"), "all", [], "method")) : ([]));
        // line 15
        echo "
";
        // line 16
        $context["revisions"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 16, $this->source); })()), "find", [], "method"), "revisionOf", [0 => craft\helpers\Template::attribute($this->env, $this->source,         // line 17
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 17, $this->source); })()), "sourceId", [])], "method"), "siteId", [0 => craft\helpers\Template::attribute($this->env, $this->source,         // line 18
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 18, $this->source); })()), "siteId", [])], "method"), "anyStatus", [], "method"), "offset", [0 => 1], "method"), "limit", [0 => 10], "method"), "orderBy", [0 => ["dateCreated" =>         // line 22
(isset($context["SORT_DESC"]) || array_key_exists("SORT_DESC", $context) ? $context["SORT_DESC"] : (function () { throw new RuntimeError('Variable "SORT_DESC" does not exist.', 22, $this->source); })())]], "method"), "all", [], "method");
        // line 24
        echo "
";
        // line 25
        $context["baseParams"] = $this->extensions['craft\web\twig\Extension']->withoutKeyFilter($this->extensions['craft\web\twig\Extension']->withoutKeyFilter($this->extensions['craft\web\twig\Extension']->withoutKeyFilter($this->extensions['craft\web\twig\Extension']->withoutKeyFilter($this->extensions['craft\web\twig\Extension']->withoutKeyFilter(craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 25, $this->source); })()), "app", []), "request", []), "queryParams", []), craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 25, $this->source); })()), "app", []), "config", []), "general", []), "pathParam", [])), "draftId"), "revisionId"), "siteId"), "fresh");
        // line 26
        $context["supportedSiteIds"] = (($context["supportedSiteIds"]) ?? (craft\helpers\ArrayHelper::getColumn(((craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 26, $this->source); })()), "app", []), "isMultiSite", [])) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 26, $this->source); })()), "getSupportedSites", [], "method")) : ([0 => craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 26, $this->source); })()), "siteId", [])])), function ($__s__) use ($context, $macros) { $context["s"] = $__s__; return (((craft\helpers\Template::attribute($this->env, $this->source, ($context["s"] ?? null), "siteId", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["s"] ?? null), "siteId", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["s"] ?? null), "siteId", [])) : ((isset($context["s"]) || array_key_exists("s", $context) ? $context["s"] : (function () { throw new RuntimeError('Variable "s" does not exist.', 26, $this->source); })()))); })));
        // line 27
        $context["editableSiteIds"] = (($context["editableSiteIds"]) ?? (array_intersect((isset($context["supportedSiteIds"]) || array_key_exists("supportedSiteIds", $context) ? $context["supportedSiteIds"] : (function () { throw new RuntimeError('Variable "supportedSiteIds" does not exist.', 27, $this->source); })()), craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 27, $this->source); })()), "app", []), "sites", []), "getEditableSiteIds", [], "method"))));
        // line 28
        $context["isMultiSiteElement"] = (twig_length_filter($this->env, (isset($context["supportedSiteIds"]) || array_key_exists("supportedSiteIds", $context) ? $context["supportedSiteIds"] : (function () { throw new RuntimeError('Variable "supportedSiteIds" does not exist.', 28, $this->source); })())) > 1);
        // line 29
        $context["canEditMultipleSites"] = (twig_length_filter($this->env, (isset($context["editableSiteIds"]) || array_key_exists("editableSiteIds", $context) ? $context["editableSiteIds"] : (function () { throw new RuntimeError('Variable "editableSiteIds" does not exist.', 29, $this->source); })())) > 1);
        // line 30
        $context["isDraft"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 30, $this->source); })()), "getIsDraft", [], "method");
        // line 31
        $context["isRevision"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 31, $this->source); })()), "getIsRevision", [], "method");
        // line 32
        $context["showSiteLabel"] = (($context["showSiteLabel"]) ?? ((isset($context["isMultiSiteElement"]) || array_key_exists("isMultiSiteElement", $context) ? $context["isMultiSiteElement"] : (function () { throw new RuntimeError('Variable "isMultiSiteElement" does not exist.', 32, $this->source); })())));
        // line 33
        $context["showRevisionLabel"] = (($context["showRevisionLabel"]) ?? (((isset($context["canHaveDrafts"]) || array_key_exists("canHaveDrafts", $context) ? $context["canHaveDrafts"] : (function () { throw new RuntimeError('Variable "canHaveDrafts" does not exist.', 33, $this->source); })()) || twig_length_filter($this->env, (isset($context["revisions"]) || array_key_exists("revisions", $context) ? $context["revisions"] : (function () { throw new RuntimeError('Variable "revisions" does not exist.', 33, $this->source); })())))));
        // line 34
        $context["cpEditUrl"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 34, $this->source); })()), "getCpEditUrl", [], "method");
        // line 35
        if ((isset($context["isDraft"]) || array_key_exists("isDraft", $context) ? $context["isDraft"] : (function () { throw new RuntimeError('Variable "isDraft" does not exist.', 35, $this->source); })())) {
            // line 36
            echo "    ";
            $context["baseUrl"] = craft\helpers\UrlHelper::url((isset($context["cpEditUrl"]) || array_key_exists("cpEditUrl", $context) ? $context["cpEditUrl"] : (function () { throw new RuntimeError('Variable "cpEditUrl" does not exist.', 36, $this->source); })()), $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["baseParams"]) || array_key_exists("baseParams", $context) ? $context["baseParams"] : (function () { throw new RuntimeError('Variable "baseParams" does not exist.', 36, $this->source); })()), ["draftId" => craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 36, $this->source); })()), "draftId", [])]));
        } elseif (        // line 37
(isset($context["isRevision"]) || array_key_exists("isRevision", $context) ? $context["isRevision"] : (function () { throw new RuntimeError('Variable "isRevision" does not exist.', 37, $this->source); })())) {
            // line 38
            echo "    ";
            $context["baseUrl"] = craft\helpers\UrlHelper::url((isset($context["cpEditUrl"]) || array_key_exists("cpEditUrl", $context) ? $context["cpEditUrl"] : (function () { throw new RuntimeError('Variable "cpEditUrl" does not exist.', 38, $this->source); })()), $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["baseParams"]) || array_key_exists("baseParams", $context) ? $context["baseParams"] : (function () { throw new RuntimeError('Variable "baseParams" does not exist.', 38, $this->source); })()), ["revisionId" => craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 38, $this->source); })()), "revisionId", [])]));
        } else {
            // line 40
            echo "    ";
            $context["baseUrl"] = (isset($context["cpEditUrl"]) || array_key_exists("cpEditUrl", $context) ? $context["cpEditUrl"] : (function () { throw new RuntimeError('Variable "cpEditUrl" does not exist.', 40, $this->source); })());
        }
        // line 42
        echo "
";
        // line 43
        $context["isUnsavedDraft"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 43, $this->source); })()), "getIsUnsavedDraft", [], "method");
        // line 44
        $context["showRevisions"] = ((isset($context["showRevisionLabel"]) || array_key_exists("showRevisionLabel", $context) ? $context["showRevisionLabel"] : (function () { throw new RuntimeError('Variable "showRevisionLabel" does not exist.', 44, $this->source); })()) &&  !(isset($context["isUnsavedDraft"]) || array_key_exists("isUnsavedDraft", $context) ? $context["isUnsavedDraft"] : (function () { throw new RuntimeError('Variable "isUnsavedDraft" does not exist.', 44, $this->source); })()));
        // line 45
        $context["enableMenu"] = ((twig_length_filter($this->env, (isset($context["editableSiteIds"]) || array_key_exists("editableSiteIds", $context) ? $context["editableSiteIds"] : (function () { throw new RuntimeError('Variable "editableSiteIds" does not exist.', 45, $this->source); })())) > 1) || (isset($context["showRevisions"]) || array_key_exists("showRevisions", $context) ? $context["showRevisions"] : (function () { throw new RuntimeError('Variable "showRevisions" does not exist.', 45, $this->source); })()));
        // line 46
        echo "
<div id=\"revision-btngroup\" class=\"btngroup\">
    <div id=\"revision-btn\" class=\"btn ";
        // line 48
        if ((isset($context["enableMenu"]) || array_key_exists("enableMenu", $context) ? $context["enableMenu"] : (function () { throw new RuntimeError('Variable "enableMenu" does not exist.', 48, $this->source); })())) {
            echo "menubtn";
        } else {
            echo "disabled";
        }
        echo "\"";
        if ((isset($context["showSiteLabel"]) || array_key_exists("showSiteLabel", $context) ? $context["showSiteLabel"] : (function () { throw new RuntimeError('Variable "showSiteLabel" does not exist.', 48, $this->source); })())) {
            echo " data-icon=\"world\"";
        }
        echo ">
        ";
        // line 49
        if ((isset($context["showSiteLabel"]) || array_key_exists("showSiteLabel", $context) ? $context["showSiteLabel"] : (function () { throw new RuntimeError('Variable "showSiteLabel" does not exist.', 49, $this->source); })())) {
            // line 50
            echo "            ";
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 50, $this->source); })()), "getSite", [], "method"), "name", []), "site"), "html", null, true);
            echo "
        ";
        }
        // line 52
        echo "        ";
        if (((isset($context["showSiteLabel"]) || array_key_exists("showSiteLabel", $context) ? $context["showSiteLabel"] : (function () { throw new RuntimeError('Variable "showSiteLabel" does not exist.', 52, $this->source); })()) && (isset($context["showRevisionLabel"]) || array_key_exists("showRevisionLabel", $context) ? $context["showRevisionLabel"] : (function () { throw new RuntimeError('Variable "showRevisionLabel" does not exist.', 52, $this->source); })()))) {
            echo "–";
        }
        // line 53
        echo "        ";
        if ((isset($context["showRevisionLabel"]) || array_key_exists("showRevisionLabel", $context) ? $context["showRevisionLabel"] : (function () { throw new RuntimeError('Variable "showRevisionLabel" does not exist.', 53, $this->source); })())) {
            // line 54
            echo "            <span id=\"revision-label\">";
            // line 55
            if ((isset($context["isDraft"]) || array_key_exists("isDraft", $context) ? $context["isDraft"] : (function () { throw new RuntimeError('Variable "isDraft" does not exist.', 55, $this->source); })())) {
                // line 56
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 56, $this->source); })()), "getDraftName", [], "method"), "html", null, true);
            } elseif (            // line 57
(isset($context["isRevision"]) || array_key_exists("isRevision", $context) ? $context["isRevision"] : (function () { throw new RuntimeError('Variable "isRevision" does not exist.', 57, $this->source); })())) {
                // line 58
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 58, $this->source); })()), "getRevisionLabel", [], "method"), "html", null, true);
            } else {
                // line 60
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Current", "app"), "html", null, true);
            }
            // line 62
            echo "</span>
        ";
        }
        // line 64
        echo "    </div>

    ";
        // line 66
        if ((isset($context["enableMenu"]) || array_key_exists("enableMenu", $context) ? $context["enableMenu"] : (function () { throw new RuntimeError('Variable "enableMenu" does not exist.', 66, $this->source); })())) {
            // line 67
            echo "        <div class=\"menu\">
            ";
            // line 68
            if ((isset($context["canEditMultipleSites"]) || array_key_exists("canEditMultipleSites", $context) ? $context["canEditMultipleSites"] : (function () { throw new RuntimeError('Variable "canEditMultipleSites" does not exist.', 68, $this->source); })())) {
                // line 69
                echo "                ";
                $context["enabledSiteIds"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 69, $this->source); })()), "app", []), "elements", []), "getEnabledSiteIdsForElement", [0 => craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 69, $this->source); })()), "id", [])], "method");
                // line 70
                echo "                ";
                $context["siteGroups"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 70, $this->source); })()), "app", []), "sites", []), "getAllGroups", [], "method");
                // line 71
                echo "                ";
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable((isset($context["siteGroups"]) || array_key_exists("siteGroups", $context) ? $context["siteGroups"] : (function () { throw new RuntimeError('Variable "siteGroups" does not exist.', 71, $this->source); })()));
                foreach ($context['_seq'] as $context["_key"] => $context["group"]) {
                    // line 72
                    echo "                    ";
                    $context["groupSiteIds"] = array_intersect(craft\helpers\Template::attribute($this->env, $this->source, $context["group"], "getSiteIds", [], "method"), (isset($context["editableSiteIds"]) || array_key_exists("editableSiteIds", $context) ? $context["editableSiteIds"] : (function () { throw new RuntimeError('Variable "editableSiteIds" does not exist.', 72, $this->source); })()));
                    // line 73
                    echo "                    ";
                    if ((isset($context["groupSiteIds"]) || array_key_exists("groupSiteIds", $context) ? $context["groupSiteIds"] : (function () { throw new RuntimeError('Variable "groupSiteIds" does not exist.', 73, $this->source); })())) {
                        // line 74
                        echo "                        ";
                        if ((twig_length_filter($this->env, (isset($context["siteGroups"]) || array_key_exists("siteGroups", $context) ? $context["siteGroups"] : (function () { throw new RuntimeError('Variable "siteGroups" does not exist.', 74, $this->source); })())) > 1)) {
                            echo "<h6>";
                            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source, $context["group"], "name", []), "site"), "html", null, true);
                            echo "</h6>";
                        }
                        // line 75
                        echo "                        <ul class=\"padded\">
                            ";
                        // line 76
                        $context['_parent'] = $context;
                        $context['_seq'] = twig_ensure_traversable((isset($context["groupSiteIds"]) || array_key_exists("groupSiteIds", $context) ? $context["groupSiteIds"] : (function () { throw new RuntimeError('Variable "groupSiteIds" does not exist.', 76, $this->source); })()));
                        foreach ($context['_seq'] as $context["_key"] => $context["siteId"]) {
                            // line 77
                            echo "                                ";
                            $context["site"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 77, $this->source); })()), "app", []), "sites", []), "getSiteById", [0 => $context["siteId"]], "method");
                            // line 78
                            echo "                                ";
                            $context["status"] = (((craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 78, $this->source); })()), "enabled", []) && twig_in_filter($context["siteId"], (isset($context["enabledSiteIds"]) || array_key_exists("enabledSiteIds", $context) ? $context["enabledSiteIds"] : (function () { throw new RuntimeError('Variable "enabledSiteIds" does not exist.', 78, $this->source); })())))) ? ("enabled") : ("disabled"));
                            // line 79
                            echo "                                <li>
                                    ";
                            // line 80
                            if (($context["siteId"] == craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 80, $this->source); })()), "siteId", []))) {
                                // line 81
                                echo "                                        <a class=\"site-option sel\">
                                            <div class=\"status ";
                                // line 82
                                echo twig_escape_filter($this->env, (isset($context["status"]) || array_key_exists("status", $context) ? $context["status"] : (function () { throw new RuntimeError('Variable "status" does not exist.', 82, $this->source); })()), "html", null, true);
                                echo "\"></div>";
                                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 82, $this->source); })()), "name", []), "site"), "html", null, true);
                                echo "
                                        </a>
                                    ";
                            } else {
                                // line 85
                                echo "                                        ";
                                $context["url"] = craft\helpers\UrlHelper::url((isset($context["baseUrl"]) || array_key_exists("baseUrl", $context) ? $context["baseUrl"] : (function () { throw new RuntimeError('Variable "baseUrl" does not exist.', 85, $this->source); })()), ["site" => craft\helpers\Template::attribute($this->env, $this->source, (isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 85, $this->source); })()), "handle", [])]);
                                // line 86
                                echo "                                        <a class=\"site-option\" href=\"";
                                echo twig_escape_filter($this->env, (isset($context["url"]) || array_key_exists("url", $context) ? $context["url"] : (function () { throw new RuntimeError('Variable "url" does not exist.', 86, $this->source); })()), "html", null, true);
                                echo "\">
                                            <div class=\"status ";
                                // line 87
                                echo twig_escape_filter($this->env, (isset($context["status"]) || array_key_exists("status", $context) ? $context["status"] : (function () { throw new RuntimeError('Variable "status" does not exist.', 87, $this->source); })()), "html", null, true);
                                echo "\"></div>";
                                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 87, $this->source); })()), "name", []), "site"), "html", null, true);
                                echo "
                                        </a>
                                    ";
                            }
                            // line 90
                            echo "                                </li>
                            ";
                        }
                        $_parent = $context['_parent'];
                        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['siteId'], $context['_parent'], $context['loop']);
                        $context = array_intersect_key($context, $_parent) + $_parent;
                        // line 92
                        echo "                        </ul>
                    ";
                    }
                    // line 94
                    echo "                ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['group'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 95
                echo "            ";
            }
            // line 96
            echo "
            ";
            // line 97
            if (((isset($context["canEditMultipleSites"]) || array_key_exists("canEditMultipleSites", $context) ? $context["canEditMultipleSites"] : (function () { throw new RuntimeError('Variable "canEditMultipleSites" does not exist.', 97, $this->source); })()) && (isset($context["showRevisions"]) || array_key_exists("showRevisions", $context) ? $context["showRevisions"] : (function () { throw new RuntimeError('Variable "showRevisions" does not exist.', 97, $this->source); })()))) {
                echo "<hr>";
            }
            // line 98
            echo "
            ";
            // line 99
            if ((isset($context["showRevisions"]) || array_key_exists("showRevisions", $context) ? $context["showRevisions"] : (function () { throw new RuntimeError('Variable "showRevisions" does not exist.', 99, $this->source); })())) {
                // line 100
                echo "                <ul class=\"padded revision-group-current\">
                    ";
                // line 101
                $context["currentRevision"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 101, $this->source); })()), "getCurrentRevision", [], "method");
                // line 102
                echo "                    ";
                $context["currentRevisionEditTime"] = (((craft\helpers\Template::attribute($this->env, $this->source, ($context["currentRevision"] ?? null), "dateCreated", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["currentRevision"] ?? null), "dateCreated", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["currentRevision"] ?? null), "dateCreated", [])) : (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 102, $this->source); })()), "dateUpdated", [])));
                // line 103
                echo "                    ";
                $context["currentRevisionCreator"] = (((isset($context["currentRevision"]) || array_key_exists("currentRevision", $context) ? $context["currentRevision"] : (function () { throw new RuntimeError('Variable "currentRevision" does not exist.', 103, $this->source); })())) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["currentRevision"]) || array_key_exists("currentRevision", $context) ? $context["currentRevision"] : (function () { throw new RuntimeError('Variable "currentRevision" does not exist.', 103, $this->source); })()), "getCreator", [], "method")) : (""));
                // line 104
                echo "                    <li>
                        <a";
                // line 105
                if (( !(isset($context["isDraft"]) || array_key_exists("isDraft", $context) ? $context["isDraft"] : (function () { throw new RuntimeError('Variable "isDraft" does not exist.', 105, $this->source); })()) &&  !(isset($context["isRevision"]) || array_key_exists("isRevision", $context) ? $context["isRevision"] : (function () { throw new RuntimeError('Variable "isRevision" does not exist.', 105, $this->source); })()))) {
                    echo " class=\"sel\"";
                }
                echo " href=\"";
                echo twig_escape_filter($this->env, (isset($context["cpEditUrl"]) || array_key_exists("cpEditUrl", $context) ? $context["cpEditUrl"] : (function () { throw new RuntimeError('Variable "cpEditUrl" does not exist.', 105, $this->source); })()), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Current", "app"), "html", null, true);
                echo "
                            <span class=\"light\">–
                                ";
                // line 107
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFilter('timestamp')->getCallable(), [(isset($context["currentRevisionEditTime"]) || array_key_exists("currentRevisionEditTime", $context) ? $context["currentRevisionEditTime"] : (function () { throw new RuntimeError('Variable "currentRevisionEditTime" does not exist.', 107, $this->source); })()), "short"]), "html", null, true);
                // line 108
                if ((isset($context["currentRevisionCreator"]) || array_key_exists("currentRevisionCreator", $context) ? $context["currentRevisionCreator"] : (function () { throw new RuntimeError('Variable "currentRevisionCreator" does not exist.', 108, $this->source); })())) {
                    echo ", ";
                    echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["currentRevisionCreator"]) || array_key_exists("currentRevisionCreator", $context) ? $context["currentRevisionCreator"] : (function () { throw new RuntimeError('Variable "currentRevisionCreator" does not exist.', 108, $this->source); })()), "name", []), "html", null, true);
                }
                // line 109
                echo "                            </span>
                        </a>
                    </li>
                </ul>
            ";
            }
            // line 114
            echo "
            ";
            // line 115
            if ((isset($context["drafts"]) || array_key_exists("drafts", $context) ? $context["drafts"] : (function () { throw new RuntimeError('Variable "drafts" does not exist.', 115, $this->source); })())) {
                // line 116
                echo "                <h6>";
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Drafts", "app"), "html", null, true);
                echo "</h6>
                <ul class=\"padded revision-group-drafts\">
                    ";
                // line 118
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable((isset($context["drafts"]) || array_key_exists("drafts", $context) ? $context["drafts"] : (function () { throw new RuntimeError('Variable "drafts" does not exist.', 118, $this->source); })()));
                foreach ($context['_seq'] as $context["_key"] => $context["draft"]) {
                    // line 119
                    echo "                        ";
                    $context["url"] = craft\helpers\UrlHelper::url((isset($context["cpEditUrl"]) || array_key_exists("cpEditUrl", $context) ? $context["cpEditUrl"] : (function () { throw new RuntimeError('Variable "cpEditUrl" does not exist.', 119, $this->source); })()), $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["baseParams"]) || array_key_exists("baseParams", $context) ? $context["baseParams"] : (function () { throw new RuntimeError('Variable "baseParams" does not exist.', 119, $this->source); })()), ["draftId" => craft\helpers\Template::attribute($this->env, $this->source, $context["draft"], "draftId", [])]));
                    // line 120
                    echo "                        <li>
                            <a";
                    // line 121
                    if ((craft\helpers\Template::attribute($this->env, $this->source, $context["draft"], "draftId", []) == craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 121, $this->source); })()), "draftId", []))) {
                        echo " class=\"sel\"";
                    }
                    echo " href=\"";
                    echo twig_escape_filter($this->env, (isset($context["url"]) || array_key_exists("url", $context) ? $context["url"] : (function () { throw new RuntimeError('Variable "url" does not exist.', 121, $this->source); })()), "html", null, true);
                    echo "\">
                                <span class=\"draft-name\">";
                    // line 122
                    echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["draft"], "draftName", []), "html", null, true);
                    echo "</span>
                                ";
                    // line 123
                    $context["creator"] = craft\helpers\Template::attribute($this->env, $this->source, $context["draft"], "getCreator", [], "method");
                    // line 124
                    echo "                                <span class=\"draft-meta light\">–
                                    ";
                    // line 125
                    echo twig_escape_filter($this->env, call_user_func_array($this->env->getFilter('timestamp')->getCallable(), [craft\helpers\Template::attribute($this->env, $this->source, $context["draft"], "dateUpdated", []), "short"]), "html", null, true);
                    // line 126
                    if ((isset($context["creator"]) || array_key_exists("creator", $context) ? $context["creator"] : (function () { throw new RuntimeError('Variable "creator" does not exist.', 126, $this->source); })())) {
                        echo ", ";
                        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["creator"]) || array_key_exists("creator", $context) ? $context["creator"] : (function () { throw new RuntimeError('Variable "creator" does not exist.', 126, $this->source); })()), "name", []), "html", null, true);
                    }
                    // line 127
                    echo "                                </span>
                            </a>
                        </li>
                    ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['draft'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 131
                echo "                </ul>
            ";
            }
            // line 133
            echo "
            ";
            // line 134
            if ((isset($context["revisions"]) || array_key_exists("revisions", $context) ? $context["revisions"] : (function () { throw new RuntimeError('Variable "revisions" does not exist.', 134, $this->source); })())) {
                // line 135
                echo "                <h6>";
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Recent Revisions", "app"), "html", null, true);
                echo "</h6>
                <ul class=\"padded\" id=\"revision-group-revisions\">
                    ";
                // line 137
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable((isset($context["revisions"]) || array_key_exists("revisions", $context) ? $context["revisions"] : (function () { throw new RuntimeError('Variable "revisions" does not exist.', 137, $this->source); })()));
                foreach ($context['_seq'] as $context["_key"] => $context["revision"]) {
                    // line 138
                    echo "                        <li>
                            ";
                    // line 139
                    $context["url"] = craft\helpers\UrlHelper::url((isset($context["cpEditUrl"]) || array_key_exists("cpEditUrl", $context) ? $context["cpEditUrl"] : (function () { throw new RuntimeError('Variable "cpEditUrl" does not exist.', 139, $this->source); })()), $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["baseParams"]) || array_key_exists("baseParams", $context) ? $context["baseParams"] : (function () { throw new RuntimeError('Variable "baseParams" does not exist.', 139, $this->source); })()), ["revisionId" => craft\helpers\Template::attribute($this->env, $this->source, $context["revision"], "revisionId", [])]));
                    // line 140
                    echo "                            <a";
                    if ((craft\helpers\Template::attribute($this->env, $this->source, $context["revision"], "revisionId", []) == craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 140, $this->source); })()), "revisionId", []))) {
                        echo " class=\"sel\"";
                    }
                    echo " href=\"";
                    echo twig_escape_filter($this->env, (isset($context["url"]) || array_key_exists("url", $context) ? $context["url"] : (function () { throw new RuntimeError('Variable "url" does not exist.', 140, $this->source); })()), "html", null, true);
                    echo "\">
                                ";
                    // line 141
                    echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["revision"], "getRevisionLabel", [], "method"), "html", null, true);
                    echo "
                                ";
                    // line 142
                    $context["creator"] = craft\helpers\Template::attribute($this->env, $this->source, $context["revision"], "getCreator", [], "method");
                    // line 143
                    echo "                                <span class=\"light\">–
                                    ";
                    // line 144
                    echo twig_escape_filter($this->env, call_user_func_array($this->env->getFilter('timestamp')->getCallable(), [craft\helpers\Template::attribute($this->env, $this->source, $context["revision"], "dateCreated", []), "short"]), "html", null, true);
                    // line 145
                    if ((isset($context["creator"]) || array_key_exists("creator", $context) ? $context["creator"] : (function () { throw new RuntimeError('Variable "creator" does not exist.', 145, $this->source); })())) {
                        echo ", ";
                        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["creator"]) || array_key_exists("creator", $context) ? $context["creator"] : (function () { throw new RuntimeError('Variable "creator" does not exist.', 145, $this->source); })()), "name", []), "html", null, true);
                    }
                    // line 146
                    echo "                                </span>
                            </a>
                        </li>
                    ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['revision'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 150
                echo "                </ul>
            ";
            }
            // line 152
            echo "        </div>
    ";
        }
        // line 154
        echo "</div>

<div id=\"revision-spinner\" class=\"spinner hidden\" title=\"";
        // line 156
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Saving", "app"), "html", null, true);
        echo "\"></div>
<div id=\"revision-status\" class=\"invisible\"></div>
";
        // line 0
        craft\helpers\Template::endProfile("template", "_includes/revisionmenu");
    }

    public function getTemplateName()
    {
        return "_includes/revisionmenu";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  436 => 0,  431 => 156,  427 => 154,  423 => 152,  419 => 150,  410 => 146,  405 => 145,  403 => 144,  400 => 143,  398 => 142,  394 => 141,  385 => 140,  383 => 139,  380 => 138,  376 => 137,  370 => 135,  368 => 134,  365 => 133,  361 => 131,  352 => 127,  347 => 126,  345 => 125,  342 => 124,  340 => 123,  336 => 122,  328 => 121,  325 => 120,  322 => 119,  318 => 118,  312 => 116,  310 => 115,  307 => 114,  300 => 109,  295 => 108,  293 => 107,  282 => 105,  279 => 104,  276 => 103,  273 => 102,  271 => 101,  268 => 100,  266 => 99,  263 => 98,  259 => 97,  256 => 96,  253 => 95,  247 => 94,  243 => 92,  236 => 90,  228 => 87,  223 => 86,  220 => 85,  212 => 82,  209 => 81,  207 => 80,  204 => 79,  201 => 78,  198 => 77,  194 => 76,  191 => 75,  184 => 74,  181 => 73,  178 => 72,  173 => 71,  170 => 70,  167 => 69,  165 => 68,  162 => 67,  160 => 66,  156 => 64,  152 => 62,  149 => 60,  146 => 58,  144 => 57,  142 => 56,  140 => 55,  138 => 54,  135 => 53,  130 => 52,  124 => 50,  122 => 49,  110 => 48,  106 => 46,  104 => 45,  102 => 44,  100 => 43,  97 => 42,  93 => 40,  89 => 38,  87 => 37,  84 => 36,  82 => 35,  80 => 34,  78 => 33,  76 => 32,  74 => 31,  72 => 30,  70 => 29,  68 => 28,  66 => 27,  64 => 26,  62 => 25,  59 => 24,  57 => 22,  56 => 18,  55 => 17,  54 => 16,  51 => 15,  49 => 13,  48 => 11,  47 => 10,  46 => 9,  43 => 8,  41 => 7,  38 => 6,);
    }

    public function getSourceContext()
    {
        return new Source("{#
    Shows a revision menu for an element.

    Only an existing element should be passed to this.
#}

{% import \"_includes/forms\" as forms %}

{% set drafts = canHaveDrafts ? element.find()
    .draftOf(element)
    .siteId(element.siteId)
    .anyStatus()
    .orderBy({dateUpdated: SORT_DESC})
    .all() : [] %}

{% set revisions = element.find()
    .revisionOf(element.sourceId)
    .siteId(element.siteId)
    .anyStatus()
    .offset(1)
    .limit(10)
    .orderBy({dateCreated: SORT_DESC})
    .all() %}

{% set baseParams = craft.app.request.queryParams|withoutKey(craft.app.config.general.pathParam)|withoutKey('draftId')|withoutKey('revisionId')|withoutKey('siteId')|withoutKey('fresh') %}
{% set supportedSiteIds = supportedSiteIds ?? (craft.app.isMultiSite ? element.getSupportedSites() : [element.siteId])|column(s => s.siteId ?? s) %}
{% set editableSiteIds = editableSiteIds ?? supportedSiteIds|intersect(craft.app.sites.getEditableSiteIds()) %}
{% set isMultiSiteElement = supportedSiteIds|length > 1 %}
{% set canEditMultipleSites = editableSiteIds|length > 1 %}
{% set isDraft = element.getIsDraft() %}
{% set isRevision = element.getIsRevision() %}
{% set showSiteLabel = showSiteLabel ?? isMultiSiteElement %}
{% set showRevisionLabel = showRevisionLabel ?? (canHaveDrafts or revisions|length) %}
{% set cpEditUrl = element.getCpEditUrl() %}
{% if isDraft %}
    {% set baseUrl = url(cpEditUrl, baseParams|merge({ draftId: element.draftId })) %}
{% elseif isRevision %}
    {% set baseUrl = url(cpEditUrl, baseParams|merge({ revisionId: element.revisionId })) %}
{% else %}
    {% set baseUrl = cpEditUrl %}
{% endif %}

{% set isUnsavedDraft = element.getIsUnsavedDraft() %}
{% set showRevisions = showRevisionLabel and not isUnsavedDraft %}
{% set enableMenu = editableSiteIds|length > 1 or showRevisions %}

<div id=\"revision-btngroup\" class=\"btngroup\">
    <div id=\"revision-btn\" class=\"btn {% if enableMenu %}menubtn{% else %}disabled{% endif %}\"{% if showSiteLabel %} data-icon=\"world\"{% endif %}>
        {% if showSiteLabel %}
            {{ element.getSite().name|t('site') }}
        {% endif %}
        {% if showSiteLabel and showRevisionLabel %}–{% endif %}
        {% if showRevisionLabel %}
            <span id=\"revision-label\">
                {%- if isDraft %}
                    {{- element.getDraftName() }}
                {%- elseif isRevision %}
                    {{- element.getRevisionLabel() }}
                {%- else %}
                    {{- 'Current'|t('app') }}
                {%- endif -%}
            </span>
        {% endif %}
    </div>

    {% if enableMenu %}
        <div class=\"menu\">
            {% if canEditMultipleSites %}
                {% set enabledSiteIds = craft.app.elements.getEnabledSiteIdsForElement(element.id) %}
                {% set siteGroups = craft.app.sites.getAllGroups() %}
                {% for group in siteGroups %}
                    {% set groupSiteIds = group.getSiteIds()|intersect(editableSiteIds) %}
                    {% if groupSiteIds %}
                        {% if siteGroups|length > 1 %}<h6>{{ group.name|t('site') }}</h6>{% endif %}
                        <ul class=\"padded\">
                            {% for siteId in groupSiteIds %}
                                {% set site = craft.app.sites.getSiteById(siteId) %}
                                {% set status = element.enabled and siteId in enabledSiteIds ? 'enabled' : 'disabled' %}
                                <li>
                                    {% if siteId == element.siteId %}
                                        <a class=\"site-option sel\">
                                            <div class=\"status {{ status }}\"></div>{{ site.name|t('site') }}
                                        </a>
                                    {% else %}
                                        {% set url = url(baseUrl, { site: site.handle }) %}
                                        <a class=\"site-option\" href=\"{{ url }}\">
                                            <div class=\"status {{ status }}\"></div>{{ site.name|t('site') }}
                                        </a>
                                    {% endif %}
                                </li>
                            {% endfor %}
                        </ul>
                    {% endif %}
                {% endfor %}
            {% endif %}

            {% if canEditMultipleSites and showRevisions %}<hr>{% endif %}

            {% if showRevisions %}
                <ul class=\"padded revision-group-current\">
                    {% set currentRevision = element.getCurrentRevision() %}
                    {% set currentRevisionEditTime = currentRevision.dateCreated ?? element.dateUpdated %}
                    {% set currentRevisionCreator = currentRevision ? currentRevision.getCreator() %}
                    <li>
                        <a{% if not isDraft and not isRevision %} class=\"sel\"{% endif %} href=\"{{ cpEditUrl }}\">{{ \"Current\"|t('app') }}
                            <span class=\"light\">–
                                {{ currentRevisionEditTime|timestamp('short') }}
                                {%- if currentRevisionCreator %}, {{ currentRevisionCreator.name }}{% endif %}
                            </span>
                        </a>
                    </li>
                </ul>
            {% endif %}

            {% if drafts %}
                <h6>{{ \"Drafts\"|t('app') }}</h6>
                <ul class=\"padded revision-group-drafts\">
                    {% for draft in drafts %}
                        {% set url = url(cpEditUrl, baseParams|merge({ draftId: draft.draftId })) %}
                        <li>
                            <a{% if draft.draftId == element.draftId %} class=\"sel\"{% endif %} href=\"{{ url }}\">
                                <span class=\"draft-name\">{{ draft.draftName }}</span>
                                {% set creator = draft.getCreator() %}
                                <span class=\"draft-meta light\">–
                                    {{ draft.dateUpdated|timestamp('short') }}
                                    {%- if creator %}, {{ creator.name }}{% endif %}
                                </span>
                            </a>
                        </li>
                    {% endfor %}
                </ul>
            {% endif %}

            {% if revisions %}
                <h6>{{ \"Recent Revisions\"|t('app') }}</h6>
                <ul class=\"padded\" id=\"revision-group-revisions\">
                    {% for revision in revisions %}
                        <li>
                            {% set url = url(cpEditUrl, baseParams|merge({ revisionId: revision.revisionId })) %}
                            <a{% if revision.revisionId == element.revisionId %} class=\"sel\"{% endif %} href=\"{{ url }}\">
                                {{ revision.getRevisionLabel() }}
                                {% set creator = revision.getCreator() %}
                                <span class=\"light\">–
                                    {{ revision.dateCreated|timestamp('short') }}
                                    {%- if creator %}, {{ creator.name }}{% endif %}
                                </span>
                            </a>
                        </li>
                    {% endfor %}
                </ul>
            {% endif %}
        </div>
    {% endif %}
</div>

<div id=\"revision-spinner\" class=\"spinner hidden\" title=\"{{ 'Saving'|t('app') }}\"></div>
<div id=\"revision-status\" class=\"invisible\"></div>
", "_includes/revisionmenu", "/Applications/MAMP/htdocs/craft/smsi/vendor/craftcms/cms/src/templates/_includes/revisionmenu.html");
    }
}
