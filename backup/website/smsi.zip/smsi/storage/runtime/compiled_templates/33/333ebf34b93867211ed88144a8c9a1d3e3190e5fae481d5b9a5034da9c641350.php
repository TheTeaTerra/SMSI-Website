<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _components/fieldtypes/Matrix/settings */
class __TwigTemplate_41ebbb48115e98e557466fb5dca509a4ec361698790e3b4c5a4422660e0a7171 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_components/fieldtypes/Matrix/settings");
        // line 1
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms", "_components/fieldtypes/Matrix/settings", 1)->unwrap();
        // line 2
        echo "

";
        // line 4
        ob_start();
        // line 5
        echo "    <div class=\"mc-sidebar block-types\">
        <div class=\"col-inner-container\">
            <div class=\"heading\">
                <h5>";
        // line 8
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Block Types", "app"), "html", null, true);
        echo "</h5>
            </div>
            <div class=\"items\">
                <div class=\"blocktypes\">
                    ";
        // line 12
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["blockTypes"]) || array_key_exists("blockTypes", $context) ? $context["blockTypes"] : (function () { throw new RuntimeError('Variable "blockTypes" does not exist.', 12, $this->source); })()));
        foreach ($context['_seq'] as $context["blockTypeId"] => $context["blockType"]) {
            // line 13
            echo "                        <div class=\"matrixconfigitem mci-blocktype";
            if (craft\helpers\Template::attribute($this->env, $this->source, $context["blockType"], "hasFieldErrors", [])) {
                echo " error";
            }
            echo "\" data-id=\"";
            echo twig_escape_filter($this->env, $context["blockTypeId"], "html", null, true);
            echo "\"";
            if (craft\helpers\Template::attribute($this->env, $this->source, $context["blockType"], "hasErrors", [], "method")) {
                echo " data-errors=\"";
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->jsonEncodeFilter(craft\helpers\Template::attribute($this->env, $this->source, $context["blockType"], "getErrors", [], "method")), "html", null, true);
                echo "\"";
            }
            echo ">
                            <div class=\"name\">";
            // line 14
            if (craft\helpers\Template::attribute($this->env, $this->source, $context["blockType"], "name", [])) {
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["blockType"], "name", []), "html", null, true);
            } else {
                echo "&nbsp;";
            }
            echo "</div>
                            <div class=\"handle code\">";
            // line 15
            if (craft\helpers\Template::attribute($this->env, $this->source, $context["blockType"], "handle", [])) {
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["blockType"], "handle", []), "html", null, true);
            } else {
                echo "&nbsp;";
            }
            echo "</div>
                            <div class=\"actions\">
                                <a class=\"move icon\" title=\"";
            // line 17
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Reorder", "app"), "html", null, true);
            echo "\" role=\"button\"></a>
                                <a class=\"settings icon";
            // line 18
            if (craft\helpers\Template::attribute($this->env, $this->source, $context["blockType"], "hasErrors", [], "method")) {
                echo " error";
            }
            echo "\" title=\"";
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Settings", "app"), "html", null, true);
            echo "\" role=\"button\"></a>
                            </div>
                            <input class=\"hidden\" name=\"blockTypes[";
            // line 20
            echo twig_escape_filter($this->env, $context["blockTypeId"], "html", null, true);
            echo "][name]\" value=\"";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["blockType"], "name", []), "html", null, true);
            echo "\">
                            <input class=\"hidden\" name=\"blockTypes[";
            // line 21
            echo twig_escape_filter($this->env, $context["blockTypeId"], "html", null, true);
            echo "][handle]\" value=\"";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["blockType"], "handle", []), "html", null, true);
            echo "\">
                        </div>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['blockTypeId'], $context['blockType'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 24
        echo "                </div>
                <div class=\"btn add icon\">";
        // line 25
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("New block type", "app"), "html", null, true);
        echo "</div>
            </div>
        </div>
    </div>
    <div class=\"mc-sidebar fields\">
        <div class=\"col-inner-container hidden\">
            <div class=\"heading\">
                <h5>";
        // line 32
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Fields", "app"), "html", null, true);
        echo "</h5>
            </div>
            <div class=\"items\">
                ";
        // line 35
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["blockTypes"]) || array_key_exists("blockTypes", $context) ? $context["blockTypes"] : (function () { throw new RuntimeError('Variable "blockTypes" does not exist.', 35, $this->source); })()));
        foreach ($context['_seq'] as $context["blockTypeId"] => $context["blockType"]) {
            // line 36
            echo "                    <div data-id=\"";
            echo twig_escape_filter($this->env, $context["blockTypeId"], "html", null, true);
            echo "\" class=\"hidden\">
                        ";
            // line 37
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["blockTypeFields"]) || array_key_exists("blockTypeFields", $context) ? $context["blockTypeFields"] : (function () { throw new RuntimeError('Variable "blockTypeFields" does not exist.', 37, $this->source); })()), $context["blockTypeId"], [], "array"));
            foreach ($context['_seq'] as $context["fieldId"] => $context["field"]) {
                // line 38
                echo "                            <div class=\"matrixconfigitem mci-field";
                if (craft\helpers\Template::attribute($this->env, $this->source, $context["field"], "hasErrors", [], "method")) {
                    echo " error";
                }
                echo "\" data-id=\"";
                echo twig_escape_filter($this->env, $context["fieldId"], "html", null, true);
                echo "\">
                                <div class=\"name";
                // line 39
                if (craft\helpers\Template::attribute($this->env, $this->source, $context["field"], "required", [])) {
                    echo " required";
                }
                echo "\">";
                // line 40
                if ((craft\helpers\Template::attribute($this->env, $this->source, $context["field"], "name", []) && (craft\helpers\Template::attribute($this->env, $this->source, $context["field"], "name", []) != "__blank__"))) {
                    echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["field"], "name", []), "html", null, true);
                } else {
                    echo "<em class=\"light\">";
                    echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("(blank)", "app"), "html", null, true);
                    echo "</em>";
                }
                // line 41
                echo "&nbsp;</div>
                                <div class=\"handle code\">";
                // line 42
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["field"], "handle", []), "html", null, true);
                echo "&nbsp;</div>
                                <div class=\"actions\">
                                    <a class=\"move icon\" title=\"";
                // line 44
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Reorder", "app"), "html", null, true);
                echo "\" role=\"button\"></a>
                                </div>
                            </div>
                        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['fieldId'], $context['field'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 48
            echo "                    </div>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['blockTypeId'], $context['blockType'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 50
        echo "                <div class=\"btn add icon\">";
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("New field", "app"), "html", null, true);
        echo "</div>
            </div>
        </div>
    </div>
    <div class=\"field-settings\">
        <div class=\"col-inner-container hidden\">
            <div class=\"heading\">
                <h5>";
        // line 57
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Field Settings", "app"), "html", null, true);
        echo "</h5>
            </div>
            <div class=\"items\">
                ";
        // line 60
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["blockTypes"]) || array_key_exists("blockTypes", $context) ? $context["blockTypes"] : (function () { throw new RuntimeError('Variable "blockTypes" does not exist.', 60, $this->source); })()));
        foreach ($context['_seq'] as $context["blockTypeId"] => $context["blockType"]) {
            // line 61
            echo "                    <div data-id=\"";
            echo twig_escape_filter($this->env, $context["blockTypeId"], "html", null, true);
            echo "\">
                        ";
            // line 62
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["blockTypeFields"]) || array_key_exists("blockTypeFields", $context) ? $context["blockTypeFields"] : (function () { throw new RuntimeError('Variable "blockTypeFields" does not exist.', 62, $this->source); })()), $context["blockTypeId"], [], "array"));
            foreach ($context['_seq'] as $context["fieldId"] => $context["field"]) {
                // line 63
                echo "                            <div data-id=\"";
                echo twig_escape_filter($this->env, $context["fieldId"], "html", null, true);
                echo "\" class=\"hidden\">
                                ";
                // line 64
                $_namespace = (((("blockTypes[" . $context["blockTypeId"]) . "][fields][") . $context["fieldId"]) . "]");
                if ($_namespace) {
                    $_originalNamespace = Craft::$app->getView()->getNamespace();
                    Craft::$app->getView()->setNamespace(Craft::$app->getView()->namespaceInputName($_namespace));
                    ob_start();
                    try {
                        // line 65
                        echo "                                    ";
                        echo twig_call_macro($macros["forms"], "macro_textField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Name", "app"), "id" => "name", "name" => "name", "value" => (((craft\helpers\Template::attribute($this->env, $this->source,                         // line 69
$context["field"], "name", []) != "__blank__")) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["field"], "name", [])) : ("")), "errors" => craft\helpers\Template::attribute($this->env, $this->source,                         // line 70
$context["field"], "getErrors", [0 => "name"], "method"), "autofocus" => true]], 65, $context, $this->getSourceContext());
                        // line 72
                        echo "

                                    ";
                        // line 74
                        echo twig_call_macro($macros["forms"], "macro_textField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Handle", "app"), "id" => "handle", "name" => "handle", "class" => "code", "autocorrect" => false, "autocapitalize" => false, "maxlength" => 64, "value" => craft\helpers\Template::attribute($this->env, $this->source,                         // line 82
$context["field"], "handle", []), "errors" => craft\helpers\Template::attribute($this->env, $this->source,                         // line 83
$context["field"], "getErrors", [0 => "handle"], "method"), "required" => true]], 74, $context, $this->getSourceContext());
                        // line 85
                        echo "

                                    ";
                        // line 87
                        echo twig_call_macro($macros["forms"], "macro_textareaField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Instructions", "app"), "id" => "instructions", "class" => "nicetext", "name" => "instructions", "value" => craft\helpers\Template::attribute($this->env, $this->source,                         // line 92
$context["field"], "instructions", []), "errors" => craft\helpers\Template::attribute($this->env, $this->source,                         // line 93
$context["field"], "getErrors", [0 => "instructions"], "method")]], 87, $context, $this->getSourceContext());
                        // line 94
                        echo "

                                    ";
                        // line 96
                        echo twig_call_macro($macros["forms"], "macro_checkboxField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("This field is required", "app"), "id" => "required", "name" => "required", "checked" => craft\helpers\Template::attribute($this->env, $this->source,                         // line 100
$context["field"], "required", [])]], 96, $context, $this->getSourceContext());
                        // line 101
                        echo "

                                    ";
                        // line 103
                        echo twig_call_macro($macros["forms"], "macro_checkboxField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Use this field’s values as search keywords?", "app"), "id" => "searchable", "name" => "searchable", "checked" => craft\helpers\Template::attribute($this->env, $this->source,                         // line 107
$context["field"], "searchable", [])]], 103, $context, $this->getSourceContext());
                        // line 108
                        echo "

                                    ";
                        // line 110
                        echo twig_call_macro($macros["forms"], "macro_selectField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Field Type", "app"), "warning" => ((( !craft\helpers\Template::attribute($this->env, $this->source,                         // line 112
$context["field"], "getIsNew", [], "method") &&  !craft\helpers\Template::attribute($this->env, $this->source, $context["field"], "hasErrors", [0 => "type"], "method"))) ? ($this->extensions['craft\web\twig\Extension']->translateFilter("Changing this may result in data loss.", "app")) : ("")), "id" => "type", "name" => "type", "options" => (((twig_slice($this->env,                         // line 115
$context["fieldId"], 0, 3) != "new")) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["fieldTypes"]) || array_key_exists("fieldTypes", $context) ? $context["fieldTypes"] : (function () { throw new RuntimeError('Variable "fieldTypes" does not exist.', 115, $this->source); })()), $context["fieldId"], [], "array")) : (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["fieldTypes"]) || array_key_exists("fieldTypes", $context) ? $context["fieldTypes"] : (function () { throw new RuntimeError('Variable "fieldTypes" does not exist.', 115, $this->source); })()), "new", []))), "value" => get_class(                        // line 116
$context["field"]), "errors" => (((craft\helpers\Template::attribute($this->env, $this->source,                         // line 117
$context["field"], "getErrors", [0 => "type"], "method", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["field"], "getErrors", [0 => "type"], "method")))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["field"], "getErrors", [0 => "type"], "method")) : (null))]], 110, $context, $this->getSourceContext());
                        // line 118
                        echo "

                                    ";
                        // line 120
                        if (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 120, $this->source); })()), "app", []), "getIsMultiSite", [], "method")) {
                            // line 121
                            echo "                                        ";
                            $context["translationMethods"] = craft\helpers\Template::attribute($this->env, $this->source, $context["field"], "supportedTranslationMethods", []);
                            // line 122
                            echo "                                        <div id=\"translation-settings\"";
                            if ((twig_length_filter($this->env, (isset($context["translationMethods"]) || array_key_exists("translationMethods", $context) ? $context["translationMethods"] : (function () { throw new RuntimeError('Variable "translationMethods" does not exist.', 122, $this->source); })())) < 2)) {
                                echo " class=\"hidden\"";
                            }
                            echo ">
                                            ";
                            // line 123
                            echo twig_call_macro($macros["forms"], "macro_selectField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Translation Method", "app"), "id" => "translation-method", "name" => "translationMethod", "options" => $this->extensions['craft\web\twig\Extension']->filterFilter([0 => ((twig_in_filter("none",                             // line 128
(isset($context["translationMethods"]) || array_key_exists("translationMethods", $context) ? $context["translationMethods"] : (function () { throw new RuntimeError('Variable "translationMethods" does not exist.', 128, $this->source); })()))) ? (["value" => "none", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Not translatable", "app")]) : ("")), 1 => ((twig_in_filter("site",                             // line 129
(isset($context["translationMethods"]) || array_key_exists("translationMethods", $context) ? $context["translationMethods"] : (function () { throw new RuntimeError('Variable "translationMethods" does not exist.', 129, $this->source); })()))) ? (["value" => "site", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Translate for each site", "app")]) : ("")), 2 => ((twig_in_filter("siteGroup",                             // line 130
(isset($context["translationMethods"]) || array_key_exists("translationMethods", $context) ? $context["translationMethods"] : (function () { throw new RuntimeError('Variable "translationMethods" does not exist.', 130, $this->source); })()))) ? (["value" => "siteGroup", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Translate for each site group", "app")]) : ("")), 3 => ((twig_in_filter("language",                             // line 131
(isset($context["translationMethods"]) || array_key_exists("translationMethods", $context) ? $context["translationMethods"] : (function () { throw new RuntimeError('Variable "translationMethods" does not exist.', 131, $this->source); })()))) ? (["value" => "language", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Translate for each language", "app")]) : ("")), 4 => ((twig_in_filter("custom",                             // line 132
(isset($context["translationMethods"]) || array_key_exists("translationMethods", $context) ? $context["translationMethods"] : (function () { throw new RuntimeError('Variable "translationMethods" does not exist.', 132, $this->source); })()))) ? (["value" => "custom", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Custom…", "app")]) : (""))]), "value" => craft\helpers\Template::attribute($this->env, $this->source,                             // line 134
$context["field"], "translationMethod", []), "toggle" => true, "targetPrefix" => "translation-method-"]], 123, $context, $this->getSourceContext());
                            // line 137
                            echo "

                                            ";
                            // line 139
                            if (twig_in_filter("custom", (isset($context["translationMethods"]) || array_key_exists("translationMethods", $context) ? $context["translationMethods"] : (function () { throw new RuntimeError('Variable "translationMethods" does not exist.', 139, $this->source); })()))) {
                                // line 140
                                echo "                                                <div id=\"translation-method-custom\" ";
                                if ((craft\helpers\Template::attribute($this->env, $this->source, $context["field"], "translationMethod", []) != "custom")) {
                                    echo "class=\"hidden\"";
                                }
                                echo ">
                                                    ";
                                // line 141
                                echo twig_call_macro($macros["forms"], "macro_textField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Translation Key Format", "app"), "id" => "translation-key-format", "name" => "translationKeyFormat", "value" => craft\helpers\Template::attribute($this->env, $this->source,                                 // line 145
$context["field"], "translationKeyFormat", []), "errors" => craft\helpers\Template::attribute($this->env, $this->source,                                 // line 146
$context["field"], "getErrors", [0 => "translationKeyFormat"], "method")]], 141, $context, $this->getSourceContext());
                                // line 147
                                echo "
                                                </div>
                                            ";
                            }
                            // line 150
                            echo "                                        </div>
                                    ";
                        }
                        // line 152
                        echo "                                ";
                    } catch (Exception $e) {
                        ob_end_clean();

                        throw $e;
                    }
                    echo Craft::$app->getView()->namespaceInputs(ob_get_clean(), $_namespace);
                    Craft::$app->getView()->setNamespace($_originalNamespace);
                } else {
                    // line 65
                    echo "                                    ";
                    echo twig_call_macro($macros["forms"], "macro_textField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Name", "app"), "id" => "name", "name" => "name", "value" => (((craft\helpers\Template::attribute($this->env, $this->source,                     // line 69
$context["field"], "name", []) != "__blank__")) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["field"], "name", [])) : ("")), "errors" => craft\helpers\Template::attribute($this->env, $this->source,                     // line 70
$context["field"], "getErrors", [0 => "name"], "method"), "autofocus" => true]], 65, $context, $this->getSourceContext());
                    // line 72
                    echo "

                                    ";
                    // line 74
                    echo twig_call_macro($macros["forms"], "macro_textField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Handle", "app"), "id" => "handle", "name" => "handle", "class" => "code", "autocorrect" => false, "autocapitalize" => false, "maxlength" => 64, "value" => craft\helpers\Template::attribute($this->env, $this->source,                     // line 82
$context["field"], "handle", []), "errors" => craft\helpers\Template::attribute($this->env, $this->source,                     // line 83
$context["field"], "getErrors", [0 => "handle"], "method"), "required" => true]], 74, $context, $this->getSourceContext());
                    // line 85
                    echo "

                                    ";
                    // line 87
                    echo twig_call_macro($macros["forms"], "macro_textareaField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Instructions", "app"), "id" => "instructions", "class" => "nicetext", "name" => "instructions", "value" => craft\helpers\Template::attribute($this->env, $this->source,                     // line 92
$context["field"], "instructions", []), "errors" => craft\helpers\Template::attribute($this->env, $this->source,                     // line 93
$context["field"], "getErrors", [0 => "instructions"], "method")]], 87, $context, $this->getSourceContext());
                    // line 94
                    echo "

                                    ";
                    // line 96
                    echo twig_call_macro($macros["forms"], "macro_checkboxField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("This field is required", "app"), "id" => "required", "name" => "required", "checked" => craft\helpers\Template::attribute($this->env, $this->source,                     // line 100
$context["field"], "required", [])]], 96, $context, $this->getSourceContext());
                    // line 101
                    echo "

                                    ";
                    // line 103
                    echo twig_call_macro($macros["forms"], "macro_checkboxField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Use this field’s values as search keywords?", "app"), "id" => "searchable", "name" => "searchable", "checked" => craft\helpers\Template::attribute($this->env, $this->source,                     // line 107
$context["field"], "searchable", [])]], 103, $context, $this->getSourceContext());
                    // line 108
                    echo "

                                    ";
                    // line 110
                    echo twig_call_macro($macros["forms"], "macro_selectField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Field Type", "app"), "warning" => ((( !craft\helpers\Template::attribute($this->env, $this->source,                     // line 112
$context["field"], "getIsNew", [], "method") &&  !craft\helpers\Template::attribute($this->env, $this->source, $context["field"], "hasErrors", [0 => "type"], "method"))) ? ($this->extensions['craft\web\twig\Extension']->translateFilter("Changing this may result in data loss.", "app")) : ("")), "id" => "type", "name" => "type", "options" => (((twig_slice($this->env,                     // line 115
$context["fieldId"], 0, 3) != "new")) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["fieldTypes"]) || array_key_exists("fieldTypes", $context) ? $context["fieldTypes"] : (function () { throw new RuntimeError('Variable "fieldTypes" does not exist.', 115, $this->source); })()), $context["fieldId"], [], "array")) : (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["fieldTypes"]) || array_key_exists("fieldTypes", $context) ? $context["fieldTypes"] : (function () { throw new RuntimeError('Variable "fieldTypes" does not exist.', 115, $this->source); })()), "new", []))), "value" => get_class(                    // line 116
$context["field"]), "errors" => (((craft\helpers\Template::attribute($this->env, $this->source,                     // line 117
$context["field"], "getErrors", [0 => "type"], "method", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["field"], "getErrors", [0 => "type"], "method")))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["field"], "getErrors", [0 => "type"], "method")) : (null))]], 110, $context, $this->getSourceContext());
                    // line 118
                    echo "

                                    ";
                    // line 120
                    if (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 120, $this->source); })()), "app", []), "getIsMultiSite", [], "method")) {
                        // line 121
                        echo "                                        ";
                        $context["translationMethods"] = craft\helpers\Template::attribute($this->env, $this->source, $context["field"], "supportedTranslationMethods", []);
                        // line 122
                        echo "                                        <div id=\"translation-settings\"";
                        if ((twig_length_filter($this->env, (isset($context["translationMethods"]) || array_key_exists("translationMethods", $context) ? $context["translationMethods"] : (function () { throw new RuntimeError('Variable "translationMethods" does not exist.', 122, $this->source); })())) < 2)) {
                            echo " class=\"hidden\"";
                        }
                        echo ">
                                            ";
                        // line 123
                        echo twig_call_macro($macros["forms"], "macro_selectField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Translation Method", "app"), "id" => "translation-method", "name" => "translationMethod", "options" => $this->extensions['craft\web\twig\Extension']->filterFilter([0 => ((twig_in_filter("none",                         // line 128
(isset($context["translationMethods"]) || array_key_exists("translationMethods", $context) ? $context["translationMethods"] : (function () { throw new RuntimeError('Variable "translationMethods" does not exist.', 128, $this->source); })()))) ? (["value" => "none", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Not translatable", "app")]) : ("")), 1 => ((twig_in_filter("site",                         // line 129
(isset($context["translationMethods"]) || array_key_exists("translationMethods", $context) ? $context["translationMethods"] : (function () { throw new RuntimeError('Variable "translationMethods" does not exist.', 129, $this->source); })()))) ? (["value" => "site", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Translate for each site", "app")]) : ("")), 2 => ((twig_in_filter("siteGroup",                         // line 130
(isset($context["translationMethods"]) || array_key_exists("translationMethods", $context) ? $context["translationMethods"] : (function () { throw new RuntimeError('Variable "translationMethods" does not exist.', 130, $this->source); })()))) ? (["value" => "siteGroup", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Translate for each site group", "app")]) : ("")), 3 => ((twig_in_filter("language",                         // line 131
(isset($context["translationMethods"]) || array_key_exists("translationMethods", $context) ? $context["translationMethods"] : (function () { throw new RuntimeError('Variable "translationMethods" does not exist.', 131, $this->source); })()))) ? (["value" => "language", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Translate for each language", "app")]) : ("")), 4 => ((twig_in_filter("custom",                         // line 132
(isset($context["translationMethods"]) || array_key_exists("translationMethods", $context) ? $context["translationMethods"] : (function () { throw new RuntimeError('Variable "translationMethods" does not exist.', 132, $this->source); })()))) ? (["value" => "custom", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Custom…", "app")]) : (""))]), "value" => craft\helpers\Template::attribute($this->env, $this->source,                         // line 134
$context["field"], "translationMethod", []), "toggle" => true, "targetPrefix" => "translation-method-"]], 123, $context, $this->getSourceContext());
                        // line 137
                        echo "

                                            ";
                        // line 139
                        if (twig_in_filter("custom", (isset($context["translationMethods"]) || array_key_exists("translationMethods", $context) ? $context["translationMethods"] : (function () { throw new RuntimeError('Variable "translationMethods" does not exist.', 139, $this->source); })()))) {
                            // line 140
                            echo "                                                <div id=\"translation-method-custom\" ";
                            if ((craft\helpers\Template::attribute($this->env, $this->source, $context["field"], "translationMethod", []) != "custom")) {
                                echo "class=\"hidden\"";
                            }
                            echo ">
                                                    ";
                            // line 141
                            echo twig_call_macro($macros["forms"], "macro_textField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Translation Key Format", "app"), "id" => "translation-key-format", "name" => "translationKeyFormat", "value" => craft\helpers\Template::attribute($this->env, $this->source,                             // line 145
$context["field"], "translationKeyFormat", []), "errors" => craft\helpers\Template::attribute($this->env, $this->source,                             // line 146
$context["field"], "getErrors", [0 => "translationKeyFormat"], "method")]], 141, $context, $this->getSourceContext());
                            // line 147
                            echo "
                                                </div>
                                            ";
                        }
                        // line 150
                        echo "                                        </div>
                                    ";
                    }
                    // line 152
                    echo "                                ";
                }
                unset($_originalNamespace, $_namespace);
                // line 153
                echo "
                                <hr>

                                <div class=\"fieldtype-settings\">
                                    <div>
                                        ";
                // line 158
                $_namespace = (((("blockTypes[" . $context["blockTypeId"]) . "][fields][") . $context["fieldId"]) . "][typesettings]");
                if ($_namespace) {
                    $_originalNamespace = Craft::$app->getView()->getNamespace();
                    Craft::$app->getView()->setNamespace(Craft::$app->getView()->namespaceInputName($_namespace));
                    ob_start();
                    try {
                        // line 159
                        echo "                                            ";
                        echo craft\helpers\Template::attribute($this->env, $this->source, $context["field"], "getSettingsHtml", [], "method");
                        echo "
                                        ";
                    } catch (Exception $e) {
                        ob_end_clean();

                        throw $e;
                    }
                    echo Craft::$app->getView()->namespaceInputs(ob_get_clean(), $_namespace);
                    Craft::$app->getView()->setNamespace($_originalNamespace);
                } else {
                    echo "                                            ";
                    echo craft\helpers\Template::attribute($this->env, $this->source, $context["field"], "getSettingsHtml", [], "method");
                    echo "
                                        ";
                }
                unset($_originalNamespace, $_namespace);
                // line 161
                echo "                                    </div>
                                </div>

                                <hr>

                                <a class=\"error delete\">";
                // line 166
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Delete", "app"), "html", null, true);
                echo "</a>
                            </div>
                        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['fieldId'], $context['field'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 169
            echo "                    </div>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['blockTypeId'], $context['blockType'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 171
        echo "            </div>
        </div>
    </div>
";
        $context["blockTypeInput"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 175
        echo "
<div id=\"matrix-configurator\" class=\"matrix-configurator\">
    ";
        // line 177
        echo twig_call_macro($macros["forms"], "macro_field", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Configuration", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Define the types of blocks that can be created within this Matrix field, as well as the fields each block type is made up of.", "app"), "name" => "config", "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 181
(isset($context["matrixField"]) || array_key_exists("matrixField", $context) ? $context["matrixField"] : (function () { throw new RuntimeError('Variable "matrixField" does not exist.', 181, $this->source); })()), "getErrors", [0 => "blockTypes"], "method")],         // line 182
(isset($context["blockTypeInput"]) || array_key_exists("blockTypeInput", $context) ? $context["blockTypeInput"] : (function () { throw new RuntimeError('Variable "blockTypeInput" does not exist.', 182, $this->source); })())], 177, $context, $this->getSourceContext());
        echo "
</div>

";
        // line 185
        if (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 185, $this->source); })()), "app", []), "getIsMultiSite", [], "method")) {
            // line 186
            echo "    ";
            echo twig_call_macro($macros["forms"], "macro_selectField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Propagation Method", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Which sites should blocks be saved to?", "app"), "id" => "propagationMethod", "name" => "propagationMethod", "options" => [0 => ["value" => "none", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Only save blocks to the site they were created in", "app")], 1 => ["value" => "siteGroup", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Save blocks to other sites in the same site group", "app")], 2 => ["value" => "language", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Save blocks to other sites with the same language", "app")], 3 => ["value" => "all", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Save blocks to all sites the owner element is saved in", "app")]], "value" => craft\helpers\Template::attribute($this->env, $this->source,             // line 197
(isset($context["matrixField"]) || array_key_exists("matrixField", $context) ? $context["matrixField"] : (function () { throw new RuntimeError('Variable "matrixField" does not exist.', 197, $this->source); })()), "propagationMethod", [])]], 186, $context, $this->getSourceContext());
            // line 198
            echo "

    ";
            // line 200
            if ((craft\helpers\Template::attribute($this->env, $this->source, (isset($context["matrixField"]) || array_key_exists("matrixField", $context) ? $context["matrixField"] : (function () { throw new RuntimeError('Variable "matrixField" does not exist.', 200, $this->source); })()), "id", []) && (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["matrixField"]) || array_key_exists("matrixField", $context) ? $context["matrixField"] : (function () { throw new RuntimeError('Variable "matrixField" does not exist.', 200, $this->source); })()), "propagationMethod", []) != "none"))) {
                // line 201
                echo "        ";
                ob_start();
                // line 202
                echo "            (function() {
                var showingWarning = false;
                \$(\"#";
                // line 204
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFilter('namespaceInputId')->getCallable(), ["propagationMethod"]), "html", null, true);
                echo "\").on('change', function() {
                    if (\$(this).val() !== '";
                // line 205
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["matrixField"]) || array_key_exists("matrixField", $context) ? $context["matrixField"] : (function () { throw new RuntimeError('Variable "matrixField" does not exist.', 205, $this->source); })()), "propagationMethod", []), "html", null, true);
                echo "') {
                        if (!showingWarning) {
                            \$('<p/>', {'class': 'warning', text: \"";
                // line 207
                echo twig_escape_filter($this->env, twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Applying this change to existing blocks can take some time.", "app"), "js"), "html", null, true);
                echo "\"})
                                .appendTo(\$(\"#";
                // line 208
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFilter('namespaceInputId')->getCallable(), ["propagationMethod-field"]), "html", null, true);
                echo "\"));
                            showingWarning = true;
                        }
                    } else if (showingWarning) {
                        \$(\"#";
                // line 212
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFilter('namespaceInputId')->getCallable(), ["propagationMethod-field"]), "html", null, true);
                echo " .warning\").remove();
                        showingWarning = false;
                    }
                });
            })();
        ";
                Craft::$app->getView()->registerJs(ob_get_clean(), 3);
                // line 218
                echo "    ";
            }
        }
        // line 220
        echo "
";
        // line 221
        echo twig_call_macro($macros["forms"], "macro_textField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Min Blocks", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("The minimum number of blocks the field is allowed to have.", "app"), "id" => "minBlocks", "name" => "minBlocks", "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 226
(isset($context["matrixField"]) || array_key_exists("matrixField", $context) ? $context["matrixField"] : (function () { throw new RuntimeError('Variable "matrixField" does not exist.', 226, $this->source); })()), "minBlocks", []), "size" => 3, "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 228
(isset($context["matrixField"]) || array_key_exists("matrixField", $context) ? $context["matrixField"] : (function () { throw new RuntimeError('Variable "matrixField" does not exist.', 228, $this->source); })()), "getErrors", [0 => "minBlocks"], "method")]], 221, $context, $this->getSourceContext());
        // line 229
        echo "

";
        // line 231
        echo twig_call_macro($macros["forms"], "macro_textField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Max Blocks", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("The maximum number of blocks the field is allowed to have.", "app"), "id" => "maxBlocks", "name" => "maxBlocks", "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 236
(isset($context["matrixField"]) || array_key_exists("matrixField", $context) ? $context["matrixField"] : (function () { throw new RuntimeError('Variable "matrixField" does not exist.', 236, $this->source); })()), "maxBlocks", []), "size" => 3, "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 238
(isset($context["matrixField"]) || array_key_exists("matrixField", $context) ? $context["matrixField"] : (function () { throw new RuntimeError('Variable "matrixField" does not exist.', 238, $this->source); })()), "getErrors", [0 => "maxBlocks"], "method")]], 231, $context, $this->getSourceContext());
        // line 239
        echo "
";
        // line 0
        craft\helpers\Template::endProfile("template", "_components/fieldtypes/Matrix/settings");
    }

    public function getTemplateName()
    {
        return "_components/fieldtypes/Matrix/settings";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  593 => 0,  590 => 239,  588 => 238,  587 => 236,  586 => 231,  582 => 229,  580 => 228,  579 => 226,  578 => 221,  575 => 220,  571 => 218,  562 => 212,  555 => 208,  551 => 207,  546 => 205,  542 => 204,  538 => 202,  535 => 201,  533 => 200,  529 => 198,  527 => 197,  525 => 186,  523 => 185,  517 => 182,  516 => 181,  515 => 177,  511 => 175,  505 => 171,  498 => 169,  489 => 166,  482 => 161,  463 => 159,  456 => 158,  449 => 153,  445 => 152,  441 => 150,  436 => 147,  434 => 146,  433 => 145,  432 => 141,  425 => 140,  423 => 139,  419 => 137,  417 => 134,  416 => 132,  415 => 131,  414 => 130,  413 => 129,  412 => 128,  411 => 123,  404 => 122,  401 => 121,  399 => 120,  395 => 118,  393 => 117,  392 => 116,  391 => 115,  390 => 112,  389 => 110,  385 => 108,  383 => 107,  382 => 103,  378 => 101,  376 => 100,  375 => 96,  371 => 94,  369 => 93,  368 => 92,  367 => 87,  363 => 85,  361 => 83,  360 => 82,  359 => 74,  355 => 72,  353 => 70,  352 => 69,  350 => 65,  340 => 152,  336 => 150,  331 => 147,  329 => 146,  328 => 145,  327 => 141,  320 => 140,  318 => 139,  314 => 137,  312 => 134,  311 => 132,  310 => 131,  309 => 130,  308 => 129,  307 => 128,  306 => 123,  299 => 122,  296 => 121,  294 => 120,  290 => 118,  288 => 117,  287 => 116,  286 => 115,  285 => 112,  284 => 110,  280 => 108,  278 => 107,  277 => 103,  273 => 101,  271 => 100,  270 => 96,  266 => 94,  264 => 93,  263 => 92,  262 => 87,  258 => 85,  256 => 83,  255 => 82,  254 => 74,  250 => 72,  248 => 70,  247 => 69,  245 => 65,  238 => 64,  233 => 63,  229 => 62,  224 => 61,  220 => 60,  214 => 57,  203 => 50,  196 => 48,  186 => 44,  181 => 42,  178 => 41,  170 => 40,  165 => 39,  156 => 38,  152 => 37,  147 => 36,  143 => 35,  137 => 32,  127 => 25,  124 => 24,  113 => 21,  107 => 20,  98 => 18,  94 => 17,  85 => 15,  77 => 14,  62 => 13,  58 => 12,  51 => 8,  46 => 5,  44 => 4,  40 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% import \"_includes/forms\" as forms %}


{% set blockTypeInput %}
    <div class=\"mc-sidebar block-types\">
        <div class=\"col-inner-container\">
            <div class=\"heading\">
                <h5>{{ \"Block Types\"|t('app') }}</h5>
            </div>
            <div class=\"items\">
                <div class=\"blocktypes\">
                    {% for blockTypeId, blockType in blockTypes %}
                        <div class=\"matrixconfigitem mci-blocktype{% if blockType.hasFieldErrors %} error{% endif %}\" data-id=\"{{ blockTypeId }}\"{% if blockType.hasErrors() %} data-errors=\"{{ blockType.getErrors() | json_encode }}\"{% endif %}>
                            <div class=\"name\">{% if blockType.name %}{{ blockType.name }}{% else %}&nbsp;{% endif %}</div>
                            <div class=\"handle code\">{% if blockType.handle %}{{ blockType.handle }}{% else %}&nbsp;{% endif %}</div>
                            <div class=\"actions\">
                                <a class=\"move icon\" title=\"{{ 'Reorder'|t('app') }}\" role=\"button\"></a>
                                <a class=\"settings icon{% if blockType.hasErrors() %} error{% endif %}\" title=\"{{ 'Settings'|t('app') }}\" role=\"button\"></a>
                            </div>
                            <input class=\"hidden\" name=\"blockTypes[{{ blockTypeId }}][name]\" value=\"{{ blockType.name }}\">
                            <input class=\"hidden\" name=\"blockTypes[{{ blockTypeId }}][handle]\" value=\"{{ blockType.handle }}\">
                        </div>
                    {% endfor %}
                </div>
                <div class=\"btn add icon\">{{ \"New block type\"|t('app') }}</div>
            </div>
        </div>
    </div>
    <div class=\"mc-sidebar fields\">
        <div class=\"col-inner-container hidden\">
            <div class=\"heading\">
                <h5>{{ \"Fields\"|t('app') }}</h5>
            </div>
            <div class=\"items\">
                {% for blockTypeId, blockType in blockTypes %}
                    <div data-id=\"{{ blockTypeId }}\" class=\"hidden\">
                        {% for fieldId, field in blockTypeFields[blockTypeId] %}
                            <div class=\"matrixconfigitem mci-field{% if field.hasErrors() %} error{% endif %}\" data-id=\"{{ fieldId }}\">
                                <div class=\"name{% if field.required %} required{% endif %}\">
                                    {%- if field.name and field.name != '__blank__' %}{{ field.name }}{% else %}<em class=\"light\">{{ '(blank)'|t('app') }}</em>{% endif -%}
                                &nbsp;</div>
                                <div class=\"handle code\">{{ field.handle }}&nbsp;</div>
                                <div class=\"actions\">
                                    <a class=\"move icon\" title=\"{{ 'Reorder'|t('app') }}\" role=\"button\"></a>
                                </div>
                            </div>
                        {% endfor %}
                    </div>
                {% endfor %}
                <div class=\"btn add icon\">{{ \"New field\"|t('app') }}</div>
            </div>
        </div>
    </div>
    <div class=\"field-settings\">
        <div class=\"col-inner-container hidden\">
            <div class=\"heading\">
                <h5>{{ \"Field Settings\"|t('app') }}</h5>
            </div>
            <div class=\"items\">
                {% for blockTypeId, blockType in blockTypes %}
                    <div data-id=\"{{ blockTypeId }}\">
                        {% for fieldId, field in blockTypeFields[blockTypeId] %}
                            <div data-id=\"{{ fieldId }}\" class=\"hidden\">
                                {% namespace 'blockTypes['~blockTypeId~'][fields]['~fieldId~']' %}
                                    {{ forms.textField({
                                        label: \"Name\"|t('app'),
                                        id: 'name',
                                        name: 'name',
                                        value: (field.name != '__blank__' ? field.name),
                                        errors: field.getErrors('name'),
                                        autofocus: true
                                    }) }}

                                    {{ forms.textField({
                                        label: \"Handle\"|t('app'),
                                        id: 'handle',
                                        name: 'handle',
                                        class: 'code',
                                        autocorrect: false,
                                        autocapitalize: false,
                                        maxlength: 64,
                                        value: field.handle,
                                        errors: field.getErrors('handle'),
                                        required: true,
                                    }) }}

                                    {{ forms.textareaField({
                                        label: \"Instructions\"|t('app'),
                                        id: 'instructions',
                                        class: 'nicetext',
                                        name: 'instructions',
                                        value: field.instructions,
                                        errors: field.getErrors('instructions'),
                                    }) }}

                                    {{ forms.checkboxField({
                                        label: \"This field is required\"|t('app'),
                                        id: 'required',
                                        name: 'required',
                                        checked: field.required
                                    }) }}

                                    {{ forms.checkboxField({
                                        label: \"Use this field’s values as search keywords?\"|t('app'),
                                        id: 'searchable',
                                        name: 'searchable',
                                        checked: field.searchable
                                    }) }}

                                    {{ forms.selectField({
                                        label: \"Field Type\"|t('app'),
                                        warning: (not field.getIsNew() and not field.hasErrors('type') ? \"Changing this may result in data loss.\"|t('app')),
                                        id: 'type',
                                        name: 'type',
                                        options: fieldId[0:3] != 'new' ? fieldTypes[fieldId] : fieldTypes.new,
                                        value: className(field),
                                        errors: field.getErrors('type') ?? null
                                    }) }}

                                    {% if craft.app.getIsMultiSite() %}
                                        {% set translationMethods = field.supportedTranslationMethods %}
                                        <div id=\"translation-settings\"{% if translationMethods|length < 2 %} class=\"hidden\"{% endif %}>
                                            {{ forms.selectField({
                                                label: \"Translation Method\"|t('app'),
                                                id: 'translation-method',
                                                name: 'translationMethod',
                                                options: [
                                                    'none' in translationMethods ? { value: 'none', label: \"Not translatable\"|t('app') },
                                                    'site' in translationMethods ? { value: 'site', label: \"Translate for each site\"|t('app') },
                                                    'siteGroup' in translationMethods ? { value: 'siteGroup', label: \"Translate for each site group\"|t('app') },
                                                    'language' in translationMethods ? { value: 'language', label: \"Translate for each language\"|t('app') },
                                                    'custom' in translationMethods ? { value: 'custom', label: \"Custom…\"|t('app') }
                                                ]|filter,
                                                value: field.translationMethod,
                                                toggle: true,
                                                targetPrefix: 'translation-method-'
                                            }) }}

                                            {% if 'custom' in translationMethods %}
                                                <div id=\"translation-method-custom\" {% if field.translationMethod != 'custom' %}class=\"hidden\"{% endif %}>
                                                    {{ forms.textField({
                                                        label: \"Translation Key Format\"|t('app'),
                                                        id: 'translation-key-format',
                                                        name: 'translationKeyFormat',
                                                        value: field.translationKeyFormat,
                                                        errors: field.getErrors('translationKeyFormat')
                                                    }) }}
                                                </div>
                                            {% endif %}
                                        </div>
                                    {% endif %}
                                {% endnamespace %}

                                <hr>

                                <div class=\"fieldtype-settings\">
                                    <div>
                                        {% namespace 'blockTypes['~blockTypeId~'][fields]['~fieldId~'][typesettings]' %}
                                            {{ field.getSettingsHtml()|raw  }}
                                        {% endnamespace %}
                                    </div>
                                </div>

                                <hr>

                                <a class=\"error delete\">{{ \"Delete\"|t('app') }}</a>
                            </div>
                        {% endfor %}
                    </div>
                {% endfor %}
            </div>
        </div>
    </div>
{% endset %}

<div id=\"matrix-configurator\" class=\"matrix-configurator\">
    {{ forms.field({
        label: \"Configuration\"|t('app'),
        instructions: \"Define the types of blocks that can be created within this Matrix field, as well as the fields each block type is made up of.\"|t('app'),
        name: 'config',
        errors: matrixField.getErrors('blockTypes'),
    }, blockTypeInput) }}
</div>

{% if craft.app.getIsMultiSite() %}
    {{ forms.selectField({
        label: 'Propagation Method'|t('app'),
        instructions: 'Which sites should blocks be saved to?'|t('app'),
        id: 'propagationMethod',
        name: 'propagationMethod',
        options: [
            { value: 'none', label: 'Only save blocks to the site they were created in'|t('app') },
            { value: 'siteGroup', label: 'Save blocks to other sites in the same site group'|t('app') },
            { value: 'language', label: 'Save blocks to other sites with the same language'|t('app') },
            { value: 'all', label: 'Save blocks to all sites the owner element is saved in'|t('app') },
        ],
        value: matrixField.propagationMethod
    }) }}

    {% if matrixField.id and matrixField.propagationMethod != 'none' %}
        {% js %}
            (function() {
                var showingWarning = false;
                \$(\"#{{ 'propagationMethod'|namespaceInputId }}\").on('change', function() {
                    if (\$(this).val() !== '{{ matrixField.propagationMethod }}') {
                        if (!showingWarning) {
                            \$('<p/>', {'class': 'warning', text: \"{{ 'Applying this change to existing blocks can take some time.'|t('app')|e('js') }}\"})
                                .appendTo(\$(\"#{{ 'propagationMethod-field'|namespaceInputId }}\"));
                            showingWarning = true;
                        }
                    } else if (showingWarning) {
                        \$(\"#{{ 'propagationMethod-field'|namespaceInputId }} .warning\").remove();
                        showingWarning = false;
                    }
                });
            })();
        {% endjs %}
    {% endif %}
{% endif %}

{{ forms.textField({
    label: \"Min Blocks\"|t('app'),
    instructions: \"The minimum number of blocks the field is allowed to have.\"|t('app'),
    id: 'minBlocks',
    name: 'minBlocks',
    value: matrixField.minBlocks,
    size: 3,
    errors: matrixField.getErrors('minBlocks')
}) }}

{{ forms.textField({
    label: \"Max Blocks\"|t('app'),
    instructions: \"The maximum number of blocks the field is allowed to have.\"|t('app'),
    id: 'maxBlocks',
    name: 'maxBlocks',
    value: matrixField.maxBlocks,
    size: 3,
    errors: matrixField.getErrors('maxBlocks')
}) }}
", "_components/fieldtypes/Matrix/settings", "/Applications/MAMP/htdocs/craft/smsi/vendor/craftcms/cms/src/templates/_components/fieldtypes/Matrix/settings.html");
    }
}
