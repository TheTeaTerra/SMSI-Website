<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* blog/_category */
class __TwigTemplate_3701d6e19b94cbc61be0769e9069e982045710da9648990daacd12f8d50681ac extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "_layouts/basic";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("template", "blog/_category");
        // line 3
        $context["posts"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 3, $this->source); })()), "entries", []), "section", [0 => "blog"], "method"), "relatedTo", [0 => (isset($context["category"]) || array_key_exists("category", $context) ? $context["category"] : (function () { throw new RuntimeError('Variable "category" does not exist.', 3, $this->source); })())], "method"), "all", [], "method");
        // line 1
        $this->parent = $this->loadTemplate("_layouts/basic", "blog/_category", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        // line 0
        craft\helpers\Template::endProfile("template", "blog/_category");
    }

    // line 5
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("block", "content");
        // line 6
        echo "    <h1 class=\"text-4xl text-block font-display my-4\">
        Blog Posts in \"";
        // line 7
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["category"]) || array_key_exists("category", $context) ? $context["category"] : (function () { throw new RuntimeError('Variable "category" does not exist.', 7, $this->source); })()), "title", []), "html", null, true);
        echo "\"
    </h1>

    ";
        // line 10
        $this->loadTemplate("_includes/listing", "blog/_category", 10)->display(twig_to_array(["posts" => (isset($context["posts"]) || array_key_exists("posts", $context) ? $context["posts"] : (function () { throw new RuntimeError('Variable "posts" does not exist.', 10, $this->source); })())]));
        // line 0
        craft\helpers\Template::endProfile("block", "content");
    }

    public function getTemplateName()
    {
        return "blog/_category";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  70 => 0,  68 => 10,  62 => 7,  59 => 6,  57 => 0,  53 => 5,  49 => 0,  46 => 1,  44 => 3,  42 => 0,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends \"_layouts/basic\" %}

{% set posts = craft.entries.section('blog').relatedTo(category).all() %}

{% block content %}
    <h1 class=\"text-4xl text-block font-display my-4\">
        Blog Posts in \"{{ category.title }}\"
    </h1>

    {% include \"_includes/listing\" with { posts : posts } only %}
{% endblock %}", "blog/_category", "/Applications/MAMP/htdocs/craft/smsi/templates/blog/_category.twig");
    }
}
