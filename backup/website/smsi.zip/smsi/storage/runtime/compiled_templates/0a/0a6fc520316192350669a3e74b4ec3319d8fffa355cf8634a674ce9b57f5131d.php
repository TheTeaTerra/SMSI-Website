<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _components/fieldtypes/PlainText/settings */
class __TwigTemplate_94b841c35109c4f47d1962cc257aef8c65947dd72201313adcc6773b5258f686 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_components/fieldtypes/PlainText/settings");
        // line 1
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms", "_components/fieldtypes/PlainText/settings", 1)->unwrap();
        // line 2
        echo "

";
        // line 4
        echo twig_call_macro($macros["forms"], "macro_textField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Placeholder Text", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("The text that will be shown if the field doesn’t have a value.", "app"), "id" => "placeholder", "name" => "placeholder", "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 9
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 9, $this->source); })()), "placeholder", []), "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 10
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 10, $this->source); })()), "getErrors", [0 => "placeholder"], "method")]], 4, $context, $this->getSourceContext());
        // line 11
        echo "

";
        // line 13
        $this->loadTemplate("_components/fieldtypes/PlainText/settings", "_components/fieldtypes/PlainText/settings", 13, "1269900781")->display(twig_array_merge($context, ["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Field Limit", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("The maximum number of characters or bytes the field is allowed to have.", "app"), "id" => "fieldLimit", "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 17
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 17, $this->source); })()), "getErrors", [0 => ((craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 17, $this->source); })()), "byteLimit", [])) ? ("byteLimit") : ("charLimit"))], "method")]));
        // line 40
        echo "

";
        // line 42
        echo twig_call_macro($macros["forms"], "macro_checkboxField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Use a monospaced font", "app"), "name" => "code", "checked" => craft\helpers\Template::attribute($this->env, $this->source,         // line 45
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 45, $this->source); })()), "code", [])]], 42, $context, $this->getSourceContext());
        // line 46
        echo "

";
        // line 48
        echo twig_call_macro($macros["forms"], "macro_checkboxField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Allow line breaks", "app"), "name" => "multiline", "checked" => craft\helpers\Template::attribute($this->env, $this->source,         // line 51
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 51, $this->source); })()), "multiline", []), "toggle" => "initialRowsContainer"]], 48, $context, $this->getSourceContext());
        // line 53
        echo "


<div id=\"initialRowsContainer\" class=\"nested-fields";
        // line 56
        if ( !craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 56, $this->source); })()), "multiline", [])) {
            echo " hidden";
        }
        echo "\">
    ";
        // line 57
        echo twig_call_macro($macros["forms"], "macro_textField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Initial Rows", "app"), "id" => "initialRows", "name" => "initialRows", "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 61
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 61, $this->source); })()), "initialRows", []), "size" => 3, "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 63
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 63, $this->source); })()), "getErrors", [0 => "initialRows"], "method")]], 57, $context, $this->getSourceContext());
        // line 64
        echo "
</div>

";
        // line 67
        if (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 67, $this->source); })()), "app", []), "db", []), "isMysql", [])) {
            // line 68
            echo "    <hr>
    <a class=\"fieldtoggle\" data-target=\"advanced\">";
            // line 69
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Advanced", "app"), "html", null, true);
            echo "</a>
    <div id=\"advanced\" class=\"hidden\">
        ";
            // line 71
            echo twig_call_macro($macros["forms"], "macro_selectField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Column Type", "app"), "id" => "column-type", "name" => "columnType", "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("The type of column this field should get in the database.", "app"), "options" => [0 => ["value" => "auto", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Automatic", "app")], 1 => ["value" => "string", "label" => "varchar (255B)"], 2 => ["value" => "text", "label" => "text (~64KB)"], 3 => ["value" => "mediumtext", "label" => "mediumtext (~16MB)"]], "value" => (((craft\helpers\Template::attribute($this->env, $this->source,             // line 82
($context["field"] ?? null), "columnType", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["field"] ?? null), "columnType", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["field"] ?? null), "columnType", [])) : ("auto")), "warning" => ((craft\helpers\Template::attribute($this->env, $this->source,             // line 83
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 83, $this->source); })()), "id", [])) ? ($this->extensions['craft\web\twig\Extension']->translateFilter("Changing this may result in data loss.", "app")) : (""))]], 71, $context, $this->getSourceContext());
            // line 84
            echo "
    </div>
";
        }
        // line 0
        craft\helpers\Template::endProfile("template", "_components/fieldtypes/PlainText/settings");
    }

    public function getTemplateName()
    {
        return "_components/fieldtypes/PlainText/settings";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  108 => 0,  103 => 84,  101 => 83,  100 => 82,  99 => 71,  94 => 69,  91 => 68,  89 => 67,  84 => 64,  82 => 63,  81 => 61,  80 => 57,  74 => 56,  69 => 53,  67 => 51,  66 => 48,  62 => 46,  60 => 45,  59 => 42,  55 => 40,  53 => 17,  52 => 13,  48 => 11,  46 => 10,  45 => 9,  44 => 4,  40 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% import \"_includes/forms\" as forms %}


{{ forms.textField({
    label: \"Placeholder Text\"|t('app'),
    instructions: \"The text that will be shown if the field doesn’t have a value.\"|t('app'),
    id: 'placeholder',
    name: 'placeholder',
    value: field.placeholder,
    errors: field.getErrors('placeholder')
}) }}

{% embed '_includes/forms/field' with {
    label: 'Field Limit'|t('app'),
    instructions: \"The maximum number of characters or bytes the field is allowed to have.\"|t('app'),
    id: 'fieldLimit',
    errors: field.getErrors(field.byteLimit ? 'byteLimit' : 'charLimit')
} %}
    {% import \"_includes/forms\" as forms %}
    {% block input %}
        <div class=\"flex\">
            {{ forms.text({
                id: 'fieldLimit',
                name: 'fieldLimit',
                value: field.charLimit ?? field.byteLimit,
                size: 3,
            }) }}
            {{ forms.select({
                id: 'limitUnit',
                name: 'limitUnit',
                options: [
                    { value: 'chars', label: 'Characters'|t('app') },
                    { value: 'bytes', label: 'Bytes'|t('app') },
                ],
                value: field.byteLimit ? 'bytes' : 'chars'
            }) }}
        </div>
    {% endblock %}
{% endembed %}


{{ forms.checkboxField({
    label: \"Use a monospaced font\"|t('app'),
    name: 'code',
    checked: field.code,
}) }}

{{ forms.checkboxField({
    label: \"Allow line breaks\"|t('app'),
    name: 'multiline',
    checked: field.multiline,
    toggle: 'initialRowsContainer'
}) }}


<div id=\"initialRowsContainer\" class=\"nested-fields{% if not field.multiline %} hidden{% endif %}\">
    {{ forms.textField({
        label: \"Initial Rows\"|t('app'),
        id: 'initialRows',
        name: 'initialRows',
        value: field.initialRows,
        size: 3,
        errors: field.getErrors('initialRows')
    }) }}
</div>

{% if craft.app.db.isMysql %}
    <hr>
    <a class=\"fieldtoggle\" data-target=\"advanced\">{{ \"Advanced\"|t('app') }}</a>
    <div id=\"advanced\" class=\"hidden\">
        {{ forms.selectField({
            label: \"Column Type\"|t('app'),
            id: 'column-type',
            name: 'columnType',
            instructions: \"The type of column this field should get in the database.\"|t('app'),
            options: [
                { value: 'auto', label: 'Automatic'|t('app') },
                { value: 'string', label: 'varchar (255B)' },
                { value: 'text', label: 'text (~64KB)' },
                { value: 'mediumtext', label: 'mediumtext (~16MB)' },
            ],
            value: field.columnType ?? 'auto',
            warning: (field.id ? \"Changing this may result in data loss.\"|t('app')),
        }) }}
    </div>
{% endif %}
", "_components/fieldtypes/PlainText/settings", "/Applications/MAMP/htdocs/craft/smsi/vendor/craftcms/cms/src/templates/_components/fieldtypes/PlainText/settings.html");
    }
}


/* _components/fieldtypes/PlainText/settings */
class __TwigTemplate_94b841c35109c4f47d1962cc257aef8c65947dd72201313adcc6773b5258f686___1269900781 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'input' => [$this, 'block_input'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 13
        return "_includes/forms/field";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("template", "_components/fieldtypes/PlainText/settings");
        // line 19
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms", "_components/fieldtypes/PlainText/settings", 19)->unwrap();
        // line 13
        $this->parent = $this->loadTemplate("_includes/forms/field", "_components/fieldtypes/PlainText/settings", 13);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        // line 0
        craft\helpers\Template::endProfile("template", "_components/fieldtypes/PlainText/settings");
    }

    // line 20
    public function block_input($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("block", "input");
        // line 21
        echo "        <div class=\"flex\">
            ";
        // line 22
        echo twig_call_macro($macros["forms"], "macro_text", [["id" => "fieldLimit", "name" => "fieldLimit", "value" => (((craft\helpers\Template::attribute($this->env, $this->source,         // line 25
($context["field"] ?? null), "charLimit", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["field"] ?? null), "charLimit", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["field"] ?? null), "charLimit", [])) : (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 25, $this->source); })()), "byteLimit", []))), "size" => 3]], 22, $context, $this->getSourceContext());
        // line 27
        echo "
            ";
        // line 28
        echo twig_call_macro($macros["forms"], "macro_select", [["id" => "limitUnit", "name" => "limitUnit", "options" => [0 => ["value" => "chars", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Characters", "app")], 1 => ["value" => "bytes", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Bytes", "app")]], "value" => ((craft\helpers\Template::attribute($this->env, $this->source,         // line 35
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 35, $this->source); })()), "byteLimit", [])) ? ("bytes") : ("chars"))]], 28, $context, $this->getSourceContext());
        // line 36
        echo "
        </div>
    ";
        // line 0
        craft\helpers\Template::endProfile("block", "input");
    }

    public function getTemplateName()
    {
        return "_components/fieldtypes/PlainText/settings";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  279 => 0,  275 => 36,  273 => 35,  272 => 28,  269 => 27,  267 => 25,  266 => 22,  263 => 21,  261 => 0,  257 => 20,  253 => 0,  250 => 13,  248 => 19,  246 => 0,  239 => 13,  108 => 0,  103 => 84,  101 => 83,  100 => 82,  99 => 71,  94 => 69,  91 => 68,  89 => 67,  84 => 64,  82 => 63,  81 => 61,  80 => 57,  74 => 56,  69 => 53,  67 => 51,  66 => 48,  62 => 46,  60 => 45,  59 => 42,  55 => 40,  53 => 17,  52 => 13,  48 => 11,  46 => 10,  45 => 9,  44 => 4,  40 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% import \"_includes/forms\" as forms %}


{{ forms.textField({
    label: \"Placeholder Text\"|t('app'),
    instructions: \"The text that will be shown if the field doesn’t have a value.\"|t('app'),
    id: 'placeholder',
    name: 'placeholder',
    value: field.placeholder,
    errors: field.getErrors('placeholder')
}) }}

{% embed '_includes/forms/field' with {
    label: 'Field Limit'|t('app'),
    instructions: \"The maximum number of characters or bytes the field is allowed to have.\"|t('app'),
    id: 'fieldLimit',
    errors: field.getErrors(field.byteLimit ? 'byteLimit' : 'charLimit')
} %}
    {% import \"_includes/forms\" as forms %}
    {% block input %}
        <div class=\"flex\">
            {{ forms.text({
                id: 'fieldLimit',
                name: 'fieldLimit',
                value: field.charLimit ?? field.byteLimit,
                size: 3,
            }) }}
            {{ forms.select({
                id: 'limitUnit',
                name: 'limitUnit',
                options: [
                    { value: 'chars', label: 'Characters'|t('app') },
                    { value: 'bytes', label: 'Bytes'|t('app') },
                ],
                value: field.byteLimit ? 'bytes' : 'chars'
            }) }}
        </div>
    {% endblock %}
{% endembed %}


{{ forms.checkboxField({
    label: \"Use a monospaced font\"|t('app'),
    name: 'code',
    checked: field.code,
}) }}

{{ forms.checkboxField({
    label: \"Allow line breaks\"|t('app'),
    name: 'multiline',
    checked: field.multiline,
    toggle: 'initialRowsContainer'
}) }}


<div id=\"initialRowsContainer\" class=\"nested-fields{% if not field.multiline %} hidden{% endif %}\">
    {{ forms.textField({
        label: \"Initial Rows\"|t('app'),
        id: 'initialRows',
        name: 'initialRows',
        value: field.initialRows,
        size: 3,
        errors: field.getErrors('initialRows')
    }) }}
</div>

{% if craft.app.db.isMysql %}
    <hr>
    <a class=\"fieldtoggle\" data-target=\"advanced\">{{ \"Advanced\"|t('app') }}</a>
    <div id=\"advanced\" class=\"hidden\">
        {{ forms.selectField({
            label: \"Column Type\"|t('app'),
            id: 'column-type',
            name: 'columnType',
            instructions: \"The type of column this field should get in the database.\"|t('app'),
            options: [
                { value: 'auto', label: 'Automatic'|t('app') },
                { value: 'string', label: 'varchar (255B)' },
                { value: 'text', label: 'text (~64KB)' },
                { value: 'mediumtext', label: 'mediumtext (~16MB)' },
            ],
            value: field.columnType ?? 'auto',
            warning: (field.id ? \"Changing this may result in data loss.\"|t('app')),
        }) }}
    </div>
{% endif %}
", "_components/fieldtypes/PlainText/settings", "/Applications/MAMP/htdocs/craft/smsi/vendor/craftcms/cms/src/templates/_components/fieldtypes/PlainText/settings.html");
    }
}
