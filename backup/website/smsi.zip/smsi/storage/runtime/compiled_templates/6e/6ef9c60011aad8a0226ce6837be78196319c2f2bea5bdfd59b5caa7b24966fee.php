<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* __string_template__20ced435a8af97cabdce8c0a8dd88eb05942b08f9001bf04ca1beef0156ac61f */
class __TwigTemplate_8ff473cd52ecd7cfeccd913ee1909f7445aec0b3f5acc6cde605c82bfb50ea5e extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "__string_template__20ced435a8af97cabdce8c0a8dd88eb05942b08f9001bf04ca1beef0156ac61f");
        // line 1
        echo "testimonials/";
        echo (((craft\helpers\Template::attribute($this->env, $this->source, ($context["_variables"] ?? null), "slug", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["_variables"] ?? null), "slug", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["_variables"] ?? null), "slug", [])) : (craft\helpers\Template::attribute($this->env, $this->source, ($context["object"] ?? null), "slug", [])));
        // line 0
        craft\helpers\Template::endProfile("template", "__string_template__20ced435a8af97cabdce8c0a8dd88eb05942b08f9001bf04ca1beef0156ac61f");
    }

    public function getTemplateName()
    {
        return "__string_template__20ced435a8af97cabdce8c0a8dd88eb05942b08f9001bf04ca1beef0156ac61f";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  41 => 0,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("testimonials/{{ (_variables.slug ?? object.slug)|raw }}", "__string_template__20ced435a8af97cabdce8c0a8dd88eb05942b08f9001bf04ca1beef0156ac61f", "");
    }
}
