<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* settings/sites/index */
class __TwigTemplate_1975ffcd8039f915ae21dd8f8e826307ac2948acba95d057917ea4c68adef3de extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'actionButton' => [$this, 'block_actionButton'],
            'sidebar' => [$this, 'block_sidebar'],
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "_layouts/cp";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("template", "settings/sites/index");
        // line 2
        $context["title"] = $this->extensions['craft\web\twig\Extension']->translateFilter("Sites", "app");
        // line 4
        $context["multiple"] = (twig_length_filter($this->env, (isset($context["sites"]) || array_key_exists("sites", $context) ? $context["sites"] : (function () { throw new RuntimeError('Variable "sites" does not exist.', 4, $this->source); })())) > 1);
        // line 5
        $context["canSort"] = ((isset($context["group"]) || array_key_exists("group", $context) ? $context["group"] : (function () { throw new RuntimeError('Variable "group" does not exist.', 5, $this->source); })()) && (isset($context["multiple"]) || array_key_exists("multiple", $context) ? $context["multiple"] : (function () { throw new RuntimeError('Variable "multiple" does not exist.', 5, $this->source); })()));
        // line 84
        ob_start();
        // line 85
        echo "    new Craft.SitesAdmin();

    new Craft.SiteAdminTable({
        tableSelector: '#sites',
        minItems: 1,
        sortable: true,
        reorderAction: 'sites/reorder-sites',
        deleteAction: 'sites/delete-site',
    });
";
        Craft::$app->getView()->registerJs(ob_get_clean(), 4);
        // line 1
        $this->parent = $this->loadTemplate("_layouts/cp", "settings/sites/index", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        // line 0
        craft\helpers\Template::endProfile("template", "settings/sites/index");
    }

    // line 8
    public function block_actionButton($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("block", "actionButton");
        // line 9
        echo "    ";
        $context["newSiteUrl"] = craft\helpers\UrlHelper::url("settings/sites/new", (((isset($context["group"]) || array_key_exists("group", $context) ? $context["group"] : (function () { throw new RuntimeError('Variable "group" does not exist.', 9, $this->source); })())) ? (["groupId" => craft\helpers\Template::attribute($this->env, $this->source, (isset($context["group"]) || array_key_exists("group", $context) ? $context["group"] : (function () { throw new RuntimeError('Variable "group" does not exist.', 9, $this->source); })()), "id", [])]) : (null)));
        // line 10
        echo "    <a href=\"";
        echo twig_escape_filter($this->env, (isset($context["newSiteUrl"]) || array_key_exists("newSiteUrl", $context) ? $context["newSiteUrl"] : (function () { throw new RuntimeError('Variable "newSiteUrl" does not exist.', 10, $this->source); })()), "html", null, true);
        echo "\" class=\"btn submit add icon\">";
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("New site", "app"), "html", null, true);
        echo "</a>
";
        // line 0
        craft\helpers\Template::endProfile("block", "actionButton");
    }

    // line 14
    public function block_sidebar($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("block", "sidebar");
        // line 15
        echo "    <nav>
        <ul id=\"groups\">
            <li><a href=\"";
        // line 17
        echo twig_escape_filter($this->env, craft\helpers\UrlHelper::url("settings/sites"), "html", null, true);
        echo "\"";
        if ( !(isset($context["group"]) || array_key_exists("group", $context) ? $context["group"] : (function () { throw new RuntimeError('Variable "group" does not exist.', 17, $this->source); })())) {
            echo " class=\"sel\"";
        }
        echo ">";
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("All Sites", "app"), "html", null, true);
        echo "</a></li>
            ";
        // line 18
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["allGroups"]) || array_key_exists("allGroups", $context) ? $context["allGroups"] : (function () { throw new RuntimeError('Variable "allGroups" does not exist.', 18, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["g"]) {
            // line 19
            echo "                <li><a href=\"";
            echo twig_escape_filter($this->env, craft\helpers\UrlHelper::url("settings/sites", ["groupId" => craft\helpers\Template::attribute($this->env, $this->source, $context["g"], "id", [])]), "html", null, true);
            echo "\"";
            if (((isset($context["group"]) || array_key_exists("group", $context) ? $context["group"] : (function () { throw new RuntimeError('Variable "group" does not exist.', 19, $this->source); })()) && (craft\helpers\Template::attribute($this->env, $this->source, $context["g"], "id", []) == craft\helpers\Template::attribute($this->env, $this->source, (isset($context["group"]) || array_key_exists("group", $context) ? $context["group"] : (function () { throw new RuntimeError('Variable "group" does not exist.', 19, $this->source); })()), "id", [])))) {
                echo " class=\"sel\"";
            }
            echo " data-id=\"";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["g"], "id", []), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source, $context["g"], "name", []), "site"), "html", null, true);
            echo "</a></li>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['g'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 21
        echo "        </ul>
    </nav>

    <div class=\"buttons\">
        <div id=\"newgroupbtn\" class=\"btn add icon\">";
        // line 25
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("New group", "app"), "html", null, true);
        echo "</div>

        ";
        // line 27
        if ((isset($context["group"]) || array_key_exists("group", $context) ? $context["group"] : (function () { throw new RuntimeError('Variable "group" does not exist.', 27, $this->source); })())) {
            // line 28
            echo "            <div id=\"groupsettingsbtn\" class=\"btn settings icon menubtn\" title=\"";
            echo "Settings";
            echo "\"></div>
            <div class=\"menu\">
                <ul>
                    <li><a data-action=\"rename\" role=\"button\">";
            // line 31
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Rename selected group", "app"), "html", null, true);
            echo "</a></li>
                    <li><a data-action=\"delete\" role=\"button\"";
            // line 32
            if (twig_length_filter($this->env, (isset($context["sites"]) || array_key_exists("sites", $context) ? $context["sites"] : (function () { throw new RuntimeError('Variable "sites" does not exist.', 32, $this->source); })()))) {
                echo " class=\"disabled\" title=\"";
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("You can only delete groups that have no sites.", "app"), "html", null, true);
                echo "\"";
            }
            echo ">";
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Delete selected group", "app"), "html", null, true);
            echo "</a></li>
                </ul>
            </div>
        ";
        }
        // line 36
        echo "    </div>
";
        // line 0
        craft\helpers\Template::endProfile("block", "sidebar");
    }

    // line 40
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("block", "content");
        // line 41
        echo "    <div class=\"tablepane\">
        <table id=\"sites\" class=\"data fullwidth\">
            <thead>
                <th scope=\"col\">";
        // line 44
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Name", "app"), "html", null, true);
        echo "</th>
                <th scope=\"col\">";
        // line 45
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Handle", "app"), "html", null, true);
        echo "</th>
                <th scope=\"col\">";
        // line 46
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Language", "app"), "html", null, true);
        echo "</th>
                <th scope=\"col\">";
        // line 47
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Primary", "app"), "html", null, true);
        echo "</th>
                <th scope=\"col\">";
        // line 48
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Base URL", "app"), "html", null, true);
        echo "</th>
                ";
        // line 49
        if ( !(isset($context["group"]) || array_key_exists("group", $context) ? $context["group"] : (function () { throw new RuntimeError('Variable "group" does not exist.', 49, $this->source); })())) {
            // line 50
            echo "                    <th scope=\"col\">";
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Group", "app"), "html", null, true);
            echo "</th>
                ";
        }
        // line 52
        echo "                ";
        if ((isset($context["canSort"]) || array_key_exists("canSort", $context) ? $context["canSort"] : (function () { throw new RuntimeError('Variable "canSort" does not exist.', 52, $this->source); })())) {
            // line 53
            echo "                    <td class=\"thin\"></td>
                ";
        }
        // line 55
        echo "                ";
        if ((isset($context["multiple"]) || array_key_exists("multiple", $context) ? $context["multiple"] : (function () { throw new RuntimeError('Variable "multiple" does not exist.', 55, $this->source); })())) {
            // line 56
            echo "                    <td class=\"thin\"></td>
                ";
        }
        // line 58
        echo "            </thead>
            <tbody>
                ";
        // line 60
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["sites"]) || array_key_exists("sites", $context) ? $context["sites"] : (function () { throw new RuntimeError('Variable "sites" does not exist.', 60, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["site"]) {
            // line 61
            echo "                    <tr data-id=\"";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "id", []), "html", null, true);
            echo "\" data-uid=\"";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "uid", []), "html", null, true);
            echo "\" data-name=\"";
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "name", []), "site"), "html", null, true);
            echo "\">
                        <th scope=\"row\" data-title=\"";
            // line 62
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Name", "app"), "html", null, true);
            echo "\"><a href=\"";
            echo twig_escape_filter($this->env, craft\helpers\UrlHelper::url(("settings/sites/" . craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "id", []))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "name", []), "site"), "html", null, true);
            echo "</a></th>
                        <td data-title=\"";
            // line 63
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Handle", "app"), "html", null, true);
            echo "\"><code>";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "handle", []), "html", null, true);
            echo "</code></td>
                        <td data-title=\"";
            // line 64
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Language", "app"), "html", null, true);
            echo "\"><code>";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "language", []), "html", null, true);
            echo "</code></td>
                        <td data-title=\"";
            // line 65
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Primary", "app"), "html", null, true);
            echo "\">";
            if (craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "primary", [])) {
                echo "<div data-icon=\"check\"></div>";
            }
            echo "</td>
                        <td data-title=\"";
            // line 66
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Base URL", "app"), "html", null, true);
            echo "\"><code>";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "baseUrl", []), "html", null, true);
            echo "</code></td>
                        ";
            // line 67
            if ( !(isset($context["group"]) || array_key_exists("group", $context) ? $context["group"] : (function () { throw new RuntimeError('Variable "group" does not exist.', 67, $this->source); })())) {
                // line 68
                echo "                            <td data-title=\"";
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Group", "app"), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "group", []), "name", []), "site"), "html", null, true);
                echo "</td>
                        ";
            }
            // line 70
            echo "                        ";
            if ((isset($context["canSort"]) || array_key_exists("canSort", $context) ? $context["canSort"] : (function () { throw new RuntimeError('Variable "canSort" does not exist.', 70, $this->source); })())) {
                // line 71
                echo "                            <td class=\"thin\"><a class=\"move icon\" title=\"";
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Reorder", "app"), "html", null, true);
                echo "\" role=\"button\"></a></td>
                        ";
            }
            // line 73
            echo "                        ";
            if ((isset($context["multiple"]) || array_key_exists("multiple", $context) ? $context["multiple"] : (function () { throw new RuntimeError('Variable "multiple" does not exist.', 73, $this->source); })())) {
                // line 74
                echo "                            <td class=\"thin\"><a class=\"delete icon";
                if (craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "primary", [])) {
                    echo " disabled";
                }
                echo "\" title=\"";
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Delete", "app"), "html", null, true);
                echo "\" role=\"button\"></a></td>
                        ";
            }
            // line 76
            echo "                    </tr>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['site'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 78
        echo "            </tbody>
        </table>
    </div>
";
        // line 0
        craft\helpers\Template::endProfile("block", "content");
    }

    public function getTemplateName()
    {
        return "settings/sites/index";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  326 => 0,  321 => 78,  314 => 76,  304 => 74,  301 => 73,  295 => 71,  292 => 70,  284 => 68,  282 => 67,  276 => 66,  268 => 65,  262 => 64,  256 => 63,  248 => 62,  239 => 61,  235 => 60,  231 => 58,  227 => 56,  224 => 55,  220 => 53,  217 => 52,  211 => 50,  209 => 49,  205 => 48,  201 => 47,  197 => 46,  193 => 45,  189 => 44,  184 => 41,  182 => 0,  178 => 40,  174 => 0,  171 => 36,  158 => 32,  154 => 31,  147 => 28,  145 => 27,  140 => 25,  134 => 21,  117 => 19,  113 => 18,  103 => 17,  99 => 15,  97 => 0,  93 => 14,  89 => 0,  82 => 10,  79 => 9,  77 => 0,  73 => 8,  69 => 0,  66 => 1,  54 => 85,  52 => 84,  50 => 5,  48 => 4,  46 => 2,  44 => 0,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends \"_layouts/cp\" %}
{% set title = \"Sites\"|t('app') %}

{% set multiple = (sites|length > 1) %}
{% set canSort = group and multiple %}


{% block actionButton %}
    {% set newSiteUrl = url('settings/sites/new', (group ? { groupId: group.id } : null)) %}
    <a href=\"{{ newSiteUrl }}\" class=\"btn submit add icon\">{{ \"New site\"|t('app') }}</a>
{% endblock %}


{% block sidebar %}
    <nav>
        <ul id=\"groups\">
            <li><a href=\"{{ url('settings/sites') }}\"{% if not group %} class=\"sel\"{% endif %}>{{ \"All Sites\"|t('app') }}</a></li>
            {% for g in allGroups %}
                <li><a href=\"{{ url('settings/sites', {groupId: g.id}) }}\"{% if group and g.id == group.id %} class=\"sel\"{% endif %} data-id=\"{{ g.id }}\">{{ g.name|t('site') }}</a></li>
            {% endfor %}
        </ul>
    </nav>

    <div class=\"buttons\">
        <div id=\"newgroupbtn\" class=\"btn add icon\">{{ \"New group\"|t('app') }}</div>

        {% if group %}
            <div id=\"groupsettingsbtn\" class=\"btn settings icon menubtn\" title=\"{{ 'Settings' }}\"></div>
            <div class=\"menu\">
                <ul>
                    <li><a data-action=\"rename\" role=\"button\">{{ \"Rename selected group\"|t('app') }}</a></li>
                    <li><a data-action=\"delete\" role=\"button\"{% if sites|length %} class=\"disabled\" title=\"{{ 'You can only delete groups that have no sites.'|t('app') }}\"{% endif %}>{{ \"Delete selected group\"|t('app') }}</a></li>
                </ul>
            </div>
        {% endif %}
    </div>
{% endblock %}


{% block content %}
    <div class=\"tablepane\">
        <table id=\"sites\" class=\"data fullwidth\">
            <thead>
                <th scope=\"col\">{{ \"Name\"|t('app') }}</th>
                <th scope=\"col\">{{ \"Handle\"|t('app') }}</th>
                <th scope=\"col\">{{ \"Language\"|t('app') }}</th>
                <th scope=\"col\">{{ \"Primary\"|t('app') }}</th>
                <th scope=\"col\">{{ \"Base URL\"|t('app') }}</th>
                {% if not group %}
                    <th scope=\"col\">{{ \"Group\"|t('app') }}</th>
                {% endif %}
                {% if canSort %}
                    <td class=\"thin\"></td>
                {% endif %}
                {% if multiple %}
                    <td class=\"thin\"></td>
                {% endif %}
            </thead>
            <tbody>
                {% for site in sites %}
                    <tr data-id=\"{{ site.id }}\" data-uid=\"{{ site.uid }}\" data-name=\"{{ site.name|t('site') }}\">
                        <th scope=\"row\" data-title=\"{{ 'Name'|t('app') }}\"><a href=\"{{ url('settings/sites/' ~ site.id) }}\">{{ site.name|t('site') }}</a></th>
                        <td data-title=\"{{ 'Handle'|t('app') }}\"><code>{{ site.handle }}</code></td>
                        <td data-title=\"{{ 'Language'|t('app') }}\"><code>{{ site.language }}</code></td>
                        <td data-title=\"{{ 'Primary'|t('app') }}\">{% if site.primary %}<div data-icon=\"check\"></div>{% endif %}</td>
                        <td data-title=\"{{ 'Base URL'|t('app') }}\"><code>{{ site.baseUrl }}</code></td>
                        {% if not group %}
                            <td data-title=\"{{ 'Group'|t('app') }}\">{{ site.group.name|t('site') }}</td>
                        {% endif %}
                        {% if canSort %}
                            <td class=\"thin\"><a class=\"move icon\" title=\"{{ 'Reorder'|t('app') }}\" role=\"button\"></a></td>
                        {% endif %}
                        {% if multiple %}
                            <td class=\"thin\"><a class=\"delete icon{% if site.primary %} disabled{% endif %}\" title=\"{{ 'Delete'|t('app') }}\" role=\"button\"></a></td>
                        {% endif %}
                    </tr>
                {% endfor %}
            </tbody>
        </table>
    </div>
{% endblock %}


{% js on ready %}
    new Craft.SitesAdmin();

    new Craft.SiteAdminTable({
        tableSelector: '#sites',
        minItems: 1,
        sortable: true,
        reorderAction: 'sites/reorder-sites',
        deleteAction: 'sites/delete-site',
    });
{% endjs %}
", "settings/sites/index", "/Applications/MAMP/htdocs/craft/smsi/vendor/craftcms/cms/src/templates/settings/sites/index.html");
    }
}
