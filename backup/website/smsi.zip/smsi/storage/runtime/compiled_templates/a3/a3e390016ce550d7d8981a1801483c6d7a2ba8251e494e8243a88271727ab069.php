<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _includes/forms/editableTable */
class __TwigTemplate_9e82db8389c17539fa0eb7e1658394f87de6a3d741c0c025ebde59a8642e5daa extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'tablecell' => [$this, 'block_tablecell'],
        ];
        $macros["_self"] = $this->macros["_self"] = $this;
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_includes/forms/editableTable");
        // line 1
        $context["static"] = (($context["static"]) ?? (false));
        // line 2
        $context["fullWidth"] = (($context["fullWidth"]) ?? (true));
        // line 3
        $context["cols"] = (($context["cols"]) ?? ([]));
        // line 4
        $context["rows"] = (($context["rows"]) ?? ([]));
        // line 5
        $context["initJs"] = ( !(isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new RuntimeError('Variable "static" does not exist.', 5, $this->source); })()) && (($context["initJs"]) ?? (true)));
        // line 6
        $context["minRows"] = (($context["minRows"]) ?? (null));
        // line 7
        $context["maxRows"] = (($context["maxRows"]) ?? (null));
        // line 8
        $context["staticRows"] = (((isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new RuntimeError('Variable "static" does not exist.', 8, $this->source); })()) || (($context["staticRows"]) ?? (false))) || ((((isset($context["minRows"]) || array_key_exists("minRows", $context) ? $context["minRows"] : (function () { throw new RuntimeError('Variable "minRows" does not exist.', 8, $this->source); })()) == 1) && ((isset($context["maxRows"]) || array_key_exists("maxRows", $context) ? $context["maxRows"] : (function () { throw new RuntimeError('Variable "maxRows" does not exist.', 8, $this->source); })()) == 1)) && (twig_length_filter($this->env, (isset($context["rows"]) || array_key_exists("rows", $context) ? $context["rows"] : (function () { throw new RuntimeError('Variable "rows" does not exist.', 8, $this->source); })())) == 1)));
        // line 9
        $context["fixedRows"] = ( !(isset($context["staticRows"]) || array_key_exists("staticRows", $context) ? $context["staticRows"] : (function () { throw new RuntimeError('Variable "staticRows" does not exist.', 9, $this->source); })()) && (((isset($context["minRows"]) || array_key_exists("minRows", $context) ? $context["minRows"] : (function () { throw new RuntimeError('Variable "minRows" does not exist.', 9, $this->source); })()) && ((isset($context["minRows"]) || array_key_exists("minRows", $context) ? $context["minRows"] : (function () { throw new RuntimeError('Variable "minRows" does not exist.', 9, $this->source); })()) == (isset($context["maxRows"]) || array_key_exists("maxRows", $context) ? $context["maxRows"] : (function () { throw new RuntimeError('Variable "maxRows" does not exist.', 9, $this->source); })()))) && ((isset($context["minRows"]) || array_key_exists("minRows", $context) ? $context["minRows"] : (function () { throw new RuntimeError('Variable "minRows" does not exist.', 9, $this->source); })()) == twig_length_filter($this->env, (isset($context["rows"]) || array_key_exists("rows", $context) ? $context["rows"] : (function () { throw new RuntimeError('Variable "rows" does not exist.', 9, $this->source); })())))));
        // line 10
        echo "
";
        // line 11
        if ( !(isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new RuntimeError('Variable "static" does not exist.', 11, $this->source); })())) {
            // line 12
            echo "    ";
            echo craft\helpers\Html::hiddenInput((isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 12, $this->source); })()), "");
            echo "
";
        }
        // line 14
        echo "
";
        // line 23
        echo "
<table id=\"";
        // line 24
        echo twig_escape_filter($this->env, (isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 24, $this->source); })()), "html", null, true);
        echo "\" class=\"editable";
        if ((isset($context["fullWidth"]) || array_key_exists("fullWidth", $context) ? $context["fullWidth"] : (function () { throw new RuntimeError('Variable "fullWidth" does not exist.', 24, $this->source); })())) {
            echo " fullwidth";
        }
        if ((isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new RuntimeError('Variable "static" does not exist.', 24, $this->source); })())) {
            echo " static";
        }
        echo "\"";
        // line 25
        if (        $this->hasBlock("attr", $context, $blocks)) {
            echo " ";
            $this->displayBlock("attr", $context, $blocks);
        }
        echo ">
    <thead>
        <tr>
            ";
        // line 28
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["cols"]) || array_key_exists("cols", $context) ? $context["cols"] : (function () { throw new RuntimeError('Variable "cols" does not exist.', 28, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["col"]) {
            // line 29
            switch (craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "type", [])) {
                case "time":
                {
                    // line 31
                    craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 31, $this->source); })()), "registerAssetBundle", [0 => "craft\\web\\assets\\timepicker\\TimepickerAsset"], "method");
                    break;
                }
                case "template":
                {
                    // line 33
                    craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 33, $this->source); })()), "registerAssetBundle", [0 => "craft\\web\\assets\\vue\\VueAsset"], "method");
                    break;
                }
            }
            // line 35
            echo "                <th scope=\"col\" class=\"";
            echo twig_call_macro($macros["_self"], "macro_cellClass", [(isset($context["fullWidth"]) || array_key_exists("fullWidth", $context) ? $context["fullWidth"] : (function () { throw new RuntimeError('Variable "fullWidth" does not exist.', 35, $this->source); })()), $context["col"], (((craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "class", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "class", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "class", [])) : ([]))], 35, $context, $this->getSourceContext());
            echo "\">";
            // line 36
            if (craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "headingHtml", [], "any", true, true)) {
                // line 37
                echo craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "headingHtml", []);
            } elseif ((craft\helpers\Template::attribute($this->env, $this->source,             // line 38
$context["col"], "heading", [], "any", true, true) && craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "heading", []))) {
                // line 39
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "heading", []), "html", null, true);
            } else {
                // line 41
                echo "                        &nbsp;";
            }
            // line 43
            if (craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "info", [], "any", true, true)) {
                // line 44
                echo "<span class=\"info\">";
                echo $this->extensions['craft\web\twig\Extension']->markdownFilter(craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "info", []));
                echo "</span>";
            }
            // line 46
            echo "</th>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['col'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 48
        echo "            ";
        if ( !(isset($context["staticRows"]) || array_key_exists("staticRows", $context) ? $context["staticRows"] : (function () { throw new RuntimeError('Variable "staticRows" does not exist.', 48, $this->source); })())) {
            // line 49
            echo "                <th colspan=\"";
            echo (((isset($context["fixedRows"]) || array_key_exists("fixedRows", $context) ? $context["fixedRows"] : (function () { throw new RuntimeError('Variable "fixedRows" does not exist.', 49, $this->source); })())) ? (1) : (2));
            echo "\"></th>
            ";
        }
        // line 51
        echo "        </tr>
    </thead>
    <tbody>
        ";
        // line 54
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["rows"]) || array_key_exists("rows", $context) ? $context["rows"] : (function () { throw new RuntimeError('Variable "rows" does not exist.', 54, $this->source); })()));
        foreach ($context['_seq'] as $context["rowId"] => $context["row"]) {
            // line 55
            echo "            <tr data-id=\"";
            echo twig_escape_filter($this->env, $context["rowId"], "html", null, true);
            echo "\">
                ";
            // line 56
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["cols"]) || array_key_exists("cols", $context) ? $context["cols"] : (function () { throw new RuntimeError('Variable "cols" does not exist.', 56, $this->source); })()));
            $context['loop'] = [
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            ];
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["colId"] => $context["col"]) {
                // line 57
                echo "                    ";
                $context["cell"] = ((craft\helpers\Template::attribute($this->env, $this->source, $context["row"], $context["colId"], [], "array", true, true)) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["row"], $context["colId"], [], "array")) : ((((craft\helpers\Template::attribute($this->env, $this->source, ($context["defaultValues"] ?? null), $context["colId"], [], "array", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["defaultValues"] ?? null), $context["colId"], [], "array")))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["defaultValues"] ?? null), $context["colId"], [], "array")) : (null))));
                // line 58
                echo "                    ";
                $context["value"] = ((craft\helpers\Template::attribute($this->env, $this->source, ($context["cell"] ?? null), "value", [], "any", true, true)) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["cell"]) || array_key_exists("cell", $context) ? $context["cell"] : (function () { throw new RuntimeError('Variable "cell" does not exist.', 58, $this->source); })()), "value", [])) : ((isset($context["cell"]) || array_key_exists("cell", $context) ? $context["cell"] : (function () { throw new RuntimeError('Variable "cell" does not exist.', 58, $this->source); })())));
                // line 59
                echo "                    ";
                if ((craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "type", []) == "heading")) {
                    // line 60
                    echo "                        <th scope=\"row\" class=\"";
                    echo twig_call_macro($macros["_self"], "macro_cellClass", [(isset($context["fullWidth"]) || array_key_exists("fullWidth", $context) ? $context["fullWidth"] : (function () { throw new RuntimeError('Variable "fullWidth" does not exist.', 60, $this->source); })()), $context["col"], (((craft\helpers\Template::attribute($this->env, $this->source, ($context["cell"] ?? null), "class", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["cell"] ?? null), "class", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["cell"] ?? null), "class", [])) : ((((craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "class", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "class", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "class", [])) : ([]))))], 60, $context, $this->getSourceContext());
                    echo "\">";
                    echo (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 60, $this->source); })());
                    echo "</th>
                    ";
                } elseif ((craft\helpers\Template::attribute($this->env, $this->source,                 // line 61
$context["col"], "type", []) == "html")) {
                    // line 62
                    echo "                        <td class=\"";
                    echo twig_call_macro($macros["_self"], "macro_cellClass", [(isset($context["fullWidth"]) || array_key_exists("fullWidth", $context) ? $context["fullWidth"] : (function () { throw new RuntimeError('Variable "fullWidth" does not exist.', 62, $this->source); })()), $context["col"], (((craft\helpers\Template::attribute($this->env, $this->source, ($context["cell"] ?? null), "class", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["cell"] ?? null), "class", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["cell"] ?? null), "class", [])) : ((((craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "class", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "class", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "class", [])) : ([]))))], 62, $context, $this->getSourceContext());
                    echo "\">";
                    echo (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 62, $this->source); })());
                    echo "</td>
                    ";
                } else {
                    // line 64
                    echo "                        ";
                    $context["hasErrors"] = (((craft\helpers\Template::attribute($this->env, $this->source, ($context["cell"] ?? null), "hasErrors", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["cell"] ?? null), "hasErrors", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["cell"] ?? null), "hasErrors", [])) : (false));
                    // line 65
                    echo "                        ";
                    $context["cellName"] = ((((((isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 65, $this->source); })()) . "[") . $context["rowId"]) . "][") . $context["colId"]) . "]");
                    // line 66
                    echo "                        ";
                    $context["isCode"] = (craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "code", [], "any", true, true) || (craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "type", []) == "color"));
                    // line 67
                    echo "                        <td class=\"";
                    echo twig_call_macro($macros["_self"], "macro_cellClass", [(isset($context["fullWidth"]) || array_key_exists("fullWidth", $context) ? $context["fullWidth"] : (function () { throw new RuntimeError('Variable "fullWidth" does not exist.', 67, $this->source); })()), $context["col"], (((craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "class", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "class", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "class", [])) : ([]))], 67, $context, $this->getSourceContext());
                    echo " ";
                    if ((isset($context["isCode"]) || array_key_exists("isCode", $context) ? $context["isCode"] : (function () { throw new RuntimeError('Variable "isCode" does not exist.', 67, $this->source); })())) {
                        echo "code";
                    }
                    echo " ";
                    if ((isset($context["hasErrors"]) || array_key_exists("hasErrors", $context) ? $context["hasErrors"] : (function () { throw new RuntimeError('Variable "hasErrors" does not exist.', 67, $this->source); })())) {
                        echo "error";
                    }
                    echo "\"";
                    if ((((craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "width", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "width", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "width", [])) : (false))) {
                        echo " width=\"";
                        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["col"], "width", []), "html", null, true);
                        echo "\"";
                    }
                    echo ">
                            ";
                    // line 68
                    $this->displayBlock('tablecell', $context, $blocks);
                    // line 137
                    echo "                        </td>
                    ";
                }
                // line 139
                echo "                ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['length'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['colId'], $context['col'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 140
            echo "                ";
            if ( !(isset($context["staticRows"]) || array_key_exists("staticRows", $context) ? $context["staticRows"] : (function () { throw new RuntimeError('Variable "staticRows" does not exist.', 140, $this->source); })())) {
                // line 141
                echo "                    <td class=\"thin action\"><a class=\"move icon\" title=\"";
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Reorder", "app"), "html", null, true);
                echo "\"></a></td>
                    ";
                // line 142
                if ( !(isset($context["fixedRows"]) || array_key_exists("fixedRows", $context) ? $context["fixedRows"] : (function () { throw new RuntimeError('Variable "fixedRows" does not exist.', 142, $this->source); })())) {
                    echo "<td class=\"thin action\"><a class=\"delete icon\" title=\"";
                    echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Delete", "app"), "html", null, true);
                    echo "\"></a></td>";
                }
                // line 143
                echo "                ";
            }
            // line 144
            echo "            </tr>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['rowId'], $context['row'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 146
        echo "    </tbody>
</table>
";
        // line 148
        if (( !(isset($context["staticRows"]) || array_key_exists("staticRows", $context) ? $context["staticRows"] : (function () { throw new RuntimeError('Variable "staticRows" does not exist.', 148, $this->source); })()) &&  !(isset($context["fixedRows"]) || array_key_exists("fixedRows", $context) ? $context["fixedRows"] : (function () { throw new RuntimeError('Variable "fixedRows" does not exist.', 148, $this->source); })()))) {
            // line 149
            echo "    <div class=\"btn add icon\">";
            echo twig_escape_filter($this->env, (((isset($context["addRowLabel"]) || array_key_exists("addRowLabel", $context))) ? ((isset($context["addRowLabel"]) || array_key_exists("addRowLabel", $context) ? $context["addRowLabel"] : (function () { throw new RuntimeError('Variable "addRowLabel" does not exist.', 149, $this->source); })())) : ($this->extensions['craft\web\twig\Extension']->translateFilter("Add a row", "app"))), "html", null, true);
            echo "</div>
";
        }
        // line 151
        echo "
";
        // line 152
        if ((isset($context["initJs"]) || array_key_exists("initJs", $context) ? $context["initJs"] : (function () { throw new RuntimeError('Variable "initJs" does not exist.', 152, $this->source); })())) {
            // line 153
            echo "    ";
            $context["jsId"] = twig_escape_filter($this->env, call_user_func_array($this->env->getFilter('namespaceInputId')->getCallable(), [(isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 153, $this->source); })())]), "js");
            // line 154
            echo "    ";
            $context["jsName"] = twig_escape_filter($this->env, call_user_func_array($this->env->getFilter('namespaceInputName')->getCallable(), [(isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 154, $this->source); })())]), "js");
            // line 155
            echo "    ";
            $context["jsCols"] = $this->extensions['craft\web\twig\Extension']->jsonEncodeFilter((isset($context["cols"]) || array_key_exists("cols", $context) ? $context["cols"] : (function () { throw new RuntimeError('Variable "cols" does not exist.', 155, $this->source); })()));
            // line 156
            echo "    ";
            $context["defaultValues"] = (($context["defaultValues"]) ?? (null));
            // line 157
            echo "    ";
            ob_start();
            // line 158
            echo "        new Craft.EditableTable(\"";
            echo twig_escape_filter($this->env, (isset($context["jsId"]) || array_key_exists("jsId", $context) ? $context["jsId"] : (function () { throw new RuntimeError('Variable "jsId" does not exist.', 158, $this->source); })()), "html", null, true);
            echo "\", \"";
            echo twig_escape_filter($this->env, (isset($context["jsName"]) || array_key_exists("jsName", $context) ? $context["jsName"] : (function () { throw new RuntimeError('Variable "jsName" does not exist.', 158, $this->source); })()), "html", null, true);
            echo "\", ";
            echo (isset($context["jsCols"]) || array_key_exists("jsCols", $context) ? $context["jsCols"] : (function () { throw new RuntimeError('Variable "jsCols" does not exist.', 158, $this->source); })());
            echo ", {
            defaultValues: ";
            // line 159
            echo (((isset($context["defaultValues"]) || array_key_exists("defaultValues", $context) ? $context["defaultValues"] : (function () { throw new RuntimeError('Variable "defaultValues" does not exist.', 159, $this->source); })())) ? ($this->extensions['craft\web\twig\Extension']->jsonEncodeFilter((isset($context["defaultValues"]) || array_key_exists("defaultValues", $context) ? $context["defaultValues"] : (function () { throw new RuntimeError('Variable "defaultValues" does not exist.', 159, $this->source); })()))) : ("{}"));
            echo ",
            staticRows: ";
            // line 160
            echo (((isset($context["staticRows"]) || array_key_exists("staticRows", $context) ? $context["staticRows"] : (function () { throw new RuntimeError('Variable "staticRows" does not exist.', 160, $this->source); })())) ? ("true") : ("false"));
            echo ",
            minRows: ";
            // line 161
            (((isset($context["minRows"]) || array_key_exists("minRows", $context) ? $context["minRows"] : (function () { throw new RuntimeError('Variable "minRows" does not exist.', 161, $this->source); })())) ? (print (twig_escape_filter($this->env, (isset($context["minRows"]) || array_key_exists("minRows", $context) ? $context["minRows"] : (function () { throw new RuntimeError('Variable "minRows" does not exist.', 161, $this->source); })()), "html", null, true))) : (print ("null")));
            echo ",
            maxRows: ";
            // line 162
            (((isset($context["maxRows"]) || array_key_exists("maxRows", $context) ? $context["maxRows"] : (function () { throw new RuntimeError('Variable "maxRows" does not exist.', 162, $this->source); })())) ? (print (twig_escape_filter($this->env, (isset($context["maxRows"]) || array_key_exists("maxRows", $context) ? $context["maxRows"] : (function () { throw new RuntimeError('Variable "maxRows" does not exist.', 162, $this->source); })()), "html", null, true))) : (print ("null")));
            echo "
        });
    ";
            Craft::$app->getView()->registerJs(ob_get_clean(), 3);
        }
        // line 0
        craft\helpers\Template::endProfile("template", "_includes/forms/editableTable");
    }

    // line 68
    public function block_tablecell($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("block", "tablecell");
        // line 69
        switch (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["col"]) || array_key_exists("col", $context) ? $context["col"] : (function () { throw new RuntimeError('Variable "col" does not exist.', 69, $this->source); })()), "type", [])) {
            case "checkbox":
            {
                // line 71
                echo "<div class=\"checkbox-wrapper\">
                                            ";
                // line 72
                $this->loadTemplate("_includes/forms/checkbox", "_includes/forms/editableTable", 72)->display(twig_to_array(["name" =>                 // line 73
(isset($context["cellName"]) || array_key_exists("cellName", $context) ? $context["cellName"] : (function () { throw new RuntimeError('Variable "cellName" does not exist.', 73, $this->source); })()), "value" => (((craft\helpers\Template::attribute($this->env, $this->source,                 // line 74
($context["col"] ?? null), "value", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["col"] ?? null), "value", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["col"] ?? null), "value", [])) : (1)), "checked" =>  !twig_test_empty(                // line 75
(isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 75, $this->source); })())), "disabled" =>                 // line 76
(isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new RuntimeError('Variable "static" does not exist.', 76, $this->source); })())]));
                // line 78
                echo "                                        </div>";
                break;
            }
            case "color":
            {
                // line 80
                $this->loadTemplate("_includes/forms/color", "_includes/forms/editableTable", 80)->display(twig_to_array(["name" =>                 // line 81
(isset($context["cellName"]) || array_key_exists("cellName", $context) ? $context["cellName"] : (function () { throw new RuntimeError('Variable "cellName" does not exist.', 81, $this->source); })()), "value" =>                 // line 82
(isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 82, $this->source); })()), "small" => true, "disabled" =>                 // line 84
(isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new RuntimeError('Variable "static" does not exist.', 84, $this->source); })())]));
                break;
            }
            case "date":
            {
                // line 87
                $this->loadTemplate("_includes/forms/date", "_includes/forms/editableTable", 87)->display(twig_to_array(["name" =>                 // line 88
(isset($context["cellName"]) || array_key_exists("cellName", $context) ? $context["cellName"] : (function () { throw new RuntimeError('Variable "cellName" does not exist.', 88, $this->source); })()), "value" =>                 // line 89
(isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 89, $this->source); })()), "disabled" =>                 // line 90
(isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new RuntimeError('Variable "static" does not exist.', 90, $this->source); })())]));
                break;
            }
            case "lightswitch":
            {
                // line 93
                $this->loadTemplate("_includes/forms/lightswitch", "_includes/forms/editableTable", 93)->display(twig_to_array(["name" =>                 // line 94
(isset($context["cellName"]) || array_key_exists("cellName", $context) ? $context["cellName"] : (function () { throw new RuntimeError('Variable "cellName" does not exist.', 94, $this->source); })()), "on" =>                 // line 95
(isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 95, $this->source); })()), "value" => (((craft\helpers\Template::attribute($this->env, $this->source,                 // line 96
($context["col"] ?? null), "value", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["col"] ?? null), "value", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["col"] ?? null), "value", [])) : (1)), "small" => true, "disabled" =>                 // line 98
(isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new RuntimeError('Variable "static" does not exist.', 98, $this->source); })())]));
                // line 100
                echo "                                    ";
                break;
            }
            case "select":
            {
                // line 101
                $this->loadTemplate("_includes/forms/select", "_includes/forms/editableTable", 101)->display(twig_to_array(["class" => "small", "name" =>                 // line 103
(isset($context["cellName"]) || array_key_exists("cellName", $context) ? $context["cellName"] : (function () { throw new RuntimeError('Variable "cellName" does not exist.', 103, $this->source); })()), "options" => (((craft\helpers\Template::attribute($this->env, $this->source,                 // line 104
($context["cell"] ?? null), "options", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["cell"] ?? null), "options", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["cell"] ?? null), "options", [])) : (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["col"]) || array_key_exists("col", $context) ? $context["col"] : (function () { throw new RuntimeError('Variable "col" does not exist.', 104, $this->source); })()), "options", []))), "value" =>                 // line 105
(isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 105, $this->source); })()), "disabled" =>                 // line 106
(isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new RuntimeError('Variable "static" does not exist.', 106, $this->source); })())]));
                break;
            }
            case "time":
            {
                // line 109
                $this->loadTemplate("_includes/forms/time", "_includes/forms/editableTable", 109)->display(twig_to_array(["name" =>                 // line 110
(isset($context["cellName"]) || array_key_exists("cellName", $context) ? $context["cellName"] : (function () { throw new RuntimeError('Variable "cellName" does not exist.', 110, $this->source); })()), "value" =>                 // line 111
(isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 111, $this->source); })()), "disabled" =>                 // line 112
(isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new RuntimeError('Variable "static" does not exist.', 112, $this->source); })())]));
                break;
            }
            case "email":
            case "url":
            {
                // line 115
                $this->loadTemplate("_includes/forms/text", "_includes/forms/editableTable", 115)->display(twig_to_array(["type" => craft\helpers\Template::attribute($this->env, $this->source,                 // line 116
(isset($context["col"]) || array_key_exists("col", $context) ? $context["col"] : (function () { throw new RuntimeError('Variable "col" does not exist.', 116, $this->source); })()), "type", []), "name" =>                 // line 117
(isset($context["cellName"]) || array_key_exists("cellName", $context) ? $context["cellName"] : (function () { throw new RuntimeError('Variable "cellName" does not exist.', 117, $this->source); })()), "placeholder" => (((craft\helpers\Template::attribute($this->env, $this->source,                 // line 118
($context["col"] ?? null), "placeholder", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["col"] ?? null), "placeholder", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["col"] ?? null), "placeholder", [])) : (null)), "value" =>                 // line 119
(isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 119, $this->source); })()), "disabled" =>                 // line 120
(isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new RuntimeError('Variable "static" does not exist.', 120, $this->source); })())]));
                break;
            }
            case "template":
            {
                // line 123
                $this->loadTemplate("_includes/forms/autosuggest", "_includes/forms/editableTable", 123)->display(twig_to_array(["name" =>                 // line 124
(isset($context["cellName"]) || array_key_exists("cellName", $context) ? $context["cellName"] : (function () { throw new RuntimeError('Variable "cellName" does not exist.', 124, $this->source); })()), "suggestions" => craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source,                 // line 125
(isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 125, $this->source); })()), "cp", []), "getTemplateSuggestions", [], "method"), "value" =>                 // line 126
(isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 126, $this->source); })()), "disabled" =>                 // line 127
(isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new RuntimeError('Variable "static" does not exist.', 127, $this->source); })())]));
                break;
            }
            default:
            {
                // line 130
                if ((isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new RuntimeError('Variable "static" does not exist.', 130, $this->source); })())) {
                    // line 131
                    echo "                                            <pre class=\"disabled\">";
                    echo twig_escape_filter($this->env, (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 131, $this->source); })()), "html", null, true);
                    echo "</pre>
                                        ";
                } else {
                    // line 133
                    echo "                                            <textarea name=\"";
                    echo twig_escape_filter($this->env, (isset($context["cellName"]) || array_key_exists("cellName", $context) ? $context["cellName"] : (function () { throw new RuntimeError('Variable "cellName" does not exist.', 133, $this->source); })()), "html", null, true);
                    echo "\" rows=\"1\"";
                    if (craft\helpers\Template::attribute($this->env, $this->source, ($context["col"] ?? null), "placeholder", [], "any", true, true)) {
                        echo " placeholder=\"";
                        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["col"]) || array_key_exists("col", $context) ? $context["col"] : (function () { throw new RuntimeError('Variable "col" does not exist.', 133, $this->source); })()), "placeholder", []), "html", null, true);
                        echo "\"";
                    }
                    echo ">";
                    echo twig_escape_filter($this->env, (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 133, $this->source); })()), "html", null, true);
                    echo "</textarea>
                                        ";
                }
            }
        }
        // line 0
        craft\helpers\Template::endProfile("block", "tablecell");
    }

    // line 15
    public function macro_cellClass($__fullWidth__ = null, $__col__ = null, $__class__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "fullWidth" => $__fullWidth__,
            "col" => $__col__,
            "class" => $__class__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            // line 0
            craft\helpers\Template::beginProfile("macro", "cellClass");
            // line 16
            echo twig_escape_filter($this->env, twig_join_filter($this->extensions['craft\web\twig\Extension']->mergeFilter(((twig_test_iterable((isset($context["class"]) || array_key_exists("class", $context) ? $context["class"] : (function () { throw new RuntimeError('Variable "class" does not exist.', 16, $this->source); })()))) ? ((isset($context["class"]) || array_key_exists("class", $context) ? $context["class"] : (function () { throw new RuntimeError('Variable "class" does not exist.', 16, $this->source); })())) : ([0 => (isset($context["class"]) || array_key_exists("class", $context) ? $context["class"] : (function () { throw new RuntimeError('Variable "class" does not exist.', 16, $this->source); })())])), $this->extensions['craft\web\twig\Extension']->filterFilter([0 => (craft\helpers\Template::attribute($this->env, $this->source,             // line 17
(isset($context["col"]) || array_key_exists("col", $context) ? $context["col"] : (function () { throw new RuntimeError('Variable "col" does not exist.', 17, $this->source); })()), "type", []) . "-cell"), 1 => ((twig_in_filter(craft\helpers\Template::attribute($this->env, $this->source,             // line 18
(isset($context["col"]) || array_key_exists("col", $context) ? $context["col"] : (function () { throw new RuntimeError('Variable "col" does not exist.', 18, $this->source); })()), "type", []), [0 => "color", 1 => "date", 2 => "email", 3 => "multiline", 4 => "number", 5 => "singleline", 6 => "template", 7 => "time", 8 => "url"])) ? ("textual") : ("")), 2 => (((            // line 19
(isset($context["fullWidth"]) || array_key_exists("fullWidth", $context) ? $context["fullWidth"] : (function () { throw new RuntimeError('Variable "fullWidth" does not exist.', 19, $this->source); })()) && (((craft\helpers\Template::attribute($this->env, $this->source, ($context["col"] ?? null), "thin", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["col"] ?? null), "thin", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["col"] ?? null), "thin", [])) : (false)))) ? ("thin") : ("")), 3 => ((craft\helpers\Template::attribute($this->env, $this->source,             // line 20
($context["col"] ?? null), "info", [], "any", true, true)) ? ("has-info") : (""))])), " "), "html", null, true);
            // line 0
            craft\helpers\Template::endProfile("macro", "cellClass");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    public function getTemplateName()
    {
        return "_includes/forms/editableTable";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  492 => 0,  490 => 20,  489 => 19,  488 => 18,  487 => 17,  486 => 16,  484 => 0,  469 => 15,  465 => 0,  449 => 133,  443 => 131,  441 => 130,  435 => 127,  434 => 126,  433 => 125,  432 => 124,  431 => 123,  425 => 120,  424 => 119,  423 => 118,  422 => 117,  421 => 116,  420 => 115,  413 => 112,  412 => 111,  411 => 110,  410 => 109,  404 => 106,  403 => 105,  402 => 104,  401 => 103,  400 => 101,  394 => 100,  392 => 98,  391 => 96,  390 => 95,  389 => 94,  388 => 93,  382 => 90,  381 => 89,  380 => 88,  379 => 87,  373 => 84,  372 => 82,  371 => 81,  370 => 80,  364 => 78,  362 => 76,  361 => 75,  360 => 74,  359 => 73,  358 => 72,  355 => 71,  351 => 69,  349 => 0,  345 => 68,  341 => 0,  334 => 162,  330 => 161,  326 => 160,  322 => 159,  313 => 158,  310 => 157,  307 => 156,  304 => 155,  301 => 154,  298 => 153,  296 => 152,  293 => 151,  287 => 149,  285 => 148,  281 => 146,  274 => 144,  271 => 143,  265 => 142,  260 => 141,  257 => 140,  243 => 139,  239 => 137,  237 => 68,  218 => 67,  215 => 66,  212 => 65,  209 => 64,  201 => 62,  199 => 61,  192 => 60,  189 => 59,  186 => 58,  183 => 57,  166 => 56,  161 => 55,  157 => 54,  152 => 51,  146 => 49,  143 => 48,  136 => 46,  131 => 44,  129 => 43,  126 => 41,  123 => 39,  121 => 38,  119 => 37,  117 => 36,  113 => 35,  108 => 33,  102 => 31,  98 => 29,  94 => 28,  85 => 25,  75 => 24,  72 => 23,  69 => 14,  63 => 12,  61 => 11,  58 => 10,  56 => 9,  54 => 8,  52 => 7,  50 => 6,  48 => 5,  46 => 4,  44 => 3,  42 => 2,  40 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{%- set static = static ?? false %}
{%- set fullWidth = fullWidth ?? true %}
{%- set cols = cols ?? [] %}
{%- set rows = rows ?? [] %}
{%- set initJs = not static and (initJs ?? true) -%}
{%- set minRows = minRows ?? null %}
{%- set maxRows = maxRows ?? null %}
{%- set staticRows = static or (staticRows ?? false) or (minRows == 1 and maxRows == 1 and rows|length == 1) %}
{%- set fixedRows = not staticRows and (minRows and minRows == maxRows and minRows == rows|length) %}

{% if not static %}
    {{ hiddenInput(name, '') }}
{% endif %}

{% macro cellClass(fullWidth, col, class) %}
    {{- (class is iterable ? class : [class])|merge([
        \"#{col.type}-cell\",
        col.type in ['color', 'date', 'email', 'multiline', 'number', 'singleline', 'template', 'time', 'url'] ? 'textual',
        fullWidth and (col.thin ?? false) ? 'thin',
        col.info is defined ? 'has-info',
    ]|filter)|join(' ') -}}
{% endmacro %}

<table id=\"{{ id }}\" class=\"editable{% if fullWidth %} fullwidth{% endif %}{% if static %} static{% endif %}\"
       {%- if block('attr') is defined %} {{ block('attr') }}{% endif %}>
    <thead>
        <tr>
            {% for col in cols %}
                {%- switch col.type %}
                    {%- case 'time' %}
                        {%- do view.registerAssetBundle('craft\\\\web\\\\assets\\\\timepicker\\\\TimepickerAsset') %}
                    {%- case 'template' %}
                        {%- do view.registerAssetBundle(\"craft\\\\web\\\\assets\\\\vue\\\\VueAsset\") %}
                {%- endswitch %}
                <th scope=\"col\" class=\"{{ _self.cellClass(fullWidth, col, col.class ?? []) }}\">
                    {%- if col.headingHtml is defined %}
                        {{- col.headingHtml|raw }}
                    {%- elseif col.heading is defined and col.heading %}
                        {{- col.heading }}
                    {%- else %}
                        &nbsp;
                    {%- endif %}
                    {%- if col.info is defined -%}
                        <span class=\"info\">{{ col.info|md|raw }}</span>
                    {%- endif -%}
                </th>
            {% endfor %}
            {% if not staticRows %}
                <th colspan=\"{{ fixedRows ? 1 : 2 }}\"></th>
            {% endif %}
        </tr>
    </thead>
    <tbody>
        {% for rowId, row in rows %}
            <tr data-id=\"{{ rowId }}\">
                {% for colId, col in cols %}
                    {% set cell = row[colId] is defined ? row[colId] : (defaultValues[colId] ?? null) %}
                    {% set value = cell.value is defined ? cell.value : cell %}
                    {% if col.type == 'heading' %}
                        <th scope=\"row\" class=\"{{ _self.cellClass(fullWidth, col, cell.class ?? col.class ?? []) }}\">{{ value|raw }}</th>
                    {% elseif col.type == 'html' %}
                        <td class=\"{{ _self.cellClass(fullWidth, col, cell.class ?? col.class ?? []) }}\">{{ value|raw }}</td>
                    {% else %}
                        {% set hasErrors = cell.hasErrors ?? false %}
                        {% set cellName = name~'['~rowId~']['~colId~']' %}
                        {% set isCode = col.code is defined or col.type == 'color' %}
                        <td class=\"{{ _self.cellClass(fullWidth, col, col.class ?? []) }} {% if isCode %}code{% endif %} {% if hasErrors %}error{% endif %}\"{% if col.width ?? false %} width=\"{{ col.width }}\"{% endif %}>
                            {% block tablecell %}
                                {%- switch col.type -%}
                                    {%- case 'checkbox' -%}
                                        <div class=\"checkbox-wrapper\">
                                            {% include \"_includes/forms/checkbox\" with {
                                                name: cellName,
                                                value:  col.value ?? 1,
                                                checked: value is not empty,
                                                disabled: static
                                            } only %}
                                        </div>
                                    {%- case 'color' -%}
                                        {% include \"_includes/forms/color\" with {
                                            name: cellName,
                                            value: value,
                                            small: true,
                                            disabled: static
                                        } only %}
                                    {%- case 'date' -%}
                                        {% include \"_includes/forms/date\" with {
                                            name: cellName,
                                            value: value,
                                            disabled: static
                                        } only %}
                                    {%- case 'lightswitch' -%}
                                        {% include \"_includes/forms/lightswitch\" with {
                                            name: cellName,
                                            on: value,
                                            value: col.value ?? 1,
                                            small: true,
                                            disabled: static
                                        } only %}
                                    {% case 'select' -%}
                                        {% include \"_includes/forms/select\" with {
                                            class: 'small',
                                            name: cellName,
                                            options: cell.options ?? col.options,
                                            value: value,
                                            disabled: static
                                        } only %}
                                    {%- case 'time' -%}
                                        {% include \"_includes/forms/time\" with {
                                            name: cellName,
                                            value: value,
                                            disabled: static
                                        } only %}
                                    {%- case 'email' or 'url' -%}
                                        {% include \"_includes/forms/text\" with {
                                            type: col.type,
                                            name: cellName,
                                            placeholder: col.placeholder ?? null,
                                            value:  value,
                                            disabled: static
                                        } only %}
                                    {%- case 'template' -%}
                                        {% include \"_includes/forms/autosuggest\" with {
                                            name: cellName,
                                            suggestions: craft.cp.getTemplateSuggestions(),
                                            value: value,
                                            disabled: static
                                        } only %}
                                    {%- default -%}
                                        {% if static %}
                                            <pre class=\"disabled\">{{ value }}</pre>
                                        {% else %}
                                            <textarea name=\"{{ cellName }}\" rows=\"1\"{% if col.placeholder is defined %} placeholder=\"{{ col.placeholder }}\"{% endif %}>{{ value }}</textarea>
                                        {% endif %}
                                {%- endswitch -%}
                            {% endblock %}
                        </td>
                    {% endif %}
                {% endfor %}
                {% if not staticRows %}
                    <td class=\"thin action\"><a class=\"move icon\" title=\"{{ 'Reorder'|t('app') }}\"></a></td>
                    {% if not fixedRows %}<td class=\"thin action\"><a class=\"delete icon\" title=\"{{ 'Delete'|t('app') }}\"></a></td>{% endif %}
                {% endif %}
            </tr>
        {% endfor %}
    </tbody>
</table>
{% if not staticRows and not fixedRows %}
    <div class=\"btn add icon\">{{ addRowLabel is defined ? addRowLabel : \"Add a row\"|t('app') }}</div>
{% endif %}

{% if initJs %}
    {% set jsId = id|namespaceInputId|e('js') %}
    {% set jsName = name|namespaceInputName|e('js') %}
    {% set jsCols = cols|json_encode %}
    {% set defaultValues = defaultValues ?? null %}
    {% js %}
        new Craft.EditableTable(\"{{ jsId }}\", \"{{ jsName }}\", {{ jsCols|raw }}, {
            defaultValues: {{ defaultValues ? defaultValues|json_encode|raw : '{}' }},
            staticRows: {{ staticRows ? 'true' : 'false' }},
            minRows: {{ minRows ? minRows : 'null' }},
            maxRows: {{ maxRows ? maxRows : 'null' }}
        });
    {% endjs %}
{% endif %}
", "_includes/forms/editableTable", "/Applications/MAMP/htdocs/craft/smsi/vendor/craftcms/cms/src/templates/_includes/forms/editableTable.html");
    }
}
