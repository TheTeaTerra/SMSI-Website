<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* settings/users/settings */
class __TwigTemplate_426e8fb71ba1339d691283a38c36b8c89564f190513deddcca4a3b34c5d40213 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 3
        return "settings/users/_layout";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("template", "settings/users/settings");
        // line 1
        Craft::$app->controller->requireAdmin();
        // line 4
        $context["selectedNavItem"] = "settings";
        // line 6
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms", "settings/users/settings", 6)->unwrap();
        // line 9
        if ( !(isset($context["settings"]) || array_key_exists("settings", $context))) {
            // line 10
            $context["settings"] = (((craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, ($context["craft"] ?? null), "app", [], "any", false, true), "projectConfig", [], "any", false, true), "get", [0 => "users"], "method", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, ($context["craft"] ?? null), "app", [], "any", false, true), "projectConfig", [], "any", false, true), "get", [0 => "users"], "method")))) ? (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, ($context["craft"] ?? null), "app", [], "any", false, true), "projectConfig", [], "any", false, true), "get", [0 => "users"], "method")) : ([]));
        }
        // line 14
        $context["settings"] = $this->extensions['craft\web\twig\Extension']->mergeFilter(["photoVolumeUid" => null, "photoSubpath" => null, "requireEmailVerification" => true, "allowPublicRegistration" => false, "defaultGroup" => null],         // line 20
(isset($context["settings"]) || array_key_exists("settings", $context) ? $context["settings"] : (function () { throw new RuntimeError('Variable "settings" does not exist.', 20, $this->source); })()));
        // line 22
        $context["allVolumes"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 22, $this->source); })()), "app", []), "volumes", []), "getAllVolumes", [], "method");
        // line 23
        $context["volumeList"] = [];
        // line 24
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["allVolumes"]) || array_key_exists("allVolumes", $context) ? $context["allVolumes"] : (function () { throw new RuntimeError('Variable "allVolumes" does not exist.', 24, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["volume"]) {
            // line 25
            $context["volumeList"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["volumeList"]) || array_key_exists("volumeList", $context) ? $context["volumeList"] : (function () { throw new RuntimeError('Variable "volumeList" does not exist.', 25, $this->source); })()), [0 => ["value" => craft\helpers\Template::attribute($this->env, $this->source, $context["volume"], "uid", []), "label" => craft\helpers\Template::attribute($this->env, $this->source, $context["volume"], "name", [])]]);
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['volume'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 51
        $macros["__internal_7126ff43f714600d6baa45375da4ef64da9379b72d7af39b469315ce21e945b4"] = $this->macros["__internal_7126ff43f714600d6baa45375da4ef64da9379b72d7af39b469315ce21e945b4"] = $this;
        // line 3
        $this->parent = $this->loadTemplate("settings/users/_layout", "settings/users/settings", 3);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        // line 0
        craft\helpers\Template::endProfile("template", "settings/users/settings");
    }

    // line 53
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("block", "content");
        // line 54
        echo "    <form id=\"settings-form\" method=\"post\" class=\"centered\" accept-charset=\"UTF-8\" data-saveshortcut>
        ";
        // line 55
        echo craft\helpers\Html::actionInput("user-settings/save-user-settings");
        echo "
        ";
        // line 56
        echo craft\helpers\Html::csrfInput();
        echo "

        ";
        // line 58
        if ((isset($context["volumeList"]) || array_key_exists("volumeList", $context) ? $context["volumeList"] : (function () { throw new RuntimeError('Variable "volumeList" does not exist.', 58, $this->source); })())) {
            // line 59
            echo "            ";
            echo twig_call_macro($macros["forms"], "macro_field", [["first" => true, "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("User Photo Location", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Where do you want to store user photos? Note that the subfolder path can contain variables like <code>{username}</code>.", "app")], twig_call_macro($macros["__internal_7126ff43f714600d6baa45375da4ef64da9379b72d7af39b469315ce21e945b4"], "macro_assetLocationInput", [            // line 63
(isset($context["volumeList"]) || array_key_exists("volumeList", $context) ? $context["volumeList"] : (function () { throw new RuntimeError('Variable "volumeList" does not exist.', 63, $this->source); })()), craft\helpers\Template::attribute($this->env, $this->source, (isset($context["settings"]) || array_key_exists("settings", $context) ? $context["settings"] : (function () { throw new RuntimeError('Variable "settings" does not exist.', 63, $this->source); })()), "photoVolumeUid", []), craft\helpers\Template::attribute($this->env, $this->source, (isset($context["settings"]) || array_key_exists("settings", $context) ? $context["settings"] : (function () { throw new RuntimeError('Variable "settings" does not exist.', 63, $this->source); })()), "photoSubpath", [])], 63, $context, $this->getSourceContext())], 59, $context, $this->getSourceContext());
            echo "
        ";
        } else {
            // line 65
            echo "            ";
            echo twig_call_macro($macros["forms"], "macro_field", [["first" => true, "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("User Photo Volume", "app")], (("<p class=\"error\">" . $this->extensions['craft\web\twig\Extension']->translateFilter("No volumes exist yet.", "app")) . "</p>")], 65, $context, $this->getSourceContext());
            // line 68
            echo "
        ";
        }
        // line 70
        echo "
        ";
        // line 71
        if (((isset($context["CraftEdition"]) || array_key_exists("CraftEdition", $context) ? $context["CraftEdition"] : (function () { throw new RuntimeError('Variable "CraftEdition" does not exist.', 71, $this->source); })()) == (isset($context["CraftPro"]) || array_key_exists("CraftPro", $context) ? $context["CraftPro"] : (function () { throw new RuntimeError('Variable "CraftPro" does not exist.', 71, $this->source); })()))) {
            // line 72
            echo "            ";
            echo twig_call_macro($macros["forms"], "macro_checkboxField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Verify email addresses?", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Should new email addresses be verified before getting saved to user accounts? (This also affects new user registration.)", "app"), "name" => "requireEmailVerification", "checked" => craft\helpers\Template::attribute($this->env, $this->source,             // line 76
(isset($context["settings"]) || array_key_exists("settings", $context) ? $context["settings"] : (function () { throw new RuntimeError('Variable "settings" does not exist.', 76, $this->source); })()), "requireEmailVerification", [])]], 72, $context, $this->getSourceContext());
            // line 77
            echo "

            ";
            // line 79
            echo twig_call_macro($macros["forms"], "macro_checkboxField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Allow public registration?", "app"), "name" => "allowPublicRegistration", "checked" => craft\helpers\Template::attribute($this->env, $this->source,             // line 82
(isset($context["settings"]) || array_key_exists("settings", $context) ? $context["settings"] : (function () { throw new RuntimeError('Variable "settings" does not exist.', 82, $this->source); })()), "allowPublicRegistration", []), "toggle" => "publicRegistrationSettings"]], 79, $context, $this->getSourceContext());
            // line 84
            echo "

            <div id=\"publicRegistrationSettings\" class=\"nested-fields";
            // line 86
            if ( !craft\helpers\Template::attribute($this->env, $this->source, (isset($context["settings"]) || array_key_exists("settings", $context) ? $context["settings"] : (function () { throw new RuntimeError('Variable "settings" does not exist.', 86, $this->source); })()), "allowPublicRegistration", [])) {
                echo " hidden";
            }
            echo "\">
                ";
            // line 87
            $context["groups"] = [0 => ["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("None", "app"), "value" => ""]];
            // line 88
            echo "                ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 88, $this->source); })()), "app", []), "userGroups", []), "getAllGroups", [], "method"));
            foreach ($context['_seq'] as $context["_key"] => $context["group"]) {
                // line 89
                echo "                    ";
                $context["groups"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["groups"]) || array_key_exists("groups", $context) ? $context["groups"] : (function () { throw new RuntimeError('Variable "groups" does not exist.', 89, $this->source); })()), [0 => ["label" => craft\helpers\Template::attribute($this->env, $this->source, $context["group"], "name", []), "value" => craft\helpers\Template::attribute($this->env, $this->source, $context["group"], "uid", [])]]);
                // line 90
                echo "                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['group'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 91
            echo "
                ";
            // line 92
            echo twig_call_macro($macros["forms"], "macro_selectField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Default User Group", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Choose a user group that publicly-registered members will be added to by default.", "app"), "name" => "defaultGroup", "options" =>             // line 96
(isset($context["groups"]) || array_key_exists("groups", $context) ? $context["groups"] : (function () { throw new RuntimeError('Variable "groups" does not exist.', 96, $this->source); })()), "value" => craft\helpers\Template::attribute($this->env, $this->source,             // line 97
(isset($context["settings"]) || array_key_exists("settings", $context) ? $context["settings"] : (function () { throw new RuntimeError('Variable "settings" does not exist.', 97, $this->source); })()), "defaultGroup", [])]], 92, $context, $this->getSourceContext());
            // line 98
            echo "
            </div>
        ";
        }
        // line 101
        echo "
        <div class=\"buttons\">
            <input type=\"submit\" class=\"btn submit\" value=\"";
        // line 103
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Save", "app"), "html", null, true);
        echo "\">
        </div>
    </form>
";
        // line 0
        craft\helpers\Template::endProfile("block", "content");
    }

    // line 28
    public function macro_assetLocationInput($__volumeOptions__ = null, $__volumeUid__ = null, $__subpath__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "volumeOptions" => $__volumeOptions__,
            "volumeUid" => $__volumeUid__,
            "subpath" => $__subpath__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            // line 0
            craft\helpers\Template::beginProfile("macro", "assetLocationInput");
            // line 29
            echo "    ";
            $macros["__internal_96c6007a54ccb5c528dac4a08f1a5d4d69f7455aeff23be486e157b7eddf5a76"] = $this->loadTemplate("_includes/forms", "settings/users/settings", 29)->unwrap();
            // line 30
            echo "    <div class=\"flex\">
        <div>
            ";
            // line 32
            echo twig_call_macro($macros["__internal_96c6007a54ccb5c528dac4a08f1a5d4d69f7455aeff23be486e157b7eddf5a76"], "macro_select", [["id" => "photoVolumeUid", "name" => "photoVolumeUid", "options" =>             // line 35
(isset($context["volumeOptions"]) || array_key_exists("volumeOptions", $context) ? $context["volumeOptions"] : (function () { throw new RuntimeError('Variable "volumeOptions" does not exist.', 35, $this->source); })()), "value" =>             // line 36
(isset($context["volumeUid"]) || array_key_exists("volumeUid", $context) ? $context["volumeUid"] : (function () { throw new RuntimeError('Variable "volumeUid" does not exist.', 36, $this->source); })())]], 32, $context, $this->getSourceContext());
            // line 37
            echo "
        </div>
        <div class=\"flex-grow\">
            ";
            // line 40
            echo twig_call_macro($macros["__internal_96c6007a54ccb5c528dac4a08f1a5d4d69f7455aeff23be486e157b7eddf5a76"], "macro_text", [["id" => "photoSubpath", "class" => "ltr", "name" => "photoSubpath", "value" =>             // line 44
(isset($context["subpath"]) || array_key_exists("subpath", $context) ? $context["subpath"] : (function () { throw new RuntimeError('Variable "subpath" does not exist.', 44, $this->source); })()), "placeholder" => $this->extensions['craft\web\twig\Extension']->translateFilter("path/to/subfolder", "app")]], 40, $context, $this->getSourceContext());
            // line 46
            echo "
        </div>
    </div>
";
            // line 0
            craft\helpers\Template::endProfile("macro", "assetLocationInput");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    public function getTemplateName()
    {
        return "settings/users/settings";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  224 => 0,  219 => 46,  217 => 44,  216 => 40,  211 => 37,  209 => 36,  208 => 35,  207 => 32,  203 => 30,  200 => 29,  198 => 0,  183 => 28,  179 => 0,  173 => 103,  169 => 101,  164 => 98,  162 => 97,  161 => 96,  160 => 92,  157 => 91,  151 => 90,  148 => 89,  143 => 88,  141 => 87,  135 => 86,  131 => 84,  129 => 82,  128 => 79,  124 => 77,  122 => 76,  120 => 72,  118 => 71,  115 => 70,  111 => 68,  108 => 65,  103 => 63,  101 => 59,  99 => 58,  94 => 56,  90 => 55,  87 => 54,  85 => 0,  81 => 53,  77 => 0,  74 => 3,  72 => 51,  66 => 25,  62 => 24,  60 => 23,  58 => 22,  56 => 20,  55 => 14,  52 => 10,  50 => 9,  48 => 6,  46 => 4,  44 => 1,  42 => 0,  35 => 3,);
    }

    public function getSourceContext()
    {
        return new Source("{% requireAdmin %}

{% extends \"settings/users/_layout\" %}
{% set selectedNavItem = 'settings' %}

{% import \"_includes/forms\" as forms %}


{% if settings is not defined %}
    {% set settings = craft.app.projectConfig.get('users') ?? [] %}
{% endif %}

{# set defaults #}
{% set settings = {
    photoVolumeUid: null,
    photoSubpath: null,
    requireEmailVerification: true,
    allowPublicRegistration: false,
    defaultGroup: null,
}|merge(settings) %}

{% set allVolumes = craft.app.volumes.getAllVolumes() %}
{% set volumeList = [] %}
{% for volume in allVolumes %}
    {% set volumeList = volumeList|merge([{'value': volume.uid, 'label': volume.name}]) %}
{% endfor %}

{% macro assetLocationInput(volumeOptions, volumeUid, subpath) %}
    {% from \"_includes/forms\" import select, text %}
    <div class=\"flex\">
        <div>
            {{ select({
                id: 'photoVolumeUid',
                name: 'photoVolumeUid',
                options: volumeOptions,
                value: volumeUid,
            }) }}
        </div>
        <div class=\"flex-grow\">
            {{ text({
                id: 'photoSubpath',
                class: 'ltr',
                name: 'photoSubpath',
                value: subpath,
                placeholder: \"path/to/subfolder\"|t('app')
            }) }}
        </div>
    </div>
{% endmacro %}

{% from _self import assetLocationInput %}

{% block content %}
    <form id=\"settings-form\" method=\"post\" class=\"centered\" accept-charset=\"UTF-8\" data-saveshortcut>
        {{ actionInput('user-settings/save-user-settings') }}
        {{ csrfInput() }}

        {% if volumeList %}
            {{ forms.field({
                first: true,
                label: \"User Photo Location\"|t('app'),
                instructions: \"Where do you want to store user photos? Note that the subfolder path can contain variables like <code>{username}</code>.\"|t('app')
            }, assetLocationInput(volumeList, settings.photoVolumeUid, settings.photoSubpath)) }}
        {% else %}
            {{ forms.field({
                first: true,
                label: \"User Photo Volume\"|t('app')
            }, '<p class=\"error\">' ~ \"No volumes exist yet.\"|t('app') ~ '</p>') }}
        {% endif %}

        {% if CraftEdition == CraftPro %}
            {{ forms.checkboxField({
                label: \"Verify email addresses?\"|t('app'),
                instructions: \"Should new email addresses be verified before getting saved to user accounts? (This also affects new user registration.)\"|t('app'),
                name: 'requireEmailVerification',
                checked: settings.requireEmailVerification,
            }) }}

            {{ forms.checkboxField({
                label: \"Allow public registration?\"|t('app'),
                name: 'allowPublicRegistration',
                checked: settings.allowPublicRegistration,
                toggle: 'publicRegistrationSettings'
            }) }}

            <div id=\"publicRegistrationSettings\" class=\"nested-fields{% if not settings.allowPublicRegistration %} hidden{% endif %}\">
                {% set groups = [{ label: \"None\"|t('app'), value: '' }] %}
                {% for group in craft.app.userGroups.getAllGroups() %}
                    {% set groups = groups|merge([{ label: group.name, value: group.uid }]) %}
                {% endfor %}

                {{ forms.selectField({
                    label: \"Default User Group\"|t('app'),
                    instructions: \"Choose a user group that publicly-registered members will be added to by default.\"|t('app'),
                    name: 'defaultGroup',
                    options: groups,
                    value: settings.defaultGroup
                }) }}
            </div>
        {% endif %}

        <div class=\"buttons\">
            <input type=\"submit\" class=\"btn submit\" value=\"{{ 'Save'|t('app') }}\">
        </div>
    </form>
{% endblock %}
", "settings/users/settings", "/Applications/MAMP/htdocs/craft/smsi/vendor/craftcms/cms/src/templates/settings/users/settings.html");
    }
}
