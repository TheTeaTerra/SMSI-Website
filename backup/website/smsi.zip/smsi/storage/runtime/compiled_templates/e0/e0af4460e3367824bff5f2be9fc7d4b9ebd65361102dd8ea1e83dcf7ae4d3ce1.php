<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* entries/_titlefield */
class __TwigTemplate_7f469694cc22ab31892d57e0312e33514b3888dae93c95ac6bdc94de291addb2 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "entries/_titlefield");
        // line 1
        $macros["__internal_c9ded1c610810094c187ea5cd79f8469e53f484916a41a50b2340d50abbfa86b"] = $this->macros["__internal_c9ded1c610810094c187ea5cd79f8469e53f484916a41a50b2340d50abbfa86b"] = $this->loadTemplate("_includes/forms", "entries/_titlefield", 1)->unwrap();
        // line 2
        $context["static"] = (((isset($context["static"]) || array_key_exists("static", $context))) ? ((isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new RuntimeError('Variable "static" does not exist.', 2, $this->source); })())) : (false));
        // line 3
        $context["entryType"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 3, $this->source); })()), "getType", [], "method");
        // line 4
        echo "
";
        // line 5
        echo twig_call_macro($macros["__internal_c9ded1c610810094c187ea5cd79f8469e53f484916a41a50b2340d50abbfa86b"], "macro_textField", [["status" => craft\helpers\Template::attribute($this->env, $this->source,         // line 6
(isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 6, $this->source); })()), "getAttributeStatus", [0 => "title"], "method"), "label" => ((twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source,         // line 7
(isset($context["entryType"]) || array_key_exists("entryType", $context) ? $context["entryType"] : (function () { throw new RuntimeError('Variable "entryType" does not exist.', 7, $this->source); })()), "titleLabel", []), "site"))) ? (twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entryType"]) || array_key_exists("entryType", $context) ? $context["entryType"] : (function () { throw new RuntimeError('Variable "entryType" does not exist.', 7, $this->source); })()), "titleLabel", []), "site"))) : ($this->extensions['craft\web\twig\Extension']->translateFilter("Title", "app"))), "siteId" => ((craft\helpers\Template::attribute($this->env, $this->source,         // line 8
(isset($context["entryType"]) || array_key_exists("entryType", $context) ? $context["entryType"] : (function () { throw new RuntimeError('Variable "entryType" does not exist.', 8, $this->source); })()), "hasTitleField", [])) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 8, $this->source); })()), "siteId", [])) : ("")), "translationDescription" => $this->extensions['craft\web\twig\Extension']->translateFilter("This field is translated for each site.", "app"), "id" => "title", "name" => "title", "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 12
(isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 12, $this->source); })()), "title", []), "errors" => (( !        // line 13
(isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new RuntimeError('Variable "static" does not exist.', 13, $this->source); })())) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (function () { throw new RuntimeError('Variable "entry" does not exist.', 13, $this->source); })()), "getErrors", [0 => "title"], "method")) : ("")), "first" => true, "autofocus" => true, "required" => ( !        // line 16
(isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new RuntimeError('Variable "static" does not exist.', 16, $this->source); })()) && craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entryType"]) || array_key_exists("entryType", $context) ? $context["entryType"] : (function () { throw new RuntimeError('Variable "entryType" does not exist.', 16, $this->source); })()), "hasTitleField", [])), "disabled" => (        // line 17
(isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new RuntimeError('Variable "static" does not exist.', 17, $this->source); })()) ||  !craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entryType"]) || array_key_exists("entryType", $context) ? $context["entryType"] : (function () { throw new RuntimeError('Variable "entryType" does not exist.', 17, $this->source); })()), "hasTitleField", [])), "maxlength" => 255]], 5, $context, $this->getSourceContext());
        // line 19
        echo "
";
        // line 0
        craft\helpers\Template::endProfile("template", "entries/_titlefield");
    }

    public function getTemplateName()
    {
        return "entries/_titlefield";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  59 => 0,  56 => 19,  54 => 17,  53 => 16,  52 => 13,  51 => 12,  50 => 8,  49 => 7,  48 => 6,  47 => 5,  44 => 4,  42 => 3,  40 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% from \"_includes/forms\" import textField %}
{% set static = static is defined ? static : false %}
{% set entryType = entry.getType() %}

{{ textField({
    status: entry.getAttributeStatus('title'),
    label: entryType.titleLabel|t('site')|e ?: 'Title'|t('app'),
    siteId: entryType.hasTitleField ? entry.siteId,
    translationDescription: 'This field is translated for each site.'|t('app'),
    id: 'title',
    name: 'title',
    value: entry.title,
    errors: (not static ? entry.getErrors('title')),
    first: true,
    autofocus: true,
    required: not static and entryType.hasTitleField,
    disabled: static or not entryType.hasTitleField,
    maxlength: 255
}) }}
", "entries/_titlefield", "/Applications/MAMP/htdocs/craft/smsi/vendor/craftcms/cms/src/templates/entries/_titlefield.html");
    }
}
