<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _partials/header */
class __TwigTemplate_a29f834e059f644d9e981fd40ee1b4d4ce139262975d8824effa9c6af871e33c extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_partials/header");
        // line 1
        $context["nav"] = ["home" => ["title" => "home"], "about" => ["title" => "about"], "services" => ["title" => "services"], "portfolio" => ["title" => "portfolio"], "contact" => ["title" => "contact"]];
        // line 8
        echo "
<header id=\"header\" class=\"fixed-top \">
  <div class=\"container-fluid\">

    <div class=\"row justify-content-center\">
      <div class=\"col-xl-9 d-flex align-items-center justify-content-between\">
        ";
        // line 15
        echo "        <!-- Uncomment below if you prefer to use an image logo -->
        <a href=\"index.html\" class=\"logo\"><img src=\"";
        // line 16
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["logo"]) || array_key_exists("logo", $context) ? $context["logo"] : (function () { throw new RuntimeError('Variable "logo" does not exist.', 16, $this->source); })()), "url", []), "html", null, true);
        echo "\" alt=\"\" class=\"img-fluid\"></a>

        <nav class=\"nav-menu d-none d-lg-block\">
          <ul>
            ";
        // line 20
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["nav"]) || array_key_exists("nav", $context) ? $context["nav"] : (function () { throw new RuntimeError('Variable "nav" does not exist.', 20, $this->source); })()));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["slug"] => $context["item"]) {
            // line 21
            echo "              <li class= ";
            echo (((craft\helpers\Template::attribute($this->env, $this->source, $context["loop"], "index", []) == 1)) ? ("active") : (""));
            echo ">
              <a href=\"";
            // line 22
            if (($context["slug"] == "home")) {
                echo " #hero ";
            } else {
                echo "#";
                echo twig_escape_filter($this->env, $context["slug"], "html", null, true);
            }
            echo "\">";
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->ucfirstFilter(craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "title", [])), "html", null, true);
            echo "</a></li>
            ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['slug'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 24
        echo "
            ";
        // line 48
        echo "
          </ul>
        </nav><!-- .nav-menu -->

        ";
        // line 53
        echo "      </div>
    </div>

  </div>";
        // line 0
        craft\helpers\Template::endProfile("template", "_partials/header");
    }

    public function getTemplateName()
    {
        return "_partials/header";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  117 => 0,  112 => 53,  106 => 48,  103 => 24,  80 => 22,  75 => 21,  58 => 20,  51 => 16,  48 => 15,  40 => 8,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% set nav = {
  home : {title : 'home'},
  about : {title : 'about'},
  services : {title : 'services'},
  portfolio : {title : 'portfolio'},
  contact : {title : 'contact'}
} %}

<header id=\"header\" class=\"fixed-top \">
  <div class=\"container-fluid\">

    <div class=\"row justify-content-center\">
      <div class=\"col-xl-9 d-flex align-items-center justify-content-between\">
        {# <h1 class=\"logo\"><a href=\"index.html\">KnightOne</a></h1> #}
        <!-- Uncomment below if you prefer to use an image logo -->
        <a href=\"index.html\" class=\"logo\"><img src=\"{{ logo.url }}\" alt=\"\" class=\"img-fluid\"></a>

        <nav class=\"nav-menu d-none d-lg-block\">
          <ul>
            {% for slug, item in nav %}
              <li class= {{ loop.index == 1 ? 'active' : '' }}>
              <a href=\"{% if slug == 'home' %} #hero {% else %}#{{- slug -}}  {% endif %}\">{{- item.title|ucfirst -}}</a></li>
            {% endfor %}

            {# <li class=\"active\"><a href=\"index.html\">Home</a></li>
            <li><a href=\"#about\">About</a></li>
            <li><a href=\"#services\">Services</a></li>
            <li><a href=\"#portfolio\">Portfolio</a></li>
            <li><a href=\"#pricing\">Pricing</a></li>
            <li class=\"drop-down\"><a href=\"\">Drop Down</a>
              <ul>
                <li><a href=\"#\">Drop Down 1</a></li>
                <li class=\"drop-down\"><a href=\"#\">Deep Drop Down</a>
                  <ul>
                    <li><a href=\"#\">Deep Drop Down 1</a></li>
                    <li><a href=\"#\">Deep Drop Down 2</a></li>
                    <li><a href=\"#\">Deep Drop Down 3</a></li>
                    <li><a href=\"#\">Deep Drop Down 4</a></li>
                    <li><a href=\"#\">Deep Drop Down 5</a></li>
                  </ul>
                </li>
                <li><a href=\"#\">Drop Down 2</a></li>
                <li><a href=\"#\">Drop Down 3</a></li>
                <li><a href=\"#\">Drop Down 4</a></li>
              </ul>
            </li>
            <li><a href=\"#contact\">Contact</a></li> #}

          </ul>
        </nav><!-- .nav-menu -->

        {# <a href=\"#about\" class=\"get-started-btn scrollto\">Get Started</a> #}
      </div>
    </div>

  </div>", "_partials/header", "/Applications/MAMP/htdocs/craft/smsi/templates/_partials/header.twig");
    }
}
