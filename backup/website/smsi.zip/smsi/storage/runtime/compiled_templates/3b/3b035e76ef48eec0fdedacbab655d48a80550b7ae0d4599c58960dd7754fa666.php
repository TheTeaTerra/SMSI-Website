<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* __string_template__0bc34dee4c70575f9535f476e1da5ff327dd0c1411cccf2ac6b85503a14e6b06 */
class __TwigTemplate_8cb418b1f0a1e0eee127012e3da77ac267388bdad55bf3c7028bed464b9d9e8c extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "__string_template__0bc34dee4c70575f9535f476e1da5ff327dd0c1411cccf2ac6b85503a14e6b06");
        // line 1
        echo "portfolio/";
        echo (((craft\helpers\Template::attribute($this->env, $this->source, ($context["_variables"] ?? null), "slug", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["_variables"] ?? null), "slug", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["_variables"] ?? null), "slug", [])) : (craft\helpers\Template::attribute($this->env, $this->source, ($context["object"] ?? null), "slug", [])));
        // line 0
        craft\helpers\Template::endProfile("template", "__string_template__0bc34dee4c70575f9535f476e1da5ff327dd0c1411cccf2ac6b85503a14e6b06");
    }

    public function getTemplateName()
    {
        return "__string_template__0bc34dee4c70575f9535f476e1da5ff327dd0c1411cccf2ac6b85503a14e6b06";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  41 => 0,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("portfolio/{{ (_variables.slug ?? object.slug)|raw }}", "__string_template__0bc34dee4c70575f9535f476e1da5ff327dd0c1411cccf2ac6b85503a14e6b06", "");
    }
}
