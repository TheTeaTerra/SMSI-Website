<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _partials/footer */
class __TwigTemplate_8c69cebb9d062d262f09fbd12ffd21c51116d110dffc87637b0327af263e2a2e extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_partials/footer");
        // line 1
        echo "<footer id=\"footer\">
    <div class=\"container\">
      <div class=\"footer-info d-flex flex-row justify-content-center\">
          <img src=\"";
        // line 4
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["logo"]) || array_key_exists("logo", $context) ? $context["logo"] : (function () { throw new RuntimeError('Variable "logo" does not exist.', 4, $this->source); })()), "getURL", [0 => (isset($context["logoImg"]) || array_key_exists("logoImg", $context) ? $context["logoImg"] : (function () { throw new RuntimeError('Variable "logoImg" does not exist.', 4, $this->source); })())], "method"), "html", null, true);
        echo "\" alt=\"";
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["siteInfo"]) || array_key_exists("siteInfo", $context) ? $context["siteInfo"] : (function () { throw new RuntimeError('Variable "siteInfo" does not exist.', 4, $this->source); })()), "title", []), "html", null, true);
        echo "\" class=\"logo\">
          <p>";
        // line 5
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["siteInfo"]) || array_key_exists("siteInfo", $context) ? $context["siteInfo"] : (function () { throw new RuntimeError('Variable "siteInfo" does not exist.', 5, $this->source); })()), "companyName", []), "html", null, true);
        echo "</p>
      </div>
      ";
        // line 7
        echo $this->extensions['craft\web\twig\Extension']->markdownFilter(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["footer"]) || array_key_exists("footer", $context) ? $context["footer"] : (function () { throw new RuntimeError('Variable "footer" does not exist.', 7, $this->source); })()), "description", []));
        echo "
      <p>&copy; ";
        // line 8
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->dateFilter($this->env, (isset($context["now"]) || array_key_exists("now", $context) ? $context["now"] : (function () { throw new RuntimeError('Variable "now" does not exist.', 8, $this->source); })()), "Y"), "html", null, true);
        echo ", built with <a class=\"text-blue-600\" href=\"https://craftcms.com\">";
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["siteInfo"]) || array_key_exists("siteInfo", $context) ? $context["siteInfo"] : (function () { throw new RuntimeError('Variable "siteInfo" does not exist.', 8, $this->source); })()), "copyrightNotice", []), "html", null, true);
        echo "</a></p>
    </div>
  </footer>";
        // line 0
        craft\helpers\Template::endProfile("template", "_partials/footer");
    }

    public function getTemplateName()
    {
        return "_partials/footer";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  65 => 0,  58 => 8,  54 => 7,  49 => 5,  43 => 4,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<footer id=\"footer\">
    <div class=\"container\">
      <div class=\"footer-info d-flex flex-row justify-content-center\">
          <img src=\"{{ logo.getURL(logoImg) }}\" alt=\"{{ siteInfo.title }}\" class=\"logo\">
          <p>{{ siteInfo.companyName }}</p>
      </div>
      {{ footer.description|markdown }}
      <p>&copy; {{ now | date('Y') }}, built with <a class=\"text-blue-600\" href=\"https://craftcms.com\">{{ siteInfo.copyrightNotice }}</a></p>
    </div>
  </footer>", "_partials/footer", "/Applications/MAMP/htdocs/craft/smsi/templates/_partials/footer.twig");
    }
}
