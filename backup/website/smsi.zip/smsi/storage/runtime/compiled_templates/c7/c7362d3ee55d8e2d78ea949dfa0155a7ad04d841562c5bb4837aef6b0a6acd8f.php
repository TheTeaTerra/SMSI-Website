<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* settings/users/fields */
class __TwigTemplate_17d65ca8e7bc63cc88243ba3d51a76c5ec880aebfd8c1884eb1aec21ab95e48d extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 3
        return "settings/users/_layout";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("template", "settings/users/fields");
        // line 1
        Craft::$app->controller->requireAdmin();
        // line 4
        $context["selectedNavItem"] = "fields";
        // line 3
        $this->parent = $this->loadTemplate("settings/users/_layout", "settings/users/fields", 3);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        // line 0
        craft\helpers\Template::endProfile("template", "settings/users/fields");
    }

    // line 7
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("block", "content");
        // line 8
        echo "    <form method=\"post\" accept-charset=\"UTF-8\" data-saveshortcut data-confirm-unload>
        ";
        // line 9
        echo craft\helpers\Html::actionInput("users/save-field-layout");
        echo "
        ";
        // line 10
        echo craft\helpers\Html::redirectInput("settings");
        echo "
        ";
        // line 11
        echo craft\helpers\Html::csrfInput();
        echo "

        ";
        // line 13
        $this->loadTemplate("_includes/fieldlayoutdesigner", "settings/users/fields", 13)->display(twig_to_array(["fieldLayout" => craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source,         // line 14
(isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 14, $this->source); })()), "app", []), "fields", []), "getLayoutByType", [0 => "craft\\elements\\User"], "method")]));
        // line 16
        echo "
        <div class=\"buttons\">
            <input type=\"submit\" class=\"btn submit\" value=\"";
        // line 18
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Save", "app"), "html", null, true);
        echo "\">
        </div>
    </form>
";
        // line 0
        craft\helpers\Template::endProfile("block", "content");
    }

    public function getTemplateName()
    {
        return "settings/users/fields";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  90 => 0,  84 => 18,  80 => 16,  78 => 14,  77 => 13,  72 => 11,  68 => 10,  64 => 9,  61 => 8,  59 => 0,  55 => 7,  51 => 0,  48 => 3,  46 => 4,  44 => 1,  42 => 0,  35 => 3,);
    }

    public function getSourceContext()
    {
        return new Source("{% requireAdmin %}

{% extends \"settings/users/_layout\" %}
{% set selectedNavItem = 'fields' %}


{% block content %}
    <form method=\"post\" accept-charset=\"UTF-8\" data-saveshortcut data-confirm-unload>
        {{ actionInput('users/save-field-layout') }}
        {{ redirectInput('settings') }}
        {{ csrfInput() }}

        {% include \"_includes/fieldlayoutdesigner\" with {
            fieldLayout: craft.app.fields.getLayoutByType('craft\\\\elements\\\\User')
        } only %}

        <div class=\"buttons\">
            <input type=\"submit\" class=\"btn submit\" value=\"{{ 'Save'|t('app') }}\">
        </div>
    </form>
{% endblock %}
", "settings/users/fields", "/Applications/MAMP/htdocs/craft/smsi/vendor/craftcms/cms/src/templates/settings/users/fields.html");
    }
}
