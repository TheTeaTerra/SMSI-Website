<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* __string_template__d96b1036ebf4f64d3db363075cd6fafdcad1b45b4d5c6ef7971b9802e5b231d8 */
class __TwigTemplate_13674d5b0171aa1f8fd681d7939efad3e1cf811c500f5db2b680538c59403932 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "__string_template__d96b1036ebf4f64d3db363075cd6fafdcad1b45b4d5c6ef7971b9802e5b231d8");
        // line 1
        echo "blog/";
        echo (((craft\helpers\Template::attribute($this->env, $this->source, ($context["_variables"] ?? null), "slug", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["_variables"] ?? null), "slug", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["_variables"] ?? null), "slug", [])) : (craft\helpers\Template::attribute($this->env, $this->source, ($context["object"] ?? null), "slug", [])));
        // line 0
        craft\helpers\Template::endProfile("template", "__string_template__d96b1036ebf4f64d3db363075cd6fafdcad1b45b4d5c6ef7971b9802e5b231d8");
    }

    public function getTemplateName()
    {
        return "__string_template__d96b1036ebf4f64d3db363075cd6fafdcad1b45b4d5c6ef7971b9802e5b231d8";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  41 => 0,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("blog/{{ (_variables.slug ?? object.slug)|raw }}", "__string_template__d96b1036ebf4f64d3db363075cd6fafdcad1b45b4d5c6ef7971b9802e5b231d8", "");
    }
}
