<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* settings/sections/_edit */
class __TwigTemplate_735af558d0e481c58b522b84872e95bfd7ef127164e919e44f6e148aaa41e056 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "_layouts/cp";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("template", "settings/sections/_edit");
        // line 2
        $context["fullPageForm"] = true;
        // line 4
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms", "settings/sections/_edit", 4)->unwrap();
        // line 6
        $context["headlessMode"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 6, $this->source); })()), "app", []), "config", []), "general", []), "headlessMode", []);
        // line 225
        if ((isset($context["brandNewSection"]) || array_key_exists("brandNewSection", $context) ? $context["brandNewSection"] : (function () { throw new RuntimeError('Variable "brandNewSection" does not exist.', 225, $this->source); })())) {
            // line 226
            ob_start();
            // line 227
            echo "        new Craft.HandleGenerator('#name', '#handle');

        ";
            // line 229
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 229, $this->source); })()), "app", []), "sites", []), "getAllSites", [], "method"));
            foreach ($context['_seq'] as $context["_key"] => $context["site"]) {
                // line 230
                echo "            new Craft.UriFormatGenerator('#name', '#sites tr[data-id=\"";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "handle", []), "html", null, true);
                echo "\"] textarea[name\$=\"[singleUri]\"]');
            new Craft.UriFormatGenerator('#name', '#sites tr[data-id=\"";
                // line 231
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "handle", []), "html", null, true);
                echo "\"] textarea[name\$=\"[uriFormat]\"]', { suffix: '/{slug}' });
            new Craft.UriFormatGenerator('#name', '#sites tr[data-id=\"";
                // line 232
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "handle", []), "html", null, true);
                echo "\"] textarea[name\$=\"[template]\"]', { suffix: '/_entry' });
        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['site'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 234
            echo "    ";
            Craft::$app->getView()->registerJs(ob_get_clean(), 3);
        }
        // line 1
        $this->parent = $this->loadTemplate("_layouts/cp", "settings/sections/_edit", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        // line 0
        craft\helpers\Template::endProfile("template", "settings/sections/_edit");
    }

    // line 9
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("block", "content");
        // line 10
        echo "    ";
        echo craft\helpers\Html::actionInput("sections/save-section");
        echo "
    ";
        // line 11
        echo craft\helpers\Html::redirectInput("settings/sections");
        echo "

    ";
        // line 13
        if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 13, $this->source); })()), "id", [])) {
            echo craft\helpers\Html::hiddenInput("sectionId", craft\helpers\Template::attribute($this->env, $this->source, (isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 13, $this->source); })()), "id", []));
        }
        // line 14
        echo "
    ";
        // line 15
        echo twig_call_macro($macros["forms"], "macro_textField", [["first" => true, "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Name", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("What this section will be called in the control panel.", "app"), "id" => "name", "name" => "name", "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 21
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 21, $this->source); })()), "name", []), "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 22
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 22, $this->source); })()), "getErrors", [0 => "name"], "method"), "autofocus" => true, "required" => true]], 15, $context, $this->getSourceContext());
        // line 25
        echo "

    ";
        // line 27
        echo twig_call_macro($macros["forms"], "macro_textField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Handle", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("How you’ll refer to this section in the templates.", "app"), "id" => "handle", "name" => "handle", "class" => "code", "autocorrect" => false, "autocapitalize" => false, "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 35
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 35, $this->source); })()), "handle", []), "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 36
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 36, $this->source); })()), "getErrors", [0 => "handle"], "method"), "required" => true]], 27, $context, $this->getSourceContext());
        // line 38
        echo "

    ";
        // line 40
        echo twig_call_macro($macros["forms"], "macro_checkboxField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Enable versioning for entries in this section?", "app"), "id" => "enableVersioning", "name" => "enableVersioning", "checked" => craft\helpers\Template::attribute($this->env, $this->source,         // line 44
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 44, $this->source); })()), "enableVersioning", [])]], 40, $context, $this->getSourceContext());
        // line 45
        echo "

    ";
        // line 47
        echo twig_call_macro($macros["forms"], "macro_selectField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Section Type", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("What type of section is this?", "app"), "warning" => (((craft\helpers\Template::attribute($this->env, $this->source,         // line 50
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 50, $this->source); })()), "id", []) && (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 50, $this->source); })()), "type", []) != "single"))) ? ($this->extensions['craft\web\twig\Extension']->translateFilter("Changing this may result in data loss.", "app")) : ("")), "id" => "type", "name" => "type", "options" =>         // line 53
(isset($context["typeOptions"]) || array_key_exists("typeOptions", $context) ? $context["typeOptions"] : (function () { throw new RuntimeError('Variable "typeOptions" does not exist.', 53, $this->source); })()), "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 54
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 54, $this->source); })()), "type", []), "toggle" => true, "targetPrefix" => ".type-", "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 57
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 57, $this->source); })()), "getErrors", [0 => "type"], "method")]], 47, $context, $this->getSourceContext());
        // line 58
        echo "

    <hr>

    ";
        // line 62
        $context["siteRows"] = [];
        // line 63
        echo "    ";
        $context["siteErrors"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 63, $this->source); })()), "getErrors", [0 => "siteSettings"], "method");
        // line 64
        echo "
    ";
        // line 65
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 65, $this->source); })()), "app", []), "sites", []), "getAllSites", [], "method"));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["site"]) {
            // line 66
            echo "        ";
            $context["siteSettings"] = (((craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, ($context["section"] ?? null), "siteSettings", [], "any", false, true), craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "id", []), [], "array", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, ($context["section"] ?? null), "siteSettings", [], "any", false, true), craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "id", []), [], "array")))) ? (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, ($context["section"] ?? null), "siteSettings", [], "any", false, true), craft\helpers\Template::attribute($this->env, $this->source, $context["site"], "id", []), [], "array")) : (null));
            // line 67
            echo "        ";
            if ((isset($context["siteSettings"]) || array_key_exists("siteSettings", $context) ? $context["siteSettings"] : (function () { throw new RuntimeError('Variable "siteSettings" does not exist.', 67, $this->source); })())) {
                // line 68
                echo "            ";
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["siteSettings"]) || array_key_exists("siteSettings", $context) ? $context["siteSettings"] : (function () { throw new RuntimeError('Variable "siteSettings" does not exist.', 68, $this->source); })()), "getErrors", [], "method"));
                foreach ($context['_seq'] as $context["attribute"] => $context["errors"]) {
                    // line 69
                    echo "                ";
                    $context["siteErrors"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["siteErrors"]) || array_key_exists("siteErrors", $context) ? $context["siteErrors"] : (function () { throw new RuntimeError('Variable "siteErrors" does not exist.', 69, $this->source); })()), $context["errors"]);
                    // line 70
                    echo "            ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['attribute'], $context['errors'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 71
                echo "        ";
            }
            // line 72
            echo "        ";
            $context["siteRows"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["siteRows"]) || array_key_exists("siteRows", $context) ? $context["siteRows"] : (function () { throw new RuntimeError('Variable "siteRows" does not exist.', 72, $this->source); })()), [craft\helpers\Template::attribute($this->env, $this->source,             // line 73
$context["site"], "handle", []) => $this->extensions['craft\web\twig\Extension']->filterFilter(["heading" => twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source,             // line 74
$context["site"], "name", []), "site")), "enabled" => twig_include($this->env, $context, "_includes/forms/lightswitch", ["name" => (("sites[" . craft\helpers\Template::attribute($this->env, $this->source,             // line 76
$context["site"], "handle", [])) . "][enabled]"), "on" => (            // line 77
(isset($context["brandNewSection"]) || array_key_exists("brandNewSection", $context) ? $context["brandNewSection"] : (function () { throw new RuntimeError('Variable "brandNewSection" does not exist.', 77, $this->source); })()) || (isset($context["siteSettings"]) || array_key_exists("siteSettings", $context) ? $context["siteSettings"] : (function () { throw new RuntimeError('Variable "siteSettings" does not exist.', 77, $this->source); })())), "value" => craft\helpers\Template::attribute($this->env, $this->source,             // line 78
$context["site"], "id", []), "small" => true]), "singleHomepage" => ["value" => (((craft\helpers\Template::attribute($this->env, $this->source,             // line 82
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 82, $this->source); })()), "type", []) == "single") && (isset($context["siteSettings"]) || array_key_exists("siteSettings", $context) ? $context["siteSettings"] : (function () { throw new RuntimeError('Variable "siteSettings" does not exist.', 82, $this->source); })())) && (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["siteSettings"]) || array_key_exists("siteSettings", $context) ? $context["siteSettings"] : (function () { throw new RuntimeError('Variable "siteSettings" does not exist.', 82, $this->source); })()), "uriFormat", []) == "__home__"))], "singleUri" => ["value" => (((((craft\helpers\Template::attribute($this->env, $this->source,             // line 85
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 85, $this->source); })()), "type", []) == "single") && (isset($context["siteSettings"]) || array_key_exists("siteSettings", $context) ? $context["siteSettings"] : (function () { throw new RuntimeError('Variable "siteSettings" does not exist.', 85, $this->source); })())) && (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["siteSettings"]) || array_key_exists("siteSettings", $context) ? $context["siteSettings"] : (function () { throw new RuntimeError('Variable "siteSettings" does not exist.', 85, $this->source); })()), "uriFormat", []) != "__home__"))) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["siteSettings"]) || array_key_exists("siteSettings", $context) ? $context["siteSettings"] : (function () { throw new RuntimeError('Variable "siteSettings" does not exist.', 85, $this->source); })()), "uriFormat", [])) : ("")), "hasErrors" => ((((craft\helpers\Template::attribute($this->env, $this->source,             // line 86
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 86, $this->source); })()), "type", []) == "single") && (isset($context["siteSettings"]) || array_key_exists("siteSettings", $context) ? $context["siteSettings"] : (function () { throw new RuntimeError('Variable "siteSettings" does not exist.', 86, $this->source); })()))) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["siteSettings"]) || array_key_exists("siteSettings", $context) ? $context["siteSettings"] : (function () { throw new RuntimeError('Variable "siteSettings" does not exist.', 86, $this->source); })()), "hasErrors", [0 => "uriFormat"], "method")) : (""))], "uriFormat" => ["value" => ((            // line 89
(isset($context["siteSettings"]) || array_key_exists("siteSettings", $context) ? $context["siteSettings"] : (function () { throw new RuntimeError('Variable "siteSettings" does not exist.', 89, $this->source); })())) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["siteSettings"]) || array_key_exists("siteSettings", $context) ? $context["siteSettings"] : (function () { throw new RuntimeError('Variable "siteSettings" does not exist.', 89, $this->source); })()), "uriFormat", [])) : ("")), "hasErrors" => ((((craft\helpers\Template::attribute($this->env, $this->source,             // line 90
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 90, $this->source); })()), "type", []) != "single") && (isset($context["siteSettings"]) || array_key_exists("siteSettings", $context) ? $context["siteSettings"] : (function () { throw new RuntimeError('Variable "siteSettings" does not exist.', 90, $this->source); })()))) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["siteSettings"]) || array_key_exists("siteSettings", $context) ? $context["siteSettings"] : (function () { throw new RuntimeError('Variable "siteSettings" does not exist.', 90, $this->source); })()), "hasErrors", [0 => "uriFormat"], "method")) : (""))], "template" => (( !            // line 92
(isset($context["headlessMode"]) || array_key_exists("headlessMode", $context) ? $context["headlessMode"] : (function () { throw new RuntimeError('Variable "headlessMode" does not exist.', 92, $this->source); })())) ? (["value" => ((            // line 93
(isset($context["siteSettings"]) || array_key_exists("siteSettings", $context) ? $context["siteSettings"] : (function () { throw new RuntimeError('Variable "siteSettings" does not exist.', 93, $this->source); })())) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["siteSettings"]) || array_key_exists("siteSettings", $context) ? $context["siteSettings"] : (function () { throw new RuntimeError('Variable "siteSettings" does not exist.', 93, $this->source); })()), "template", [])) : ("")), "hasErrors" => ((            // line 94
(isset($context["siteSettings"]) || array_key_exists("siteSettings", $context) ? $context["siteSettings"] : (function () { throw new RuntimeError('Variable "siteSettings" does not exist.', 94, $this->source); })())) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["siteSettings"]) || array_key_exists("siteSettings", $context) ? $context["siteSettings"] : (function () { throw new RuntimeError('Variable "siteSettings" does not exist.', 94, $this->source); })()), "hasErrors", [0 => "template"], "method")) : (""))]) : ("")), "enabledByDefault" => ((            // line 96
(isset($context["siteSettings"]) || array_key_exists("siteSettings", $context) ? $context["siteSettings"] : (function () { throw new RuntimeError('Variable "siteSettings" does not exist.', 96, $this->source); })())) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["siteSettings"]) || array_key_exists("siteSettings", $context) ? $context["siteSettings"] : (function () { throw new RuntimeError('Variable "siteSettings" does not exist.', 96, $this->source); })()), "enabledByDefault", [])) : (true))])]);
            // line 99
            echo "    ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['site'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 100
        echo "
    ";
        // line 101
        echo twig_call_macro($macros["forms"], "macro_editableTableField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Site Settings", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Choose which sites this section should be available in, and configure the site-specific settings.", "app"), "id" => "sites", "name" => "sites", "cols" => $this->extensions['craft\web\twig\Extension']->filterFilter(["heading" => ["type" => "heading", "heading" => $this->extensions['craft\web\twig\Extension']->translateFilter("Site", "app"), "thin" => true], "enabled" => ["type" => "heading", "thin" => true, "class" => (( !craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source,         // line 115
(isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 115, $this->source); })()), "app", []), "getIsMultiSite", [], "method")) ? ("hidden") : (""))], "singleHomepage" => ["type" => "checkbox", "headingHtml" => $this->extensions['craft\web\twig\Extension']->tagFunction("div", ["data" => ["icon" => "home"], "title" => $this->extensions['craft\web\twig\Extension']->translateFilter("Homepage", "app")]), "thin" => true, "class" => $this->extensions['craft\web\twig\Extension']->filterFilter([0 => "single-homepage", 1 => "type-single", 2 => (((craft\helpers\Template::attribute($this->env, $this->source,         // line 124
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 124, $this->source); })()), "type", []) != "single")) ? ("hidden") : (""))])], "singleUri" => ["type" => "singleline", "heading" => $this->extensions['craft\web\twig\Extension']->translateFilter("URI", "app"), "info" => $this->extensions['craft\web\twig\Extension']->translateFilter("What the entry URI should be for the site. Leave blank if the entry doesn’t have a URL.", "app"), "code" => true, "width" => ((        // line 131
(isset($context["headlessMode"]) || array_key_exists("headlessMode", $context) ? $context["headlessMode"] : (function () { throw new RuntimeError('Variable "headlessMode" does not exist.', 131, $this->source); })())) ? (500) : ("")), "class" => $this->extensions['craft\web\twig\Extension']->filterFilter([0 => "single-uri", 1 => "type-single", 2 => (((craft\helpers\Template::attribute($this->env, $this->source,         // line 132
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 132, $this->source); })()), "type", []) != "single")) ? ("hidden") : (""))])], "uriFormat" => ["type" => "singleline", "heading" => $this->extensions['craft\web\twig\Extension']->translateFilter("Entry URI Format", "app"), "info" => $this->extensions['craft\web\twig\Extension']->translateFilter("What entry URIs should look like for the site. Leave blank if entries don’t have URLs.", "app"), "code" => true, "width" => ((        // line 139
(isset($context["headlessMode"]) || array_key_exists("headlessMode", $context) ? $context["headlessMode"] : (function () { throw new RuntimeError('Variable "headlessMode" does not exist.', 139, $this->source); })())) ? (500) : ("")), "class" => $this->extensions['craft\web\twig\Extension']->filterFilter([0 => "type-channel", 1 => "type-structure", 2 => (((craft\helpers\Template::attribute($this->env, $this->source,         // line 140
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 140, $this->source); })()), "type", []) == "single")) ? (" hidden") : (""))])], "template" => (( !        // line 142
(isset($context["headlessMode"]) || array_key_exists("headlessMode", $context) ? $context["headlessMode"] : (function () { throw new RuntimeError('Variable "headlessMode" does not exist.', 142, $this->source); })())) ? (["type" => "template", "heading" => $this->extensions['craft\web\twig\Extension']->translateFilter("Template", "app"), "info" => $this->extensions['craft\web\twig\Extension']->translateFilter("Which template should be loaded when an entry’s URL is requested.", "app"), "code" => true]) : ("")), "enabledByDefault" => ["type" => "lightswitch", "heading" => $this->extensions['craft\web\twig\Extension']->translateFilter("Default Status", "app"), "thin" => true, "class" => $this->extensions['craft\web\twig\Extension']->filterFilter([0 => "type-channel", 1 => "type-structure", 2 => (((craft\helpers\Template::attribute($this->env, $this->source,         // line 152
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 152, $this->source); })()), "type", []) == "single")) ? (" hidden") : (""))])]]), "rows" =>         // line 155
(isset($context["siteRows"]) || array_key_exists("siteRows", $context) ? $context["siteRows"] : (function () { throw new RuntimeError('Variable "siteRows" does not exist.', 155, $this->source); })()), "fullWidth" =>  !        // line 156
(isset($context["headlessMode"]) || array_key_exists("headlessMode", $context) ? $context["headlessMode"] : (function () { throw new RuntimeError('Variable "headlessMode" does not exist.', 156, $this->source); })()), "staticRows" => true, "errors" => array_unique(        // line 158
(isset($context["siteErrors"]) || array_key_exists("siteErrors", $context) ? $context["siteErrors"] : (function () { throw new RuntimeError('Variable "siteErrors" does not exist.', 158, $this->source); })()))]], 101, $context, $this->getSourceContext());
        // line 159
        echo "

    ";
        // line 161
        if (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 161, $this->source); })()), "app", []), "getIsMultiSite", [], "method")) {
            // line 162
            echo "        <div class=\"field type-channel type-structure ";
            if ((craft\helpers\Template::attribute($this->env, $this->source, (isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 162, $this->source); })()), "type", []) == "single")) {
                echo "hidden";
            }
            echo "\">
            ";
            // line 163
            echo twig_call_macro($macros["forms"], "macro_selectField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Propagation Method", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Of the enabled sites above, which sites should entries in this section be saved to?", "app"), "warning" => ((((craft\helpers\Template::attribute($this->env, $this->source,             // line 166
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 166, $this->source); })()), "id", []) && (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 166, $this->source); })()), "propagationMethod", []) != "none")) && (twig_length_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 166, $this->source); })()), "siteSettings", [])) > 1))) ? ($this->extensions['craft\web\twig\Extension']->translateFilter("Changing this may result in data loss.", "app")) : ("")), "id" => "propagationMethod", "name" => "propagationMethod", "options" => [0 => ["value" => "none", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Only save entries to the site they were created in", "app")], 1 => ["value" => "siteGroup", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Save entries to other sites in the same site group", "app")], 2 => ["value" => "language", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Save entries to other sites with the same language", "app")], 3 => ["value" => "all", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Save entries to all sites enabled for this section", "app")]], "value" => craft\helpers\Template::attribute($this->env, $this->source,             // line 175
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 175, $this->source); })()), "propagationMethod", [])]], 163, $context, $this->getSourceContext());
            // line 176
            echo "
        </div>
    ";
        }
        // line 179
        echo "
    <div class=\"field type-structure ";
        // line 180
        if ((craft\helpers\Template::attribute($this->env, $this->source, (isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 180, $this->source); })()), "type", []) != "structure")) {
            echo "hidden";
        }
        echo "\">
        ";
        // line 181
        echo twig_call_macro($macros["forms"], "macro_textField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Max Levels", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("The maximum number of levels this section can have. Leave blank if you don’t care.", "app"), "id" => "maxLevels", "name" => "maxLevels", "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 186
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 186, $this->source); })()), "maxLevels", []), "size" => 5, "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 188
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 188, $this->source); })()), "getErrors", [0 => "maxLevels"], "method")]], 181, $context, $this->getSourceContext());
        // line 189
        echo "
    </div>

    ";
        // line 192
        if (((isset($context["CraftEdition"]) || array_key_exists("CraftEdition", $context) ? $context["CraftEdition"] : (function () { throw new RuntimeError('Variable "CraftEdition" does not exist.', 192, $this->source); })()) == (isset($context["CraftPro"]) || array_key_exists("CraftPro", $context) ? $context["CraftPro"] : (function () { throw new RuntimeError('Variable "CraftPro" does not exist.', 192, $this->source); })()))) {
            // line 193
            echo "        ";
            echo twig_call_macro($macros["forms"], "macro_editableTableField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Preview Targets", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Locations that should be available for previewing entries in this section.", "app"), "id" => "previewTargets", "name" => "previewTargets", "cols" => ["label" => ["type" => "singleline", "heading" => $this->extensions['craft\web\twig\Extension']->translateFilter("Label", "app")], "urlFormat" => ["type" => "singleline", "heading" => $this->extensions['craft\web\twig\Extension']->translateFilter("URL Format", "app"), "info" => $this->extensions['craft\web\twig\Extension']->translateFilter("The URL/URI to use for this target.", "app"), "code" => true], "refresh" => ["type" => "checkbox", "heading" => $this->extensions['craft\web\twig\Extension']->translateFilter("Refresh", "app"), "info" => $this->extensions['craft\web\twig\Extension']->translateFilter("Whether preview frames should be automatically refreshed when content changes.", "app"), "thin" => true]], "defaultValues" => ["refresh" => true], "rows" => craft\helpers\Template::attribute($this->env, $this->source,             // line 219
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 219, $this->source); })()), "previewTargets", []), "errors" => craft\helpers\Template::attribute($this->env, $this->source,             // line 220
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 220, $this->source); })()), "getErrors", [0 => "previewTargets"], "method")]], 193, $context, $this->getSourceContext());
            // line 221
            echo "
    ";
        }
        // line 0
        craft\helpers\Template::endProfile("block", "content");
    }

    public function getTemplateName()
    {
        return "settings/sections/_edit";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  294 => 0,  290 => 221,  288 => 220,  287 => 219,  285 => 193,  283 => 192,  278 => 189,  276 => 188,  275 => 186,  274 => 181,  268 => 180,  265 => 179,  260 => 176,  258 => 175,  257 => 166,  256 => 163,  249 => 162,  247 => 161,  243 => 159,  241 => 158,  240 => 156,  239 => 155,  238 => 152,  237 => 142,  236 => 140,  235 => 139,  234 => 132,  233 => 131,  232 => 124,  231 => 115,  230 => 101,  227 => 100,  213 => 99,  211 => 96,  210 => 94,  209 => 93,  208 => 92,  207 => 90,  206 => 89,  205 => 86,  204 => 85,  203 => 82,  202 => 78,  201 => 77,  200 => 76,  199 => 74,  198 => 73,  196 => 72,  193 => 71,  187 => 70,  184 => 69,  179 => 68,  176 => 67,  173 => 66,  156 => 65,  153 => 64,  150 => 63,  148 => 62,  142 => 58,  140 => 57,  139 => 54,  138 => 53,  137 => 50,  136 => 47,  132 => 45,  130 => 44,  129 => 40,  125 => 38,  123 => 36,  122 => 35,  121 => 27,  117 => 25,  115 => 22,  114 => 21,  113 => 15,  110 => 14,  106 => 13,  101 => 11,  96 => 10,  94 => 0,  90 => 9,  86 => 0,  83 => 1,  79 => 234,  71 => 232,  67 => 231,  62 => 230,  58 => 229,  54 => 227,  52 => 226,  50 => 225,  48 => 6,  46 => 4,  44 => 2,  42 => 0,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends \"_layouts/cp\" %}
{% set fullPageForm = true %}

{% import \"_includes/forms\" as forms %}

{% set headlessMode = craft.app.config.general.headlessMode %}


{% block content %}
    {{ actionInput('sections/save-section') }}
    {{ redirectInput('settings/sections') }}

    {% if section.id %}{{ hiddenInput('sectionId', section.id) }}{% endif %}

    {{ forms.textField({
        first: true,
        label: \"Name\"|t('app'),
        instructions: \"What this section will be called in the control panel.\"|t('app'),
        id: 'name',
        name: 'name',
        value: section.name,
        errors: section.getErrors('name'),
        autofocus: true,
        required: true,
    }) }}

    {{ forms.textField({
        label: \"Handle\"|t('app'),
        instructions: \"How you’ll refer to this section in the templates.\"|t('app'),
        id: 'handle',
        name: 'handle',
        class: 'code',
        autocorrect: false,
        autocapitalize: false,
        value: section.handle,
        errors: section.getErrors('handle'),
        required: true
    }) }}

    {{ forms.checkboxField({
        label: \"Enable versioning for entries in this section?\"|t('app'),
        id: 'enableVersioning',
        name: 'enableVersioning',
        checked: section.enableVersioning
    }) }}

    {{ forms.selectField({
        label: \"Section Type\"|t('app'),
        instructions: \"What type of section is this?\"|t('app'),
        warning: section.id and section.type != 'single' ? 'Changing this may result in data loss.'|t('app'),
        id: 'type',
        name: 'type',
        options: typeOptions,
        value: section.type,
        toggle: true,
        targetPrefix: '.type-',
        errors: section.getErrors('type')
    }) }}

    <hr>

    {% set siteRows = [] %}
    {% set siteErrors = section.getErrors('siteSettings') %}

    {% for site in craft.app.sites.getAllSites() %}
        {% set siteSettings = section.siteSettings[site.id] ?? null %}
        {% if siteSettings %}
            {% for attribute, errors in siteSettings.getErrors() %}
                {% set siteErrors = siteErrors|merge(errors) %}
            {% endfor %}
        {% endif %}
        {% set siteRows = siteRows|merge({
            (site.handle): {
                heading: site.name|t('site')|e,
                enabled: include('_includes/forms/lightswitch', {
                    name: 'sites['~site.handle~'][enabled]',
                    on: brandNewSection or siteSettings,
                    value: site.id,
                    small: true
                }),
                singleHomepage: {
                    value: (section.type == 'single' and siteSettings and siteSettings.uriFormat == '__home__')
                },
                singleUri: {
                   value: (section.type == 'single' and siteSettings and siteSettings.uriFormat != '__home__') ? siteSettings.uriFormat,
                   hasErrors: (section.type == 'single' and siteSettings ? siteSettings.hasErrors('uriFormat'))
                },
                uriFormat: {
                    value: siteSettings ? siteSettings.uriFormat,
                    hasErrors: (section.type != 'single' and siteSettings ? siteSettings.hasErrors('uriFormat'))
                },
                template: not headlessMode ? {
                    value: siteSettings ? siteSettings.template,
                    hasErrors: siteSettings ? siteSettings.hasErrors('template'),
                },
                enabledByDefault: siteSettings ? siteSettings.enabledByDefault : true,
            }|filter
        }) %}
    {% endfor %}

    {{ forms.editableTableField({
        label: \"Site Settings\"|t('app'),
        instructions: \"Choose which sites this section should be available in, and configure the site-specific settings.\"|t('app'),
        id: 'sites',
        name: 'sites',
        cols: {
            heading: {
                type: 'heading',
                heading: \"Site\"|t('app'),
                thin: true
            },
            enabled: {
                type: 'heading',
                thin: true,
                class: not craft.app.getIsMultiSite() ? 'hidden'
            },
            singleHomepage: {
                type: 'checkbox',
                headingHtml: tag('div', {
                    data: {icon: 'home'},
                    title: 'Homepage'|t('app')
                }),
                thin: true,
                class: ['single-homepage', 'type-single', section.type != 'single' ? 'hidden']|filter
            },
            singleUri: {
                type: 'singleline',
                heading: \"URI\"|t('app'),
                info: \"What the entry URI should be for the site. Leave blank if the entry doesn’t have a URL.\"|t('app'),
                code: true,
                width: headlessMode ? 500,
                class: ['single-uri', 'type-single', section.type != 'single' ? 'hidden']|filter
            },
            uriFormat: {
                type: 'singleline',
                heading: \"Entry URI Format\"|t('app'),
                info: \"What entry URIs should look like for the site. Leave blank if entries don’t have URLs.\"|t('app'),
                code: true,
                width: headlessMode ? 500,
                class: ['type-channel', 'type-structure', section.type == 'single' ? ' hidden']|filter
            },
            template: not headlessMode ? {
                type: 'template',
                heading: \"Template\"|t('app'),
                info: \"Which template should be loaded when an entry’s URL is requested.\"|t('app'),
                code: true
            },
            enabledByDefault: {
                type: 'lightswitch',
                heading: \"Default Status\"|t('app'),
                thin: true,
                class: ['type-channel', 'type-structure', section.type == 'single' ? ' hidden']|filter
            }
        }|filter,
        rows: siteRows,
        fullWidth: not headlessMode,
        staticRows: true,
        errors: siteErrors|unique
    }) }}

    {% if craft.app.getIsMultiSite() %}
        <div class=\"field type-channel type-structure {% if section.type == 'single' %}hidden{% endif %}\">
            {{ forms.selectField({
                label: 'Propagation Method'|t('app'),
                instructions: 'Of the enabled sites above, which sites should entries in this section be saved to?'|t('app'),
                warning: section.id and section.propagationMethod != 'none' and section.siteSettings|length > 1 ? 'Changing this may result in data loss.'|t('app'),
                id: 'propagationMethod',
                name: 'propagationMethod',
                options: [
                    { value: 'none', label: 'Only save entries to the site they were created in'|t('app') },
                    { value: 'siteGroup', label: 'Save entries to other sites in the same site group'|t('app') },
                    { value: 'language', label: 'Save entries to other sites with the same language'|t('app') },
                    { value: 'all', label: 'Save entries to all sites enabled for this section'|t('app') },
                ],
                value: section.propagationMethod
            }) }}
        </div>
    {% endif %}

    <div class=\"field type-structure {% if section.type != 'structure' %}hidden{% endif %}\">
        {{ forms.textField({
            label: \"Max Levels\"|t('app'),
            instructions: \"The maximum number of levels this section can have. Leave blank if you don’t care.\"|t('app'),
            id: 'maxLevels',
            name: 'maxLevels',
            value: section.maxLevels,
            size: 5,
            errors: section.getErrors('maxLevels')
        }) }}
    </div>

    {% if CraftEdition == CraftPro %}
        {{ forms.editableTableField({
            label: 'Preview Targets'|t('app'),
            instructions: 'Locations that should be available for previewing entries in this section.'|t('app'),
            id: 'previewTargets',
            name: 'previewTargets',
            cols: {
                label: {
                    type: 'singleline',
                    heading: 'Label'|t('app'),
                },
                urlFormat: {
                    type: 'singleline',
                    heading: 'URL Format'|t('app'),
                    info: 'The URL/URI to use for this target.'|t('app'),
                    code: true,
                },
                refresh: {
                    type: 'checkbox',
                    heading: 'Refresh'|t('app'),
                    info: 'Whether preview frames should be automatically refreshed when content changes.'|t('app'),
                    thin: true,
                }
            },
            defaultValues: {
                refresh: true,
            },
            rows: section.previewTargets,
            errors: section.getErrors('previewTargets')
        }) }}
    {% endif %}
{% endblock %}

{% if brandNewSection %}
    {% js %}
        new Craft.HandleGenerator('#name', '#handle');

        {% for site in craft.app.sites.getAllSites() %}
            new Craft.UriFormatGenerator('#name', '#sites tr[data-id=\"{{ site.handle }}\"] textarea[name\$=\"[singleUri]\"]');
            new Craft.UriFormatGenerator('#name', '#sites tr[data-id=\"{{ site.handle }}\"] textarea[name\$=\"[uriFormat]\"]', { suffix: '/{slug}' });
            new Craft.UriFormatGenerator('#name', '#sites tr[data-id=\"{{ site.handle }}\"] textarea[name\$=\"[template]\"]', { suffix: '/_entry' });
        {% endfor %}
    {% endjs %}
{% endif %}
", "settings/sections/_edit", "/Applications/MAMP/htdocs/craft/smsi/vendor/craftcms/cms/src/templates/settings/sections/_edit.html");
    }
}
