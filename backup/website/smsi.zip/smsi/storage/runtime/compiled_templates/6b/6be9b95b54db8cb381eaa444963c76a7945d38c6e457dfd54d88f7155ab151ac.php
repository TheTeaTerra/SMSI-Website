<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _includes/fields */
class __TwigTemplate_286a27aa431e7352d8147a484b0110ee3d2221108b95f56622970d8db3399fc0 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_includes/fields");
        // line 1
        $context["element"] = (($context["element"]) ?? (null));
        // line 2
        $context["namespace"] = (((isset($context["namespace"]) || array_key_exists("namespace", $context))) ? ((isset($context["namespace"]) || array_key_exists("namespace", $context) ? $context["namespace"] : (function () { throw new RuntimeError('Variable "namespace" does not exist.', 2, $this->source); })())) : ("fields"));
        // line 3
        echo "
";
        // line 4
        $_namespace = (isset($context["namespace"]) || array_key_exists("namespace", $context) ? $context["namespace"] : (function () { throw new RuntimeError('Variable "namespace" does not exist.', 4, $this->source); })());
        if ($_namespace) {
            $_originalNamespace = Craft::$app->getView()->getNamespace();
            Craft::$app->getView()->setNamespace(Craft::$app->getView()->namespaceInputName($_namespace));
            ob_start();
            try {
                // line 5
                echo "    ";
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable((isset($context["fields"]) || array_key_exists("fields", $context) ? $context["fields"] : (function () { throw new RuntimeError('Variable "fields" does not exist.', 5, $this->source); })()));
                foreach ($context['_seq'] as $context["_key"] => $context["field"]) {
                    // line 6
                    echo "        ";
                    $this->loadTemplate("_includes/field", "_includes/fields", 6)->display(twig_to_array(["field" =>                     // line 7
$context["field"], "required" => craft\helpers\Template::attribute($this->env, $this->source,                     // line 8
$context["field"], "required", []), "element" =>                     // line 9
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 9, $this->source); })()), "static" => ((                    // line 10
$context["static"]) ?? (false)), "registerDeltas" => ((                    // line 11
$context["registerDeltas"]) ?? (false))]));
                    // line 13
                    echo "    ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['field'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
            } catch (Exception $e) {
                ob_end_clean();

                throw $e;
            }
            echo Craft::$app->getView()->namespaceInputs(ob_get_clean(), $_namespace);
            Craft::$app->getView()->setNamespace($_originalNamespace);
        } else {
            // line 5
            echo "    ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["fields"]) || array_key_exists("fields", $context) ? $context["fields"] : (function () { throw new RuntimeError('Variable "fields" does not exist.', 5, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["field"]) {
                // line 6
                echo "        ";
                $this->loadTemplate("_includes/field", "_includes/fields", 6)->display(twig_to_array(["field" =>                 // line 7
$context["field"], "required" => craft\helpers\Template::attribute($this->env, $this->source,                 // line 8
$context["field"], "required", []), "element" =>                 // line 9
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 9, $this->source); })()), "static" => ((                // line 10
$context["static"]) ?? (false)), "registerDeltas" => ((                // line 11
$context["registerDeltas"]) ?? (false))]));
                // line 13
                echo "    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['field'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
        }
        unset($_originalNamespace, $_namespace);
        // line 0
        craft\helpers\Template::endProfile("template", "_includes/fields");
    }

    public function getTemplateName()
    {
        return "_includes/fields";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  100 => 0,  92 => 13,  90 => 11,  89 => 10,  88 => 9,  87 => 8,  86 => 7,  84 => 6,  79 => 5,  65 => 13,  63 => 11,  62 => 10,  61 => 9,  60 => 8,  59 => 7,  57 => 6,  52 => 5,  45 => 4,  42 => 3,  40 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% set element = element ?? null %}
{% set namespace = namespace is defined ? namespace : 'fields' %}

{% namespace namespace %}
    {% for field in fields %}
        {% include \"_includes/field\" with {
            field: field,
            required: field.required,
            element: element,
            static: static ?? false,
            registerDeltas: registerDeltas ?? false,
        } only %}
    {% endfor %}
{% endnamespace %}
", "_includes/fields", "/Applications/MAMP/htdocs/craft/smsi/vendor/craftcms/cms/src/templates/_includes/fields.html");
    }
}
