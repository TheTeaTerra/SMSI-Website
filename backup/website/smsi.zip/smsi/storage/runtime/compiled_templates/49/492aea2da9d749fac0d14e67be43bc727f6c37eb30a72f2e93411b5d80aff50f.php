<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _includes/post-blocks */
class __TwigTemplate_1e6177725a2fc1aefd9f72345f3ab6107d6e9c73db57f8f1520de36f5828fde7 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_includes/post-blocks");
        // line 1
        echo "<div class=\"my-8\">
    ";
        // line 2
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["blocks"]) || array_key_exists("blocks", $context) ? $context["blocks"] : (function () { throw new RuntimeError('Variable "blocks" does not exist.', 2, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["block"]) {
            // line 3
            echo "        <div class=\"my-4\">
         ";
            // line 4
            if ((craft\helpers\Template::attribute($this->env, $this->source, $context["block"], "type", []) == "text")) {
                // line 5
                echo "            ";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["block"], "text", []), "html", null, true);
                echo "
         ";
            } elseif ((craft\helpers\Template::attribute($this->env, $this->source,             // line 6
$context["block"], "type", []) == "image")) {
                // line 7
                echo "            ";
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, $context["block"], "image", []), "all", [], "method"));
                foreach ($context['_seq'] as $context["_key"] => $context["image"]) {
                    // line 8
                    echo "                <img src=\"";
                    echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["image"], "url", []), "html", null, true);
                    echo "\" alt=\"";
                    echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["image"], "title", []), "html", null, true);
                    echo "\" />
            ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['image'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 10
                echo "         ";
            }
            // line 11
            echo "        </div>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['block'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 13
        echo "  </div>";
        // line 0
        craft\helpers\Template::endProfile("template", "_includes/post-blocks");
    }

    public function getTemplateName()
    {
        return "_includes/post-blocks";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  85 => 0,  83 => 13,  76 => 11,  73 => 10,  62 => 8,  57 => 7,  55 => 6,  50 => 5,  48 => 4,  45 => 3,  41 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<div class=\"my-8\">
    {% for block in blocks %}
        <div class=\"my-4\">
         {% if block.type == 'text' %}
            {{ block.text }}
         {% elseif  block.type == 'image' %}
            {% for image in block.image.all() %}
                <img src=\"{{ image.url }}\" alt=\"{{ image.title }}\" />
            {% endfor %}
         {% endif %}
        </div>
    {% endfor %}
  </div>", "_includes/post-blocks", "/Applications/MAMP/htdocs/craft/smsi/templates/_includes/post-blocks.twig");
    }
}
