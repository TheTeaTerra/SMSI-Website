<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* entries */
class __TwigTemplate_74a75c352f5ad9e79a3e0873aa865636af33cff25d28647738159a4924a5d6fe extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "_layouts/elementindex";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("template", "entries");
        // line 2
        $context["title"] = $this->extensions['craft\web\twig\Extension']->translateFilter("Entries", "app");
        // line 3
        $context["elementType"] = "craft\\elements\\Entry";
        // line 5
        craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 5, $this->source); })()), "registerTranslations", [0 => "app", 1 => [0 => "New entry"]], "method");
        // line 10
        if ((isset($context["sectionHandle"]) || array_key_exists("sectionHandle", $context))) {
            // line 11
            ob_start();
            // line 12
            echo "        window.defaultSectionHandle = \"";
            echo twig_escape_filter($this->env, twig_escape_filter($this->env, (isset($context["sectionHandle"]) || array_key_exists("sectionHandle", $context) ? $context["sectionHandle"] : (function () { throw new RuntimeError('Variable "sectionHandle" does not exist.', 12, $this->source); })()), "js"), "html", null, true);
            echo "\";
    ";
            Craft::$app->getView()->registerJs(ob_get_clean(), 3);
        }
        // line 1
        $this->parent = $this->loadTemplate("_layouts/elementindex", "entries", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        // line 0
        craft\helpers\Template::endProfile("template", "entries");
    }

    public function getTemplateName()
    {
        return "entries";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  63 => 0,  60 => 1,  53 => 12,  51 => 11,  49 => 10,  47 => 5,  45 => 3,  43 => 2,  41 => 0,  34 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends \"_layouts/elementindex\" %}
{% set title = \"Entries\"|t('app') %}
{% set elementType = 'craft\\\\elements\\\\Entry' %}

{% do view.registerTranslations('app', [
    'New entry',
]) %}


{% if sectionHandle is defined %}
    {% js %}
        window.defaultSectionHandle = \"{{ sectionHandle|e('js') }}\";
    {% endjs %}
{% endif %}
", "entries", "/Applications/MAMP/htdocs/craft/smsi/vendor/craftcms/cms/src/templates/entries/index.html");
    }
}
