<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _elements/sources */
class __TwigTemplate_1ad1894afcc6e2dedb23fc786ac3b23e9ef1902643612a9dbf01111d26598e64 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_elements/sources");
        // line 1
        ob_start();
        // line 2
        $context["keyPrefix"] = (($context["keyPrefix"]) ?? (""));
        // line 3
        echo "<ul>
    ";
        // line 4
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["sources"]) || array_key_exists("sources", $context) ? $context["sources"] : (function () { throw new RuntimeError('Variable "sources" does not exist.', 4, $this->source); })()));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["source"]) {
            // line 5
            echo "        ";
            if (craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "heading", [], "any", true, true)) {
                // line 6
                echo "            <li class=\"heading\"><span>";
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "heading", []), "site"), "html", null, true);
                echo "</span></li>
        ";
            } else {
                // line 8
                echo "            ";
                $context["key"] = (((craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "keyPath", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "keyPath", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "keyPath", [])) : (((isset($context["keyPrefix"]) || array_key_exists("keyPrefix", $context) ? $context["keyPrefix"] : (function () { throw new RuntimeError('Variable "keyPrefix" does not exist.', 8, $this->source); })()) . craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "key", []))));
                // line 9
                echo "            <li>";
                ob_start();
                // line 10
                echo "                <a data-key=\"";
                echo twig_escape_filter($this->env, (isset($context["key"]) || array_key_exists("key", $context) ? $context["key"] : (function () { throw new RuntimeError('Variable "key" does not exist.', 10, $this->source); })()), "html", null, true);
                echo "\"";
                // line 11
                if ((craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "hasThumbs", [], "any", true, true) && craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "hasThumbs", []))) {
                    echo " data-has-thumbs";
                }
                // line 12
                if (craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "structureId", [], "any", true, true)) {
                    echo " data-has-structure";
                }
                // line 13
                if (craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "defaultSort", [], "any", true, true)) {
                    $context["defaultSort"] = craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "defaultSort", []);
                    echo " data-default-sort=\"";
                    echo twig_escape_filter($this->env, ((twig_test_iterable((isset($context["defaultSort"]) || array_key_exists("defaultSort", $context) ? $context["defaultSort"] : (function () { throw new RuntimeError('Variable "defaultSort" does not exist.', 13, $this->source); })()))) ? (twig_join_filter((isset($context["defaultSort"]) || array_key_exists("defaultSort", $context) ? $context["defaultSort"] : (function () { throw new RuntimeError('Variable "defaultSort" does not exist.', 13, $this->source); })()), ":")) : ((isset($context["defaultSort"]) || array_key_exists("defaultSort", $context) ? $context["defaultSort"] : (function () { throw new RuntimeError('Variable "defaultSort" does not exist.', 13, $this->source); })()))), "html", null, true);
                    echo "\"";
                }
                // line 14
                if (craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "sites", [], "any", true, true)) {
                    echo " data-sites=\"";
                    echo twig_escape_filter($this->env, twig_join_filter(craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "sites", []), ","), "html", null, true);
                    echo "\"";
                }
                // line 15
                if (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "criteria", [], "any", false, true), "status", [], "any", true, true)) {
                    echo " data-override-status";
                }
                // line 16
                if (craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "data", [], "any", true, true)) {
                    // line 17
                    $context['_parent'] = $context;
                    $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "data", []));
                    foreach ($context['_seq'] as $context["dataKey"] => $context["dataVal"]) {
                        echo " data-";
                        echo twig_escape_filter($this->env, $context["dataKey"], "html", null, true);
                        echo "=\"";
                        echo twig_escape_filter($this->env, $context["dataVal"], "html", null, true);
                        echo "\"";
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['_iterated'], $context['dataKey'], $context['dataVal'], $context['_parent'], $context['loop']);
                    $context = array_intersect_key($context, $_parent) + $_parent;
                }
                // line 18
                echo ">
                        ";
                // line 19
                if (craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "status", [], "any", true, true)) {
                    // line 20
                    echo "                            <span class=\"status ";
                    echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "status", []), "html", null, true);
                    echo "\"></span>
                        ";
                } elseif (craft\helpers\Template::attribute($this->env, $this->source,                 // line 21
$context["source"], "icon", [], "any", true, true)) {
                    // line 22
                    echo "                            <span class=\"icon\">
                                ";
                    // line 23
                    echo (($this->extensions['craft\web\twig\Extension']->svgFunction(craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "icon", []), true, true)) ? ($this->extensions['craft\web\twig\Extension']->svgFunction(craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "icon", []), true, true)) : ((("<span data-icon='" . craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "icon", [])) . "'></span>")));
                    echo "
                            </span>
                        ";
                } elseif (craft\helpers\Template::attribute($this->env, $this->source,                 // line 25
$context["source"], "iconMask", [], "any", true, true)) {
                    // line 26
                    echo "                            <span class=\"icon icon-mask\">
                                ";
                    // line 27
                    echo (($this->extensions['craft\web\twig\Extension']->svgFunction(craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "iconMask", []), true, true)) ? ($this->extensions['craft\web\twig\Extension']->svgFunction(craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "iconMask", []), true, true)) : ((("<span data-icon='" . craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "iconMask", [])) . "'></span>")));
                    echo "
                            </span>
                        ";
                }
                // line 30
                echo "                        <span class=\"label\">";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "label", []), "html", null, true);
                echo "</span>
                        ";
                // line 31
                if (craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "badgeCount", [], "any", true, true)) {
                    // line 32
                    echo "                            <span class=\"badge\">";
                    echo twig_escape_filter($this->env, call_user_func_array($this->env->getFilter('number')->getCallable(), [craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "badgeCount", []), 0]), "html", null, true);
                    echo "</span>
                        ";
                }
                // line 34
                echo "                </a>
                ";
                // line 35
                if ((craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "nested", [], "any", true, true) &&  !twig_test_empty(craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "nested", [])))) {
                    // line 36
                    echo "                    <div class=\"toggle\"></div>
                    ";
                    // line 37
                    $this->loadTemplate("_elements/sources", "_elements/sources", 37)->display(twig_array_merge($context, ["keyPrefix" => (                    // line 38
(isset($context["key"]) || array_key_exists("key", $context) ? $context["key"] : (function () { throw new RuntimeError('Variable "key" does not exist.', 38, $this->source); })()) . "/"), "sources" => craft\helpers\Template::attribute($this->env, $this->source,                     // line 39
$context["source"], "nested", [])]));
                    // line 41
                    echo "                ";
                }
                // line 42
                echo "            ";
                echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
                echo "</li>
        ";
            }
            // line 44
            echo "    ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['source'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 45
        echo "</ul>
";
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
        // line 0
        craft\helpers\Template::endProfile("template", "_elements/sources");
    }

    public function getTemplateName()
    {
        return "_elements/sources";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  205 => 0,  201 => 45,  187 => 44,  181 => 42,  178 => 41,  176 => 39,  175 => 38,  174 => 37,  171 => 36,  169 => 35,  166 => 34,  160 => 32,  158 => 31,  153 => 30,  147 => 27,  144 => 26,  142 => 25,  137 => 23,  134 => 22,  132 => 21,  127 => 20,  125 => 19,  122 => 18,  108 => 17,  106 => 16,  102 => 15,  96 => 14,  89 => 13,  85 => 12,  81 => 11,  77 => 10,  74 => 9,  71 => 8,  65 => 6,  62 => 5,  45 => 4,  42 => 3,  40 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% spaceless %}
{% set keyPrefix = keyPrefix ?? '' %}
<ul>
    {% for source in sources %}
        {% if source.heading is defined %}
            <li class=\"heading\"><span>{{ source.heading|t('site') }}</span></li>
        {% else %}
            {% set key = source.keyPath ?? (keyPrefix ~ source.key) %}
            <li>{% spaceless %}
                <a data-key=\"{{ key }}\"
                    {%- if source.hasThumbs is defined and source.hasThumbs %} data-has-thumbs{% endif %}
                    {%- if source.structureId is defined %} data-has-structure{% endif %}
                    {%- if source.defaultSort is defined %}{% set defaultSort = source.defaultSort %} data-default-sort=\"{{ defaultSort is iterable ? defaultSort|join(':') : defaultSort }}\"{% endif %}
                    {%- if source.sites is defined %} data-sites=\"{{ source.sites|join(',') }}\"{% endif %}
                    {%- if source.criteria.status is defined %} data-override-status{% endif %}
                    {%- if source.data is defined -%}
                        {% for dataKey, dataVal in source.data %} data-{{ dataKey }}=\"{{ dataVal }}\"{% endfor %}
                    {%- endif %}>
                        {% if source.status is defined %}
                            <span class=\"status {{ source.status }}\"></span>
                        {% elseif source.icon is defined %}
                            <span class=\"icon\">
                                {{ (svg(source.icon, sanitize=true, namespace=true) ?: \"<span data-icon='#{source.icon}'></span>\")|raw }}
                            </span>
                        {% elseif source.iconMask is defined %}
                            <span class=\"icon icon-mask\">
                                {{ (svg(source.iconMask, sanitize=true, namespace=true) ?: \"<span data-icon='#{source.iconMask}'></span>\")|raw }}
                            </span>
                        {% endif %}
                        <span class=\"label\">{{ source.label }}</span>
                        {% if source.badgeCount is defined %}
                            <span class=\"badge\">{{ source.badgeCount|number(decimals=0) }}</span>
                        {% endif %}
                </a>
                {% if source.nested is defined and source.nested is not empty %}
                    <div class=\"toggle\"></div>
                    {% include \"_elements/sources\" with {
                        keyPrefix: key ~ '/',
                        sources: source.nested
                    } %}
                {% endif %}
            {% endspaceless %}</li>
        {% endif %}
    {% endfor %}
</ul>
{% endspaceless %}
", "_elements/sources", "/Applications/MAMP/htdocs/craft/smsi/vendor/craftcms/cms/src/templates/_elements/sources.html");
    }
}
