<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* partials/hero */
class __TwigTemplate_deb43f4afad9310d500339ce7318b47d54e86850644744c9c3b8167dfeb5a57d extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "partials/hero");
        // line 1
        echo "<section id=\"hero\" class=\"d-flex flex-column justify-content-center\">
    <div class=\"container\">
      <div class=\"row justify-content-center\">
        <div class=\"col-xl-8\">
          <h1>KnightOne - Create Bootstrap Website Template</h1>
          <h2>We are team of designers making websites with Bootstrap</h2>
          <a href=\"https://www.youtube.com/watch?v=jDDaplaOz7Q\" class=\"venobox play-btn mb-4\" data-vbtype=\"video\" data-autoplay=\"true\"></a>
        </div>
      </div>
    </div>
  </section>";
        // line 0
        craft\helpers\Template::endProfile("template", "partials/hero");
    }

    public function getTemplateName()
    {
        return "partials/hero";
    }

    public function getDebugInfo()
    {
        return array (  50 => 0,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<section id=\"hero\" class=\"d-flex flex-column justify-content-center\">
    <div class=\"container\">
      <div class=\"row justify-content-center\">
        <div class=\"col-xl-8\">
          <h1>KnightOne - Create Bootstrap Website Template</h1>
          <h2>We are team of designers making websites with Bootstrap</h2>
          <a href=\"https://www.youtube.com/watch?v=jDDaplaOz7Q\" class=\"venobox play-btn mb-4\" data-vbtype=\"video\" data-autoplay=\"true\"></a>
        </div>
      </div>
    </div>
  </section>", "partials/hero", "/Applications/MAMP/htdocs/craft/smsi/templates/partials/hero.twig");
    }
}
