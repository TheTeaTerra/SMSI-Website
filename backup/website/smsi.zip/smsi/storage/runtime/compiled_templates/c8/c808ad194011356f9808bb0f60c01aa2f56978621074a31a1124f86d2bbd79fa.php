<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _components/volumes/Local/settings */
class __TwigTemplate_04420ac873ec56e53cf8833c785aebecfb5b86aa9069eeb0b4af3649b2df219a extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_components/volumes/Local/settings");
        // line 1
        $macros["__internal_6080daa1e3fcdeb36275bc0780d979fe0661eb32a7bb889d0710bd71b663dab1"] = $this->macros["__internal_6080daa1e3fcdeb36275bc0780d979fe0661eb32a7bb889d0710bd71b663dab1"] = $this->loadTemplate("_includes/forms", "_components/volumes/Local/settings", 1)->unwrap();
        // line 2
        echo "
";
        // line 3
        echo twig_call_macro($macros["__internal_6080daa1e3fcdeb36275bc0780d979fe0661eb32a7bb889d0710bd71b663dab1"], "macro_autosuggestField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("File System Path", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("The path to the volume’s directory on the file system.", "app"), "id" => "path", "class" => "ltr", "name" => "path", "suggestEnvVars" => true, "suggestAliases" => true, "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 11
(isset($context["volume"]) || array_key_exists("volume", $context) ? $context["volume"] : (function () { throw new RuntimeError('Variable "volume" does not exist.', 11, $this->source); })()), "path", []), "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 12
(isset($context["volume"]) || array_key_exists("volume", $context) ? $context["volume"] : (function () { throw new RuntimeError('Variable "volume" does not exist.', 12, $this->source); })()), "getErrors", [0 => "path"], "method"), "required" => true, "placeholder" => $this->extensions['craft\web\twig\Extension']->translateFilter("/path/to/folder", "app")]], 3, $context, $this->getSourceContext());
        // line 15
        echo "
";
        // line 0
        craft\helpers\Template::endProfile("template", "_components/volumes/Local/settings");
    }

    public function getTemplateName()
    {
        return "_components/volumes/Local/settings";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  50 => 0,  47 => 15,  45 => 12,  44 => 11,  43 => 3,  40 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% from \"_includes/forms\" import autosuggestField %}

{{ autosuggestField({
    label: \"File System Path\"|t('app'),
    instructions: \"The path to the volume’s directory on the file system.\"|t('app'),
    id: 'path',
    class: 'ltr',
    name: 'path',
    suggestEnvVars: true,
    suggestAliases: true,
    value: volume.path,
    errors: volume.getErrors('path'),
    required: true,
    placeholder: \"/path/to/folder\"|t('app')
}) }}
", "_components/volumes/Local/settings", "/Applications/MAMP/htdocs/craft/smsi/vendor/craftcms/cms/src/templates/_components/volumes/Local/settings.html");
    }
}
