<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _includes/listing */
class __TwigTemplate_45374fe5b171c5fbf9e6101ed89e94437298a379facef4017e9405d2607f55bd extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_includes/listing");
        // line 1
        echo "<div class=\"post-list my-10 flex\">
";
        // line 2
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["posts"]) || array_key_exists("posts", $context) ? $context["posts"] : (function () { throw new RuntimeError('Variable "posts" does not exist.', 2, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["post"]) {
            // line 3
            echo "    <a href=\"";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["post"], "url", []), "html", null, true);
            echo "\" class=\"flex shadow-lg rounded items-center justify-center overflow-hidden\">
        ";
            // line 4
            if (twig_length_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["post"], "featureImage", []))) {
                // line 5
                echo "            ";
                $context["image"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, $context["post"], "featureImage", []), "one", [], "method");
                // line 6
                echo "            <div  class=\"w-1/4\">
                <img src=\"";
                // line 7
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["image"]) || array_key_exists("image", $context) ? $context["image"] : (function () { throw new RuntimeError('Variable "image" does not exist.', 7, $this->source); })()), "getUrl", [0 => ["width" => 300, "height" => 300]], "method"), "html", null, true);
                echo "\" 
                    alt=\"";
                // line 8
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["image"]) || array_key_exists("image", $context) ? $context["image"] : (function () { throw new RuntimeError('Variable "image" does not exist.', 8, $this->source); })()), "title", []), "html", null, true);
                echo "\" class=\"block\"
                />
            </div>
        ";
            }
            // line 12
            echo "        <span class=\"title w-3/4 p-4\">";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["post"], "title", []), "html", null, true);
            echo "</span>
    </a>
";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['post'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 15
        echo "</div>";
        // line 0
        craft\helpers\Template::endProfile("template", "_includes/listing");
    }

    public function getTemplateName()
    {
        return "_includes/listing";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  81 => 0,  79 => 15,  69 => 12,  62 => 8,  58 => 7,  55 => 6,  52 => 5,  50 => 4,  45 => 3,  41 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<div class=\"post-list my-10 flex\">
{% for post in posts %}
    <a href=\"{{ post.url }}\" class=\"flex shadow-lg rounded items-center justify-center overflow-hidden\">
        {% if post.featureImage|length %}
            {% set image = post.featureImage.one() %}
            <div  class=\"w-1/4\">
                <img src=\"{{ image.getUrl({ width: 300, height: 300 }) }}\" 
                    alt=\"{{ image.title }}\" class=\"block\"
                />
            </div>
        {% endif %}
        <span class=\"title w-3/4 p-4\">{{ post.title }}</span>
    </a>
{% endfor %}
</div>", "_includes/listing", "/Applications/MAMP/htdocs/craft/smsi/templates/_includes/listing.twig");
    }
}
