<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _elements/element */
class __TwigTemplate_ff98834441a0c060d7a7f3f863ee4c5bff9e5ecfae5d42fee603baf4c698400c extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_elements/element");
        // line 1
        echo \Craft::$app->getView()->invokeHook("cp.elements.element", $context);

        // line 0
        craft\helpers\Template::endProfile("template", "_elements/element");
    }

    public function getTemplateName()
    {
        return "_elements/element";
    }

    public function getDebugInfo()
    {
        return array (  41 => 0,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% hook \"cp.elements.element\" %}
", "_elements/element", "/Applications/MAMP/htdocs/craft/smsi/vendor/craftcms/cms/src/templates/_elements/element.html");
    }
}
