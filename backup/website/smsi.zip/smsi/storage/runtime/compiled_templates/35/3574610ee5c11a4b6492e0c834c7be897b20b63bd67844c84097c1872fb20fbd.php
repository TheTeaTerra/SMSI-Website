<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _includes/forms/lightswitch */
class __TwigTemplate_fe1b58d9bf95c4c44a1253f33bfe1e2d180a05b9e79583baeeb909040c20a122 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_includes/forms/lightswitch");
        // line 1
        $context["on"] = (($context["on"]) ?? (false));
        // line 2
        $context["indeterminate"] = ( !(isset($context["on"]) || array_key_exists("on", $context) ? $context["on"] : (function () { throw new RuntimeError('Variable "on" does not exist.', 2, $this->source); })()) && (($context["indeterminate"]) ?? (false)));
        // line 3
        $context["value"] = (($context["value"]) ?? ("1"));
        // line 4
        $context["indeterminateValue"] = (($context["indeterminateValue"]) ?? ("-"));
        // line 5
        $context["small"] = (($context["small"]) ?? (false));
        // line 6
        $context["toggle"] = (($context["toggle"]) ?? (null));
        // line 7
        $context["reverseToggle"] = (($context["reverseToggle"]) ?? (null));
        // line 8
        $context["disabled"] = (((($context["disabled"]) ?? (false))) ? (true) : (false));
        // line 10
        $context["containerAttributes"] = $this->extensions['craft\web\twig\Extension']->mergeFilter(["id" => ((        // line 11
$context["id"]) ?? (null)), "class" => $this->extensions['craft\web\twig\Extension']->filterFilter([0 => "lightswitch", 1 => ((        // line 14
(isset($context["on"]) || array_key_exists("on", $context) ? $context["on"] : (function () { throw new RuntimeError('Variable "on" does not exist.', 14, $this->source); })())) ? ("on") : ("")), 2 => ((        // line 15
(isset($context["indeterminate"]) || array_key_exists("indeterminate", $context) ? $context["indeterminate"] : (function () { throw new RuntimeError('Variable "indeterminate" does not exist.', 15, $this->source); })())) ? ("indeterminate") : ("")), 3 => ((        // line 16
(isset($context["small"]) || array_key_exists("small", $context) ? $context["small"] : (function () { throw new RuntimeError('Variable "small" does not exist.', 16, $this->source); })())) ? ("small") : ("")), 4 => (((        // line 17
(isset($context["toggle"]) || array_key_exists("toggle", $context) ? $context["toggle"] : (function () { throw new RuntimeError('Variable "toggle" does not exist.', 17, $this->source); })()) || (isset($context["reverseToggle"]) || array_key_exists("reverseToggle", $context) ? $context["reverseToggle"] : (function () { throw new RuntimeError('Variable "reverseToggle" does not exist.', 17, $this->source); })()))) ? ("fieldtoggle") : ("")), 5 => ((        // line 18
(isset($context["disabled"]) || array_key_exists("disabled", $context) ? $context["disabled"] : (function () { throw new RuntimeError('Variable "disabled" does not exist.', 18, $this->source); })())) ? ("disabled") : (""))]), "tabindex" => "0", "data" => ["value" => (((        // line 22
(isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 22, $this->source); })()) != "1")) ? ((isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 22, $this->source); })())) : (false)), "indeterminate-value" => (((        // line 23
(isset($context["indeterminateValue"]) || array_key_exists("indeterminateValue", $context) ? $context["indeterminateValue"] : (function () { throw new RuntimeError('Variable "indeterminateValue" does not exist.', 23, $this->source); })()) != "-")) ? ((isset($context["indeterminateValue"]) || array_key_exists("indeterminateValue", $context) ? $context["indeterminateValue"] : (function () { throw new RuntimeError('Variable "indeterminateValue" does not exist.', 23, $this->source); })())) : (false)), "target" => ((        // line 24
(isset($context["toggle"]) || array_key_exists("toggle", $context) ? $context["toggle"] : (function () { throw new RuntimeError('Variable "toggle" does not exist.', 24, $this->source); })())) ? ((isset($context["toggle"]) || array_key_exists("toggle", $context) ? $context["toggle"] : (function () { throw new RuntimeError('Variable "toggle" does not exist.', 24, $this->source); })())) : (false)), "reverse-target" => ((        // line 25
(isset($context["reverseToggle"]) || array_key_exists("reverseToggle", $context) ? $context["reverseToggle"] : (function () { throw new RuntimeError('Variable "reverseToggle" does not exist.', 25, $this->source); })())) ? ((isset($context["reverseToggle"]) || array_key_exists("reverseToggle", $context) ? $context["reverseToggle"] : (function () { throw new RuntimeError('Variable "reverseToggle" does not exist.', 25, $this->source); })())) : (false))], "aria" => ["labelledby" => ((        // line 28
$context["labelId"]) ?? (null))]], ((        // line 30
$context["containerAttributes"]) ?? ([])), true);
        // line 32
        if (        $this->hasBlock("attr", $context, $blocks)) {
            // line 33
            $context["containerAttributes"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["containerAttributes"]) || array_key_exists("containerAttributes", $context) ? $context["containerAttributes"] : (function () { throw new RuntimeError('Variable "containerAttributes" does not exist.', 33, $this->source); })()), $this->extensions['craft\web\twig\Extension']->parseAttrFilter((("<div " .             $this->renderBlock("attr", $context, $blocks)) . ">")), true);
        }
        // line 35
        echo "
<div ";
        // line 36
        echo craft\helpers\Html::renderTagAttributes((isset($context["containerAttributes"]) || array_key_exists("containerAttributes", $context) ? $context["containerAttributes"] : (function () { throw new RuntimeError('Variable "containerAttributes" does not exist.', 36, $this->source); })()));
        echo ">
    <div class=\"lightswitch-container\">
        <div class=\"handle\"></div>
    </div>
    ";
        // line 40
        if ((isset($context["name"]) || array_key_exists("name", $context))) {
            // line 41
            echo craft\helpers\Html::hiddenInput((isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 41, $this->source); })()), (((isset($context["on"]) || array_key_exists("on", $context) ? $context["on"] : (function () { throw new RuntimeError('Variable "on" does not exist.', 41, $this->source); })())) ? ((isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 41, $this->source); })())) : ((((isset($context["indeterminate"]) || array_key_exists("indeterminate", $context) ? $context["indeterminate"] : (function () { throw new RuntimeError('Variable "indeterminate" does not exist.', 41, $this->source); })())) ? ((isset($context["indeterminateValue"]) || array_key_exists("indeterminateValue", $context) ? $context["indeterminateValue"] : (function () { throw new RuntimeError('Variable "indeterminateValue" does not exist.', 41, $this->source); })())) : ("")))), ["disabled" => (isset($context["disabled"]) || array_key_exists("disabled", $context) ? $context["disabled"] : (function () { throw new RuntimeError('Variable "disabled" does not exist.', 41, $this->source); })())]);
        }
        // line 43
        echo "</div>
";
        // line 0
        craft\helpers\Template::endProfile("template", "_includes/forms/lightswitch");
    }

    public function getTemplateName()
    {
        return "_includes/forms/lightswitch";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  91 => 0,  88 => 43,  85 => 41,  83 => 40,  76 => 36,  73 => 35,  70 => 33,  68 => 32,  66 => 30,  65 => 28,  64 => 25,  63 => 24,  62 => 23,  61 => 22,  60 => 18,  59 => 17,  58 => 16,  57 => 15,  56 => 14,  55 => 11,  54 => 10,  52 => 8,  50 => 7,  48 => 6,  46 => 5,  44 => 4,  42 => 3,  40 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{%- set on = on ?? false %}
{%- set indeterminate = not on and (indeterminate ?? false) %}
{%- set value = value ?? '1' %}
{%- set indeterminateValue = indeterminateValue ?? '-' %}
{%- set small = small ?? false %}
{%- set toggle = toggle ?? null %}
{%- set reverseToggle = reverseToggle ?? null %}
{%- set disabled = (disabled ?? false) ? true : false %}

{%- set containerAttributes = {
    id: id ?? null,
    class: [
        'lightswitch',
        on ? 'on',
        indeterminate ? 'indeterminate',
        small ? 'small',
        toggle or reverseToggle ? 'fieldtoggle',
        disabled ? 'disabled',
    ]|filter,
    tabindex: '0',
    data: {
        'value': value != '1' ? value : false,
        'indeterminate-value': indeterminateValue != '-' ? indeterminateValue : false,
        'target': toggle ?: false,
        'reverse-target': reverseToggle ?: false,
    },
    aria: {
        labelledby: labelId ?? null,
    },
}|merge(containerAttributes ?? [], recursive=true) %}

{%- if block('attr') is defined %}
    {%- set containerAttributes = containerAttributes|merge(('<div ' ~ block('attr') ~ '>')|parseAttr, recursive=true) %}
{% endif %}

<div {{ attr(containerAttributes) }}>
    <div class=\"lightswitch-container\">
        <div class=\"handle\"></div>
    </div>
    {% if name is defined -%}
        {{ hiddenInput(name, on ? value : (indeterminate ? indeterminateValue : ''), {disabled: disabled}) }}
    {%- endif %}
</div>
", "_includes/forms/lightswitch", "/Applications/MAMP/htdocs/craft/smsi/vendor/craftcms/cms/src/templates/_includes/forms/lightswitch.html");
    }
}
