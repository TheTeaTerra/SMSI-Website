<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* settings/sections/_entrytypes/index */
class __TwigTemplate_5971c3cc0b4ed4126cfde25752bb0c1c68cd8381ba4a911084726b5ba9b8e03b extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'actionButton' => [$this, 'block_actionButton'],
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "_layouts/cp";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("template", "settings/sections/_entrytypes/index");
        // line 3
        craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 3, $this->source); })()), "registerAssetBundle", [0 => "craft\\web\\assets\\admintable\\AdminTableAsset"], "method");
        // line 5
        craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 5, $this->source); })()), "registerTranslations", [0 => "app", 1 => [0 => "Name", 1 => "Handle"]], "method");
        // line 10
        $context["entryTypes"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 10, $this->source); })()), "getEntryTypes", [], "method");
        // line 11
        $context["multiple"] = (twig_length_filter($this->env, (isset($context["entryTypes"]) || array_key_exists("entryTypes", $context) ? $context["entryTypes"] : (function () { throw new RuntimeError('Variable "entryTypes" does not exist.', 11, $this->source); })())) > 1);
        // line 23
        $context["tableData"] = [];
        // line 24
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["entryTypes"]) || array_key_exists("entryTypes", $context) ? $context["entryTypes"] : (function () { throw new RuntimeError('Variable "entryTypes" does not exist.', 24, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["entryType"]) {
            // line 25
            $context["tableData"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["tableData"]) || array_key_exists("tableData", $context) ? $context["tableData"] : (function () { throw new RuntimeError('Variable "tableData" does not exist.', 25, $this->source); })()), [0 => ["id" => craft\helpers\Template::attribute($this->env, $this->source,             // line 26
$context["entryType"], "id", []), "title" => $this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source,             // line 27
$context["entryType"], "name", []), "site"), "url" => craft\helpers\UrlHelper::url(((("settings/sections/" . craft\helpers\Template::attribute($this->env, $this->source,             // line 28
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 28, $this->source); })()), "id", [])) . "/entrytypes/") . craft\helpers\Template::attribute($this->env, $this->source, $context["entryType"], "id", []))), "name" => twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source,             // line 29
$context["entryType"], "name", []), "site")), "handle" => craft\helpers\Template::attribute($this->env, $this->source,             // line 30
$context["entryType"], "handle", [])]]);
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['entryType'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 34
        ob_start();
        // line 35
        echo "var columns = [
    { name: '__slot:title', title: Craft.t('app', 'Name') },
    { name: '__slot:handle', title: Craft.t('app', 'Handle') },
];

new Craft.VueAdminTable({
    columns: columns,
    container: '#entrytypes-vue-admin-table',
    deleteAction: '";
        // line 43
        echo (((craft\helpers\Template::attribute($this->env, $this->source, (isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 43, $this->source); })()), "type", []) != "single")) ? ("sections/delete-entry-type") : (""));
        echo "',
    reorderAction: '";
        // line 44
        echo (((craft\helpers\Template::attribute($this->env, $this->source, (isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 44, $this->source); })()), "type", []) != "single")) ? ("sections/reorder-entry-types") : (""));
        echo "',
    tableData: ";
        // line 45
        echo $this->extensions['craft\web\twig\Extension']->jsonEncodeFilter((isset($context["tableData"]) || array_key_exists("tableData", $context) ? $context["tableData"] : (function () { throw new RuntimeError('Variable "tableData" does not exist.', 45, $this->source); })()));
        echo ",
    minItems: 1
});
";
        Craft::$app->getView()->registerJs(ob_get_clean(), 3);
        // line 1
        $this->parent = $this->loadTemplate("_layouts/cp", "settings/sections/_entrytypes/index", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        // line 0
        craft\helpers\Template::endProfile("template", "settings/sections/_entrytypes/index");
    }

    // line 13
    public function block_actionButton($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("block", "actionButton");
        // line 14
        echo "    ";
        if ((craft\helpers\Template::attribute($this->env, $this->source, (isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 14, $this->source); })()), "type", []) != "single")) {
            // line 15
            echo "        <a href=\"";
            echo twig_escape_filter($this->env, craft\helpers\UrlHelper::url((("settings/sections/" . craft\helpers\Template::attribute($this->env, $this->source, (isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 15, $this->source); })()), "id", [])) . "/entrytypes/new")), "html", null, true);
            echo "\" class=\"btn submit add icon\">";
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("New entry type", "app"), "html", null, true);
            echo "</a>
    ";
        }
        // line 0
        craft\helpers\Template::endProfile("block", "actionButton");
    }

    // line 19
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("block", "content");
        // line 20
        echo "    <div id=\"entrytypes-vue-admin-table\"></div>
";
        // line 0
        craft\helpers\Template::endProfile("block", "content");
    }

    public function getTemplateName()
    {
        return "settings/sections/_entrytypes/index";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  134 => 0,  131 => 20,  129 => 0,  125 => 19,  121 => 0,  113 => 15,  110 => 14,  108 => 0,  104 => 13,  100 => 0,  97 => 1,  90 => 45,  86 => 44,  82 => 43,  72 => 35,  70 => 34,  64 => 30,  63 => 29,  62 => 28,  61 => 27,  60 => 26,  59 => 25,  55 => 24,  53 => 23,  51 => 11,  49 => 10,  47 => 5,  45 => 3,  43 => 0,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends \"_layouts/cp\" %}

{% do view.registerAssetBundle('craft\\\\web\\\\assets\\\\admintable\\\\AdminTableAsset') -%}

{% do view.registerTranslations('app', [
    \"Name\",
    \"Handle\",
]) %}

{% set entryTypes = section.getEntryTypes() %}
{% set multiple  = (entryTypes|length > 1) %}

{% block actionButton %}
    {% if section.type != 'single' %}
        <a href=\"{{ url('settings/sections/' ~ section.id ~ '/entrytypes/new') }}\" class=\"btn submit add icon\">{{ \"New entry type\"|t('app') }}</a>
    {% endif %}
{% endblock %}

{% block content %}
    <div id=\"entrytypes-vue-admin-table\"></div>
{% endblock %}

{% set tableData = [] %}
{% for entryType in entryTypes %}
    {% set tableData = tableData|merge([{
        id: entryType.id,
        title: entryType.name|t('site'),
        url: url('settings/sections/' ~ section.id ~ '/entrytypes/' ~ entryType.id),
        name: entryType.name|t('site')|e,
        handle: entryType.handle,
    }]) %}
{% endfor %}

{% js %}
var columns = [
    { name: '__slot:title', title: Craft.t('app', 'Name') },
    { name: '__slot:handle', title: Craft.t('app', 'Handle') },
];

new Craft.VueAdminTable({
    columns: columns,
    container: '#entrytypes-vue-admin-table',
    deleteAction: '{{ section.type != 'single' ? 'sections/delete-entry-type' : '' }}',
    reorderAction: '{{ section.type != 'single' ? 'sections/reorder-entry-types' : '' }}',
    tableData: {{ tableData|json_encode|raw }},
    minItems: 1
});
{% endjs %}
", "settings/sections/_entrytypes/index", "/Applications/MAMP/htdocs/craft/smsi/vendor/craftcms/cms/src/templates/settings/sections/_entrytypes/index.html");
    }
}
