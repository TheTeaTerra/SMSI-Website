<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* settings/sites/_edit */
class __TwigTemplate_cba2bd88320e490d42d595e7e06e9b03b46f0ce57966f1b3615ed5ca81b0279f extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "_layouts/cp";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("template", "settings/sites/_edit");
        // line 3
        $context["fullPageForm"] = true;
        // line 5
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms", "settings/sites/_edit", 5)->unwrap();
        // line 107
        if ( !craft\helpers\Template::attribute($this->env, $this->source, (isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 107, $this->source); })()), "handle", [])) {
            // line 108
            ob_start();
            // line 109
            echo "        new Craft.HandleGenerator('#name', '#handle');
    ";
            Craft::$app->getView()->registerJs(ob_get_clean(), 3);
        }
        // line 1
        $this->parent = $this->loadTemplate("_layouts/cp", "settings/sites/_edit", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        // line 0
        craft\helpers\Template::endProfile("template", "settings/sites/_edit");
    }

    // line 8
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("block", "content");
        // line 9
        echo "    ";
        echo craft\helpers\Html::actionInput("sites/save-site");
        echo "
    ";
        // line 10
        echo craft\helpers\Html::redirectInput("settings/sites");
        echo "
    ";
        // line 11
        if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 11, $this->source); })()), "id", [])) {
            echo craft\helpers\Html::hiddenInput("siteId", craft\helpers\Template::attribute($this->env, $this->source, (isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 11, $this->source); })()), "id", []));
        }
        // line 12
        echo "
    ";
        // line 13
        echo twig_call_macro($macros["forms"], "macro_selectField", [["first" => true, "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Group", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Which group should this site belong to?", "app"), "warning" => (((craft\helpers\Template::attribute($this->env, $this->source,         // line 17
(isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 17, $this->source); })()), "id", []) && craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 17, $this->source); })()), "app", []), "isMultiSite", []))) ? ($this->extensions['craft\web\twig\Extension']->translateFilter("Changing this may result in data loss.", "app")) : ("")), "id" => "group", "name" => "group", "options" =>         // line 20
(isset($context["groupOptions"]) || array_key_exists("groupOptions", $context) ? $context["groupOptions"] : (function () { throw new RuntimeError('Variable "groupOptions" does not exist.', 20, $this->source); })()), "value" =>         // line 21
(isset($context["groupId"]) || array_key_exists("groupId", $context) ? $context["groupId"] : (function () { throw new RuntimeError('Variable "groupId" does not exist.', 21, $this->source); })())]], 13, $context, $this->getSourceContext());
        // line 22
        echo "

    <div id=\"site-settings\">
        ";
        // line 25
        echo twig_call_macro($macros["forms"], "macro_textField", [["first" => true, "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Name", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("What this site will be called in the control panel.", "app"), "id" => "name", "name" => "name", "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 31
(isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 31, $this->source); })()), "name", []), "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 32
(isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 32, $this->source); })()), "getErrors", [0 => "name"], "method"), "autofocus" => true, "required" => true]], 25, $context, $this->getSourceContext());
        // line 35
        echo "

        ";
        // line 37
        echo twig_call_macro($macros["forms"], "macro_textField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Handle", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("How you’ll refer to this site in the templates.", "app"), "id" => "handle", "name" => "handle", "class" => "code", "autocorrect" => false, "autocapitalize" => false, "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 45
(isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 45, $this->source); })()), "handle", []), "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 46
(isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 46, $this->source); })()), "getErrors", [0 => "handle"], "method"), "required" => true]], 37, $context, $this->getSourceContext());
        // line 48
        echo "

        ";
        // line 50
        if ( !craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 50, $this->source); })()), "app", []), "i18n", []), "getIsIntlLoaded", [], "method")) {
            // line 51
            echo "            ";
            $context["languageWarning"] = $this->extensions['craft\web\twig\Extension']->translateFilter("Enable the [Intl extension]({link1}) or install additional [locale data files]({link2}) for more language options.", "app", ["link1" => "http://php.net/manual/en/book.intl.php", "link2" => "https://github.com/craftcms/locales"]);
            // line 55
            echo "        ";
        }
        // line 56
        echo "
        ";
        // line 57
        echo twig_call_macro($macros["forms"], "macro_selectField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Language", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("The language content in this site will use.", "app"), "id" => "language", "name" => "language", "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 62
(isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 62, $this->source); })()), "language", []), "options" =>         // line 63
(isset($context["languageOptions"]) || array_key_exists("languageOptions", $context) ? $context["languageOptions"] : (function () { throw new RuntimeError('Variable "languageOptions" does not exist.', 63, $this->source); })()), "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 64
(isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 64, $this->source); })()), "getErrors", [0 => "language"], "method"), "warning" => ((        // line 65
$context["languageWarning"]) ?? (null))]], 57, $context, $this->getSourceContext());
        // line 66
        echo "

        ";
        // line 68
        if (((craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 68, $this->source); })()), "app", []), "isMultiSite", []) ||  !craft\helpers\Template::attribute($this->env, $this->source, (isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 68, $this->source); })()), "id", [])) &&  !craft\helpers\Template::attribute($this->env, $this->source, (isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 68, $this->source); })()), "primary", []))) {
            // line 69
            echo "            ";
            echo twig_call_macro($macros["forms"], "macro_lightswitchField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Make this the primary site?", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("The primary site will be loaded by default on the front end.", "app"), "id" => "primary", "name" => "primary", "on" => craft\helpers\Template::attribute($this->env, $this->source,             // line 74
(isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 74, $this->source); })()), "primary", [])]], 69, $context, $this->getSourceContext());
            // line 75
            echo "
        ";
        } else {
            // line 77
            echo "            ";
            echo craft\helpers\Html::hiddenInput("primary", "1");
            echo "
        ";
        }
        // line 79
        echo "
        <hr>

        ";
        // line 82
        echo twig_call_macro($macros["forms"], "macro_checkboxField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("This site has its own base URL", "app"), "id" => "has-urls", "name" => "hasUrls", "checked" => craft\helpers\Template::attribute($this->env, $this->source,         // line 86
(isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 86, $this->source); })()), "hasUrls", []), "toggle" => "url-settings"]], 82, $context, $this->getSourceContext());
        // line 88
        echo "

        <div id=\"url-settings\" class=\"nested-fields";
        // line 90
        if ( !craft\helpers\Template::attribute($this->env, $this->source, (isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 90, $this->source); })()), "hasUrls", [])) {
            echo " hidden";
        }
        echo "\">
            ";
        // line 91
        echo twig_call_macro($macros["forms"], "macro_autosuggestField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Base URL", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("The base URL for the site.", "app"), "id" => "base-url", "class" => "ltr", "suggestEnvVars" => true, "suggestAliases" => true, "name" => "baseUrl", "value" => ((craft\helpers\Template::attribute($this->env, $this->source,         // line 99
(isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 99, $this->source); })()), "originalBaseUrl", [])) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 99, $this->source); })()), "originalBaseUrl", [])) : (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 99, $this->source); })()), "baseUrl", []))), "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 100
(isset($context["site"]) || array_key_exists("site", $context) ? $context["site"] : (function () { throw new RuntimeError('Variable "site" does not exist.', 100, $this->source); })()), "getErrors", [0 => "baseUrl"], "method")]], 91, $context, $this->getSourceContext());
        // line 101
        echo "
        </div>
    </div>
";
        // line 0
        craft\helpers\Template::endProfile("block", "content");
    }

    public function getTemplateName()
    {
        return "settings/sites/_edit";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  176 => 0,  171 => 101,  169 => 100,  168 => 99,  167 => 91,  161 => 90,  157 => 88,  155 => 86,  154 => 82,  149 => 79,  143 => 77,  139 => 75,  137 => 74,  135 => 69,  133 => 68,  129 => 66,  127 => 65,  126 => 64,  125 => 63,  124 => 62,  123 => 57,  120 => 56,  117 => 55,  114 => 51,  112 => 50,  108 => 48,  106 => 46,  105 => 45,  104 => 37,  100 => 35,  98 => 32,  97 => 31,  96 => 25,  91 => 22,  89 => 21,  88 => 20,  87 => 17,  86 => 13,  83 => 12,  79 => 11,  75 => 10,  70 => 9,  68 => 0,  64 => 8,  60 => 0,  57 => 1,  52 => 109,  50 => 108,  48 => 107,  46 => 5,  44 => 3,  42 => 0,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends \"_layouts/cp\" %}

{% set fullPageForm = true %}

{% import \"_includes/forms\" as forms %}


{% block content %}
    {{ actionInput('sites/save-site') }}
    {{ redirectInput('settings/sites') }}
    {% if site.id %}{{ hiddenInput('siteId', site.id) }}{% endif %}

    {{ forms.selectField({
        first: true,
        label: \"Group\"|t('app'),
        instructions: \"Which group should this site belong to?\"|t('app'),
        warning: site.id and craft.app.isMultiSite ? 'Changing this may result in data loss.'|t('app'),
        id: 'group',
        name: 'group',
        options: groupOptions,
        value: groupId
    }) }}

    <div id=\"site-settings\">
        {{ forms.textField({
            first: true,
            label: \"Name\"|t('app'),
            instructions: \"What this site will be called in the control panel.\"|t('app'),
            id: 'name',
            name: 'name',
            value: site.name,
            errors: site.getErrors('name'),
            autofocus: true,
            required: true,
        }) }}

        {{ forms.textField({
            label: \"Handle\"|t('app'),
            instructions: \"How you’ll refer to this site in the templates.\"|t('app'),
            id: 'handle',
            name: 'handle',
            class: 'code',
            autocorrect: false,
            autocapitalize: false,
            value: site.handle,
            errors: site.getErrors('handle'),
            required: true
        }) }}

        {% if not craft.app.i18n.getIsIntlLoaded() %}
            {% set languageWarning = 'Enable the [Intl extension]({link1}) or install additional [locale data files]({link2}) for more language options.'|t('app', {
                link1: 'http://php.net/manual/en/book.intl.php',
                link2: 'https://github.com/craftcms/locales'
            }) %}
        {% endif %}

        {{ forms.selectField({
            label: \"Language\"|t('app'),
            instructions: \"The language content in this site will use.\"|t('app'),
            id: 'language',
            name: 'language',
            value: site.language,
            options: languageOptions,
            errors: site.getErrors('language'),
            warning: languageWarning ?? null
        }) }}

        {% if (craft.app.isMultiSite or not site.id) and not site.primary %}
            {{ forms.lightswitchField({
                label: \"Make this the primary site?\"|t('app'),
                instructions: \"The primary site will be loaded by default on the front end.\"|t('app'),
                id: 'primary',
                name: 'primary',
                on: site.primary
            }) }}
        {% else %}
            {{ hiddenInput('primary', '1') }}
        {% endif %}

        <hr>

        {{ forms.checkboxField({
            label: \"This site has its own base URL\"|t('app'),
            id: 'has-urls',
            name: 'hasUrls',
            checked: site.hasUrls,
            toggle: 'url-settings'
        }) }}

        <div id=\"url-settings\" class=\"nested-fields{% if not site.hasUrls %} hidden{% endif %}\">
            {{ forms.autosuggestField({
                label: \"Base URL\"|t('app'),
                instructions: \"The base URL for the site.\"|t('app'),
                id: 'base-url',
                class: 'ltr',
                suggestEnvVars: true,
                suggestAliases: true,
                name: 'baseUrl',
                value: site.originalBaseUrl ?: site.baseUrl,
                errors: site.getErrors('baseUrl')
            }) }}
        </div>
    </div>
{% endblock %}


{% if not site.handle %}
    {% js %}
        new Craft.HandleGenerator('#name', '#handle');
    {% endjs %}
{% endif %}
", "settings/sites/_edit", "/Applications/MAMP/htdocs/craft/smsi/vendor/craftcms/cms/src/templates/settings/sites/_edit.html");
    }
}
