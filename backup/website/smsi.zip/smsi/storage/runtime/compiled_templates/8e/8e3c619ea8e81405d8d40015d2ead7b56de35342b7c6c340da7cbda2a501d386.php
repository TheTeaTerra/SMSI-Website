<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _components/utilities/DeprecationErrors */
class __TwigTemplate_532808a21fb2ab50d3bd915533e61af60e5a179e75e88970d1ca9e838d6ec0c1 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_components/utilities/DeprecationErrors");
        // line 1
        if ((isset($context["logs"]) || array_key_exists("logs", $context) ? $context["logs"] : (function () { throw new RuntimeError('Variable "logs" does not exist.', 1, $this->source); })())) {
            // line 2
            echo "    <div class=\"buttons first\">
        <div id=\"clearall\" class=\"btn submit\">";
            // line 3
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Clear all", "app"), "html", null, true);
            echo "</div>
    </div>
";
        }
        // line 6
        echo "

<div class=\"readable\">
    <p id=\"nologs\"";
        // line 9
        if ((isset($context["logs"]) || array_key_exists("logs", $context) ? $context["logs"] : (function () { throw new RuntimeError('Variable "logs" does not exist.', 9, $this->source); })())) {
            echo " class=\"hidden\"";
        }
        echo ">";
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("No deprecation errors to report!", "app"), "html", null, true);
        echo "</p>

    ";
        // line 11
        if ((isset($context["logs"]) || array_key_exists("logs", $context) ? $context["logs"] : (function () { throw new RuntimeError('Variable "logs" does not exist.', 11, $this->source); })())) {
            // line 12
            echo "        <table id=\"deprecationerrors\" class=\"data fullwidth fixed-layout\">
            <thead>
                <tr>
                    <th>";
            // line 15
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Message", "app"), "html", null, true);
            echo "</th>
                    <th>";
            // line 16
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Origin", "app"), "html", null, true);
            echo "</th>
                    <th class=\"nowrap\">";
            // line 17
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Last Occurrence", "app"), "html", null, true);
            echo "</th>
                    <th class=\"nowrap\">";
            // line 18
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Stack Trace", "app"), "html", null, true);
            echo "</th>
                    <th style=\"width: 14px;\"></th>
                </tr>
            </thead>
            <tbody>
            ";
            // line 23
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["logs"]) || array_key_exists("logs", $context) ? $context["logs"] : (function () { throw new RuntimeError('Variable "logs" does not exist.', 23, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["log"]) {
                // line 24
                echo "                <tr data-id=\"";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["log"], "id", []), "html", null, true);
                echo "\">
                    <td>";
                // line 25
                echo craft\helpers\Template::attribute($this->env, $this->source, $context["log"], "message", []);
                echo "</td>
                    <td class=\"code\">";
                // line 27
                echo $this->extensions['craft\web\twig\Extension']->replaceFilter(twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["log"], "file", [])), "/", "/<wbr>");
                // line 28
                if (craft\helpers\Template::attribute($this->env, $this->source, $context["log"], "line", [])) {
                    // line 29
                    echo ":";
                    echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["log"], "line", []), "html", null, true);
                }
                // line 31
                echo "</td>
                    <td>";
                // line 32
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFilter('timestamp')->getCallable(), [craft\helpers\Template::attribute($this->env, $this->source, $context["log"], "lastOccurrence", [])]), "html", null, true);
                echo "</td>
                    <td class=\"nowrap viewtraces\"><a role=\"button\">";
                // line 33
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Stack Trace", "app"), "html", null, true);
                echo "</a></td>
                    <td><a class=\"delete icon\" title=\"";
                // line 34
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Delete", "app"), "html", null, true);
                echo "\" role=\"button\"></a></td>
                </tr>
            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['log'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 37
            echo "            </tbody>
        </table>
    ";
        }
        // line 40
        echo "</div>
";
        // line 0
        craft\helpers\Template::endProfile("template", "_components/utilities/DeprecationErrors");
    }

    public function getTemplateName()
    {
        return "_components/utilities/DeprecationErrors";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  139 => 0,  136 => 40,  131 => 37,  122 => 34,  118 => 33,  114 => 32,  111 => 31,  107 => 29,  105 => 28,  103 => 27,  99 => 25,  94 => 24,  90 => 23,  82 => 18,  78 => 17,  74 => 16,  70 => 15,  65 => 12,  63 => 11,  54 => 9,  49 => 6,  43 => 3,  40 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% if logs %}
    <div class=\"buttons first\">
        <div id=\"clearall\" class=\"btn submit\">{{ \"Clear all\"|t('app') }}</div>
    </div>
{% endif %}


<div class=\"readable\">
    <p id=\"nologs\"{% if logs %} class=\"hidden\"{% endif %}>{{ \"No deprecation errors to report!\"|t('app') }}</p>

    {% if logs %}
        <table id=\"deprecationerrors\" class=\"data fullwidth fixed-layout\">
            <thead>
                <tr>
                    <th>{{ \"Message\"|t('app') }}</th>
                    <th>{{ \"Origin\"|t('app') }}</th>
                    <th class=\"nowrap\">{{ \"Last Occurrence\"|t('app') }}</th>
                    <th class=\"nowrap\">{{ \"Stack Trace\"|t('app') }}</th>
                    <th style=\"width: 14px;\"></th>
                </tr>
            </thead>
            <tbody>
            {% for log in logs %}
                <tr data-id=\"{{ log.id }}\">
                    <td>{{ log.message|raw }}</td>
                    <td class=\"code\">
                        {{- log.file|e|replace('/', '/<wbr>')|raw }}
                        {%- if log.line -%}
                            :{{ log.line }}
                        {%- endif -%}
                    </td>
                    <td>{{ log.lastOccurrence|timestamp }}</td>
                    <td class=\"nowrap viewtraces\"><a role=\"button\">{{ \"Stack Trace\"|t('app') }}</a></td>
                    <td><a class=\"delete icon\" title=\"{{ 'Delete'|t('app') }}\" role=\"button\"></a></td>
                </tr>
            {% endfor %}
            </tbody>
        </table>
    {% endif %}
</div>
", "_components/utilities/DeprecationErrors", "/Applications/MAMP/htdocs/craft/smsi/vendor/craftcms/cms/src/templates/_components/utilities/DeprecationErrors/index.html");
    }
}
