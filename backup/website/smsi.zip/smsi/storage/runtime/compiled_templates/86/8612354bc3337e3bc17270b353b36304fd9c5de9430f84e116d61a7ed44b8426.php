<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* partials/header */
class __TwigTemplate_1c1bcb1bc8a0f6caa6cfa444bd61240305eae7f19559b0f0b3db607c9058f6d0 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "partials/header");
        // line 1
        echo "
  <header id=\"header\" class=\"fixed-top \">
    <div class=\"container-fluid\">

      <div class=\"row justify-content-center\">
        <div class=\"col-xl-9 d-flex align-items-center justify-content-between\">
          <h1 class=\"logo\"><a href=\"index.html\">KnightOne</a></h1>
          <!-- Uncomment below if you prefer to use an image logo -->
          <!-- <a href=\"index.html\" class=\"logo\"><img src=\"assets/img/logo.png\" alt=\"\" class=\"img-fluid\"></a>-->

          <nav class=\"nav-menu d-none d-lg-block\">
            <ul>
              <li class=\"active\"><a href=\"index.html\">Home</a></li>
              <li><a href=\"#about\">About</a></li>
              <li><a href=\"#services\">Services</a></li>
              <li><a href=\"#portfolio\">Portfolio</a></li>
              <li><a href=\"#pricing\">Pricing</a></li>
              <li class=\"drop-down\"><a href=\"\">Drop Down</a>
                <ul>
                  <li><a href=\"#\">Drop Down 1</a></li>
                  <li class=\"drop-down\"><a href=\"#\">Deep Drop Down</a>
                    <ul>
                      <li><a href=\"#\">Deep Drop Down 1</a></li>
                      <li><a href=\"#\">Deep Drop Down 2</a></li>
                      <li><a href=\"#\">Deep Drop Down 3</a></li>
                      <li><a href=\"#\">Deep Drop Down 4</a></li>
                      <li><a href=\"#\">Deep Drop Down 5</a></li>
                    </ul>
                  </li>
                  <li><a href=\"#\">Drop Down 2</a></li>
                  <li><a href=\"#\">Drop Down 3</a></li>
                  <li><a href=\"#\">Drop Down 4</a></li>
                </ul>
              </li>
              <li><a href=\"#contact\">Contact</a></li>

            </ul>
          </nav><!-- .nav-menu -->

          <a href=\"#about\" class=\"get-started-btn scrollto\">Get Started</a>
        </div>
      </div>

    </div>
  ";
        // line 0
        craft\helpers\Template::endProfile("template", "partials/header");
    }

    public function getTemplateName()
    {
        return "partials/header";
    }

    public function getDebugInfo()
    {
        return array (  84 => 0,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("
  <header id=\"header\" class=\"fixed-top \">
    <div class=\"container-fluid\">

      <div class=\"row justify-content-center\">
        <div class=\"col-xl-9 d-flex align-items-center justify-content-between\">
          <h1 class=\"logo\"><a href=\"index.html\">KnightOne</a></h1>
          <!-- Uncomment below if you prefer to use an image logo -->
          <!-- <a href=\"index.html\" class=\"logo\"><img src=\"assets/img/logo.png\" alt=\"\" class=\"img-fluid\"></a>-->

          <nav class=\"nav-menu d-none d-lg-block\">
            <ul>
              <li class=\"active\"><a href=\"index.html\">Home</a></li>
              <li><a href=\"#about\">About</a></li>
              <li><a href=\"#services\">Services</a></li>
              <li><a href=\"#portfolio\">Portfolio</a></li>
              <li><a href=\"#pricing\">Pricing</a></li>
              <li class=\"drop-down\"><a href=\"\">Drop Down</a>
                <ul>
                  <li><a href=\"#\">Drop Down 1</a></li>
                  <li class=\"drop-down\"><a href=\"#\">Deep Drop Down</a>
                    <ul>
                      <li><a href=\"#\">Deep Drop Down 1</a></li>
                      <li><a href=\"#\">Deep Drop Down 2</a></li>
                      <li><a href=\"#\">Deep Drop Down 3</a></li>
                      <li><a href=\"#\">Deep Drop Down 4</a></li>
                      <li><a href=\"#\">Deep Drop Down 5</a></li>
                    </ul>
                  </li>
                  <li><a href=\"#\">Drop Down 2</a></li>
                  <li><a href=\"#\">Drop Down 3</a></li>
                  <li><a href=\"#\">Drop Down 4</a></li>
                </ul>
              </li>
              <li><a href=\"#contact\">Contact</a></li>

            </ul>
          </nav><!-- .nav-menu -->

          <a href=\"#about\" class=\"get-started-btn scrollto\">Get Started</a>
        </div>
      </div>

    </div>
  ", "partials/header", "/Applications/MAMP/htdocs/craft/smsi/templates/partials/header.twig");
    }
}
