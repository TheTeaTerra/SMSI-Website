<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* assets */
class __TwigTemplate_4e9ef503646337a7dd8b2d3f814af255a2c890fb35cd8aeaa5a471481c3458b7 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "_layouts/elementindex";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("template", "assets");
        // line 2
        $context["title"] = $this->extensions['craft\web\twig\Extension']->translateFilter("Assets", "app");
        // line 3
        $context["elementType"] = "craft\\elements\\Asset";
        // line 5
        craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 5, $this->source); })()), "registerAssetBundle", [0 => "craft\\web\\assets\\fileupload\\FileUploadAsset"], "method");
        // line 6
        craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 6, $this->source); })()), "registerAssetBundle", [0 => "craft\\web\\assets\\prismjs\\PrismJsAsset"], "method");
        // line 8
        if ((isset($context["volumeHandle"]) || array_key_exists("volumeHandle", $context))) {
            // line 9
            ob_start();
            // line 10
            echo "        window.defaultVolumeHandle = \"";
            echo twig_escape_filter($this->env, twig_escape_filter($this->env, (isset($context["volumeHandle"]) || array_key_exists("volumeHandle", $context) ? $context["volumeHandle"] : (function () { throw new RuntimeError('Variable "volumeHandle" does not exist.', 10, $this->source); })()), "js"), "html", null, true);
            echo "\";
    ";
            Craft::$app->getView()->registerJs(ob_get_clean(), 3);
        }
        // line 1
        $this->parent = $this->loadTemplate("_layouts/elementindex", "assets", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        // line 0
        craft\helpers\Template::endProfile("template", "assets");
    }

    public function getTemplateName()
    {
        return "assets";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  65 => 0,  62 => 1,  55 => 10,  53 => 9,  51 => 8,  49 => 6,  47 => 5,  45 => 3,  43 => 2,  41 => 0,  34 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends \"_layouts/elementindex\" %}
{% set title = \"Assets\"|t('app') %}
{% set elementType = 'craft\\\\elements\\\\Asset' %}

{% do view.registerAssetBundle(\"craft\\\\web\\\\assets\\\\fileupload\\\\FileUploadAsset\") %}
{% do view.registerAssetBundle(\"craft\\\\web\\\\assets\\\\prismjs\\\\PrismJsAsset\") %}

{% if volumeHandle is defined %}
    {% js %}
        window.defaultVolumeHandle = \"{{ volumeHandle|e('js') }}\";
    {% endjs %}
{% endif %}
", "assets", "/Applications/MAMP/htdocs/craft/smsi/vendor/craftcms/cms/src/templates/assets/index.html");
    }
}
