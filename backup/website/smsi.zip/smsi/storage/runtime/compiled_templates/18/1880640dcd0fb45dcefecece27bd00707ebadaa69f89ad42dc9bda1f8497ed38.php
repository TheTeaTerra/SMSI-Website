<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* __string_template__751b5193b31368bf84fe800f1d8f76319bafe0df1a8db1e99b98f4e4116c017c */
class __TwigTemplate_82467aca9848d901912c5874ee3662ad08c646896511fa2b35c5ebef06b8125a extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "__string_template__751b5193b31368bf84fe800f1d8f76319bafe0df1a8db1e99b98f4e4116c017c");
        // line 1
        echo "teams/";
        echo (((craft\helpers\Template::attribute($this->env, $this->source, ($context["_variables"] ?? null), "slug", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["_variables"] ?? null), "slug", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["_variables"] ?? null), "slug", [])) : (craft\helpers\Template::attribute($this->env, $this->source, ($context["object"] ?? null), "slug", [])));
        // line 0
        craft\helpers\Template::endProfile("template", "__string_template__751b5193b31368bf84fe800f1d8f76319bafe0df1a8db1e99b98f4e4116c017c");
    }

    public function getTemplateName()
    {
        return "__string_template__751b5193b31368bf84fe800f1d8f76319bafe0df1a8db1e99b98f4e4116c017c";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  41 => 0,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("teams/{{ (_variables.slug ?? object.slug)|raw }}", "__string_template__751b5193b31368bf84fe800f1d8f76319bafe0df1a8db1e99b98f4e4116c017c", "");
    }
}
