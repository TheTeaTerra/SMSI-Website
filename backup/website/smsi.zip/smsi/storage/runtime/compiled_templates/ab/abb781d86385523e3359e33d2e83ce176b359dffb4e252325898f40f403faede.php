<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _components/fieldtypes/Number/input */
class __TwigTemplate_6f8377155680cbb4cd83466ff02b041a879c73a412dfe63e8c18e6c35fa5a075 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_components/fieldtypes/Number/input");
        // line 1
        $macros["__internal_e0717419270110065511e8ee5aba59693214b48bbfc8d8f1d8b420128756b34e"] = $this->macros["__internal_e0717419270110065511e8ee5aba59693214b48bbfc8d8f1d8b420128756b34e"] = $this->loadTemplate("_includes/forms", "_components/fieldtypes/Number/input", 1)->unwrap();
        // line 2
        echo "
";
        // line 3
        echo craft\helpers\Html::hiddenInput((craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 3, $this->source); })()), "handle", []) . "[locale]"), craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 3, $this->source); })()), "app", []), "language", []));
        echo "

<div class=\"flex\">
    ";
        // line 6
        if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 6, $this->source); })()), "prefix", [])) {
            // line 7
            echo "        <div>
            ";
            // line 8
            echo $this->extensions['craft\web\twig\Extension']->markdownFilter(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 8, $this->source); })()), "prefix", []), null, true);
            echo "
        </div>
    ";
        }
        // line 11
        echo "    <div>
        ";
        // line 12
        echo twig_call_macro($macros["__internal_e0717419270110065511e8ee5aba59693214b48bbfc8d8f1d8b420128756b34e"], "macro_text", [["name" => (craft\helpers\Template::attribute($this->env, $this->source,         // line 13
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 13, $this->source); })()), "handle", []) . "[value]"), "value" =>         // line 14
(isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 14, $this->source); })()), "size" => craft\helpers\Template::attribute($this->env, $this->source,         // line 15
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 15, $this->source); })()), "size", [])]], 12, $context, $this->getSourceContext());
        // line 16
        echo "
    </div>
    ";
        // line 18
        if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 18, $this->source); })()), "suffix", [])) {
            // line 19
            echo "        <div>
            ";
            // line 20
            echo $this->extensions['craft\web\twig\Extension']->markdownFilter(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 20, $this->source); })()), "suffix", []), null, true);
            echo "
        </div>
    ";
        }
        // line 23
        echo "</div>
";
        // line 0
        craft\helpers\Template::endProfile("template", "_components/fieldtypes/Number/input");
    }

    public function getTemplateName()
    {
        return "_components/fieldtypes/Number/input";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  86 => 0,  83 => 23,  77 => 20,  74 => 19,  72 => 18,  68 => 16,  66 => 15,  65 => 14,  64 => 13,  63 => 12,  60 => 11,  54 => 8,  51 => 7,  49 => 6,  43 => 3,  40 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% from '_includes/forms' import text %}

{{ hiddenInput(\"#{field.handle}[locale]\", craft.app.language) }}

<div class=\"flex\">
    {% if field.prefix %}
        <div>
            {{ field.prefix|md(inlineOnly=true)|raw }}
        </div>
    {% endif %}
    <div>
        {{ text({
            name: field.handle ~ '[value]',
            value: value,
            size: field.size
        }) }}
    </div>
    {% if field.suffix %}
        <div>
            {{ field.suffix|md(inlineOnly=true)|raw }}
        </div>
    {% endif %}
</div>
", "_components/fieldtypes/Number/input", "/Applications/MAMP/htdocs/craft/smsi/vendor/craftcms/cms/src/templates/_components/fieldtypes/Number/input.html");
    }
}
