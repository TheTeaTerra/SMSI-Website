<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* test */
class __TwigTemplate_d554afb5f85b0134ddac4d1a3d06a9503788174a3fb87af5a2eb21c70d253526 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "test");
        // line 1
        $this->loadTemplate("_layouts/app", "test", 1)->display($context);
        // line 2
        $this->displayBlock('content', $context, $blocks);
        // line 0
        craft\helpers\Template::endProfile("template", "test");
    }

    // line 2
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("block", "content");
        // line 3
        echo "
<!-- ======= About Section ======= -->
<section id=\"about\" class=\"about\">
  <div class=\"container\" data-aos=\"fade-up\">

    <div class=\"section-title\">
      <h2>About</h2>
      <p>About Us</p>
    </div>

    <div class=\"row content\">
      <div class=\"col-lg-6\">
        <p>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore
          magna aliqua.
        </p>
        <ul>
          <li><i class=\"ri-check-double-line\"></i> Ullamco laboris nisi ut aliquip ex ea commodo consequat</li>
          <li><i class=\"ri-check-double-line\"></i> Duis aute irure dolor in reprehenderit in voluptate velit</li>
          <li><i class=\"ri-check-double-line\"></i> Ullamco laboris nisi ut aliquip ex ea commodo consequat</li>
        </ul>
      </div>
      <div class=\"col-lg-6 pt-4 pt-lg-0\">
        <p>
          Ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate
          velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in
          culpa qui officia deserunt mollit anim id est laborum.
        </p>
        <a href=\"#\" class=\"btn-learn-more\">Learn More</a>
      </div>
    </div>

  </div>
</section><!-- End About Section -->

<!-- ======= Counts Section ======= -->
<section id=\"counts\" class=\"counts\">
  <div class=\"container\" data-aos=\"fade-up\">

    <div class=\"row no-gutters\">

      <div class=\"col-lg-3 col-md-6 d-md-flex align-items-md-stretch\">
        <div class=\"count-box\">
          <i class=\"icofont-simple-smile\"></i>
          <span data-toggle=\"counter-up\">232</span>
          <p><strong>Happy Clients</strong> consequuntur quae qui deca rode</p>
          <a href=\"#\">Find out more &raquo;</a>
        </div>
      </div>

      <div class=\"col-lg-3 col-md-6 d-md-flex align-items-md-stretch\">
        <div class=\"count-box\">
          <i class=\"icofont-document-folder\"></i>
          <span data-toggle=\"counter-up\">521</span>
          <p><strong>Projects</strong> adipisci atque cum quia aut numquam delectus</p>
          <a href=\"#\">Find out more &raquo;</a>
        </div>
      </div>

      <div class=\"col-lg-3 col-md-6 d-md-flex align-items-md-stretch\">
        <div class=\"count-box\">
          <i class=\"icofont-live-support\"></i>
          <span data-toggle=\"counter-up\">1,463</span>
          <p><strong>Hours Of Support</strong> aut commodi quaerat. Aliquam ratione</p>
          <a href=\"#\">Find out more &raquo;</a>
        </div>
      </div>

      <div class=\"col-lg-3 col-md-6 d-md-flex align-items-md-stretch\">
        <div class=\"count-box\">
          <i class=\"icofont-users-alt-5\"></i>
          <span data-toggle=\"counter-up\">15</span>
          <p><strong>Hard Workers</strong> rerum asperiores dolor molestiae doloribu</p>
          <a href=\"#\">Find out more &raquo;</a>
        </div>
      </div>

    </div>

  </div>
</section><!-- End Counts Section -->

<!-- ======= Why Us Section ======= -->
<section id=\"why-us\" class=\"why-us section-bg\">
  <div class=\"container-fluid\" data-aos=\"fade-up\">

    <div class=\"row\">

      <div class=\"col-lg-5 align-items-stretch video-box\" style='background-image: url(\"assets/img/why-us.jpg\");' data-aos=\"zoom-in\" data-aos-delay=\"100\">
        <a href=\"https://www.youtube.com/watch?v=jDDaplaOz7Q\" class=\"venobox play-btn mb-4\" data-vbtype=\"video\" data-autoplay=\"true\"></a>
      </div>

      <div class=\"col-lg-7 d-flex flex-column justify-content-center align-items-stretch\">

        <div class=\"content\">
          <h3>Eum ipsam laborum deleniti <strong>velit pariatur architecto</strong></h3>
          <p>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Duis aute irure dolor in reprehenderit
          </p>
        </div>

        <div class=\"accordion-list\">
          <ul>
            <li>
              <a data-toggle=\"collapse\" class=\"collapse\" href=\"#accordion-list-1\"><span>01</span> Non consectetur a erat nam at lectus urna duis? <i class=\"bx bx-chevron-down icon-show\"></i><i class=\"bx bx-chevron-up icon-close\"></i></a>
              <div id=\"accordion-list-1\" class=\"collapse show\" data-parent=\".accordion-list\">
                <p>
                  Feugiat pretium nibh ipsum consequat. Tempus iaculis urna id volutpat lacus laoreet non curabitur gravida. Venenatis lectus magna fringilla urna porttitor rhoncus dolor purus non.
                </p>
              </div>
            </li>

            <li>
              <a data-toggle=\"collapse\" href=\"#accordion-list-2\" class=\"collapsed\"><span>02</span> Feugiat scelerisque varius morbi enim nunc? <i class=\"bx bx-chevron-down icon-show\"></i><i class=\"bx bx-chevron-up icon-close\"></i></a>
              <div id=\"accordion-list-2\" class=\"collapse\" data-parent=\".accordion-list\">
                <p>
                  Dolor sit amet consectetur adipiscing elit pellentesque habitant morbi. Id interdum velit laoreet id donec ultrices. Fringilla phasellus faucibus scelerisque eleifend donec pretium. Est pellentesque elit ullamcorper dignissim. Mauris ultrices eros in cursus turpis massa tincidunt dui.
                </p>
              </div>
            </li>

            <li>
              <a data-toggle=\"collapse\" href=\"#accordion-list-3\" class=\"collapsed\"><span>03</span> Dolor sit amet consectetur adipiscing elit? <i class=\"bx bx-chevron-down icon-show\"></i><i class=\"bx bx-chevron-up icon-close\"></i></a>
              <div id=\"accordion-list-3\" class=\"collapse\" data-parent=\".accordion-list\">
                <p>
                  Eleifend mi in nulla posuere sollicitudin aliquam ultrices sagittis orci. Faucibus pulvinar elementum integer enim. Sem nulla pharetra diam sit amet nisl suscipit. Rutrum tellus pellentesque eu tincidunt. Lectus urna duis convallis convallis tellus. Urna molestie at elementum eu facilisis sed odio morbi quis
                </p>
              </div>
            </li>

          </ul>
        </div>

      </div>

    </div>

  </div>
</section><!-- End Why Us Section -->

<!-- ======= Services Section ======= -->
<section id=\"services\" class=\"services\">
  <div class=\"container\" data-aos=\"fade-up\">

    <div class=\"section-title\">
      <h2>Services</h2>
      <p>Check our Services</p>
    </div>

    <div class=\"row\">
      <div class=\"col-lg-4 col-md-6 d-flex align-items-stretch\" data-aos=\"zoom-in\" data-aos-delay=\"100\">
        <div class=\"icon-box\">
          <div class=\"icon\"><i class=\"bx bxl-dribbble\"></i></div>
          <h4><a href=\"\">Lorem Ipsum</a></h4>
          <p>Voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi</p>
        </div>
      </div>

      <div class=\"col-lg-4 col-md-6 d-flex align-items-stretch mt-4 mt-md-0\" data-aos=\"zoom-in\" data-aos-delay=\"200\">
        <div class=\"icon-box\">
          <div class=\"icon\"><i class=\"bx bx-file\"></i></div>
          <h4><a href=\"\">Sed ut perspiciatis</a></h4>
          <p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore</p>
        </div>
      </div>

      <div class=\"col-lg-4 col-md-6 d-flex align-items-stretch mt-4 mt-lg-0\" data-aos=\"zoom-in\" data-aos-delay=\"300\">
        <div class=\"icon-box\">
          <div class=\"icon\"><i class=\"bx bx-tachometer\"></i></div>
          <h4><a href=\"\">Magni Dolores</a></h4>
          <p>Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia</p>
        </div>
      </div>

      <div class=\"col-lg-4 col-md-6 d-flex align-items-stretch mt-4\" data-aos=\"zoom-in\" data-aos-delay=\"100\">
        <div class=\"icon-box\">
          <div class=\"icon\"><i class=\"bx bx-world\"></i></div>
          <h4><a href=\"\">Nemo Enim</a></h4>
          <p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis</p>
        </div>
      </div>

      <div class=\"col-lg-4 col-md-6 d-flex align-items-stretch mt-4\" data-aos=\"zoom-in\" data-aos-delay=\"200\">
        <div class=\"icon-box\">
          <div class=\"icon\"><i class=\"bx bx-slideshow\"></i></div>
          <h4><a href=\"\">Dele cardo</a></h4>
          <p>Quis consequatur saepe eligendi voluptatem consequatur dolor consequuntur</p>
        </div>
      </div>

      <div class=\"col-lg-4 col-md-6 d-flex align-items-stretch mt-4\" data-aos=\"zoom-in\" data-aos-delay=\"300\">
        <div class=\"icon-box\">
          <div class=\"icon\"><i class=\"bx bx-arch\"></i></div>
          <h4><a href=\"\">Divera don</a></h4>
          <p>Modi nostrum vel laborum. Porro fugit error sit minus sapiente sit aspernatur</p>
        </div>
      </div>

    </div>

  </div>
</section><!-- End Services Section -->

<!-- ======= Testimonials Section ======= -->
<section id=\"testimonials\" class=\"testimonials section-bg\">
  <div class=\"container\" data-aos=\"fade-up\">

    <div class=\"section-title\">
      <h2>Testimonials</h2>
      <p>Testimonials</p>
    </div>

    <div class=\"owl-carousel testimonials-carousel\">

      <div class=\"testimonial-wrap\">
        <div class=\"testimonial-item\">
          <img src=\"assets/img/testimonials/testimonials-1.jpg\" class=\"testimonial-img\" alt=\"\">
          <h3>Saul Goodman</h3>
          <h4>Ceo &amp; Founder</h4>
          <p>
            <i class=\"bx bxs-quote-alt-left quote-icon-left\"></i>
            Proin iaculis purus consequat sem cure digni ssim donec porttitora entum suscipit rhoncus. Accusantium quam, ultricies eget id, aliquam eget nibh et. Maecen aliquam, risus at semper.
            <i class=\"bx bxs-quote-alt-right quote-icon-right\"></i>
          </p>
        </div>
      </div>

      <div class=\"testimonial-wrap\">
        <div class=\"testimonial-item\">
          <img src=\"assets/img/testimonials/testimonials-2.jpg\" class=\"testimonial-img\" alt=\"\">
          <h3>Sara Wilsson</h3>
          <h4>Designer</h4>
          <p>
            <i class=\"bx bxs-quote-alt-left quote-icon-left\"></i>
            Export tempor illum tamen malis malis eram quae irure esse labore quem cillum quid cillum eram malis quorum velit fore eram velit sunt aliqua noster fugiat irure amet legam anim culpa.
            <i class=\"bx bxs-quote-alt-right quote-icon-right\"></i>
          </p>
        </div>
      </div>

      <div class=\"testimonial-wrap\">
        <div class=\"testimonial-item\">
          <img src=\"assets/img/testimonials/testimonials-3.jpg\" class=\"testimonial-img\" alt=\"\">
          <h3>Jena Karlis</h3>
          <h4>Store Owner</h4>
          <p>
            <i class=\"bx bxs-quote-alt-left quote-icon-left\"></i>
            Enim nisi quem export duis labore cillum quae magna enim sint quorum nulla quem veniam duis minim tempor labore quem eram duis noster aute amet eram fore quis sint minim.
            <i class=\"bx bxs-quote-alt-right quote-icon-right\"></i>
          </p>
        </div>
      </div>

      <div class=\"testimonial-wrap\">
        <div class=\"testimonial-item\">
          <img src=\"assets/img/testimonials/testimonials-4.jpg\" class=\"testimonial-img\" alt=\"\">
          <h3>Matt Brandon</h3>
          <h4>Freelancer</h4>
          <p>
            <i class=\"bx bxs-quote-alt-left quote-icon-left\"></i>
            Fugiat enim eram quae cillum dolore dolor amet nulla culpa multos export minim fugiat minim velit minim dolor enim duis veniam ipsum anim magna sunt elit fore quem dolore labore illum veniam.
            <i class=\"bx bxs-quote-alt-right quote-icon-right\"></i>
          </p>
        </div>
      </div>

      <div class=\"testimonial-wrap\">
        <div class=\"testimonial-item\">
          <img src=\"assets/img/testimonials/testimonials-5.jpg\" class=\"testimonial-img\" alt=\"\">
          <h3>John Larson</h3>
          <h4>Entrepreneur</h4>
          <p>
            <i class=\"bx bxs-quote-alt-left quote-icon-left\"></i>
            Quis quorum aliqua sint quem legam fore sunt eram irure aliqua veniam tempor noster veniam enim culpa labore duis sunt culpa nulla illum cillum fugiat legam esse veniam culpa fore nisi cillum quid.
            <i class=\"bx bxs-quote-alt-right quote-icon-right\"></i>
          </p>
        </div>
      </div>

    </div>

  </div>
</section><!-- End Testimonials Section -->

<!-- ======= Cta Section ======= -->
<section id=\"cta\" class=\"cta\">
  <div class=\"container\" data-aos=\"zoom-in\">

    <div class=\"text-center\">
      <h3>Call To Action</h3>
      <p> Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
      <a class=\"cta-btn\" href=\"#\">Call To Action</a>
    </div>

  </div>
</section><!-- End Cta Section -->

<!-- ======= Portfolio Section ======= -->
<section id=\"portfolio\" class=\"portfolio\">
  <div class=\"container\" data-aos=\"fade-up\">

    <div class=\"section-title\">
      <h2>Portfolio</h2>
      <p>Check our Portfolio</p>
    </div>

    <div class=\"row\" data-aos=\"fade-up\" data-aos-delay=\"100\">
      <div class=\"col-lg-12 d-flex justify-content-center\">
        <ul id=\"portfolio-flters\">
          <li data-filter=\"*\" class=\"filter-active\">All</li>
          <li data-filter=\".filter-app\">App</li>
          <li data-filter=\".filter-card\">Card</li>
          <li data-filter=\".filter-web\">Web</li>
        </ul>
      </div>
    </div>

    <div class=\"row portfolio-container\" data-aos=\"fade-up\" data-aos-delay=\"200\">

      <div class=\"col-lg-4 col-md-6 portfolio-item filter-app\">
        <img src=\"assets/img/portfolio/portfolio-1.jpg\" class=\"img-fluid\" alt=\"\">
        <div class=\"portfolio-info\">
          <h4>App 1</h4>
          <p>App</p>
          <a href=\"assets/img/portfolio/portfolio-1.jpg\" data-gall=\"portfolioGallery\" class=\"venobox preview-link\" title=\"App 1\"><i class=\"bx bx-plus\"></i></a>
          <a href=\"portfolio-details.html\" class=\"details-link\" title=\"More Details\"><i class=\"bx bx-link\"></i></a>
        </div>
      </div>

      <div class=\"col-lg-4 col-md-6 portfolio-item filter-web\">
        <img src=\"assets/img/portfolio/portfolio-2.jpg\" class=\"img-fluid\" alt=\"\">
        <div class=\"portfolio-info\">
          <h4>Web 3</h4>
          <p>Web</p>
          <a href=\"assets/img/portfolio/portfolio-2.jpg\" data-gall=\"portfolioGallery\" class=\"venobox preview-link\" title=\"Web 3\"><i class=\"bx bx-plus\"></i></a>
          <a href=\"portfolio-details.html\" class=\"details-link\" title=\"More Details\"><i class=\"bx bx-link\"></i></a>
        </div>
      </div>

      <div class=\"col-lg-4 col-md-6 portfolio-item filter-app\">
        <img src=\"assets/img/portfolio/portfolio-3.jpg\" class=\"img-fluid\" alt=\"\">
        <div class=\"portfolio-info\">
          <h4>App 2</h4>
          <p>App</p>
          <a href=\"assets/img/portfolio/portfolio-3.jpg\" data-gall=\"portfolioGallery\" class=\"venobox preview-link\" title=\"App 2\"><i class=\"bx bx-plus\"></i></a>
          <a href=\"portfolio-details.html\" class=\"details-link\" title=\"More Details\"><i class=\"bx bx-link\"></i></a>
        </div>
      </div>

      <div class=\"col-lg-4 col-md-6 portfolio-item filter-card\">
        <img src=\"assets/img/portfolio/portfolio-4.jpg\" class=\"img-fluid\" alt=\"\">
        <div class=\"portfolio-info\">
          <h4>Card 2</h4>
          <p>Card</p>
          <a href=\"assets/img/portfolio/portfolio-4.jpg\" data-gall=\"portfolioGallery\" class=\"venobox preview-link\" title=\"Card 2\"><i class=\"bx bx-plus\"></i></a>
          <a href=\"portfolio-details.html\" class=\"details-link\" title=\"More Details\"><i class=\"bx bx-link\"></i></a>
        </div>
      </div>

      <div class=\"col-lg-4 col-md-6 portfolio-item filter-web\">
        <img src=\"assets/img/portfolio/portfolio-5.jpg\" class=\"img-fluid\" alt=\"\">
        <div class=\"portfolio-info\">
          <h4>Web 2</h4>
          <p>Web</p>
          <a href=\"assets/img/portfolio/portfolio-5.jpg\" data-gall=\"portfolioGallery\" class=\"venobox preview-link\" title=\"Web 2\"><i class=\"bx bx-plus\"></i></a>
          <a href=\"portfolio-details.html\" class=\"details-link\" title=\"More Details\"><i class=\"bx bx-link\"></i></a>
        </div>
      </div>

      <div class=\"col-lg-4 col-md-6 portfolio-item filter-app\">
        <img src=\"assets/img/portfolio/portfolio-6.jpg\" class=\"img-fluid\" alt=\"\">
        <div class=\"portfolio-info\">
          <h4>App 3</h4>
          <p>App</p>
          <a href=\"assets/img/portfolio/portfolio-6.jpg\" data-gall=\"portfolioGallery\" class=\"venobox preview-link\" title=\"App 3\"><i class=\"bx bx-plus\"></i></a>
          <a href=\"portfolio-details.html\" class=\"details-link\" title=\"More Details\"><i class=\"bx bx-link\"></i></a>
        </div>
      </div>

      <div class=\"col-lg-4 col-md-6 portfolio-item filter-card\">
        <img src=\"assets/img/portfolio/portfolio-7.jpg\" class=\"img-fluid\" alt=\"\">
        <div class=\"portfolio-info\">
          <h4>Card 1</h4>
          <p>Card</p>
          <a href=\"assets/img/portfolio/portfolio-7.jpg\" data-gall=\"portfolioGallery\" class=\"venobox preview-link\" title=\"Card 1\"><i class=\"bx bx-plus\"></i></a>
          <a href=\"portfolio-details.html\" class=\"details-link\" title=\"More Details\"><i class=\"bx bx-link\"></i></a>
        </div>
      </div>

      <div class=\"col-lg-4 col-md-6 portfolio-item filter-card\">
        <img src=\"assets/img/portfolio/portfolio-8.jpg\" class=\"img-fluid\" alt=\"\">
        <div class=\"portfolio-info\">
          <h4>Card 3</h4>
          <p>Card</p>
          <a href=\"assets/img/portfolio/portfolio-8.jpg\" data-gall=\"portfolioGallery\" class=\"venobox preview-link\" title=\"Card 3\"><i class=\"bx bx-plus\"></i></a>
          <a href=\"portfolio-details.html\" class=\"details-link\" title=\"More Details\"><i class=\"bx bx-link\"></i></a>
        </div>
      </div>

      <div class=\"col-lg-4 col-md-6 portfolio-item filter-web\">
        <img src=\"assets/img/portfolio/portfolio-9.jpg\" class=\"img-fluid\" alt=\"\">
        <div class=\"portfolio-info\">
          <h4>Web 3</h4>
          <p>Web</p>
          <a href=\"assets/img/portfolio/portfolio-9.jpg\" data-gall=\"portfolioGallery\" class=\"venobox preview-link\" title=\"Web 3\"><i class=\"bx bx-plus\"></i></a>
          <a href=\"portfolio-details.html\" class=\"details-link\" title=\"More Details\"><i class=\"bx bx-link\"></i></a>
        </div>
      </div>

    </div>

  </div>
</section><!-- End Portfolio Section -->

<!-- ======= Team Section ======= -->
<section id=\"team\" class=\"team section-bg\">
  <div class=\"container\" data-aos=\"fade-up\">

    <div class=\"section-title\">
      <h2>Team</h2>
      <p>Check our Team</p>
    </div>

    <div class=\"row\">

      <div class=\"col-xl-3 col-lg-4 col-md-6\">
        <div class=\"member\" data-aos=\"zoom-in\" data-aos-delay=\"100\">
          <img src=\"assets/img/team/team-1.jpg\" class=\"img-fluid\" alt=\"\">
          <div class=\"member-info\">
            <div class=\"member-info-content\">
              <h4>Walter White</h4>
              <span>Chief Executive Officer</span>
            </div>
            <div class=\"social\">
              <a href=\"\"><i class=\"icofont-twitter\"></i></a>
              <a href=\"\"><i class=\"icofont-facebook\"></i></a>
              <a href=\"\"><i class=\"icofont-instagram\"></i></a>
              <a href=\"\"><i class=\"icofont-linkedin\"></i></a>
            </div>
          </div>
        </div>
      </div>

      <div class=\"col-xl-3 col-lg-4 col-md-6\" data-wow-delay=\"0.1s\">
        <div class=\"member\" data-aos=\"zoom-in\" data-aos-delay=\"200\">
          <img src=\"assets/img/team/team-2.jpg\" class=\"img-fluid\" alt=\"\">
          <div class=\"member-info\">
            <div class=\"member-info-content\">
              <h4>Sarah Jhonson</h4>
              <span>Product Manager</span>
            </div>
            <div class=\"social\">
              <a href=\"\"><i class=\"icofont-twitter\"></i></a>
              <a href=\"\"><i class=\"icofont-facebook\"></i></a>
              <a href=\"\"><i class=\"icofont-instagram\"></i></a>
              <a href=\"\"><i class=\"icofont-linkedin\"></i></a>
            </div>
          </div>
        </div>
      </div>

      <div class=\"col-xl-3 col-lg-4 col-md-6\" data-wow-delay=\"0.2s\">
        <div class=\"member\" data-aos=\"zoom-in\" data-aos-delay=\"300\">
          <img src=\"assets/img/team/team-3.jpg\" class=\"img-fluid\" alt=\"\">
          <div class=\"member-info\">
            <div class=\"member-info-content\">
              <h4>William Anderson</h4>
              <span>CTO</span>
            </div>
            <div class=\"social\">
              <a href=\"\"><i class=\"icofont-twitter\"></i></a>
              <a href=\"\"><i class=\"icofont-facebook\"></i></a>
              <a href=\"\"><i class=\"icofont-instagram\"></i></a>
              <a href=\"\"><i class=\"icofont-linkedin\"></i></a>
            </div>
          </div>
        </div>
      </div>

      <div class=\"col-xl-3 col-lg-4 col-md-6\" data-wow-delay=\"0.3s\">
        <div class=\"member\" data-aos=\"zoom-in\" data-aos-delay=\"400\">
          <img src=\"assets/img/team/team-4.jpg\" class=\"img-fluid\" alt=\"\">
          <div class=\"member-info\">
            <div class=\"member-info-content\">
              <h4>Amanda Jepson</h4>
              <span>Accountant</span>
            </div>
            <div class=\"social\">
              <a href=\"\"><i class=\"icofont-twitter\"></i></a>
              <a href=\"\"><i class=\"icofont-facebook\"></i></a>
              <a href=\"\"><i class=\"icofont-instagram\"></i></a>
              <a href=\"\"><i class=\"icofont-linkedin\"></i></a>
            </div>
          </div>
        </div>
      </div>

    </div>

  </div>
</section><!-- End Team Section -->

<!-- ======= Pricing Section ======= -->
<section id=\"pricing\" class=\"pricing\">
  <div class=\"container\" data-aos=\"fade-up\">

    <div class=\"section-title\">
      <h2>Pricing</h2>
      <p>Our Competing Prices</p>
    </div>

    <div class=\"row align-items-center\">

      <div class=\"col-lg-4\">
        <div class=\"box\" data-aos=\"zoom-in\" data-aos-delay=\"100\">
          <h3>Free</h3>
          <h4>\$0<span>per month</span></h4>
          <ul>
            <li><i class=\"bx bx-check\"></i> Quam adipiscing vitae proin</li>
            <li><i class=\"bx bx-check\"></i> Nec feugiat nisl pretium</li>
            <li><i class=\"bx bx-check\"></i> Nulla at volutpat diam uteera</li>
            <li class=\"na\"><i class=\"bx bx-x\"></i> <span>Pharetra massa massa ultricies</span></li>
            <li class=\"na\"><i class=\"bx bx-x\"></i> <span>Massa ultricies mi quis hendrerit</span></li>
          </ul>
          <a href=\"#\" class=\"get-started-btn\">Get Started</a>
        </div>
      </div>

      <div class=\"col-lg-4\">
        <div class=\"box featured\" data-aos=\"zoom-in\" data-aos-delay=\"100\">
          <h3>Business</h3>
          <h4>\$29<span>per month</span></h4>
          <ul>
            <li><i class=\"bx bx-check\"></i> Quam adipiscing vitae proin</li>
            <li><i class=\"bx bx-check\"></i> Nec feugiat nisl pretium</li>
            <li><i class=\"bx bx-check\"></i> Nulla at volutpat diam uteera</li>
            <li><i class=\"bx bx-check\"></i> Pharetra massa massa ultricies</li>
            <li><i class=\"bx bx-check\"></i> Massa ultricies mi quis hendrerit</li>
          </ul>
          <a href=\"#\" class=\"get-started-btn\">Get Started</a>
        </div>
      </div>

      <div class=\"col-lg-4\">
        <div class=\"box\" data-aos=\"zoom-in\" data-aos-delay=\"100\">
          <h3>Developer</h3>
          <h4>\$49<span>per month</span></h4>
          <ul>
            <li><i class=\"bx bx-check\"></i> Quam adipiscing vitae proin</li>
            <li><i class=\"bx bx-check\"></i> Nec feugiat nisl pretium</li>
            <li><i class=\"bx bx-check\"></i> Nulla at volutpat diam uteera</li>
            <li><i class=\"bx bx-check\"></i> Pharetra massa massa ultricies</li>
            <li><i class=\"bx bx-check\"></i> Massa ultricies mi quis hendrerit</li>
          </ul>
          <a href=\"#\" class=\"get-started-btn\">Get Started</a>
        </div>
      </div>

    </div>

  </div>
</section><!-- End Pricing Section -->

<!-- ======= Frequently Asked Questions Section ======= -->
<section id=\"faq\" class=\"faq\">
  <div class=\"container\" data-aos=\"fade-up\">

    <div class=\"section-title\">
      <h2>F.A.Q</h2>
      <p>Frequently Asked Questions</p>
    </div>

    <div class=\"row faq-item d-flex align-items-stretch\" data-aos=\"fade-up\" data-aos-delay=\"100\">
      <div class=\"col-lg-5\">
        <i class=\"bx bx-help-circle\"></i>
        <h4>Non consectetur a erat nam at lectus urna duis?</h4>
      </div>
      <div class=\"col-lg-7\">
        <p>
          Feugiat pretium nibh ipsum consequat. Tempus iaculis urna id volutpat lacus laoreet non curabitur gravida. Venenatis lectus magna fringilla urna porttitor rhoncus dolor purus non.
        </p>
      </div>
    </div><!-- End F.A.Q Item-->

    <div class=\"row faq-item d-flex align-items-stretch\" data-aos=\"fade-up\" data-aos-delay=\"200\">
      <div class=\"col-lg-5\">
        <i class=\"bx bx-help-circle\"></i>
        <h4>Feugiat scelerisque varius morbi enim nunc faucibus a pellentesque?</h4>
      </div>
      <div class=\"col-lg-7\">
        <p>
          Dolor sit amet consectetur adipiscing elit pellentesque habitant morbi. Id interdum velit laoreet id donec ultrices. Fringilla phasellus faucibus scelerisque eleifend donec pretium. Est pellentesque elit ullamcorper dignissim.
        </p>
      </div>
    </div><!-- End F.A.Q Item-->

    <div class=\"row faq-item d-flex align-items-stretch\" data-aos=\"fade-up\" data-aos-delay=\"300\">
      <div class=\"col-lg-5\">
        <i class=\"bx bx-help-circle\"></i>
        <h4>Dolor sit amet consectetur adipiscing elit pellentesque habitant morbi?</h4>
      </div>
      <div class=\"col-lg-7\">
        <p>
          Eleifend mi in nulla posuere sollicitudin aliquam ultrices sagittis orci. Faucibus pulvinar elementum integer enim. Sem nulla pharetra diam sit amet nisl suscipit. Rutrum tellus pellentesque eu tincidunt. Lectus urna duis convallis convallis tellus.
        </p>
      </div>
    </div><!-- End F.A.Q Item-->

    <div class=\"row faq-item d-flex align-items-stretch\" data-aos=\"fade-up\" data-aos-delay=\"400\">
      <div class=\"col-lg-5\">
        <i class=\"bx bx-help-circle\"></i>
        <h4>Ac odio tempor orci dapibus. Aliquam eleifend mi in nulla?</h4>
      </div>
      <div class=\"col-lg-7\">
        <p>
          Aperiam itaque sit optio et deleniti eos nihil quidem cumque. Voluptas dolorum accusantium sunt sit enim. Provident consequuntur quam aut reiciendis qui rerum dolorem sit odio. Repellat assumenda soluta sunt pariatur error doloribus fuga.
        </p>
      </div>
    </div><!-- End F.A.Q Item-->

    <div class=\"row faq-item d-flex align-items-stretch\" data-aos=\"fade-up\" data-aos-delay=\"500\">
      <div class=\"col-lg-5\">
        <i class=\"bx bx-help-circle\"></i>
        <h4>Tempus quam pellentesque nec nam aliquam sem et tortor consequat?</h4>
      </div>
      <div class=\"col-lg-7\">
        <p>
          Molestie a iaculis at erat pellentesque adipiscing commodo. Dignissim suspendisse in est ante in. Nunc vel risus commodo viverra maecenas accumsan. Sit amet nisl suscipit adipiscing bibendum est. Purus gravida quis blandit turpis cursus in
        </p>
      </div>
    </div><!-- End F.A.Q Item-->

  </div>
</section><!-- End Frequently Asked Questions Section -->

<!-- ======= Contact Section ======= -->
<section id=\"contact\" class=\"contact section-bg\">
  <div class=\"container\" data-aos=\"fade-up\">

    <div class=\"section-title\">
      <h2>Contact</h2>
      <p>Contact Us</p>
    </div>

    <div class=\"row\">

      <div class=\"col-lg-6\">

        <div class=\"row\">
          <div class=\"col-md-12\">
            <div class=\"info-box\">
              <i class=\"bx bx-map\"></i>
              <h3>Our Address</h3>
              <p>A108 Adam Street, New York, NY 535022</p>
            </div>
          </div>
          <div class=\"col-md-6\">
            <div class=\"info-box mt-4\">
              <i class=\"bx bx-envelope\"></i>
              <h3>Email Us</h3>
              <p>info@example.com<br>contact@example.com</p>
            </div>
          </div>
          <div class=\"col-md-6\">
            <div class=\"info-box mt-4\">
              <i class=\"bx bx-phone-call\"></i>
              <h3>Call Us</h3>
              <p>+1 5589 55488 55<br>+1 6678 254445 41</p>
            </div>
          </div>
        </div>

      </div>

      <div class=\"col-lg-6\">
        <form action=\"forms/contact.php\" method=\"post\" role=\"form\" class=\"php-email-form\">
          <div class=\"form-row\">
            <div class=\"col form-group\">
              <input type=\"text\" name=\"name\" class=\"form-control\" id=\"name\" placeholder=\"Your Name\" data-rule=\"minlen:4\" data-msg=\"Please enter at least 4 chars\" />
              <div class=\"validate\"></div>
            </div>
            <div class=\"col form-group\">
              <input type=\"email\" class=\"form-control\" name=\"email\" id=\"email\" placeholder=\"Your Email\" data-rule=\"email\" data-msg=\"Please enter a valid email\" />
              <div class=\"validate\"></div>
            </div>
          </div>
          <div class=\"form-group\">
            <input type=\"text\" class=\"form-control\" name=\"subject\" id=\"subject\" placeholder=\"Subject\" data-rule=\"minlen:4\" data-msg=\"Please enter at least 8 chars of subject\" />
            <div class=\"validate\"></div>
          </div>
          <div class=\"form-group\">
            <textarea class=\"form-control\" name=\"message\" rows=\"5\" data-rule=\"required\" data-msg=\"Please write something for us\" placeholder=\"Message\"></textarea>
            <div class=\"validate\"></div>
          </div>
          <div class=\"mb-3\">
            <div class=\"loading\">Loading</div>
            <div class=\"error-message\"></div>
            <div class=\"sent-message\">Your message has been sent. Thank you!</div>
          </div>
          <div class=\"text-center\"><button type=\"submit\">Send Message</button></div>
        </form>
      </div>

    </div>

  </div>
</section><!-- End Contact Section -->




";
        // line 0
        craft\helpers\Template::endProfile("block", "content");
    }

    public function getTemplateName()
    {
        return "test";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  766 => 0,  53 => 3,  51 => 0,  47 => 2,  43 => 0,  41 => 2,  39 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% include \"_layouts/app\" %}
{% block content %}

<!-- ======= About Section ======= -->
<section id=\"about\" class=\"about\">
  <div class=\"container\" data-aos=\"fade-up\">

    <div class=\"section-title\">
      <h2>About</h2>
      <p>About Us</p>
    </div>

    <div class=\"row content\">
      <div class=\"col-lg-6\">
        <p>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore
          magna aliqua.
        </p>
        <ul>
          <li><i class=\"ri-check-double-line\"></i> Ullamco laboris nisi ut aliquip ex ea commodo consequat</li>
          <li><i class=\"ri-check-double-line\"></i> Duis aute irure dolor in reprehenderit in voluptate velit</li>
          <li><i class=\"ri-check-double-line\"></i> Ullamco laboris nisi ut aliquip ex ea commodo consequat</li>
        </ul>
      </div>
      <div class=\"col-lg-6 pt-4 pt-lg-0\">
        <p>
          Ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate
          velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in
          culpa qui officia deserunt mollit anim id est laborum.
        </p>
        <a href=\"#\" class=\"btn-learn-more\">Learn More</a>
      </div>
    </div>

  </div>
</section><!-- End About Section -->

<!-- ======= Counts Section ======= -->
<section id=\"counts\" class=\"counts\">
  <div class=\"container\" data-aos=\"fade-up\">

    <div class=\"row no-gutters\">

      <div class=\"col-lg-3 col-md-6 d-md-flex align-items-md-stretch\">
        <div class=\"count-box\">
          <i class=\"icofont-simple-smile\"></i>
          <span data-toggle=\"counter-up\">232</span>
          <p><strong>Happy Clients</strong> consequuntur quae qui deca rode</p>
          <a href=\"#\">Find out more &raquo;</a>
        </div>
      </div>

      <div class=\"col-lg-3 col-md-6 d-md-flex align-items-md-stretch\">
        <div class=\"count-box\">
          <i class=\"icofont-document-folder\"></i>
          <span data-toggle=\"counter-up\">521</span>
          <p><strong>Projects</strong> adipisci atque cum quia aut numquam delectus</p>
          <a href=\"#\">Find out more &raquo;</a>
        </div>
      </div>

      <div class=\"col-lg-3 col-md-6 d-md-flex align-items-md-stretch\">
        <div class=\"count-box\">
          <i class=\"icofont-live-support\"></i>
          <span data-toggle=\"counter-up\">1,463</span>
          <p><strong>Hours Of Support</strong> aut commodi quaerat. Aliquam ratione</p>
          <a href=\"#\">Find out more &raquo;</a>
        </div>
      </div>

      <div class=\"col-lg-3 col-md-6 d-md-flex align-items-md-stretch\">
        <div class=\"count-box\">
          <i class=\"icofont-users-alt-5\"></i>
          <span data-toggle=\"counter-up\">15</span>
          <p><strong>Hard Workers</strong> rerum asperiores dolor molestiae doloribu</p>
          <a href=\"#\">Find out more &raquo;</a>
        </div>
      </div>

    </div>

  </div>
</section><!-- End Counts Section -->

<!-- ======= Why Us Section ======= -->
<section id=\"why-us\" class=\"why-us section-bg\">
  <div class=\"container-fluid\" data-aos=\"fade-up\">

    <div class=\"row\">

      <div class=\"col-lg-5 align-items-stretch video-box\" style='background-image: url(\"assets/img/why-us.jpg\");' data-aos=\"zoom-in\" data-aos-delay=\"100\">
        <a href=\"https://www.youtube.com/watch?v=jDDaplaOz7Q\" class=\"venobox play-btn mb-4\" data-vbtype=\"video\" data-autoplay=\"true\"></a>
      </div>

      <div class=\"col-lg-7 d-flex flex-column justify-content-center align-items-stretch\">

        <div class=\"content\">
          <h3>Eum ipsam laborum deleniti <strong>velit pariatur architecto</strong></h3>
          <p>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Duis aute irure dolor in reprehenderit
          </p>
        </div>

        <div class=\"accordion-list\">
          <ul>
            <li>
              <a data-toggle=\"collapse\" class=\"collapse\" href=\"#accordion-list-1\"><span>01</span> Non consectetur a erat nam at lectus urna duis? <i class=\"bx bx-chevron-down icon-show\"></i><i class=\"bx bx-chevron-up icon-close\"></i></a>
              <div id=\"accordion-list-1\" class=\"collapse show\" data-parent=\".accordion-list\">
                <p>
                  Feugiat pretium nibh ipsum consequat. Tempus iaculis urna id volutpat lacus laoreet non curabitur gravida. Venenatis lectus magna fringilla urna porttitor rhoncus dolor purus non.
                </p>
              </div>
            </li>

            <li>
              <a data-toggle=\"collapse\" href=\"#accordion-list-2\" class=\"collapsed\"><span>02</span> Feugiat scelerisque varius morbi enim nunc? <i class=\"bx bx-chevron-down icon-show\"></i><i class=\"bx bx-chevron-up icon-close\"></i></a>
              <div id=\"accordion-list-2\" class=\"collapse\" data-parent=\".accordion-list\">
                <p>
                  Dolor sit amet consectetur adipiscing elit pellentesque habitant morbi. Id interdum velit laoreet id donec ultrices. Fringilla phasellus faucibus scelerisque eleifend donec pretium. Est pellentesque elit ullamcorper dignissim. Mauris ultrices eros in cursus turpis massa tincidunt dui.
                </p>
              </div>
            </li>

            <li>
              <a data-toggle=\"collapse\" href=\"#accordion-list-3\" class=\"collapsed\"><span>03</span> Dolor sit amet consectetur adipiscing elit? <i class=\"bx bx-chevron-down icon-show\"></i><i class=\"bx bx-chevron-up icon-close\"></i></a>
              <div id=\"accordion-list-3\" class=\"collapse\" data-parent=\".accordion-list\">
                <p>
                  Eleifend mi in nulla posuere sollicitudin aliquam ultrices sagittis orci. Faucibus pulvinar elementum integer enim. Sem nulla pharetra diam sit amet nisl suscipit. Rutrum tellus pellentesque eu tincidunt. Lectus urna duis convallis convallis tellus. Urna molestie at elementum eu facilisis sed odio morbi quis
                </p>
              </div>
            </li>

          </ul>
        </div>

      </div>

    </div>

  </div>
</section><!-- End Why Us Section -->

<!-- ======= Services Section ======= -->
<section id=\"services\" class=\"services\">
  <div class=\"container\" data-aos=\"fade-up\">

    <div class=\"section-title\">
      <h2>Services</h2>
      <p>Check our Services</p>
    </div>

    <div class=\"row\">
      <div class=\"col-lg-4 col-md-6 d-flex align-items-stretch\" data-aos=\"zoom-in\" data-aos-delay=\"100\">
        <div class=\"icon-box\">
          <div class=\"icon\"><i class=\"bx bxl-dribbble\"></i></div>
          <h4><a href=\"\">Lorem Ipsum</a></h4>
          <p>Voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi</p>
        </div>
      </div>

      <div class=\"col-lg-4 col-md-6 d-flex align-items-stretch mt-4 mt-md-0\" data-aos=\"zoom-in\" data-aos-delay=\"200\">
        <div class=\"icon-box\">
          <div class=\"icon\"><i class=\"bx bx-file\"></i></div>
          <h4><a href=\"\">Sed ut perspiciatis</a></h4>
          <p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore</p>
        </div>
      </div>

      <div class=\"col-lg-4 col-md-6 d-flex align-items-stretch mt-4 mt-lg-0\" data-aos=\"zoom-in\" data-aos-delay=\"300\">
        <div class=\"icon-box\">
          <div class=\"icon\"><i class=\"bx bx-tachometer\"></i></div>
          <h4><a href=\"\">Magni Dolores</a></h4>
          <p>Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia</p>
        </div>
      </div>

      <div class=\"col-lg-4 col-md-6 d-flex align-items-stretch mt-4\" data-aos=\"zoom-in\" data-aos-delay=\"100\">
        <div class=\"icon-box\">
          <div class=\"icon\"><i class=\"bx bx-world\"></i></div>
          <h4><a href=\"\">Nemo Enim</a></h4>
          <p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis</p>
        </div>
      </div>

      <div class=\"col-lg-4 col-md-6 d-flex align-items-stretch mt-4\" data-aos=\"zoom-in\" data-aos-delay=\"200\">
        <div class=\"icon-box\">
          <div class=\"icon\"><i class=\"bx bx-slideshow\"></i></div>
          <h4><a href=\"\">Dele cardo</a></h4>
          <p>Quis consequatur saepe eligendi voluptatem consequatur dolor consequuntur</p>
        </div>
      </div>

      <div class=\"col-lg-4 col-md-6 d-flex align-items-stretch mt-4\" data-aos=\"zoom-in\" data-aos-delay=\"300\">
        <div class=\"icon-box\">
          <div class=\"icon\"><i class=\"bx bx-arch\"></i></div>
          <h4><a href=\"\">Divera don</a></h4>
          <p>Modi nostrum vel laborum. Porro fugit error sit minus sapiente sit aspernatur</p>
        </div>
      </div>

    </div>

  </div>
</section><!-- End Services Section -->

<!-- ======= Testimonials Section ======= -->
<section id=\"testimonials\" class=\"testimonials section-bg\">
  <div class=\"container\" data-aos=\"fade-up\">

    <div class=\"section-title\">
      <h2>Testimonials</h2>
      <p>Testimonials</p>
    </div>

    <div class=\"owl-carousel testimonials-carousel\">

      <div class=\"testimonial-wrap\">
        <div class=\"testimonial-item\">
          <img src=\"assets/img/testimonials/testimonials-1.jpg\" class=\"testimonial-img\" alt=\"\">
          <h3>Saul Goodman</h3>
          <h4>Ceo &amp; Founder</h4>
          <p>
            <i class=\"bx bxs-quote-alt-left quote-icon-left\"></i>
            Proin iaculis purus consequat sem cure digni ssim donec porttitora entum suscipit rhoncus. Accusantium quam, ultricies eget id, aliquam eget nibh et. Maecen aliquam, risus at semper.
            <i class=\"bx bxs-quote-alt-right quote-icon-right\"></i>
          </p>
        </div>
      </div>

      <div class=\"testimonial-wrap\">
        <div class=\"testimonial-item\">
          <img src=\"assets/img/testimonials/testimonials-2.jpg\" class=\"testimonial-img\" alt=\"\">
          <h3>Sara Wilsson</h3>
          <h4>Designer</h4>
          <p>
            <i class=\"bx bxs-quote-alt-left quote-icon-left\"></i>
            Export tempor illum tamen malis malis eram quae irure esse labore quem cillum quid cillum eram malis quorum velit fore eram velit sunt aliqua noster fugiat irure amet legam anim culpa.
            <i class=\"bx bxs-quote-alt-right quote-icon-right\"></i>
          </p>
        </div>
      </div>

      <div class=\"testimonial-wrap\">
        <div class=\"testimonial-item\">
          <img src=\"assets/img/testimonials/testimonials-3.jpg\" class=\"testimonial-img\" alt=\"\">
          <h3>Jena Karlis</h3>
          <h4>Store Owner</h4>
          <p>
            <i class=\"bx bxs-quote-alt-left quote-icon-left\"></i>
            Enim nisi quem export duis labore cillum quae magna enim sint quorum nulla quem veniam duis minim tempor labore quem eram duis noster aute amet eram fore quis sint minim.
            <i class=\"bx bxs-quote-alt-right quote-icon-right\"></i>
          </p>
        </div>
      </div>

      <div class=\"testimonial-wrap\">
        <div class=\"testimonial-item\">
          <img src=\"assets/img/testimonials/testimonials-4.jpg\" class=\"testimonial-img\" alt=\"\">
          <h3>Matt Brandon</h3>
          <h4>Freelancer</h4>
          <p>
            <i class=\"bx bxs-quote-alt-left quote-icon-left\"></i>
            Fugiat enim eram quae cillum dolore dolor amet nulla culpa multos export minim fugiat minim velit minim dolor enim duis veniam ipsum anim magna sunt elit fore quem dolore labore illum veniam.
            <i class=\"bx bxs-quote-alt-right quote-icon-right\"></i>
          </p>
        </div>
      </div>

      <div class=\"testimonial-wrap\">
        <div class=\"testimonial-item\">
          <img src=\"assets/img/testimonials/testimonials-5.jpg\" class=\"testimonial-img\" alt=\"\">
          <h3>John Larson</h3>
          <h4>Entrepreneur</h4>
          <p>
            <i class=\"bx bxs-quote-alt-left quote-icon-left\"></i>
            Quis quorum aliqua sint quem legam fore sunt eram irure aliqua veniam tempor noster veniam enim culpa labore duis sunt culpa nulla illum cillum fugiat legam esse veniam culpa fore nisi cillum quid.
            <i class=\"bx bxs-quote-alt-right quote-icon-right\"></i>
          </p>
        </div>
      </div>

    </div>

  </div>
</section><!-- End Testimonials Section -->

<!-- ======= Cta Section ======= -->
<section id=\"cta\" class=\"cta\">
  <div class=\"container\" data-aos=\"zoom-in\">

    <div class=\"text-center\">
      <h3>Call To Action</h3>
      <p> Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
      <a class=\"cta-btn\" href=\"#\">Call To Action</a>
    </div>

  </div>
</section><!-- End Cta Section -->

<!-- ======= Portfolio Section ======= -->
<section id=\"portfolio\" class=\"portfolio\">
  <div class=\"container\" data-aos=\"fade-up\">

    <div class=\"section-title\">
      <h2>Portfolio</h2>
      <p>Check our Portfolio</p>
    </div>

    <div class=\"row\" data-aos=\"fade-up\" data-aos-delay=\"100\">
      <div class=\"col-lg-12 d-flex justify-content-center\">
        <ul id=\"portfolio-flters\">
          <li data-filter=\"*\" class=\"filter-active\">All</li>
          <li data-filter=\".filter-app\">App</li>
          <li data-filter=\".filter-card\">Card</li>
          <li data-filter=\".filter-web\">Web</li>
        </ul>
      </div>
    </div>

    <div class=\"row portfolio-container\" data-aos=\"fade-up\" data-aos-delay=\"200\">

      <div class=\"col-lg-4 col-md-6 portfolio-item filter-app\">
        <img src=\"assets/img/portfolio/portfolio-1.jpg\" class=\"img-fluid\" alt=\"\">
        <div class=\"portfolio-info\">
          <h4>App 1</h4>
          <p>App</p>
          <a href=\"assets/img/portfolio/portfolio-1.jpg\" data-gall=\"portfolioGallery\" class=\"venobox preview-link\" title=\"App 1\"><i class=\"bx bx-plus\"></i></a>
          <a href=\"portfolio-details.html\" class=\"details-link\" title=\"More Details\"><i class=\"bx bx-link\"></i></a>
        </div>
      </div>

      <div class=\"col-lg-4 col-md-6 portfolio-item filter-web\">
        <img src=\"assets/img/portfolio/portfolio-2.jpg\" class=\"img-fluid\" alt=\"\">
        <div class=\"portfolio-info\">
          <h4>Web 3</h4>
          <p>Web</p>
          <a href=\"assets/img/portfolio/portfolio-2.jpg\" data-gall=\"portfolioGallery\" class=\"venobox preview-link\" title=\"Web 3\"><i class=\"bx bx-plus\"></i></a>
          <a href=\"portfolio-details.html\" class=\"details-link\" title=\"More Details\"><i class=\"bx bx-link\"></i></a>
        </div>
      </div>

      <div class=\"col-lg-4 col-md-6 portfolio-item filter-app\">
        <img src=\"assets/img/portfolio/portfolio-3.jpg\" class=\"img-fluid\" alt=\"\">
        <div class=\"portfolio-info\">
          <h4>App 2</h4>
          <p>App</p>
          <a href=\"assets/img/portfolio/portfolio-3.jpg\" data-gall=\"portfolioGallery\" class=\"venobox preview-link\" title=\"App 2\"><i class=\"bx bx-plus\"></i></a>
          <a href=\"portfolio-details.html\" class=\"details-link\" title=\"More Details\"><i class=\"bx bx-link\"></i></a>
        </div>
      </div>

      <div class=\"col-lg-4 col-md-6 portfolio-item filter-card\">
        <img src=\"assets/img/portfolio/portfolio-4.jpg\" class=\"img-fluid\" alt=\"\">
        <div class=\"portfolio-info\">
          <h4>Card 2</h4>
          <p>Card</p>
          <a href=\"assets/img/portfolio/portfolio-4.jpg\" data-gall=\"portfolioGallery\" class=\"venobox preview-link\" title=\"Card 2\"><i class=\"bx bx-plus\"></i></a>
          <a href=\"portfolio-details.html\" class=\"details-link\" title=\"More Details\"><i class=\"bx bx-link\"></i></a>
        </div>
      </div>

      <div class=\"col-lg-4 col-md-6 portfolio-item filter-web\">
        <img src=\"assets/img/portfolio/portfolio-5.jpg\" class=\"img-fluid\" alt=\"\">
        <div class=\"portfolio-info\">
          <h4>Web 2</h4>
          <p>Web</p>
          <a href=\"assets/img/portfolio/portfolio-5.jpg\" data-gall=\"portfolioGallery\" class=\"venobox preview-link\" title=\"Web 2\"><i class=\"bx bx-plus\"></i></a>
          <a href=\"portfolio-details.html\" class=\"details-link\" title=\"More Details\"><i class=\"bx bx-link\"></i></a>
        </div>
      </div>

      <div class=\"col-lg-4 col-md-6 portfolio-item filter-app\">
        <img src=\"assets/img/portfolio/portfolio-6.jpg\" class=\"img-fluid\" alt=\"\">
        <div class=\"portfolio-info\">
          <h4>App 3</h4>
          <p>App</p>
          <a href=\"assets/img/portfolio/portfolio-6.jpg\" data-gall=\"portfolioGallery\" class=\"venobox preview-link\" title=\"App 3\"><i class=\"bx bx-plus\"></i></a>
          <a href=\"portfolio-details.html\" class=\"details-link\" title=\"More Details\"><i class=\"bx bx-link\"></i></a>
        </div>
      </div>

      <div class=\"col-lg-4 col-md-6 portfolio-item filter-card\">
        <img src=\"assets/img/portfolio/portfolio-7.jpg\" class=\"img-fluid\" alt=\"\">
        <div class=\"portfolio-info\">
          <h4>Card 1</h4>
          <p>Card</p>
          <a href=\"assets/img/portfolio/portfolio-7.jpg\" data-gall=\"portfolioGallery\" class=\"venobox preview-link\" title=\"Card 1\"><i class=\"bx bx-plus\"></i></a>
          <a href=\"portfolio-details.html\" class=\"details-link\" title=\"More Details\"><i class=\"bx bx-link\"></i></a>
        </div>
      </div>

      <div class=\"col-lg-4 col-md-6 portfolio-item filter-card\">
        <img src=\"assets/img/portfolio/portfolio-8.jpg\" class=\"img-fluid\" alt=\"\">
        <div class=\"portfolio-info\">
          <h4>Card 3</h4>
          <p>Card</p>
          <a href=\"assets/img/portfolio/portfolio-8.jpg\" data-gall=\"portfolioGallery\" class=\"venobox preview-link\" title=\"Card 3\"><i class=\"bx bx-plus\"></i></a>
          <a href=\"portfolio-details.html\" class=\"details-link\" title=\"More Details\"><i class=\"bx bx-link\"></i></a>
        </div>
      </div>

      <div class=\"col-lg-4 col-md-6 portfolio-item filter-web\">
        <img src=\"assets/img/portfolio/portfolio-9.jpg\" class=\"img-fluid\" alt=\"\">
        <div class=\"portfolio-info\">
          <h4>Web 3</h4>
          <p>Web</p>
          <a href=\"assets/img/portfolio/portfolio-9.jpg\" data-gall=\"portfolioGallery\" class=\"venobox preview-link\" title=\"Web 3\"><i class=\"bx bx-plus\"></i></a>
          <a href=\"portfolio-details.html\" class=\"details-link\" title=\"More Details\"><i class=\"bx bx-link\"></i></a>
        </div>
      </div>

    </div>

  </div>
</section><!-- End Portfolio Section -->

<!-- ======= Team Section ======= -->
<section id=\"team\" class=\"team section-bg\">
  <div class=\"container\" data-aos=\"fade-up\">

    <div class=\"section-title\">
      <h2>Team</h2>
      <p>Check our Team</p>
    </div>

    <div class=\"row\">

      <div class=\"col-xl-3 col-lg-4 col-md-6\">
        <div class=\"member\" data-aos=\"zoom-in\" data-aos-delay=\"100\">
          <img src=\"assets/img/team/team-1.jpg\" class=\"img-fluid\" alt=\"\">
          <div class=\"member-info\">
            <div class=\"member-info-content\">
              <h4>Walter White</h4>
              <span>Chief Executive Officer</span>
            </div>
            <div class=\"social\">
              <a href=\"\"><i class=\"icofont-twitter\"></i></a>
              <a href=\"\"><i class=\"icofont-facebook\"></i></a>
              <a href=\"\"><i class=\"icofont-instagram\"></i></a>
              <a href=\"\"><i class=\"icofont-linkedin\"></i></a>
            </div>
          </div>
        </div>
      </div>

      <div class=\"col-xl-3 col-lg-4 col-md-6\" data-wow-delay=\"0.1s\">
        <div class=\"member\" data-aos=\"zoom-in\" data-aos-delay=\"200\">
          <img src=\"assets/img/team/team-2.jpg\" class=\"img-fluid\" alt=\"\">
          <div class=\"member-info\">
            <div class=\"member-info-content\">
              <h4>Sarah Jhonson</h4>
              <span>Product Manager</span>
            </div>
            <div class=\"social\">
              <a href=\"\"><i class=\"icofont-twitter\"></i></a>
              <a href=\"\"><i class=\"icofont-facebook\"></i></a>
              <a href=\"\"><i class=\"icofont-instagram\"></i></a>
              <a href=\"\"><i class=\"icofont-linkedin\"></i></a>
            </div>
          </div>
        </div>
      </div>

      <div class=\"col-xl-3 col-lg-4 col-md-6\" data-wow-delay=\"0.2s\">
        <div class=\"member\" data-aos=\"zoom-in\" data-aos-delay=\"300\">
          <img src=\"assets/img/team/team-3.jpg\" class=\"img-fluid\" alt=\"\">
          <div class=\"member-info\">
            <div class=\"member-info-content\">
              <h4>William Anderson</h4>
              <span>CTO</span>
            </div>
            <div class=\"social\">
              <a href=\"\"><i class=\"icofont-twitter\"></i></a>
              <a href=\"\"><i class=\"icofont-facebook\"></i></a>
              <a href=\"\"><i class=\"icofont-instagram\"></i></a>
              <a href=\"\"><i class=\"icofont-linkedin\"></i></a>
            </div>
          </div>
        </div>
      </div>

      <div class=\"col-xl-3 col-lg-4 col-md-6\" data-wow-delay=\"0.3s\">
        <div class=\"member\" data-aos=\"zoom-in\" data-aos-delay=\"400\">
          <img src=\"assets/img/team/team-4.jpg\" class=\"img-fluid\" alt=\"\">
          <div class=\"member-info\">
            <div class=\"member-info-content\">
              <h4>Amanda Jepson</h4>
              <span>Accountant</span>
            </div>
            <div class=\"social\">
              <a href=\"\"><i class=\"icofont-twitter\"></i></a>
              <a href=\"\"><i class=\"icofont-facebook\"></i></a>
              <a href=\"\"><i class=\"icofont-instagram\"></i></a>
              <a href=\"\"><i class=\"icofont-linkedin\"></i></a>
            </div>
          </div>
        </div>
      </div>

    </div>

  </div>
</section><!-- End Team Section -->

<!-- ======= Pricing Section ======= -->
<section id=\"pricing\" class=\"pricing\">
  <div class=\"container\" data-aos=\"fade-up\">

    <div class=\"section-title\">
      <h2>Pricing</h2>
      <p>Our Competing Prices</p>
    </div>

    <div class=\"row align-items-center\">

      <div class=\"col-lg-4\">
        <div class=\"box\" data-aos=\"zoom-in\" data-aos-delay=\"100\">
          <h3>Free</h3>
          <h4>\$0<span>per month</span></h4>
          <ul>
            <li><i class=\"bx bx-check\"></i> Quam adipiscing vitae proin</li>
            <li><i class=\"bx bx-check\"></i> Nec feugiat nisl pretium</li>
            <li><i class=\"bx bx-check\"></i> Nulla at volutpat diam uteera</li>
            <li class=\"na\"><i class=\"bx bx-x\"></i> <span>Pharetra massa massa ultricies</span></li>
            <li class=\"na\"><i class=\"bx bx-x\"></i> <span>Massa ultricies mi quis hendrerit</span></li>
          </ul>
          <a href=\"#\" class=\"get-started-btn\">Get Started</a>
        </div>
      </div>

      <div class=\"col-lg-4\">
        <div class=\"box featured\" data-aos=\"zoom-in\" data-aos-delay=\"100\">
          <h3>Business</h3>
          <h4>\$29<span>per month</span></h4>
          <ul>
            <li><i class=\"bx bx-check\"></i> Quam adipiscing vitae proin</li>
            <li><i class=\"bx bx-check\"></i> Nec feugiat nisl pretium</li>
            <li><i class=\"bx bx-check\"></i> Nulla at volutpat diam uteera</li>
            <li><i class=\"bx bx-check\"></i> Pharetra massa massa ultricies</li>
            <li><i class=\"bx bx-check\"></i> Massa ultricies mi quis hendrerit</li>
          </ul>
          <a href=\"#\" class=\"get-started-btn\">Get Started</a>
        </div>
      </div>

      <div class=\"col-lg-4\">
        <div class=\"box\" data-aos=\"zoom-in\" data-aos-delay=\"100\">
          <h3>Developer</h3>
          <h4>\$49<span>per month</span></h4>
          <ul>
            <li><i class=\"bx bx-check\"></i> Quam adipiscing vitae proin</li>
            <li><i class=\"bx bx-check\"></i> Nec feugiat nisl pretium</li>
            <li><i class=\"bx bx-check\"></i> Nulla at volutpat diam uteera</li>
            <li><i class=\"bx bx-check\"></i> Pharetra massa massa ultricies</li>
            <li><i class=\"bx bx-check\"></i> Massa ultricies mi quis hendrerit</li>
          </ul>
          <a href=\"#\" class=\"get-started-btn\">Get Started</a>
        </div>
      </div>

    </div>

  </div>
</section><!-- End Pricing Section -->

<!-- ======= Frequently Asked Questions Section ======= -->
<section id=\"faq\" class=\"faq\">
  <div class=\"container\" data-aos=\"fade-up\">

    <div class=\"section-title\">
      <h2>F.A.Q</h2>
      <p>Frequently Asked Questions</p>
    </div>

    <div class=\"row faq-item d-flex align-items-stretch\" data-aos=\"fade-up\" data-aos-delay=\"100\">
      <div class=\"col-lg-5\">
        <i class=\"bx bx-help-circle\"></i>
        <h4>Non consectetur a erat nam at lectus urna duis?</h4>
      </div>
      <div class=\"col-lg-7\">
        <p>
          Feugiat pretium nibh ipsum consequat. Tempus iaculis urna id volutpat lacus laoreet non curabitur gravida. Venenatis lectus magna fringilla urna porttitor rhoncus dolor purus non.
        </p>
      </div>
    </div><!-- End F.A.Q Item-->

    <div class=\"row faq-item d-flex align-items-stretch\" data-aos=\"fade-up\" data-aos-delay=\"200\">
      <div class=\"col-lg-5\">
        <i class=\"bx bx-help-circle\"></i>
        <h4>Feugiat scelerisque varius morbi enim nunc faucibus a pellentesque?</h4>
      </div>
      <div class=\"col-lg-7\">
        <p>
          Dolor sit amet consectetur adipiscing elit pellentesque habitant morbi. Id interdum velit laoreet id donec ultrices. Fringilla phasellus faucibus scelerisque eleifend donec pretium. Est pellentesque elit ullamcorper dignissim.
        </p>
      </div>
    </div><!-- End F.A.Q Item-->

    <div class=\"row faq-item d-flex align-items-stretch\" data-aos=\"fade-up\" data-aos-delay=\"300\">
      <div class=\"col-lg-5\">
        <i class=\"bx bx-help-circle\"></i>
        <h4>Dolor sit amet consectetur adipiscing elit pellentesque habitant morbi?</h4>
      </div>
      <div class=\"col-lg-7\">
        <p>
          Eleifend mi in nulla posuere sollicitudin aliquam ultrices sagittis orci. Faucibus pulvinar elementum integer enim. Sem nulla pharetra diam sit amet nisl suscipit. Rutrum tellus pellentesque eu tincidunt. Lectus urna duis convallis convallis tellus.
        </p>
      </div>
    </div><!-- End F.A.Q Item-->

    <div class=\"row faq-item d-flex align-items-stretch\" data-aos=\"fade-up\" data-aos-delay=\"400\">
      <div class=\"col-lg-5\">
        <i class=\"bx bx-help-circle\"></i>
        <h4>Ac odio tempor orci dapibus. Aliquam eleifend mi in nulla?</h4>
      </div>
      <div class=\"col-lg-7\">
        <p>
          Aperiam itaque sit optio et deleniti eos nihil quidem cumque. Voluptas dolorum accusantium sunt sit enim. Provident consequuntur quam aut reiciendis qui rerum dolorem sit odio. Repellat assumenda soluta sunt pariatur error doloribus fuga.
        </p>
      </div>
    </div><!-- End F.A.Q Item-->

    <div class=\"row faq-item d-flex align-items-stretch\" data-aos=\"fade-up\" data-aos-delay=\"500\">
      <div class=\"col-lg-5\">
        <i class=\"bx bx-help-circle\"></i>
        <h4>Tempus quam pellentesque nec nam aliquam sem et tortor consequat?</h4>
      </div>
      <div class=\"col-lg-7\">
        <p>
          Molestie a iaculis at erat pellentesque adipiscing commodo. Dignissim suspendisse in est ante in. Nunc vel risus commodo viverra maecenas accumsan. Sit amet nisl suscipit adipiscing bibendum est. Purus gravida quis blandit turpis cursus in
        </p>
      </div>
    </div><!-- End F.A.Q Item-->

  </div>
</section><!-- End Frequently Asked Questions Section -->

<!-- ======= Contact Section ======= -->
<section id=\"contact\" class=\"contact section-bg\">
  <div class=\"container\" data-aos=\"fade-up\">

    <div class=\"section-title\">
      <h2>Contact</h2>
      <p>Contact Us</p>
    </div>

    <div class=\"row\">

      <div class=\"col-lg-6\">

        <div class=\"row\">
          <div class=\"col-md-12\">
            <div class=\"info-box\">
              <i class=\"bx bx-map\"></i>
              <h3>Our Address</h3>
              <p>A108 Adam Street, New York, NY 535022</p>
            </div>
          </div>
          <div class=\"col-md-6\">
            <div class=\"info-box mt-4\">
              <i class=\"bx bx-envelope\"></i>
              <h3>Email Us</h3>
              <p>info@example.com<br>contact@example.com</p>
            </div>
          </div>
          <div class=\"col-md-6\">
            <div class=\"info-box mt-4\">
              <i class=\"bx bx-phone-call\"></i>
              <h3>Call Us</h3>
              <p>+1 5589 55488 55<br>+1 6678 254445 41</p>
            </div>
          </div>
        </div>

      </div>

      <div class=\"col-lg-6\">
        <form action=\"forms/contact.php\" method=\"post\" role=\"form\" class=\"php-email-form\">
          <div class=\"form-row\">
            <div class=\"col form-group\">
              <input type=\"text\" name=\"name\" class=\"form-control\" id=\"name\" placeholder=\"Your Name\" data-rule=\"minlen:4\" data-msg=\"Please enter at least 4 chars\" />
              <div class=\"validate\"></div>
            </div>
            <div class=\"col form-group\">
              <input type=\"email\" class=\"form-control\" name=\"email\" id=\"email\" placeholder=\"Your Email\" data-rule=\"email\" data-msg=\"Please enter a valid email\" />
              <div class=\"validate\"></div>
            </div>
          </div>
          <div class=\"form-group\">
            <input type=\"text\" class=\"form-control\" name=\"subject\" id=\"subject\" placeholder=\"Subject\" data-rule=\"minlen:4\" data-msg=\"Please enter at least 8 chars of subject\" />
            <div class=\"validate\"></div>
          </div>
          <div class=\"form-group\">
            <textarea class=\"form-control\" name=\"message\" rows=\"5\" data-rule=\"required\" data-msg=\"Please write something for us\" placeholder=\"Message\"></textarea>
            <div class=\"validate\"></div>
          </div>
          <div class=\"mb-3\">
            <div class=\"loading\">Loading</div>
            <div class=\"error-message\"></div>
            <div class=\"sent-message\">Your message has been sent. Thank you!</div>
          </div>
          <div class=\"text-center\"><button type=\"submit\">Send Message</button></div>
        </form>
      </div>

    </div>

  </div>
</section><!-- End Contact Section -->




{% endblock %}", "test", "/Applications/MAMP/htdocs/craft/smsi/templates/test.html");
    }
}
