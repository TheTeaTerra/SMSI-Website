<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* settings/fields */
class __TwigTemplate_c0eb76944dd01cf006c1aac9a5ece5bdf2054e1da159cb5259530a32a4bdb865 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'actionButton' => [$this, 'block_actionButton'],
            'sidebar' => [$this, 'block_sidebar'],
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 3
        return "_layouts/cp";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("template", "settings/fields");
        // line 1
        Craft::$app->controller->requireAdmin();
        // line 4
        $context["title"] = $this->extensions['craft\web\twig\Extension']->translateFilter("Fields", "app");
        // line 6
        craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 6, $this->source); })()), "registerAssetBundle", [0 => "craft\\web\\assets\\fields\\FieldsAsset"], "method");
        // line 7
        craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 7, $this->source); })()), "registerAssetBundle", [0 => "craft\\web\\assets\\admintable\\AdminTableAsset"], "method");
        // line 9
        craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 9, $this->source); })()), "registerTranslations", [0 => "app", 1 => [0 => "What do you want to name the group?", 1 => "Could not create the group:", 2 => "Could not create the group:", 3 => "Are you sure you want to delete this group and all its fields?", 4 => "Could not delete the group.", 5 => "Group renamed.", 6 => "Name", 7 => "Handle", 8 => "Type", 9 => "Group", 10 => "This group doesn’t have any fields yet.", 11 => "No fields exist yet."]], "method");
        // line 24
        $context["crumbs"] = [0 => ["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Settings", "app"), "url" => craft\helpers\UrlHelper::url("settings")]];
        // line 28
        $context["groups"] = craft\helpers\ArrayHelper::index(craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 28, $this->source); })()), "app", []), "fields", []), "getAllGroups", [], "method"), "id");
        // line 30
        if ((isset($context["groupId"]) || array_key_exists("groupId", $context))) {
            // line 31
            if ( !craft\helpers\Template::attribute($this->env, $this->source, ($context["groups"] ?? null), (isset($context["groupId"]) || array_key_exists("groupId", $context) ? $context["groupId"] : (function () { throw new RuntimeError('Variable "groupId" does not exist.', 31, $this->source); })()), [], "array", true, true)) {
                // line 32
                throw new yii\web\NotFoundHttpException();
            }
            // line 35
            $context["fields"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["groups"]) || array_key_exists("groups", $context) ? $context["groups"] : (function () { throw new RuntimeError('Variable "groups" does not exist.', 35, $this->source); })()), (isset($context["groupId"]) || array_key_exists("groupId", $context) ? $context["groupId"] : (function () { throw new RuntimeError('Variable "groupId" does not exist.', 35, $this->source); })()), [], "array"), "getFields", [], "method");
            // line 36
            $context["emptyMessage"] = $this->extensions['craft\web\twig\Extension']->translateFilter("This group doesn’t have any fields yet.", "app");
        } else {
            // line 38
            $context["emptyMessage"] = $this->extensions['craft\web\twig\Extension']->translateFilter("No fields exist yet.", "app");
            // line 39
            $context["fields"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 39, $this->source); })()), "app", []), "fields", []), "getAllFields", [], "method");
        }
        // line 81
        $context["tableData"] = [];
        // line 82
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["fields"]) || array_key_exists("fields", $context) ? $context["fields"] : (function () { throw new RuntimeError('Variable "fields" does not exist.', 82, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["field"]) {
            // line 83
            $context["fieldIsMissing"] = false;
            // line 85
            if (call_user_func_array($this->env->getTest('missing')->getCallable(), [$context["field"]])) {
                // line 86
                $context["fieldIsMissing"] = true;
            }
            // line 89
            if ( !(isset($context["groupId"]) || array_key_exists("groupId", $context))) {
                // line 90
                $context["group"] = twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, $context["field"], "group", []), "name", []), "site"));
            }
            // line 93
            $context["tableData"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["tableData"]) || array_key_exists("tableData", $context) ? $context["tableData"] : (function () { throw new RuntimeError('Variable "tableData" does not exist.', 93, $this->source); })()), [0 => ["id" => craft\helpers\Template::attribute($this->env, $this->source,             // line 94
$context["field"], "id", []), "title" => $this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source,             // line 95
$context["field"], "name", []), "site"), "url" => craft\helpers\UrlHelper::url(("settings/fields/edit/" . craft\helpers\Template::attribute($this->env, $this->source,             // line 96
$context["field"], "id", []))), "handle" => craft\helpers\Template::attribute($this->env, $this->source,             // line 97
$context["field"], "handle", []), "type" => ["isMissing" =>             // line 99
(isset($context["fieldIsMissing"]) || array_key_exists("fieldIsMissing", $context) ? $context["fieldIsMissing"] : (function () { throw new RuntimeError('Variable "fieldIsMissing" does not exist.', 99, $this->source); })()), "label" => ((            // line 100
(isset($context["fieldIsMissing"]) || array_key_exists("fieldIsMissing", $context) ? $context["fieldIsMissing"] : (function () { throw new RuntimeError('Variable "fieldIsMissing" does not exist.', 100, $this->source); })())) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["field"], "expectedType", [])) : (craft\helpers\Template::attribute($this->env, $this->source, $context["field"], "displayName", [], "method")))], "group" => ((            // line 103
$context["group"]) ?? (null))]]);
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['field'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 107
        ob_start();
        // line 108
        echo "    var columns = [
        { name: '__slot:title', title: Craft.t('app', 'Name') },
        { name: '__slot:handle', title: Craft.t('app', 'Handle') },
        {
            name: 'type',
            title: Craft.t('app', 'Type'),
            callback: function(value) {
                if (value.isMissing) {
                    return '<span class=\"error\">' + value.label + '</span>'
                }

                return value.label
            }
        },
    ];

    ";
        // line 124
        if ( !(isset($context["groupId"]) || array_key_exists("groupId", $context))) {
            // line 125
            echo "        columns.push({
            name: 'group',
            title: Craft.t('app', 'Group'),
        })
    ";
        }
        // line 130
        echo "
    new Craft.VueAdminTable({
        columns: columns,
        container: '#fields-vue-admin-table',
        deleteAction: 'fields/delete-field',
        emptyMessage: Craft.t('app', '";
        // line 135
        echo twig_escape_filter($this->env, (isset($context["emptyMessage"]) || array_key_exists("emptyMessage", $context) ? $context["emptyMessage"] : (function () { throw new RuntimeError('Variable "emptyMessage" does not exist.', 135, $this->source); })()), "html", null, true);
        echo "'),
        tableData: ";
        // line 136
        echo $this->extensions['craft\web\twig\Extension']->jsonEncodeFilter((isset($context["tableData"]) || array_key_exists("tableData", $context) ? $context["tableData"] : (function () { throw new RuntimeError('Variable "tableData" does not exist.', 136, $this->source); })()));
        echo ",
    });
";
        Craft::$app->getView()->registerJs(ob_get_clean(), 3);
        // line 3
        $this->parent = $this->loadTemplate("_layouts/cp", "settings/fields", 3);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        // line 0
        craft\helpers\Template::endProfile("template", "settings/fields");
    }

    // line 43
    public function block_actionButton($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("block", "actionButton");
        // line 44
        echo "    ";
        if ((isset($context["groups"]) || array_key_exists("groups", $context) ? $context["groups"] : (function () { throw new RuntimeError('Variable "groups" does not exist.', 44, $this->source); })())) {
            // line 45
            echo "        ";
            $context["newFieldUrl"] = craft\helpers\UrlHelper::url("settings/fields/new", (((isset($context["groupId"]) || array_key_exists("groupId", $context))) ? (["groupId" => (isset($context["groupId"]) || array_key_exists("groupId", $context) ? $context["groupId"] : (function () { throw new RuntimeError('Variable "groupId" does not exist.', 45, $this->source); })())]) : (null)));
            // line 46
            echo "        <a href=\"";
            echo twig_escape_filter($this->env, (isset($context["newFieldUrl"]) || array_key_exists("newFieldUrl", $context) ? $context["newFieldUrl"] : (function () { throw new RuntimeError('Variable "newFieldUrl" does not exist.', 46, $this->source); })()), "html", null, true);
            echo "\" class=\"submit btn add icon\">";
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("New field", "app"), "html", null, true);
            echo "</a>
    ";
        }
        // line 0
        craft\helpers\Template::endProfile("block", "actionButton");
    }

    // line 51
    public function block_sidebar($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("block", "sidebar");
        // line 52
        echo "    <nav>
        <ul id=\"groups\">
            <li><a href=\"";
        // line 54
        echo twig_escape_filter($this->env, craft\helpers\UrlHelper::url("settings/fields"), "html", null, true);
        echo "\"";
        if ( !(isset($context["groupId"]) || array_key_exists("groupId", $context))) {
            echo " class=\"sel\"";
        }
        echo ">";
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("All Fields", "app"), "html", null, true);
        echo "</a></li>
            ";
        // line 55
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["groups"]) || array_key_exists("groups", $context) ? $context["groups"] : (function () { throw new RuntimeError('Variable "groups" does not exist.', 55, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["group"]) {
            // line 56
            echo "                <li><a href=\"";
            echo twig_escape_filter($this->env, craft\helpers\UrlHelper::url(("settings/fields/" . craft\helpers\Template::attribute($this->env, $this->source, $context["group"], "id", []))), "html", null, true);
            echo "\"";
            if (((isset($context["groupId"]) || array_key_exists("groupId", $context)) && (craft\helpers\Template::attribute($this->env, $this->source, $context["group"], "id", []) == (isset($context["groupId"]) || array_key_exists("groupId", $context) ? $context["groupId"] : (function () { throw new RuntimeError('Variable "groupId" does not exist.', 56, $this->source); })())))) {
                echo " class=\"sel\"";
            }
            echo " data-id=\"";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["group"], "id", []), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source, $context["group"], "name", []), "site"), "html", null, true);
            echo "</a></li>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['group'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 58
        echo "        </ul>
    </nav>

    <div class=\"buttons\">
        <div id=\"newgroupbtn\" class=\"btn add icon\">";
        // line 62
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("New group", "app"), "html", null, true);
        echo "</div>

        ";
        // line 64
        if ((isset($context["groupId"]) || array_key_exists("groupId", $context))) {
            // line 65
            echo "            <div id=\"groupsettingsbtn\" class=\"btn settings icon menubtn\" title=\"";
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Settings", "app"), "html", null, true);
            echo "\"></div>
            <div class=\"menu\">
                <ul>
                    <li><a data-action=\"rename\" role=\"button\">";
            // line 68
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Rename selected group", "app"), "html", null, true);
            echo "</a></li>
                    <li><a data-action=\"delete\" role=\"button\">";
            // line 69
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Delete selected group", "app"), "html", null, true);
            echo "</a></li>
                </ul>
            </div>
        ";
        }
        // line 73
        echo "    </div>
";
        // line 0
        craft\helpers\Template::endProfile("block", "sidebar");
    }

    // line 77
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("block", "content");
        // line 78
        echo "    <div id=\"fields-vue-admin-table\"></div>
";
        // line 0
        craft\helpers\Template::endProfile("block", "content");
    }

    public function getTemplateName()
    {
        return "settings/fields";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  273 => 0,  270 => 78,  268 => 0,  264 => 77,  260 => 0,  257 => 73,  250 => 69,  246 => 68,  239 => 65,  237 => 64,  232 => 62,  226 => 58,  209 => 56,  205 => 55,  195 => 54,  191 => 52,  189 => 0,  185 => 51,  181 => 0,  173 => 46,  170 => 45,  167 => 44,  165 => 0,  161 => 43,  157 => 0,  154 => 3,  148 => 136,  144 => 135,  137 => 130,  130 => 125,  128 => 124,  110 => 108,  108 => 107,  102 => 103,  101 => 100,  100 => 99,  99 => 97,  98 => 96,  97 => 95,  96 => 94,  95 => 93,  92 => 90,  90 => 89,  87 => 86,  85 => 85,  83 => 83,  79 => 82,  77 => 81,  74 => 39,  72 => 38,  69 => 36,  67 => 35,  64 => 32,  62 => 31,  60 => 30,  58 => 28,  56 => 24,  54 => 9,  52 => 7,  50 => 6,  48 => 4,  46 => 1,  44 => 0,  37 => 3,);
    }

    public function getSourceContext()
    {
        return new Source("{% requireAdmin %}

{% extends \"_layouts/cp\" %}
{% set title = \"Fields\"|t('app') %}

{% do view.registerAssetBundle(\"craft\\\\web\\\\assets\\\\fields\\\\FieldsAsset\") %}
{% do view.registerAssetBundle('craft\\\\web\\\\assets\\\\admintable\\\\AdminTableAsset') -%}

{% do view.registerTranslations('app', [
    \"What do you want to name the group?\",
    \"Could not create the group:\",
    \"Could not create the group:\",
    \"Are you sure you want to delete this group and all its fields?\",
    \"Could not delete the group.\",
    \"Group renamed.\",
    \"Name\",
    \"Handle\",
    \"Type\",
    \"Group\",
    \"This group doesn’t have any fields yet.\",
    \"No fields exist yet.\",
]) %}

{% set crumbs = [
    { label: \"Settings\"|t('app'), url: url('settings') }
] %}

{% set groups = craft.app.fields.getAllGroups()|index('id') %}

{% if groupId is defined %}
    {% if groups[groupId] is not defined %}
        {% exit 404 %}
    {% endif %}

    {% set fields = groups[groupId].getFields() %}
    {% set emptyMessage = \"This group doesn’t have any fields yet.\"|t('app') %}
{% else %}
    {% set emptyMessage = \"No fields exist yet.\"|t('app') %}
    {% set fields = craft.app.fields.getAllFields() %}
{% endif %}


{% block actionButton %}
    {% if groups %}
        {% set newFieldUrl = url('settings/fields/new', (groupId is defined ? { groupId: groupId } : null)) %}
        <a href=\"{{ newFieldUrl }}\" class=\"submit btn add icon\">{{ \"New field\"|t('app') }}</a>
    {% endif %}
{% endblock %}


{% block sidebar %}
    <nav>
        <ul id=\"groups\">
            <li><a href=\"{{ url('settings/fields') }}\"{% if groupId is not defined %} class=\"sel\"{% endif %}>{{ \"All Fields\"|t('app') }}</a></li>
            {% for group in groups %}
                <li><a href=\"{{ url('settings/fields/'~group.id) }}\"{% if groupId is defined and group.id == groupId %} class=\"sel\"{% endif %} data-id=\"{{ group.id }}\">{{ group.name|t('site') }}</a></li>
            {% endfor %}
        </ul>
    </nav>

    <div class=\"buttons\">
        <div id=\"newgroupbtn\" class=\"btn add icon\">{{ \"New group\"|t('app') }}</div>

        {% if groupId is defined %}
            <div id=\"groupsettingsbtn\" class=\"btn settings icon menubtn\" title=\"{{ 'Settings'|t('app') }}\"></div>
            <div class=\"menu\">
                <ul>
                    <li><a data-action=\"rename\" role=\"button\">{{ \"Rename selected group\"|t('app') }}</a></li>
                    <li><a data-action=\"delete\" role=\"button\">{{ \"Delete selected group\"|t('app') }}</a></li>
                </ul>
            </div>
        {% endif %}
    </div>
{% endblock %}


{% block content %}
    <div id=\"fields-vue-admin-table\"></div>
{% endblock %}

{% set tableData = [] %}
{% for field in fields %}
    {% set fieldIsMissing = false %}

    {% if field is missing %}
        {% set fieldIsMissing = true %}
    {% endif %}

    {% if groupId is not defined %}
        {% set group = field.group.name|t('site')|e %}
    {% endif %}

    {% set tableData = tableData|merge([{
        id: field.id,
        title: field.name|t('site'),
        url: url('settings/fields/edit/' ~ field.id),
        handle: field.handle,
        type: {
            isMissing: fieldIsMissing,
            label: fieldIsMissing ? field.expectedType : field.displayName()
        },

        group: group ?? null,
    }]) %}
{% endfor %}

{% js %}
    var columns = [
        { name: '__slot:title', title: Craft.t('app', 'Name') },
        { name: '__slot:handle', title: Craft.t('app', 'Handle') },
        {
            name: 'type',
            title: Craft.t('app', 'Type'),
            callback: function(value) {
                if (value.isMissing) {
                    return '<span class=\"error\">' + value.label + '</span>'
                }

                return value.label
            }
        },
    ];

    {% if groupId is not defined %}
        columns.push({
            name: 'group',
            title: Craft.t('app', 'Group'),
        })
    {% endif %}

    new Craft.VueAdminTable({
        columns: columns,
        container: '#fields-vue-admin-table',
        deleteAction: 'fields/delete-field',
        emptyMessage: Craft.t('app', '{{ emptyMessage }}'),
        tableData: {{ tableData|json_encode|raw }},
    });
{% endjs %}
", "settings/fields", "/Applications/MAMP/htdocs/craft/smsi/vendor/craftcms/cms/src/templates/settings/fields/index.html");
    }
}
