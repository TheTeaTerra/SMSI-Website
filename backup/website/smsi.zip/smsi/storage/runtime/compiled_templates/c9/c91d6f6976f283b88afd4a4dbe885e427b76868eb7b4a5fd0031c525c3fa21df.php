<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _components/fieldtypes/Categories/settings */
class __TwigTemplate_614f7abe4ba4a39748b516ff65bec5778b1b8f72c87237fddecf73cd4ee456b8 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'fieldSettings' => [$this, 'block_fieldSettings'],
            'branchLimitField' => [$this, 'block_branchLimitField'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "_components/fieldtypes/elementfieldsettings";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("template", "_components/fieldtypes/Categories/settings");
        // line 3
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms", "_components/fieldtypes/Categories/settings", 3)->unwrap();
        // line 1
        $this->parent = $this->loadTemplate("_components/fieldtypes/elementfieldsettings", "_components/fieldtypes/Categories/settings", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        // line 0
        craft\helpers\Template::endProfile("template", "_components/fieldtypes/Categories/settings");
    }

    // line 6
    public function block_fieldSettings($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("block", "fieldSettings");
        // line 7
        echo "    ";
        $this->displayBlock("sourcesField", $context, $blocks);
        echo "

    ";
        // line 9
        $this->displayBlock('branchLimitField', $context, $blocks);
        // line 20
        echo "
    ";
        // line 21
        $this->displayBlock("viewModeField", $context, $blocks);
        echo "
    ";
        // line 22
        $this->displayBlock("selectionLabelField", $context, $blocks);
        echo "
    ";
        // line 23
        $this->displayBlock("validateRelatedElementsField", $context, $blocks);
        echo "
    ";
        // line 24
        $this->displayBlock("advancedSettings", $context, $blocks);
        echo "
";
        // line 0
        craft\helpers\Template::endProfile("block", "fieldSettings");
    }

    // line 9
    public function block_branchLimitField($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("block", "branchLimitField");
        // line 10
        echo "        ";
        echo twig_call_macro($macros["forms"], "macro_textField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Branch Limit", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Limit the number of selectable category branches.", "app"), "id" => "branchLimit", "name" => "branchLimit", "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 15
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 15, $this->source); })()), "branchLimit", []), "size" => 2, "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 17
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 17, $this->source); })()), "getErrors", [0 => "branchLimit"], "method")]], 10, $context, $this->getSourceContext());
        // line 18
        echo "
    ";
        // line 0
        craft\helpers\Template::endProfile("block", "branchLimitField");
    }

    public function getTemplateName()
    {
        return "_components/fieldtypes/Categories/settings";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  105 => 0,  102 => 18,  100 => 17,  99 => 15,  97 => 10,  95 => 0,  91 => 9,  87 => 0,  83 => 24,  79 => 23,  75 => 22,  71 => 21,  68 => 20,  66 => 9,  60 => 7,  58 => 0,  54 => 6,  50 => 0,  47 => 1,  45 => 3,  43 => 0,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends \"_components/fieldtypes/elementfieldsettings\" %}

{% import \"_includes/forms\" as forms %}


{% block fieldSettings %}
    {{ block('sourcesField') }}

    {% block branchLimitField %}
        {{ forms.textField({
            label: \"Branch Limit\"|t('app'),
            instructions: \"Limit the number of selectable category branches.\"|t('app'),
            id: 'branchLimit',
            name: 'branchLimit',
            value: field.branchLimit,
            size: 2,
            errors: field.getErrors('branchLimit')
        }) }}
    {% endblock %}

    {{ block('viewModeField') }}
    {{ block('selectionLabelField') }}
    {{ block('validateRelatedElementsField') }}
    {{ block('advancedSettings') }}
{% endblock %}
", "_components/fieldtypes/Categories/settings", "/Applications/MAMP/htdocs/craft/smsi/vendor/craftcms/cms/src/templates/_components/fieldtypes/Categories/settings.html");
    }
}
