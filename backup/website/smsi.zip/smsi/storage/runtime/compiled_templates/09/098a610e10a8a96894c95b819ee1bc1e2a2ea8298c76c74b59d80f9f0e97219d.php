<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* __string_template__5f1a9ac6e8673a02557d0e8a0ded4c63b39435f0ed8c6f5dbf27ed059143717f */
class __TwigTemplate_537a194c79cba1feeb5d2cd0f9e771b3e334a4aa716e5236e3191d21df33fb9b extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "__string_template__5f1a9ac6e8673a02557d0e8a0ded4c63b39435f0ed8c6f5dbf27ed059143717f");
        // line 1
        echo "cariers/";
        echo (((craft\helpers\Template::attribute($this->env, $this->source, ($context["_variables"] ?? null), "slug", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["_variables"] ?? null), "slug", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["_variables"] ?? null), "slug", [])) : (craft\helpers\Template::attribute($this->env, $this->source, ($context["object"] ?? null), "slug", [])));
        // line 0
        craft\helpers\Template::endProfile("template", "__string_template__5f1a9ac6e8673a02557d0e8a0ded4c63b39435f0ed8c6f5dbf27ed059143717f");
    }

    public function getTemplateName()
    {
        return "__string_template__5f1a9ac6e8673a02557d0e8a0ded4c63b39435f0ed8c6f5dbf27ed059143717f";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  41 => 0,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("cariers/{{ (_variables.slug ?? object.slug)|raw }}", "__string_template__5f1a9ac6e8673a02557d0e8a0ded4c63b39435f0ed8c6f5dbf27ed059143717f", "");
    }
}
