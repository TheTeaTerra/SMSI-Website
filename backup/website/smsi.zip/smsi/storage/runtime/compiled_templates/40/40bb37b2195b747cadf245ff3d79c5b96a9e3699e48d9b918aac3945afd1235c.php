<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* settings/assets/settings */
class __TwigTemplate_99a3aaad924ee87c4eb7c38b9abdffafd5e679d8ea76e14513885b6af42ccc9c extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 3
        return "settings/assets/_layout";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("template", "settings/assets/settings");
        // line 1
        Craft::$app->controller->requireAdmin();
        // line 4
        $context["selectedNavItem"] = "settings";
        // line 6
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms", "settings/assets/settings", 6)->unwrap();
        // line 9
        if ( !(isset($context["settings"]) || array_key_exists("settings", $context))) {
            // line 10
            $context["settings"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 10, $this->source); })()), "app", []), "projectConfig", []), "get", [0 => "assets"], "method");
        }
        // line 13
        $context["allVolumes"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 13, $this->source); })()), "app", []), "volumes", []), "getAllVolumes", [], "method");
        // line 15
        $context["volumeOptions"] = [0 => ["value" => "", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("In the local temp folder", "app")]];
        // line 18
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["allVolumes"]) || array_key_exists("allVolumes", $context) ? $context["allVolumes"] : (function () { throw new RuntimeError('Variable "allVolumes" does not exist.', 18, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["volume"]) {
            // line 19
            $context["volumeOptions"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["volumeOptions"]) || array_key_exists("volumeOptions", $context) ? $context["volumeOptions"] : (function () { throw new RuntimeError('Variable "volumeOptions" does not exist.', 19, $this->source); })()), [0 => ["value" => craft\helpers\Template::attribute($this->env, $this->source,             // line 20
$context["volume"], "uid", []), "label" => craft\helpers\Template::attribute($this->env, $this->source, $context["volume"], "name", [])]]);
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['volume'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 24
        ob_start();
        // line 25
        echo "    ";
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms", "settings/assets/settings", 25)->unwrap();
        // line 26
        echo "    <div class=\"flex\">
        <div>
            ";
        // line 28
        echo twig_call_macro($macros["forms"], "macro_select", [["id" => "tempVolumeUid", "name" => "tempVolumeUid", "options" =>         // line 31
(isset($context["volumeOptions"]) || array_key_exists("volumeOptions", $context) ? $context["volumeOptions"] : (function () { throw new RuntimeError('Variable "volumeOptions" does not exist.', 31, $this->source); })()), "value" => (((craft\helpers\Template::attribute($this->env, $this->source,         // line 32
($context["settings"] ?? null), "tempVolumeUid", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["settings"] ?? null), "tempVolumeUid", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["settings"] ?? null), "tempVolumeUid", [])) : (null))]], 28, $context, $this->getSourceContext());
        // line 33
        echo "
        </div>
        <div class=\"flex-grow\">
            ";
        // line 36
        echo twig_call_macro($macros["forms"], "macro_text", [["id" => "tempSubpath", "class" => ("ltr" . (( !(((craft\helpers\Template::attribute($this->env, $this->source,         // line 38
($context["settings"] ?? null), "tempVolumeUid", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["settings"] ?? null), "tempVolumeUid", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["settings"] ?? null), "tempVolumeUid", [])) : (null))) ? (" hidden") : (""))), "name" => "tempSubpath", "value" => (((craft\helpers\Template::attribute($this->env, $this->source,         // line 40
($context["settings"] ?? null), "tempSubpath", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["settings"] ?? null), "tempSubpath", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["settings"] ?? null), "tempSubpath", [])) : (null)), "placeholder" => $this->extensions['craft\web\twig\Extension']->translateFilter("path/to/subfolder", "app")]], 36, $context, $this->getSourceContext());
        // line 42
        echo "
        </div>
    </div>
";
        $context["tempVolumeInput"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 65
        ob_start();
        // line 66
        echo "    \$('#tempVolumeUid').change(function() {
        if (\$(this).val()) {
            \$('#tempSubpath').removeClass('hidden');
        } else {
            \$('#tempSubpath').addClass('hidden');
        }
    })
";
        Craft::$app->getView()->registerJs(ob_get_clean(), 3);
        // line 3
        $this->parent = $this->loadTemplate("settings/assets/_layout", "settings/assets/settings", 3);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        // line 0
        craft\helpers\Template::endProfile("template", "settings/assets/settings");
    }

    // line 47
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("block", "content");
        // line 48
        echo "    <form id=\"settings-form\" method=\"post\" class=\"centered\" accept-charset=\"UTF-8\" data-saveshortcut>
        ";
        // line 49
        echo craft\helpers\Html::actionInput("asset-settings/save-asset-settings");
        echo "
        ";
        // line 50
        echo craft\helpers\Html::csrfInput();
        echo "

        ";
        // line 52
        echo twig_call_macro($macros["forms"], "macro_field", [["first" => true, "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Temp Uploads Location", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Where do you want to store temporary asset uploads?", "app"), "warning" => ((twig_test_empty(        // line 56
(isset($context["allVolumes"]) || array_key_exists("allVolumes", $context) ? $context["allVolumes"] : (function () { throw new RuntimeError('Variable "allVolumes" does not exist.', 56, $this->source); })()))) ? ($this->extensions['craft\web\twig\Extension']->translateFilter("No volumes exist yet.", "app")) : (""))],         // line 57
(isset($context["tempVolumeInput"]) || array_key_exists("tempVolumeInput", $context) ? $context["tempVolumeInput"] : (function () { throw new RuntimeError('Variable "tempVolumeInput" does not exist.', 57, $this->source); })())], 52, $context, $this->getSourceContext());
        echo "

        <div class=\"buttons\">
            <input type=\"submit\" class=\"btn submit\" value=\"";
        // line 60
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Save", "app"), "html", null, true);
        echo "\">
        </div>
    </form>
";
        // line 0
        craft\helpers\Template::endProfile("block", "content");
    }

    public function getTemplateName()
    {
        return "settings/assets/settings";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  149 => 0,  143 => 60,  137 => 57,  136 => 56,  135 => 52,  130 => 50,  126 => 49,  123 => 48,  121 => 0,  117 => 47,  113 => 0,  110 => 3,  100 => 66,  98 => 65,  92 => 42,  90 => 40,  89 => 38,  88 => 36,  83 => 33,  81 => 32,  80 => 31,  79 => 28,  75 => 26,  72 => 25,  70 => 24,  64 => 20,  63 => 19,  59 => 18,  57 => 15,  55 => 13,  52 => 10,  50 => 9,  48 => 6,  46 => 4,  44 => 1,  42 => 0,  35 => 3,);
    }

    public function getSourceContext()
    {
        return new Source("{% requireAdmin %}

{% extends \"settings/assets/_layout\" %}
{% set selectedNavItem = 'settings' %}

{% import \"_includes/forms\" as forms %}


{% if settings is not defined %}
    {% set settings = craft.app.projectConfig.get('assets') %}
{% endif %}

{% set allVolumes = craft.app.volumes.getAllVolumes() %}

{% set volumeOptions = [
    { value: '', label: 'In the local temp folder'|t('app') }
] %}
{% for volume in allVolumes %}
    {% set volumeOptions = volumeOptions|merge([
        { value: volume.uid, label: volume.name }
    ]) %}
{% endfor %}

{% set tempVolumeInput %}
    {% import \"_includes/forms\" as forms %}
    <div class=\"flex\">
        <div>
            {{ forms.select({
                id: 'tempVolumeUid',
                name: 'tempVolumeUid',
                options: volumeOptions,
                value: settings.tempVolumeUid ?? null
            }) }}
        </div>
        <div class=\"flex-grow\">
            {{ forms.text({
                id: 'tempSubpath',
                class: 'ltr' ~ (not (settings.tempVolumeUid ?? null) ? ' hidden'),
                name: 'tempSubpath',
                value: settings.tempSubpath ?? null,
                placeholder: 'path/to/subfolder'|t('app')
            }) }}
        </div>
    </div>
{% endset %}

{% block content %}
    <form id=\"settings-form\" method=\"post\" class=\"centered\" accept-charset=\"UTF-8\" data-saveshortcut>
        {{ actionInput('asset-settings/save-asset-settings') }}
        {{ csrfInput() }}

        {{ forms.field({
            first: true,
            label: 'Temp Uploads Location'|t('app'),
            instructions: 'Where do you want to store temporary asset uploads?'|t('app'),
            warning: allVolumes is empty ? 'No volumes exist yet.'|t('app')
        }, tempVolumeInput) }}

        <div class=\"buttons\">
            <input type=\"submit\" class=\"btn submit\" value=\"{{ 'Save'|t('app') }}\">
        </div>
    </form>
{% endblock %}

{% js %}
    \$('#tempVolumeUid').change(function() {
        if (\$(this).val()) {
            \$('#tempSubpath').removeClass('hidden');
        } else {
            \$('#tempSubpath').addClass('hidden');
        }
    })
{% endjs %}
", "settings/assets/settings", "/Applications/MAMP/htdocs/craft/smsi/vendor/craftcms/cms/src/templates/settings/assets/settings.html");
    }
}
