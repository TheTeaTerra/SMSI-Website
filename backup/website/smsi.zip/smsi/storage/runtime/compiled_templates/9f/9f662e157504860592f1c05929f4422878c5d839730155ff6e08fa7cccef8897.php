<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _layouts/element */
class __TwigTemplate_559a0da354aeb73cd4ef14836da548f0dcf5be5d63fee9d324d49ed8d3175480 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'header' => [$this, 'block_header'],
            'contextMenu' => [$this, 'block_contextMenu'],
            'actionButton' => [$this, 'block_actionButton'],
            'main' => [$this, 'block_main'],
            'content' => [$this, 'block_content'],
            'details' => [$this, 'block_details'],
            'meta' => [$this, 'block_meta'],
            'settings' => [$this, 'block_settings'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 26
        return "_layouts/cp";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("template", "_layouts/element");
        // line 27
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms", "_layouts/element", 27)->unwrap();
        // line 29
        $context["supportedSiteIds"] = craft\helpers\ArrayHelper::getColumn(((craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 29, $this->source); })()), "app", []), "isMultiSite", [])) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 29, $this->source); })()), "getSupportedSites", [], "method")) : ([0 => craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 29, $this->source); })()), "siteId", [])])), function ($__s__) use ($context, $macros) { $context["s"] = $__s__; return (((craft\helpers\Template::attribute($this->env, $this->source, ($context["s"] ?? null), "siteId", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["s"] ?? null), "siteId", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["s"] ?? null), "siteId", [])) : ((isset($context["s"]) || array_key_exists("s", $context) ? $context["s"] : (function () { throw new RuntimeError('Variable "s" does not exist.', 29, $this->source); })()))); });
        // line 30
        $context["editableSiteIds"] = array_intersect((isset($context["supportedSiteIds"]) || array_key_exists("supportedSiteIds", $context) ? $context["supportedSiteIds"] : (function () { throw new RuntimeError('Variable "supportedSiteIds" does not exist.', 30, $this->source); })()), craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 30, $this->source); })()), "app", []), "sites", []), "getEditableSiteIds", [], "method"));
        // line 31
        $context["isMultiSiteElement"] = (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 31, $this->source); })()), "app", []), "isMultiSite", []) && (twig_length_filter($this->env, (isset($context["supportedSiteIds"]) || array_key_exists("supportedSiteIds", $context) ? $context["supportedSiteIds"] : (function () { throw new RuntimeError('Variable "supportedSiteIds" does not exist.', 31, $this->source); })())) > 1));
        // line 32
        $context["canEditMultipleSites"] = ((isset($context["isMultiSiteElement"]) || array_key_exists("isMultiSiteElement", $context) ? $context["isMultiSiteElement"] : (function () { throw new RuntimeError('Variable "isMultiSiteElement" does not exist.', 32, $this->source); })()) && (twig_length_filter($this->env, (isset($context["editableSiteIds"]) || array_key_exists("editableSiteIds", $context) ? $context["editableSiteIds"] : (function () { throw new RuntimeError('Variable "editableSiteIds" does not exist.', 32, $this->source); })())) > 1));
        // line 33
        $context["isDraft"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 33, $this->source); })()), "getIsDraft", [], "method");
        // line 34
        $context["isUnsavedDraft"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 34, $this->source); })()), "getIsUnsavedDraft", [], "method");
        // line 35
        $context["isRevision"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 35, $this->source); })()), "getIsRevision", [], "method");
        // line 36
        $context["isCurrent"] = ( !(isset($context["isDraft"]) || array_key_exists("isDraft", $context) ? $context["isDraft"] : (function () { throw new RuntimeError('Variable "isDraft" does not exist.', 36, $this->source); })()) &&  !(isset($context["isRevision"]) || array_key_exists("isRevision", $context) ? $context["isRevision"] : (function () { throw new RuntimeError('Variable "isRevision" does not exist.', 36, $this->source); })()));
        // line 38
        $context["previewTargets"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 38, $this->source); })()), "getPreviewTargets", [], "method");
        // line 39
        $context["enablePreview"] = ((isset($context["previewTargets"]) || array_key_exists("previewTargets", $context) ? $context["previewTargets"] : (function () { throw new RuntimeError('Variable "previewTargets" does not exist.', 39, $this->source); })()) &&  !craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 39, $this->source); })()), "app", []), "request", []), "isMobileBrowser", [0 => true], "method"));
        // line 41
        $context["canDeleteDraft"] = (((isset($context["isDraft"]) || array_key_exists("isDraft", $context) ? $context["isDraft"] : (function () { throw new RuntimeError('Variable "isDraft" does not exist.', 41, $this->source); })()) &&  !(isset($context["isUnsavedDraft"]) || array_key_exists("isUnsavedDraft", $context) ? $context["isUnsavedDraft"] : (function () { throw new RuntimeError('Variable "isUnsavedDraft" does not exist.', 41, $this->source); })())) && ((($context["canDeleteDraft"]) ?? (false)) || (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 41, $this->source); })()), "creatorId", []) == craft\helpers\Template::attribute($this->env, $this->source, (isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new RuntimeError('Variable "currentUser" does not exist.', 41, $this->source); })()), "id", []))));
        // line 42
        $context["canUpdateSource"] = (($context["canUpdateSource"]) ?? (false));
        // line 43
        $context["canDuplicateSource"] = (($context["canDuplicateSource"]) ?? (false));
        // line 44
        $context["canAddAnother"] = (($context["canAddAnother"]) ?? (false));
        // line 45
        $context["canDeleteSource"] = (($context["canDeleteSource"]) ?? (false));
        // line 46
        $context["canEdit"] = (($context["canEdit"]) ?? (((((isset($context["canUpdateSource"]) || array_key_exists("canUpdateSource", $context) ? $context["canUpdateSource"] : (function () { throw new RuntimeError('Variable "canUpdateSource" does not exist.', 46, $this->source); })()) || (isset($context["canDuplicateSource"]) || array_key_exists("canDuplicateSource", $context) ? $context["canDuplicateSource"] : (function () { throw new RuntimeError('Variable "canDuplicateSource" does not exist.', 46, $this->source); })())) || (isset($context["canAddAnother"]) || array_key_exists("canAddAnother", $context) ? $context["canAddAnother"] : (function () { throw new RuntimeError('Variable "canAddAnother" does not exist.', 46, $this->source); })())) || (isset($context["saveDraftAction"]) || array_key_exists("saveDraftAction", $context) ? $context["saveDraftAction"] : (function () { throw new RuntimeError('Variable "saveDraftAction" does not exist.', 46, $this->source); })()))));
        // line 48
        $context["redirectUrl"] = (($context["redirectUrl"]) ?? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 48, $this->source); })()), "cpEditUrl", [])));
        // line 49
        $context["addAnotherRedirectUrl"] = (($context["addAnotherRedirectUrl"]) ?? (null));
        // line 51
        $context["saveSourceAction"] = (($context["saveSourceAction"]) ?? (null));
        // line 52
        $context["duplicateSourceAction"] = (($context["duplicateSourceAction"]) ?? (null));
        // line 53
        $context["deleteSourceAction"] = (($context["deleteSourceAction"]) ?? (null));
        // line 54
        $context["revertSourceAction"] = (($context["revertSourceAction"]) ?? (null));
        // line 55
        $context["saveDraftAction"] = (($context["saveDraftAction"]) ?? (null));
        // line 57
        if ( !(isset($context["isRevision"]) || array_key_exists("isRevision", $context) ? $context["isRevision"] : (function () { throw new RuntimeError('Variable "isRevision" does not exist.', 57, $this->source); })())) {
            // line 58
            $context["fullPageForm"] = true;
        }
        // line 61
        if ((isset($context["isDraft"]) || array_key_exists("isDraft", $context) ? $context["isDraft"] : (function () { throw new RuntimeError('Variable "isDraft" does not exist.', 61, $this->source); })())) {
            // line 62
            craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 62, $this->source); })()), "app", []), "session", []), "authorize", [0 => ("previewDraft:" . craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 62, $this->source); })()), "draftId", []))], "method");
        } elseif (        // line 63
(isset($context["isRevision"]) || array_key_exists("isRevision", $context) ? $context["isRevision"] : (function () { throw new RuntimeError('Variable "isRevision" does not exist.', 63, $this->source); })())) {
            // line 64
            craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 64, $this->source); })()), "app", []), "session", []), "authorize", [0 => ("previewRevision:" . craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 64, $this->source); })()), "revisionId", []))], "method");
        } else {
            // line 66
            craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 66, $this->source); })()), "app", []), "session", []), "authorize", [0 => ("previewElement:" . craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 66, $this->source); })()), "id", []))], "method");
        }
        // line 71
        $context["showStatusToggles"] = ((craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 71, $this->source); })()), "hasStatuses", [], "method") && ( !        // line 72
(isset($context["isUnsavedDraft"]) || array_key_exists("isUnsavedDraft", $context) ? $context["isUnsavedDraft"] : (function () { throw new RuntimeError('Variable "isUnsavedDraft" does not exist.', 72, $this->source); })()) || (isset($context["canUpdateSource"]) || array_key_exists("canUpdateSource", $context) ? $context["canUpdateSource"] : (function () { throw new RuntimeError('Variable "canUpdateSource" does not exist.', 72, $this->source); })()))) && ((        // line 73
$context["showStatusToggles"]) ?? (true)));
        // line 75
        if (( !(isset($context["isDraft"]) || array_key_exists("isDraft", $context) ? $context["isDraft"] : (function () { throw new RuntimeError('Variable "isDraft" does not exist.', 75, $this->source); })()) &&  !(isset($context["canUpdateSource"]) || array_key_exists("canUpdateSource", $context) ? $context["canUpdateSource"] : (function () { throw new RuntimeError('Variable "canUpdateSource" does not exist.', 75, $this->source); })()))) {
            // line 76
            $context["saveShortcut"] = false;
        } elseif ((        // line 77
(isset($context["isUnsavedDraft"]) || array_key_exists("isUnsavedDraft", $context) ? $context["isUnsavedDraft"] : (function () { throw new RuntimeError('Variable "isUnsavedDraft" does not exist.', 77, $this->source); })()) || ((isset($context["isCurrent"]) || array_key_exists("isCurrent", $context) ? $context["isCurrent"] : (function () { throw new RuntimeError('Variable "isCurrent" does not exist.', 77, $this->source); })()) && (isset($context["canUpdateSource"]) || array_key_exists("canUpdateSource", $context) ? $context["canUpdateSource"] : (function () { throw new RuntimeError('Variable "canUpdateSource" does not exist.', 77, $this->source); })())))) {
            // line 78
            $context["saveShortcutRedirect"] = "{cpEditUrl}";
        }
        // line 81
        if ( !(isset($context["tabs"]) || array_key_exists("tabs", $context))) {
            // line 82
            $context["tabs"] = [];
            // line 83
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((((craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, ($context["element"] ?? null), "fieldLayout", [], "any", false, true), "tabs", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, ($context["element"] ?? null), "fieldLayout", [], "any", false, true), "tabs", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, ($context["element"] ?? null), "fieldLayout", [], "any", false, true), "tabs", [])) : ([])));
            foreach ($context['_seq'] as $context["_key"] => $context["tab"]) {
                // line 84
                $context["tabs"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["tabs"]) || array_key_exists("tabs", $context) ? $context["tabs"] : (function () { throw new RuntimeError('Variable "tabs" does not exist.', 84, $this->source); })()), [0 => ["label" => $this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source,                 // line 85
$context["tab"], "name", []), "site"), "url" => ("#" . craft\helpers\Template::attribute($this->env, $this->source,                 // line 86
$context["tab"], "getHtmlId", [], "method")), "class" => ((craft\helpers\Template::attribute($this->env, $this->source,                 // line 87
$context["tab"], "elementHasErrors", [0 => (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 87, $this->source); })())], "method")) ? ("error") : (""))]]);
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['tab'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
        }
        // line 92
        $context["settingsHtml"] = twig_trim_filter(((        $this->hasBlock("settings", $context, $blocks)) ? (        $this->renderBlock("settings", $context, $blocks)) : ("")));
        // line 332
        if (((isset($context["canEditMultipleSites"]) || array_key_exists("canEditMultipleSites", $context) ? $context["canEditMultipleSites"] : (function () { throw new RuntimeError('Variable "canEditMultipleSites" does not exist.', 332, $this->source); })()) && craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 332, $this->source); })()), "enabled", []))) {
            // line 334
            $context["siteStatusesQuery"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 334, $this->source); })()), "find", [], "method"), "select", [0 => [0 => "elements_sites.siteId", 1 => "elements_sites.enabled"]], "method"), "id", [0 => craft\helpers\Template::attribute($this->env, $this->source,             // line 336
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 336, $this->source); })()), "id", [])], "method"), "siteId", [0 =>             // line 337
(isset($context["editableSiteIds"]) || array_key_exists("editableSiteIds", $context) ? $context["editableSiteIds"] : (function () { throw new RuntimeError('Variable "editableSiteIds" does not exist.', 337, $this->source); })())], "method"), "anyStatus", [], "method"), "asArray", [], "method");
            // line 340
            if ((isset($context["isDraft"]) || array_key_exists("isDraft", $context) ? $context["isDraft"] : (function () { throw new RuntimeError('Variable "isDraft" does not exist.', 340, $this->source); })())) {
                // line 341
                craft\helpers\Template::attribute($this->env, $this->source, (isset($context["siteStatusesQuery"]) || array_key_exists("siteStatusesQuery", $context) ? $context["siteStatusesQuery"] : (function () { throw new RuntimeError('Variable "siteStatusesQuery" does not exist.', 341, $this->source); })()), "drafts", [], "method");
            } elseif (            // line 342
(isset($context["isRevision"]) || array_key_exists("isRevision", $context) ? $context["isRevision"] : (function () { throw new RuntimeError('Variable "isRevision" does not exist.', 342, $this->source); })())) {
                // line 343
                craft\helpers\Template::attribute($this->env, $this->source, (isset($context["siteStatusesQuery"]) || array_key_exists("siteStatusesQuery", $context) ? $context["siteStatusesQuery"] : (function () { throw new RuntimeError('Variable "siteStatusesQuery" does not exist.', 343, $this->source); })()), "revisions", [], "method");
            }
            // line 345
            $context["siteStatuses"] = twig_array_map(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["siteStatusesQuery"]) || array_key_exists("siteStatusesQuery", $context) ? $context["siteStatusesQuery"] : (function () { throw new RuntimeError('Variable "siteStatusesQuery" does not exist.', 345, $this->source); })()), "pairs", [], "method"),             // line 346
function ($__s__) use ($context, $macros) { $context["s"] = $__s__; return (((isset($context["s"]) || array_key_exists("s", $context) ? $context["s"] : (function () { throw new RuntimeError('Variable "s" does not exist.', 346, $this->source); })())) ? (true) : (false)); });
        } elseif (        // line 347
(isset($context["canEditMultipleSites"]) || array_key_exists("canEditMultipleSites", $context) ? $context["canEditMultipleSites"] : (function () { throw new RuntimeError('Variable "canEditMultipleSites" does not exist.', 347, $this->source); })())) {
            // line 348
            $context["siteStatusValues"] = [];
            // line 349
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["editableSiteIds"]) || array_key_exists("editableSiteIds", $context) ? $context["editableSiteIds"] : (function () { throw new RuntimeError('Variable "editableSiteIds" does not exist.', 349, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["siteId"]) {
                // line 350
                $context["siteStatusValues"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["siteStatusValues"]) || array_key_exists("siteStatusValues", $context) ? $context["siteStatusValues"] : (function () { throw new RuntimeError('Variable "siteStatusValues" does not exist.', 350, $this->source); })()), [0 => false]);
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['siteId'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 352
            $context["siteStatuses"] = array_combine((isset($context["editableSiteIds"]) || array_key_exists("editableSiteIds", $context) ? $context["editableSiteIds"] : (function () { throw new RuntimeError('Variable "editableSiteIds" does not exist.', 352, $this->source); })()), (isset($context["siteStatusValues"]) || array_key_exists("siteStatusValues", $context) ? $context["siteStatusValues"] : (function () { throw new RuntimeError('Variable "siteStatusValues" does not exist.', 352, $this->source); })()));
        } else {
            // line 354
            $context["siteStatuses"] = [craft\helpers\Template::attribute($this->env, $this->source,             // line 355
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 355, $this->source); })()), "siteId", []) => ((craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 355, $this->source); })()), "enabled", [])) ? (true) : (false))];
        }
        // line 359
        $context["settings"] = ["elementType" => get_class(        // line 360
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 360, $this->source); })())), "elementTypeDisplayName" => craft\helpers\Template::attribute($this->env, $this->source,         // line 361
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 361, $this->source); })()), "displayName", [], "method"), "sourceId" => craft\helpers\Template::attribute($this->env, $this->source,         // line 362
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 362, $this->source); })()), "getSourceId", [], "method"), "siteId" => craft\helpers\Template::attribute($this->env, $this->source,         // line 363
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 363, $this->source); })()), "siteId", []), "isUnsavedDraft" =>         // line 364
(isset($context["isUnsavedDraft"]) || array_key_exists("isUnsavedDraft", $context) ? $context["isUnsavedDraft"] : (function () { throw new RuntimeError('Variable "isUnsavedDraft" does not exist.', 364, $this->source); })()), "siteStatuses" =>         // line 365
(isset($context["siteStatuses"]) || array_key_exists("siteStatuses", $context) ? $context["siteStatuses"] : (function () { throw new RuntimeError('Variable "siteStatuses" does not exist.', 365, $this->source); })()), "enabled" => ((craft\helpers\Template::attribute($this->env, $this->source,         // line 366
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 366, $this->source); })()), "enabled", [])) ? (true) : (false)), "enabledForSite" => (craft\helpers\Template::attribute($this->env, $this->source,         // line 367
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 367, $this->source); })()), "enabled", []) && craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 367, $this->source); })()), "enabledForSite", [])), "isLive" => (((        // line 368
(isset($context["isCurrent"]) || array_key_exists("isCurrent", $context) ? $context["isCurrent"] : (function () { throw new RuntimeError('Variable "isCurrent" does not exist.', 368, $this->source); })()) && craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 368, $this->source); })()), "enabled", [])) && craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 368, $this->source); })()), "enabledForSite", [])) && craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 368, $this->source); })()), "getRoute", [], "method")), "cpEditUrl" => craft\helpers\Template::attribute($this->env, $this->source,         // line 369
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 369, $this->source); })()), "cpEditUrl", []), "hashedRedirectUrl" => call_user_func_array($this->env->getFilter('hash')->getCallable(), [((        // line 370
(isset($context["isUnsavedDraft"]) || array_key_exists("isUnsavedDraft", $context) ? $context["isUnsavedDraft"] : (function () { throw new RuntimeError('Variable "isUnsavedDraft" does not exist.', 370, $this->source); })())) ? ((isset($context["redirectUrl"]) || array_key_exists("redirectUrl", $context) ? $context["redirectUrl"] : (function () { throw new RuntimeError('Variable "redirectUrl" does not exist.', 370, $this->source); })())) : ("{cpEditUrl}"))]), "draftId" => craft\helpers\Template::attribute($this->env, $this->source,         // line 371
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 371, $this->source); })()), "draftId", []), "revisionId" => craft\helpers\Template::attribute($this->env, $this->source,         // line 372
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 372, $this->source); })()), "revisionId", []), "draftName" => ((        // line 373
(isset($context["isDraft"]) || array_key_exists("isDraft", $context) ? $context["isDraft"] : (function () { throw new RuntimeError('Variable "isDraft" does not exist.', 373, $this->source); })())) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 373, $this->source); })()), "draftName", [])) : (null)), "draftNotes" => ((        // line 374
(isset($context["isDraft"]) || array_key_exists("isDraft", $context) ? $context["isDraft"] : (function () { throw new RuntimeError('Variable "isDraft" does not exist.', 374, $this->source); })())) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 374, $this->source); })()), "draftNotes", [])) : (null)), "canEditMultipleSites" =>         // line 375
(isset($context["canEditMultipleSites"]) || array_key_exists("canEditMultipleSites", $context) ? $context["canEditMultipleSites"] : (function () { throw new RuntimeError('Variable "canEditMultipleSites" does not exist.', 375, $this->source); })()), "canDeleteDraft" =>         // line 376
(isset($context["canDeleteDraft"]) || array_key_exists("canDeleteDraft", $context) ? $context["canDeleteDraft"] : (function () { throw new RuntimeError('Variable "canDeleteDraft" does not exist.', 376, $this->source); })()), "canUpdateSource" =>         // line 377
(isset($context["canUpdateSource"]) || array_key_exists("canUpdateSource", $context) ? $context["canUpdateSource"] : (function () { throw new RuntimeError('Variable "canUpdateSource" does not exist.', 377, $this->source); })()), "saveDraftAction" =>         // line 378
(isset($context["saveDraftAction"]) || array_key_exists("saveDraftAction", $context) ? $context["saveDraftAction"] : (function () { throw new RuntimeError('Variable "saveDraftAction" does not exist.', 378, $this->source); })()), "deleteDraftAction" => ((        // line 379
$context["deleteDraftAction"]) ?? (null)), "applyDraftAction" => ((        // line 380
$context["applyDraftAction"]) ?? (null)), "enablePreview" =>         // line 381
(isset($context["enablePreview"]) || array_key_exists("enablePreview", $context) ? $context["enablePreview"] : (function () { throw new RuntimeError('Variable "enablePreview" does not exist.', 381, $this->source); })()), "previewTargets" =>         // line 382
(isset($context["previewTargets"]) || array_key_exists("previewTargets", $context) ? $context["previewTargets"] : (function () { throw new RuntimeError('Variable "previewTargets" does not exist.', 382, $this->source); })())];
        // line 384
        ob_start();
        // line 385
        echo "    window.draftEditor = new Craft.DraftEditor(";
        echo $this->extensions['craft\web\twig\Extension']->jsonEncodeFilter((isset($context["settings"]) || array_key_exists("settings", $context) ? $context["settings"] : (function () { throw new RuntimeError('Variable "settings" does not exist.', 385, $this->source); })()));
        echo ");
";
        Craft::$app->getView()->registerJs(ob_get_clean(), 3);
        // line 26
        $this->parent = $this->loadTemplate("_layouts/cp", "_layouts/element", 26);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        // line 0
        craft\helpers\Template::endProfile("template", "_layouts/element");
    }

    // line 94
    public function block_header($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("block", "header");
        // line 95
        echo "    <div class=\"flex flex-nowrap\">
        ";
        // line 96
        $this->displayBlock("pageTitle", $context, $blocks);
        echo "
        ";
        // line 97
        $this->displayBlock("contextMenu", $context, $blocks);
        echo "
    </div>
    <div class=\"flex\">
        ";
        // line 100
        if ((isset($context["previewTargets"]) || array_key_exists("previewTargets", $context) ? $context["previewTargets"] : (function () { throw new RuntimeError('Variable "previewTargets" does not exist.', 100, $this->source); })())) {
            // line 101
            echo "            <div class=\"btngroup\">
                ";
            // line 102
            if ((isset($context["enablePreview"]) || array_key_exists("enablePreview", $context) ? $context["enablePreview"] : (function () { throw new RuntimeError('Variable "enablePreview" does not exist.', 102, $this->source); })())) {
                // line 103
                echo "                    <div id=\"preview-btn\" class=\"btn\">";
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Preview", "app"), "html", null, true);
                echo "</div>
                ";
            }
            // line 105
            echo "                <div id=\"share-btn\" class=\"btn\">";
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Share", "app"), "html", null, true);
            echo "</div>
            </div>
        ";
        }
        // line 108
        echo "
        ";
        // line 109
        if (((isset($context["isCurrent"]) || array_key_exists("isCurrent", $context) ? $context["isCurrent"] : (function () { throw new RuntimeError('Variable "isCurrent" does not exist.', 109, $this->source); })()) && (isset($context["saveDraftAction"]) || array_key_exists("saveDraftAction", $context) ? $context["saveDraftAction"] : (function () { throw new RuntimeError('Variable "saveDraftAction" does not exist.', 109, $this->source); })()))) {
            // line 110
            echo "            <div id=\"save-draft-btn-container\">
                ";
            // line 111
            if (((isset($context["canUpdateSource"]) || array_key_exists("canUpdateSource", $context) ? $context["canUpdateSource"] : (function () { throw new RuntimeError('Variable "canUpdateSource" does not exist.', 111, $this->source); })()) && (isset($context["saveSourceAction"]) || array_key_exists("saveSourceAction", $context) ? $context["saveSourceAction"] : (function () { throw new RuntimeError('Variable "saveSourceAction" does not exist.', 111, $this->source); })()))) {
                // line 112
                echo "                    <div id=\"save-draft-btn\" class=\"btn\">";
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Save as a draft", "app"), "html", null, true);
                echo "</div>
                ";
            } else {
                // line 114
                echo "                    <input type=\"submit\" id=\"save-draft-btn\" class=\"btn submit\" value=\"";
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Save as a draft", "app"), "html", null, true);
                echo "\">
                ";
            }
            // line 116
            echo "            </div>
        ";
        }
        // line 118
        echo "
        ";
        // line 119
        $this->displayBlock("actionButton", $context, $blocks);
        echo "
    </div>
";
        // line 0
        craft\helpers\Template::endProfile("block", "header");
    }

    // line 123
    public function block_contextMenu($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("block", "contextMenu");
        // line 124
        echo "    ";
        if ((((isset($context["isMultiSiteElement"]) || array_key_exists("isMultiSiteElement", $context) ? $context["isMultiSiteElement"] : (function () { throw new RuntimeError('Variable "isMultiSiteElement" does not exist.', 124, $this->source); })()) || (isset($context["saveDraftAction"]) || array_key_exists("saveDraftAction", $context) ? $context["saveDraftAction"] : (function () { throw new RuntimeError('Variable "saveDraftAction" does not exist.', 124, $this->source); })())) || craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 124, $this->source); })()), "find", [], "method"), "revisionOf", [0 => (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 124, $this->source); })())], "method"), "exists", [], "method"))) {
            // line 125
            echo "        ";
            $this->loadTemplate("_includes/revisionmenu", "_layouts/element", 125)->display(twig_array_merge($context, ["canHaveDrafts" =>  !twig_test_empty(            // line 126
(isset($context["saveDraftAction"]) || array_key_exists("saveDraftAction", $context) ? $context["saveDraftAction"] : (function () { throw new RuntimeError('Variable "saveDraftAction" does not exist.', 126, $this->source); })()))]));
            // line 128
            echo "    ";
        }
        // line 0
        craft\helpers\Template::endProfile("block", "contextMenu");
    }

    // line 131
    public function block_actionButton($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("block", "actionButton");
        // line 132
        echo "    ";
        if (((isset($context["isUnsavedDraft"]) || array_key_exists("isUnsavedDraft", $context) ? $context["isUnsavedDraft"] : (function () { throw new RuntimeError('Variable "isUnsavedDraft" does not exist.', 132, $this->source); })()) || (isset($context["isCurrent"]) || array_key_exists("isCurrent", $context) ? $context["isCurrent"] : (function () { throw new RuntimeError('Variable "isCurrent" does not exist.', 132, $this->source); })()))) {
            // line 133
            echo "        ";
            // line 134
            echo "        ";
            if (((isset($context["isUnsavedDraft"]) || array_key_exists("isUnsavedDraft", $context) ? $context["isUnsavedDraft"] : (function () { throw new RuntimeError('Variable "isUnsavedDraft" does not exist.', 134, $this->source); })()) || ((isset($context["canUpdateSource"]) || array_key_exists("canUpdateSource", $context) ? $context["canUpdateSource"] : (function () { throw new RuntimeError('Variable "canUpdateSource" does not exist.', 134, $this->source); })()) && (isset($context["saveSourceAction"]) || array_key_exists("saveSourceAction", $context) ? $context["saveSourceAction"] : (function () { throw new RuntimeError('Variable "saveSourceAction" does not exist.', 134, $this->source); })())))) {
                // line 135
                echo "            <div id=\"save-btn-container\" class=\"btngroup submit\">
                ";
                // line 136
                echo $this->extensions['craft\web\twig\Extension']->tagFunction("input", ["type" => "submit", "class" => [0 => "btn", 1 => "submit"], "value" => ((                // line 139
(isset($context["isUnsavedDraft"]) || array_key_exists("isUnsavedDraft", $context) ? $context["isUnsavedDraft"] : (function () { throw new RuntimeError('Variable "isUnsavedDraft" does not exist.', 139, $this->source); })())) ? ($this->extensions['craft\web\twig\Extension']->translateFilter("Create", "app")) : ($this->extensions['craft\web\twig\Extension']->translateFilter("Save", "app")))]);
                // line 140
                echo "
                <div class=\"btn submit menubtn\"></div>
                <div class=\"menu\" data-align=\"right\">
                    <ul>
                        <li>
                            <a class=\"formsubmit\" data-redirect=\"";
                // line 145
                echo twig_escape_filter($this->env, call_user_func_array($this->env->getFilter('hash')->getCallable(), ["{cpEditUrl}"]), "html", null, true);
                echo "\">
                                ";
                // line 146
                echo twig_call_macro($macros["forms"], "macro_optionShortcutLabel", ["S"], 146, $context, $this->getSourceContext());
                echo "
                                ";
                // line 147
                echo twig_escape_filter($this->env, (((isset($context["isUnsavedDraft"]) || array_key_exists("isUnsavedDraft", $context) ? $context["isUnsavedDraft"] : (function () { throw new RuntimeError('Variable "isUnsavedDraft" does not exist.', 147, $this->source); })())) ? ($this->extensions['craft\web\twig\Extension']->translateFilter("Create and continue editing", "app")) : ($this->extensions['craft\web\twig\Extension']->translateFilter("Save and continue editing", "app"))), "html", null, true);
                echo "
                            </a>
                        </li>
                        ";
                // line 150
                if ((isset($context["canUpdateSource"]) || array_key_exists("canUpdateSource", $context) ? $context["canUpdateSource"] : (function () { throw new RuntimeError('Variable "canUpdateSource" does not exist.', 150, $this->source); })())) {
                    // line 151
                    echo "                            ";
                    if (((isset($context["canAddAnother"]) || array_key_exists("canAddAnother", $context) ? $context["canAddAnother"] : (function () { throw new RuntimeError('Variable "canAddAnother" does not exist.', 151, $this->source); })()) && (isset($context["addAnotherRedirectUrl"]) || array_key_exists("addAnotherRedirectUrl", $context) ? $context["addAnotherRedirectUrl"] : (function () { throw new RuntimeError('Variable "addAnotherRedirectUrl" does not exist.', 151, $this->source); })()))) {
                        // line 152
                        echo "                                <li>
                                    <a class=\"formsubmit\" data-redirect=\"";
                        // line 153
                        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFilter('hash')->getCallable(), [(isset($context["addAnotherRedirectUrl"]) || array_key_exists("addAnotherRedirectUrl", $context) ? $context["addAnotherRedirectUrl"] : (function () { throw new RuntimeError('Variable "addAnotherRedirectUrl" does not exist.', 153, $this->source); })())]), "html", null, true);
                        echo "\">
                                        ";
                        // line 154
                        echo twig_escape_filter($this->env, (((isset($context["isUnsavedDraft"]) || array_key_exists("isUnsavedDraft", $context) ? $context["isUnsavedDraft"] : (function () { throw new RuntimeError('Variable "isUnsavedDraft" does not exist.', 154, $this->source); })())) ? ($this->extensions['craft\web\twig\Extension']->translateFilter("Create and add another", "app")) : ($this->extensions['craft\web\twig\Extension']->translateFilter("Save and add another", "app"))), "html", null, true);
                        echo "
                                    </a>
                                </li>
                            ";
                    }
                    // line 158
                    echo "                            ";
                    if ((( !(isset($context["isUnsavedDraft"]) || array_key_exists("isUnsavedDraft", $context) ? $context["isUnsavedDraft"] : (function () { throw new RuntimeError('Variable "isUnsavedDraft" does not exist.', 158, $this->source); })()) && (isset($context["canDuplicateSource"]) || array_key_exists("canDuplicateSource", $context) ? $context["canDuplicateSource"] : (function () { throw new RuntimeError('Variable "canDuplicateSource" does not exist.', 158, $this->source); })())) && (isset($context["duplicateSourceAction"]) || array_key_exists("duplicateSourceAction", $context) ? $context["duplicateSourceAction"] : (function () { throw new RuntimeError('Variable "duplicateSourceAction" does not exist.', 158, $this->source); })()))) {
                        // line 159
                        echo "                                <li>
                                    <a class=\"formsubmit\" data-action=\"";
                        // line 160
                        echo twig_escape_filter($this->env, (isset($context["duplicateSourceAction"]) || array_key_exists("duplicateSourceAction", $context) ? $context["duplicateSourceAction"] : (function () { throw new RuntimeError('Variable "duplicateSourceAction" does not exist.', 160, $this->source); })()), "html", null, true);
                        echo "\" data-redirect=\"";
                        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFilter('hash')->getCallable(), ["{cpEditUrl}"]), "html", null, true);
                        echo "\">
                                        ";
                        // line 161
                        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Save as a new {type}", "app", ["type" => craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 161, $this->source); })()), "lowerDisplayName", [], "method")]), "html", null, true);
                        echo "
                                    </a>
                                </li>
                            ";
                    }
                    // line 165
                    echo "                        ";
                }
                // line 166
                echo "                    </ul>
                    ";
                // line 167
                if ((( !(isset($context["isUnsavedDraft"]) || array_key_exists("isUnsavedDraft", $context) ? $context["isUnsavedDraft"] : (function () { throw new RuntimeError('Variable "isUnsavedDraft" does not exist.', 167, $this->source); })()) && (isset($context["canDeleteSource"]) || array_key_exists("canDeleteSource", $context) ? $context["canDeleteSource"] : (function () { throw new RuntimeError('Variable "canDeleteSource" does not exist.', 167, $this->source); })())) && (isset($context["deleteSourceAction"]) || array_key_exists("deleteSourceAction", $context) ? $context["deleteSourceAction"] : (function () { throw new RuntimeError('Variable "deleteSourceAction" does not exist.', 167, $this->source); })()))) {
                    // line 168
                    echo "                        <hr>
                        <ul>
                            <li>
                                <a class=\"formsubmit error\" data-action=\"";
                    // line 171
                    echo twig_escape_filter($this->env, (isset($context["deleteSourceAction"]) || array_key_exists("deleteSourceAction", $context) ? $context["deleteSourceAction"] : (function () { throw new RuntimeError('Variable "deleteSourceAction" does not exist.', 171, $this->source); })()), "html", null, true);
                    echo "\"
                                   data-confirm=\"";
                    // line 172
                    echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Are you sure you want to delete this {type}?", "app", ["type" => craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 172, $this->source); })()), "lowerDisplayName", [], "method")]), "html", null, true);
                    echo "\"
                                   data-redirect=\"";
                    // line 173
                    echo twig_escape_filter($this->env, call_user_func_array($this->env->getFilter('hash')->getCallable(), [((isset($context["redirectUrl"]) || array_key_exists("redirectUrl", $context) ? $context["redirectUrl"] : (function () { throw new RuntimeError('Variable "redirectUrl" does not exist.', 173, $this->source); })()) . "#")]), "html", null, true);
                    echo "\">
                                    ";
                    // line 174
                    echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Delete {type}", "app", ["type" => craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 174, $this->source); })()), "lowerDisplayName", [], "method")]), "html", null, true);
                    echo "
                                </a>
                            </li>
                        </ul>
                    ";
                }
                // line 179
                echo "                </div>
            </div>
        ";
            }
            // line 182
            echo "    ";
        } elseif ((isset($context["isDraft"]) || array_key_exists("isDraft", $context) ? $context["isDraft"] : (function () { throw new RuntimeError('Variable "isDraft" does not exist.', 182, $this->source); })())) {
            // line 183
            echo "        ";
            if (((isset($context["canUpdateSource"]) || array_key_exists("canUpdateSource", $context) ? $context["canUpdateSource"] : (function () { throw new RuntimeError('Variable "canUpdateSource" does not exist.', 183, $this->source); })()) && (isset($context["saveSourceAction"]) || array_key_exists("saveSourceAction", $context) ? $context["saveSourceAction"] : (function () { throw new RuntimeError('Variable "saveSourceAction" does not exist.', 183, $this->source); })()))) {
                // line 184
                echo "            <input type=\"submit\" class=\"btn submit\" value=\"";
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Publish changes", "app"), "html", null, true);
                echo "\">
        ";
            }
            // line 186
            echo "    ";
        } elseif ((isset($context["isRevision"]) || array_key_exists("isRevision", $context) ? $context["isRevision"] : (function () { throw new RuntimeError('Variable "isRevision" does not exist.', 186, $this->source); })())) {
            // line 187
            echo "        ";
            if (((isset($context["canUpdateSource"]) || array_key_exists("canUpdateSource", $context) ? $context["canUpdateSource"] : (function () { throw new RuntimeError('Variable "canUpdateSource" does not exist.', 187, $this->source); })()) && (isset($context["revertSourceAction"]) || array_key_exists("revertSourceAction", $context) ? $context["revertSourceAction"] : (function () { throw new RuntimeError('Variable "revertSourceAction" does not exist.', 187, $this->source); })()))) {
                // line 188
                echo "            <form method=\"post\" accept-charset=\"UTF-8\">
                ";
                // line 189
                echo craft\helpers\Html::csrfInput();
                echo "
                ";
                // line 190
                echo craft\helpers\Html::actionInput((isset($context["revertSourceAction"]) || array_key_exists("revertSourceAction", $context) ? $context["revertSourceAction"] : (function () { throw new RuntimeError('Variable "revertSourceAction" does not exist.', 190, $this->source); })()));
                echo "
                ";
                // line 191
                echo craft\helpers\Html::redirectInput("{cpEditUrl}");
                echo "
                ";
                // line 192
                echo craft\helpers\Html::hiddenInput("revisionId", craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 192, $this->source); })()), "revisionId", []));
                echo "
                <div class=\"secondary-buttons\">
                    <input type=\"button\" class=\"btn submit formsubmit\" value=\"";
                // line 194
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Revert {type} to this revision", "app", ["type" => craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 194, $this->source); })()), "lowerDisplayName", [], "method")]), "html", null, true);
                echo "\">
                </div>
            </form>
        ";
            }
            // line 198
            echo "    ";
        }
        // line 0
        craft\helpers\Template::endProfile("block", "actionButton");
    }

    // line 201
    public function block_main($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("block", "main");
        // line 202
        echo "    ";
        if ((isset($context["fullPageForm"]) || array_key_exists("fullPageForm", $context) ? $context["fullPageForm"] : (function () { throw new RuntimeError('Variable "fullPageForm" does not exist.', 202, $this->source); })())) {
            // line 203
            echo "        ";
            // line 204
            echo "        ";
            if ((( !(isset($context["isDraft"]) || array_key_exists("isDraft", $context) ? $context["isDraft"] : (function () { throw new RuntimeError('Variable "isDraft" does not exist.', 204, $this->source); })()) && (isset($context["canUpdateSource"]) || array_key_exists("canUpdateSource", $context) ? $context["canUpdateSource"] : (function () { throw new RuntimeError('Variable "canUpdateSource" does not exist.', 204, $this->source); })())) && (isset($context["saveSourceAction"]) || array_key_exists("saveSourceAction", $context) ? $context["saveSourceAction"] : (function () { throw new RuntimeError('Variable "saveSourceAction" does not exist.', 204, $this->source); })()))) {
                // line 205
                echo "            ";
                // line 206
                echo "            ";
                echo craft\helpers\Html::actionInput((isset($context["saveSourceAction"]) || array_key_exists("saveSourceAction", $context) ? $context["saveSourceAction"] : (function () { throw new RuntimeError('Variable "saveSourceAction" does not exist.', 206, $this->source); })()));
                echo "
            ";
                // line 207
                echo craft\helpers\Html::redirectInput((isset($context["redirectUrl"]) || array_key_exists("redirectUrl", $context) ? $context["redirectUrl"] : (function () { throw new RuntimeError('Variable "redirectUrl" does not exist.', 207, $this->source); })()));
                echo "
        ";
            }
            // line 209
            echo "
        ";
            // line 211
            echo "        ";
            if (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 211, $this->source); })()), "app", []), "isMultiSite", [])) {
                // line 212
                echo "            ";
                echo craft\helpers\Html::hiddenInput("siteId", craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 212, $this->source); })()), "siteId", []));
                echo "
        ";
            }
            // line 214
            echo "
        ";
            // line 216
            echo "        ";
            if (((isset($context["isUnsavedDraft"]) || array_key_exists("isUnsavedDraft", $context) ? $context["isUnsavedDraft"] : (function () { throw new RuntimeError('Variable "isUnsavedDraft" does not exist.', 216, $this->source); })()) && craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 216, $this->source); })()), "app", []), "request", []), "getQueryParam", [0 => "fresh"], "method"))) {
                // line 217
                echo "            ";
                echo craft\helpers\Html::hiddenInput("propagateAll", "1");
                echo "
        ";
            }
            // line 219
            echo "    ";
        }
        // line 220
        echo "    ";
        $this->displayParentBlock("main", $context, $blocks);
        echo "
";
        // line 0
        craft\helpers\Template::endProfile("block", "main");
    }

    // line 223
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("block", "content");
        // line 224
        echo "    <div id=\"fields\">
        ";
        // line 225
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((((craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, ($context["element"] ?? null), "fieldLayout", [], "any", false, true), "tabs", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, ($context["element"] ?? null), "fieldLayout", [], "any", false, true), "tabs", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, ($context["element"] ?? null), "fieldLayout", [], "any", false, true), "tabs", [])) : ([])));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["tab"]) {
            // line 226
            echo "            <div id=\"";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["tab"], "getHtmlId", [], "method"), "html", null, true);
            echo "\"";
            if ( !craft\helpers\Template::attribute($this->env, $this->source, $context["loop"], "first", [])) {
                echo " class=\"hidden\"";
            }
            echo ">
                ";
            // line 227
            $this->loadTemplate("_includes/fields", "_layouts/element", 227)->display(twig_to_array(["fields" => craft\helpers\Template::attribute($this->env, $this->source,             // line 228
$context["tab"], "getFields", [], "method"), "element" =>             // line 229
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 229, $this->source); })()), "static" => (            // line 230
(isset($context["isRevision"]) || array_key_exists("isRevision", $context) ? $context["isRevision"] : (function () { throw new RuntimeError('Variable "isRevision" does not exist.', 230, $this->source); })()) ||  !(isset($context["canEdit"]) || array_key_exists("canEdit", $context) ? $context["canEdit"] : (function () { throw new RuntimeError('Variable "canEdit" does not exist.', 230, $this->source); })())), "registerDeltas" => true]));
            // line 233
            echo "            </div>
        ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['tab'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 235
        echo "    </div>
";
        // line 0
        craft\helpers\Template::endProfile("block", "content");
    }

    // line 238
    public function block_details($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("block", "details");
        // line 239
        echo "    ";
        if ((isset($context["settingsHtml"]) || array_key_exists("settingsHtml", $context) ? $context["settingsHtml"] : (function () { throw new RuntimeError('Variable "settingsHtml" does not exist.', 239, $this->source); })())) {
            // line 240
            echo "        <div id=\"settings\" class=\"meta\">
            ";
            // line 241
            echo (isset($context["settingsHtml"]) || array_key_exists("settingsHtml", $context) ? $context["settingsHtml"] : (function () { throw new RuntimeError('Variable "settingsHtml" does not exist.', 241, $this->source); })());
            echo "
        </div>
    ";
        }
        // line 244
        echo "
    ";
        // line 245
        if (((isset($context["showStatusToggles"]) || array_key_exists("showStatusToggles", $context) ? $context["showStatusToggles"] : (function () { throw new RuntimeError('Variable "showStatusToggles" does not exist.', 245, $this->source); })()) && (isset($context["isMultiSiteElement"]) || array_key_exists("isMultiSiteElement", $context) ? $context["isMultiSiteElement"] : (function () { throw new RuntimeError('Variable "isMultiSiteElement" does not exist.', 245, $this->source); })()))) {
            // line 246
            echo "        <div class=\"meta\">
            ";
            // line 247
            echo twig_call_macro($macros["forms"], "macro_lightswitchField", [["status" => craft\helpers\Template::attribute($this->env, $this->source,             // line 248
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 248, $this->source); })()), "getAttributeStatus", [0 => "enabled"], "method"), "label" => ($this->extensions['craft\web\twig\Extension']->translateFilter("Enabled for {site}", "app", ["site" => twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source,             // line 249
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 249, $this->source); })()), "site", []), "name", []), "site"))]) . ((            // line 250
(isset($context["canEditMultipleSites"]) || array_key_exists("canEditMultipleSites", $context) ? $context["canEditMultipleSites"] : (function () { throw new RuntimeError('Variable "canEditMultipleSites" does not exist.', 250, $this->source); })())) ? ("<a id=\"expand-status-btn\" data-icon=\"ellipsis\" class=\"btn\" role=\"button\"></a>") : (""))), "id" => ("enabledForSite-" . craft\helpers\Template::attribute($this->env, $this->source,             // line 251
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 251, $this->source); })()), "siteId", [])), "name" => (("enabledForSite[" . craft\helpers\Template::attribute($this->env, $this->source,             // line 252
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 252, $this->source); })()), "siteId", [])) . "]"), "on" => (craft\helpers\Template::attribute($this->env, $this->source,             // line 253
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 253, $this->source); })()), "enabled", []) && craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 253, $this->source); })()), "enabledForSite", [])), "disabled" =>             // line 254
(isset($context["isRevision"]) || array_key_exists("isRevision", $context) ? $context["isRevision"] : (function () { throw new RuntimeError('Variable "isRevision" does not exist.', 254, $this->source); })())]], 247, $context, $this->getSourceContext());
            // line 255
            echo "
        </div>
    ";
        }
        // line 258
        echo "
    <div id=\"meta-details\" class=\"meta read-only\">
        ";
        // line 260
        $this->displayBlock('meta', $context, $blocks);
        // line 298
        echo "    </div>

    ";
        // line 300
        if (((isset($context["isDraft"]) || array_key_exists("isDraft", $context) ? $context["isDraft"] : (function () { throw new RuntimeError('Variable "isDraft" does not exist.', 300, $this->source); })()) && craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 300, $this->source); })()), "getIsOutdated", [], "method"))) {
            // line 301
            echo "        ";
            craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 301, $this->source); })()), "app", []), "session", []), "authorize", [0 => ("mergeDraftSourceChanges:" . craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 301, $this->source); })()), "draftId", []))], "method");
            // line 302
            echo "        <div class=\"meta read-only warning\">
            <p>";
            // line 303
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("The source {type} has been updated recently.", "app", ["type" => craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 303, $this->source); })()), "lowerDisplayName", [], "method")]), "html", null, true);
            echo "</p>
            <div class=\"flex flex-nowrap\">
                ";
            // line 305
            if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 305, $this->source); })()), "trackChanges", [])) {
                // line 306
                echo "                    ";
                echo $this->extensions['craft\web\twig\Extension']->tagFunction("div", ["id" => "merge-changes-btn", "class" => [0 => "btn"], "role" => "button", "text" => $this->extensions['craft\web\twig\Extension']->translateFilter("Merge changes into draft", "app")]);
                // line 311
                echo "
                    <div id=\"merge-changes-spinner\" class=\"spinner hidden\"></div>
                ";
            }
            // line 314
            echo "            </div>
        </div>
    ";
        }
        // line 0
        craft\helpers\Template::endProfile("block", "details");
    }

    // line 260
    public function block_meta($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("block", "meta");
        // line 261
        echo "            ";
        if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 261, $this->source); })()), "hasStatuses", [], "method")) {
            // line 262
            echo "                ";
            if ((isset($context["isUnsavedDraft"]) || array_key_exists("isUnsavedDraft", $context) ? $context["isUnsavedDraft"] : (function () { throw new RuntimeError('Variable "isUnsavedDraft" does not exist.', 262, $this->source); })())) {
                // line 263
                echo "                    ";
                $context["statusColor"] = "white";
                // line 264
                echo "                    ";
                $context["statusLabel"] = $this->extensions['craft\web\twig\Extension']->translateFilter("Draft", "app");
                // line 265
                echo "                ";
            } else {
                // line 266
                echo "                    ";
                $context["status"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 266, $this->source); })()), "getStatus", [], "method");
                // line 267
                echo "                    ";
                $context["statusDef"] = (((craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, ($context["element"] ?? null), "statuses", [], "method", false, true), (isset($context["status"]) || array_key_exists("status", $context) ? $context["status"] : (function () { throw new RuntimeError('Variable "status" does not exist.', 267, $this->source); })()), [], "array", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, ($context["element"] ?? null), "statuses", [], "method", false, true), (isset($context["status"]) || array_key_exists("status", $context) ? $context["status"] : (function () { throw new RuntimeError('Variable "status" does not exist.', 267, $this->source); })()), [], "array")))) ? (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, ($context["element"] ?? null), "statuses", [], "method", false, true), (isset($context["status"]) || array_key_exists("status", $context) ? $context["status"] : (function () { throw new RuntimeError('Variable "status" does not exist.', 267, $this->source); })()), [], "array")) : (null));
                // line 268
                echo "                    ";
                $context["statusColor"] = (((craft\helpers\Template::attribute($this->env, $this->source, ($context["statusDef"] ?? null), "color", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["statusDef"] ?? null), "color", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["statusDef"] ?? null), "color", [])) : ((isset($context["status"]) || array_key_exists("status", $context) ? $context["status"] : (function () { throw new RuntimeError('Variable "status" does not exist.', 268, $this->source); })())));
                // line 269
                echo "                    ";
                $context["statusLabel"] = (((craft\helpers\Template::attribute($this->env, $this->source, ($context["statusDef"] ?? null), "label", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["statusDef"] ?? null), "label", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["statusDef"] ?? null), "label", [])) : ((($context["statusDef"]) ?? ($this->extensions['craft\web\twig\Extension']->ucfirstFilter((isset($context["status"]) || array_key_exists("status", $context) ? $context["status"] : (function () { throw new RuntimeError('Variable "status" does not exist.', 269, $this->source); })()))))));
                // line 270
                echo "                ";
            }
            // line 271
            echo "                <div class=\"data\">
                    <h5 class=\"heading\">";
            // line 272
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Status", "app"), "html", null, true);
            echo "</h5>
                    <div id=\"status-value\" class=\"value\"><span class=\"status ";
            // line 273
            echo twig_escape_filter($this->env, (isset($context["statusColor"]) || array_key_exists("statusColor", $context) ? $context["statusColor"] : (function () { throw new RuntimeError('Variable "statusColor" does not exist.', 273, $this->source); })()), "html", null, true);
            echo "\"></span>";
            echo twig_escape_filter($this->env, (isset($context["statusLabel"]) || array_key_exists("statusLabel", $context) ? $context["statusLabel"] : (function () { throw new RuntimeError('Variable "statusLabel" does not exist.', 273, $this->source); })()), "html", null, true);
            echo "</div>
                </div>
            ";
        }
        // line 276
        echo "            <div class=\"data\">
                <h5 class=\"heading\">";
        // line 277
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Created at", "app"), "html", null, true);
        echo "</h5>
                <div id=\"date-created-value\" class=\"value\">";
        // line 278
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->datetimeFilter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 278, $this->source); })()), "dateCreated", []), "short"), "html", null, true);
        echo "</div>
            </div>
            <div class=\"data\">
                <h5 class=\"heading\">";
        // line 281
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Updated at", "app"), "html", null, true);
        echo "</h5>
                <div id=\"date-updated-value\" class=\"value\">";
        // line 282
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->datetimeFilter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 282, $this->source); })()), "dateUpdated", []), "short"), "html", null, true);
        echo "</div>
            </div>
            ";
        // line 284
        if ((isset($context["isRevision"]) || array_key_exists("isRevision", $context) ? $context["isRevision"] : (function () { throw new RuntimeError('Variable "isRevision" does not exist.', 284, $this->source); })())) {
            // line 285
            echo "                ";
            $context["revisionNotes"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 285, $this->source); })()), "revisionNotes", []);
            // line 286
            echo "            ";
        } elseif (( !(isset($context["isDraft"]) || array_key_exists("isDraft", $context) ? $context["isDraft"] : (function () { throw new RuntimeError('Variable "isDraft" does not exist.', 286, $this->source); })()) && craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 286, $this->source); })()), "currentRevision", []))) {
            // line 287
            echo "                ";
            $context["revisionNotes"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 287, $this->source); })()), "currentRevision", []), "revisionNotes", []);
            // line 288
            echo "            ";
        } else {
            // line 289
            echo "                ";
            $context["revisionNotes"] = null;
            // line 290
            echo "            ";
        }
        // line 291
        echo "            ";
        if ((isset($context["revisionNotes"]) || array_key_exists("revisionNotes", $context) ? $context["revisionNotes"] : (function () { throw new RuntimeError('Variable "revisionNotes" does not exist.', 291, $this->source); })())) {
            // line 292
            echo "                <div class=\"data\">
                    <h5 class=\"heading\">";
            // line 293
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Notes", "app"), "html", null, true);
            echo "</h5>
                    <div class=\"value\">";
            // line 294
            echo twig_escape_filter($this->env, (isset($context["revisionNotes"]) || array_key_exists("revisionNotes", $context) ? $context["revisionNotes"] : (function () { throw new RuntimeError('Variable "revisionNotes" does not exist.', 294, $this->source); })()), "html", null, true);
            echo "</div>
                </div>
            ";
        }
        // line 297
        echo "        ";
        // line 0
        craft\helpers\Template::endProfile("block", "meta");
    }

    // line 319
    public function block_settings($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("block", "settings");
        // line 320
        echo "    ";
        if (((isset($context["showStatusToggles"]) || array_key_exists("showStatusToggles", $context) ? $context["showStatusToggles"] : (function () { throw new RuntimeError('Variable "showStatusToggles" does not exist.', 320, $this->source); })()) &&  !(isset($context["isMultiSiteElement"]) || array_key_exists("isMultiSiteElement", $context) ? $context["isMultiSiteElement"] : (function () { throw new RuntimeError('Variable "isMultiSiteElement" does not exist.', 320, $this->source); })()))) {
            // line 321
            echo "        ";
            echo twig_call_macro($macros["forms"], "macro_lightswitchField", [["status" => craft\helpers\Template::attribute($this->env, $this->source,             // line 322
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 322, $this->source); })()), "getAttributeStatus", [0 => "enabled"], "method"), "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Enabled", "app"), "id" => "enabled", "name" => "enabled", "on" => craft\helpers\Template::attribute($this->env, $this->source,             // line 326
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 326, $this->source); })()), "enabled", []), "disabled" =>             // line 327
(isset($context["isRevision"]) || array_key_exists("isRevision", $context) ? $context["isRevision"] : (function () { throw new RuntimeError('Variable "isRevision" does not exist.', 327, $this->source); })())]], 321, $context, $this->getSourceContext());
            // line 328
            echo "
    ";
        }
        // line 0
        craft\helpers\Template::endProfile("block", "settings");
    }

    public function getTemplateName()
    {
        return "_layouts/element";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  834 => 0,  830 => 328,  828 => 327,  827 => 326,  826 => 322,  824 => 321,  821 => 320,  819 => 0,  815 => 319,  811 => 0,  809 => 297,  803 => 294,  799 => 293,  796 => 292,  793 => 291,  790 => 290,  787 => 289,  784 => 288,  781 => 287,  778 => 286,  775 => 285,  773 => 284,  768 => 282,  764 => 281,  758 => 278,  754 => 277,  751 => 276,  743 => 273,  739 => 272,  736 => 271,  733 => 270,  730 => 269,  727 => 268,  724 => 267,  721 => 266,  718 => 265,  715 => 264,  712 => 263,  709 => 262,  706 => 261,  704 => 0,  700 => 260,  696 => 0,  691 => 314,  686 => 311,  683 => 306,  681 => 305,  676 => 303,  673 => 302,  670 => 301,  668 => 300,  664 => 298,  662 => 260,  658 => 258,  653 => 255,  651 => 254,  650 => 253,  649 => 252,  648 => 251,  647 => 250,  646 => 249,  645 => 248,  644 => 247,  641 => 246,  639 => 245,  636 => 244,  630 => 241,  627 => 240,  624 => 239,  622 => 0,  618 => 238,  614 => 0,  611 => 235,  596 => 233,  594 => 230,  593 => 229,  592 => 228,  591 => 227,  582 => 226,  565 => 225,  562 => 224,  560 => 0,  556 => 223,  552 => 0,  547 => 220,  544 => 219,  538 => 217,  535 => 216,  532 => 214,  526 => 212,  523 => 211,  520 => 209,  515 => 207,  510 => 206,  508 => 205,  505 => 204,  503 => 203,  500 => 202,  498 => 0,  494 => 201,  490 => 0,  487 => 198,  480 => 194,  475 => 192,  471 => 191,  467 => 190,  463 => 189,  460 => 188,  457 => 187,  454 => 186,  448 => 184,  445 => 183,  442 => 182,  437 => 179,  429 => 174,  425 => 173,  421 => 172,  417 => 171,  412 => 168,  410 => 167,  407 => 166,  404 => 165,  397 => 161,  391 => 160,  388 => 159,  385 => 158,  378 => 154,  374 => 153,  371 => 152,  368 => 151,  366 => 150,  360 => 147,  356 => 146,  352 => 145,  345 => 140,  343 => 139,  342 => 136,  339 => 135,  336 => 134,  334 => 133,  331 => 132,  329 => 0,  325 => 131,  321 => 0,  318 => 128,  316 => 126,  314 => 125,  311 => 124,  309 => 0,  305 => 123,  301 => 0,  296 => 119,  293 => 118,  289 => 116,  283 => 114,  277 => 112,  275 => 111,  272 => 110,  270 => 109,  267 => 108,  260 => 105,  254 => 103,  252 => 102,  249 => 101,  247 => 100,  241 => 97,  237 => 96,  234 => 95,  232 => 0,  228 => 94,  224 => 0,  221 => 26,  215 => 385,  213 => 384,  211 => 382,  210 => 381,  209 => 380,  208 => 379,  207 => 378,  206 => 377,  205 => 376,  204 => 375,  203 => 374,  202 => 373,  201 => 372,  200 => 371,  199 => 370,  198 => 369,  197 => 368,  196 => 367,  195 => 366,  194 => 365,  193 => 364,  192 => 363,  191 => 362,  190 => 361,  189 => 360,  188 => 359,  185 => 355,  184 => 354,  181 => 352,  175 => 350,  171 => 349,  169 => 348,  167 => 347,  165 => 346,  164 => 345,  161 => 343,  159 => 342,  157 => 341,  155 => 340,  153 => 337,  152 => 336,  151 => 334,  149 => 332,  147 => 92,  140 => 87,  139 => 86,  138 => 85,  137 => 84,  133 => 83,  131 => 82,  129 => 81,  126 => 78,  124 => 77,  122 => 76,  120 => 75,  118 => 73,  117 => 72,  116 => 71,  113 => 66,  110 => 64,  108 => 63,  106 => 62,  104 => 61,  101 => 58,  99 => 57,  97 => 55,  95 => 54,  93 => 53,  91 => 52,  89 => 51,  87 => 49,  85 => 48,  83 => 46,  81 => 45,  79 => 44,  77 => 43,  75 => 42,  73 => 41,  71 => 39,  69 => 38,  67 => 36,  65 => 35,  63 => 34,  61 => 33,  59 => 32,  57 => 31,  55 => 30,  53 => 29,  51 => 27,  49 => 0,  42 => 26,);
    }

    public function getSourceContext()
    {
        return new Source("{#
    \"Edit Element\" layout template

    The following variables should be defined by the sub-template:

    - element: the source element or one of its drafts/revisions
    - canDeleteDraft (optional): whether the current user is allowed to delete the draft (if it is one).
      If the current user created the draft, then it will be deletable regardless.
    - canUpdateSource (optional): whether the current user is allowed to update the source element
      (e.g. by publishing a draft or reverting the element to a prior revision)
    - canDuplicateSource: whether the current user is allowed to duplicate the source element
    - canAddAnother: whether the current user is allowed to create another source element after saving the current one
    - canDeleteSource: whether the current user is allowed to delete the source element
    - redirectUrl: the URL that the user should be redirected to after saving the source element
    - addAnotherRedirectUrl: the URL that the user should be redirected to after opting to save and add another
    - saveSourceAction: the controller action that should be used to save the source element
    - duplicateSourceAction: the controller action that should be used to duplicate the source element
    - deleteSourceAction: the controller action that should be used to delete the source element
    - saveDraftAction: the controller action that should be used to save a draft
    - deleteDraftAction: the controller action that should be used to delete a draft
    - applyDraftAction: the controller action that should be used to apply a draft onto the source element
    - revertSourceAction: the controller action that should be used to revert the source element to a revision
    - showStatusToggles: whether the “Enabled” / “Enabled” for <Site>” fields should be added to the details pane
#}

{% extends '_layouts/cp' %}
{% import '_includes/forms' as forms %}

{% set supportedSiteIds = (craft.app.isMultiSite ? element.getSupportedSites() : [element.siteId])|column(s => s.siteId ?? s) %}
{% set editableSiteIds = supportedSiteIds|intersect(craft.app.sites.getEditableSiteIds()) %}
{% set isMultiSiteElement = craft.app.isMultiSite and supportedSiteIds|length > 1 %}
{% set canEditMultipleSites = isMultiSiteElement and editableSiteIds|length > 1 %}
{% set isDraft = element.getIsDraft() %}
{% set isUnsavedDraft = element.getIsUnsavedDraft() %}
{% set isRevision = element.getIsRevision() %}
{% set isCurrent = not isDraft and not isRevision %}

{% set previewTargets = element.getPreviewTargets() %}
{% set enablePreview = previewTargets and not craft.app.request.isMobileBrowser(true) %}

{% set canDeleteDraft = isDraft and not isUnsavedDraft and ((canDeleteDraft ?? false) or element.creatorId == currentUser.id) %}
{% set canUpdateSource = canUpdateSource ?? false %}
{% set canDuplicateSource = canDuplicateSource ?? false %}
{% set canAddAnother = canAddAnother ?? false %}
{% set canDeleteSource = canDeleteSource ?? false %}
{% set canEdit = canEdit ?? (canUpdateSource or canDuplicateSource or canAddAnother or saveDraftAction) %}

{% set redirectUrl = redirectUrl ?? element.cpEditUrl %}
{% set addAnotherRedirectUrl = addAnotherRedirectUrl ?? null %}

{% set saveSourceAction = saveSourceAction ?? null %}
{% set duplicateSourceAction = duplicateSourceAction ?? null %}
{% set deleteSourceAction = deleteSourceAction ?? null %}
{% set revertSourceAction = revertSourceAction ?? null %}
{% set saveDraftAction = saveDraftAction ?? null %}

{% if not isRevision %}
    {% set fullPageForm = true %}
{% endif %}

{% if isDraft %}
    {% do craft.app.session.authorize('previewDraft:' ~ element.draftId) %}
{% elseif isRevision %}
    {% do craft.app.session.authorize('previewRevision:' ~ element.revisionId) %}
{% else %}
    {% do craft.app.session.authorize('previewElement:' ~ element.id) %}
{% endif %}

{# If this is an unsaved draft, then we should only show status toggles if the
   user actually has permission to publish chanegs #}
{% set showStatusToggles = element.hasStatuses() and
    (not isUnsavedDraft or canUpdateSource) and
    (showStatusToggles ?? true) %}

{% if not isDraft and not canUpdateSource %}
    {% set saveShortcut = false %}
{% elseif isUnsavedDraft or (isCurrent and canUpdateSource) %}
    {% set saveShortcutRedirect = '{cpEditUrl}' %}
{% endif %}

{% if tabs is not defined %}
    {% set tabs = [] %}
    {% for tab in element.fieldLayout.tabs ?? [] %}
        {% set tabs = tabs|merge([{
            label: tab.name|t('site'),
            url: '#' ~ tab.getHtmlId(),
            class: tab.elementHasErrors(element) ? 'error',
        }]) %}
    {% endfor %}
{% endif %}

{% set settingsHtml = (block('settings') ?? '')|trim %}

{% block header %}
    <div class=\"flex flex-nowrap\">
        {{ block('pageTitle') }}
        {{ block('contextMenu') }}
    </div>
    <div class=\"flex\">
        {% if previewTargets %}
            <div class=\"btngroup\">
                {% if enablePreview %}
                    <div id=\"preview-btn\" class=\"btn\">{{ \"Preview\"|t('app') }}</div>
                {% endif %}
                <div id=\"share-btn\" class=\"btn\">{{ 'Share'|t('app') }}</div>
            </div>
        {% endif %}

        {% if isCurrent and saveDraftAction %}
            <div id=\"save-draft-btn-container\">
                {% if canUpdateSource and saveSourceAction %}
                    <div id=\"save-draft-btn\" class=\"btn\">{{ 'Save as a draft'|t('app') }}</div>
                {% else %}
                    <input type=\"submit\" id=\"save-draft-btn\" class=\"btn submit\" value=\"{{ 'Save as a draft'|t('app') }}\">
                {% endif %}
            </div>
        {% endif %}

        {{ block('actionButton') }}
    </div>
{% endblock %}

{% block contextMenu %}
    {% if isMultiSiteElement or saveDraftAction or element.find().revisionOf(element).exists() %}
        {% include \"_includes/revisionmenu\" with {
            canHaveDrafts: saveDraftAction is not empty,
        } %}
    {% endif %}
{% endblock %}

{% block actionButton %}
    {% if isUnsavedDraft or isCurrent %}
        {# Can they save the source element, and do we know how to save it? #}
        {% if isUnsavedDraft or (canUpdateSource and saveSourceAction) %}
            <div id=\"save-btn-container\" class=\"btngroup submit\">
                {{ tag('input', {
                    type: 'submit',
                    class: ['btn', 'submit'],
                    value: isUnsavedDraft ? 'Create'|t('app') : 'Save'|t('app'),
                }) }}
                <div class=\"btn submit menubtn\"></div>
                <div class=\"menu\" data-align=\"right\">
                    <ul>
                        <li>
                            <a class=\"formsubmit\" data-redirect=\"{{ '{cpEditUrl}'|hash }}\">
                                {{ forms.optionShortcutLabel('S') }}
                                {{ isUnsavedDraft ? 'Create and continue editing'|t('app') : 'Save and continue editing'|t('app') }}
                            </a>
                        </li>
                        {% if canUpdateSource %}
                            {% if canAddAnother and addAnotherRedirectUrl %}
                                <li>
                                    <a class=\"formsubmit\" data-redirect=\"{{ addAnotherRedirectUrl|hash }}\">
                                        {{ isUnsavedDraft ? 'Create and add another'|t('app') : 'Save and add another'|t('app') }}
                                    </a>
                                </li>
                            {% endif %}
                            {% if not isUnsavedDraft and canDuplicateSource and duplicateSourceAction %}
                                <li>
                                    <a class=\"formsubmit\" data-action=\"{{ duplicateSourceAction }}\" data-redirect=\"{{ '{cpEditUrl}'|hash }}\">
                                        {{ \"Save as a new {type}\"|t('app', { type: element.lowerDisplayName() }) }}
                                    </a>
                                </li>
                            {% endif %}
                        {% endif %}
                    </ul>
                    {% if not isUnsavedDraft and canDeleteSource and deleteSourceAction %}
                        <hr>
                        <ul>
                            <li>
                                <a class=\"formsubmit error\" data-action=\"{{ deleteSourceAction }}\"
                                   data-confirm=\"{{ 'Are you sure you want to delete this {type}?'|t('app', { type: element.lowerDisplayName() }) }}\"
                                   data-redirect=\"{{ (redirectUrl ~ '#')|hash }}\">
                                    {{ 'Delete {type}'|t('app', { type: element.lowerDisplayName() }) }}
                                </a>
                            </li>
                        </ul>
                    {% endif %}
                </div>
            </div>
        {% endif %}
    {% elseif isDraft %}
        {% if canUpdateSource and saveSourceAction %}
            <input type=\"submit\" class=\"btn submit\" value=\"{{ 'Publish changes'|t('app') }}\">
        {% endif %}
    {% elseif isRevision %}
        {% if canUpdateSource and revertSourceAction %}
            <form method=\"post\" accept-charset=\"UTF-8\">
                {{ csrfInput() }}
                {{ actionInput(revertSourceAction) }}
                {{ redirectInput('{cpEditUrl}') }}
                {{ hiddenInput('revisionId', element.revisionId) }}
                <div class=\"secondary-buttons\">
                    <input type=\"button\" class=\"btn submit formsubmit\" value=\"{{ 'Revert {type} to this revision'|t('app', { type: element.lowerDisplayName() }) }}\">
                </div>
            </form>
        {% endif %}
    {% endif %}
{% endblock %}

{% block main %}
    {% if fullPageForm %}
        {# action and redirect params #}
        {% if not isDraft and canUpdateSource and saveSourceAction %}
            {# current revision -- user can update source #}
            {{ actionInput(saveSourceAction) }}
            {{ redirectInput(redirectUrl) }}
        {% endif %}

        {# siteId param #}
        {% if craft.app.isMultiSite %}
            {{ hiddenInput('siteId', element.siteId) }}
        {% endif %}

        {# propagateAll param #}
        {% if isUnsavedDraft and craft.app.request.getQueryParam('fresh') %}
            {{ hiddenInput('propagateAll', '1') }}
        {% endif %}
    {% endif %}
    {{ parent() }}
{% endblock %}

{% block content %}
    <div id=\"fields\">
        {% for tab in element.fieldLayout.tabs ?? [] %}
            <div id=\"{{ tab.getHtmlId() }}\"{% if not loop.first %} class=\"hidden\"{% endif %}>
                {% include \"_includes/fields\" with {
                    fields:  tab.getFields(),
                    element: element,
                    static:  isRevision or not canEdit,
                    registerDeltas: true,
                } only %}
            </div>
        {% endfor %}
    </div>
{% endblock %}

{% block details %}
    {% if settingsHtml %}
        <div id=\"settings\" class=\"meta\">
            {{ settingsHtml|raw }}
        </div>
    {% endif %}

    {% if showStatusToggles and isMultiSiteElement %}
        <div class=\"meta\">
            {{ forms.lightswitchField({
                status: element.getAttributeStatus('enabled'),
                label: 'Enabled for {site}'|t('app', { site: element.site.name|t('site')|e }) ~
                    (canEditMultipleSites ? '<a id=\"expand-status-btn\" data-icon=\"ellipsis\" class=\"btn\" role=\"button\"></a>'),
                id: \"enabledForSite-#{element.siteId}\",
                name: \"enabledForSite[#{element.siteId}]\",
                on: element.enabled and element.enabledForSite,
                disabled: isRevision,
            }) }}
        </div>
    {% endif %}

    <div id=\"meta-details\" class=\"meta read-only\">
        {% block meta %}
            {% if element.hasStatuses() %}
                {% if isUnsavedDraft %}
                    {% set statusColor = 'white' %}
                    {% set statusLabel = 'Draft'|t('app') %}
                {% else %}
                    {% set status = element.getStatus() %}
                    {% set statusDef = element.statuses()[status] ?? null %}
                    {% set statusColor = statusDef.color ?? status %}
                    {% set statusLabel = statusDef.label ?? statusDef ?? status|ucfirst %}
                {% endif %}
                <div class=\"data\">
                    <h5 class=\"heading\">{{ 'Status'|t('app') }}</h5>
                    <div id=\"status-value\" class=\"value\"><span class=\"status {{ statusColor }}\"></span>{{ statusLabel }}</div>
                </div>
            {% endif %}
            <div class=\"data\">
                <h5 class=\"heading\">{{ \"Created at\"|t('app') }}</h5>
                <div id=\"date-created-value\" class=\"value\">{{ element.dateCreated|datetime('short') }}</div>
            </div>
            <div class=\"data\">
                <h5 class=\"heading\">{{ \"Updated at\"|t('app') }}</h5>
                <div id=\"date-updated-value\" class=\"value\">{{ element.dateUpdated|datetime('short') }}</div>
            </div>
            {% if isRevision %}
                {% set revisionNotes = element.revisionNotes %}
            {% elseif not isDraft and element.currentRevision %}
                {% set revisionNotes = element.currentRevision.revisionNotes %}
            {% else %}
                {% set revisionNotes = null %}
            {% endif %}
            {% if revisionNotes %}
                <div class=\"data\">
                    <h5 class=\"heading\">{{ \"Notes\"|t('app') }}</h5>
                    <div class=\"value\">{{ revisionNotes }}</div>
                </div>
            {% endif %}
        {% endblock %}
    </div>

    {% if isDraft and element.getIsOutdated() %}
        {% do craft.app.session.authorize('mergeDraftSourceChanges:' ~ element.draftId) %}
        <div class=\"meta read-only warning\">
            <p>{{ 'The source {type} has been updated recently.'|t('app', {type: element.lowerDisplayName()}) }}</p>
            <div class=\"flex flex-nowrap\">
                {% if element.trackChanges %}
                    {{ tag('div', {
                        id: 'merge-changes-btn',
                        class: ['btn'],
                        role: 'button',
                        text: 'Merge changes into draft'|t('app'),
                    }) }}
                    <div id=\"merge-changes-spinner\" class=\"spinner hidden\"></div>
                {% endif %}
            </div>
        </div>
    {% endif %}
{% endblock %}

{% block settings %}
    {% if showStatusToggles and not isMultiSiteElement %}
        {{ forms.lightswitchField({
            status: element.getAttributeStatus('enabled'),
            label: 'Enabled'|t('app'),
            id: 'enabled',
            name: 'enabled',
            on: element.enabled,
            disabled: isRevision,
        }) }}
    {% endif %}
{% endblock %}

{% if canEditMultipleSites and element.enabled %}
    {# get the element's statuses across all sites #}
    {% set siteStatusesQuery = element.find()
        .select(['elements_sites.siteId', 'elements_sites.enabled'])
        .id(element.id)
        .siteId(editableSiteIds)
        .anyStatus()
        .asArray() %}
    {% if isDraft %}
        {% do siteStatusesQuery.drafts() %}
    {% elseif isRevision %}
        {% do siteStatusesQuery.revisions() %}
    {% endif %}
    {% set siteStatuses = siteStatusesQuery
        .pairs()|map(s => s ? true : false) %}
{% elseif canEditMultipleSites %}
    {% set siteStatusValues = {} %}
    {% for siteId in editableSiteIds %}
        {% set siteStatusValues = siteStatusValues|merge([false]) %}
    {% endfor %}
    {% set siteStatuses = combine(editableSiteIds, siteStatusValues) %}
{% else %}
    {% set siteStatuses = {
        (\"#{element.siteId}\"): element.enabled ? true : false
    } %}
{% endif %}

{% set settings = {
    elementType: className(element),
    elementTypeDisplayName: element.displayName(),
    sourceId: element.getSourceId(),
    siteId: element.siteId,
    isUnsavedDraft: isUnsavedDraft,
    siteStatuses: siteStatuses,
    enabled: element.enabled ? true : false,
    enabledForSite: element.enabled and element.enabledForSite,
    isLive: isCurrent and element.enabled and element.enabledForSite and element.getRoute(),
    cpEditUrl: element.cpEditUrl,
    hashedRedirectUrl: (isUnsavedDraft ? redirectUrl : '{cpEditUrl}')|hash,
    draftId: element.draftId,
    revisionId: element.revisionId,
    draftName: isDraft ? element.draftName : null,
    draftNotes: isDraft ? element.draftNotes : null,
    canEditMultipleSites: canEditMultipleSites,
    canDeleteDraft: canDeleteDraft,
    canUpdateSource: canUpdateSource,
    saveDraftAction: saveDraftAction,
    deleteDraftAction: deleteDraftAction ?? null,
    applyDraftAction: applyDraftAction ?? null,
    enablePreview: enablePreview,
    previewTargets: previewTargets,
} %}
{% js %}
    window.draftEditor = new Craft.DraftEditor({{ settings|json_encode|raw }});
{% endjs %}
", "_layouts/element", "/Applications/MAMP/htdocs/craft/smsi/vendor/craftcms/cms/src/templates/_layouts/element.html");
    }
}
