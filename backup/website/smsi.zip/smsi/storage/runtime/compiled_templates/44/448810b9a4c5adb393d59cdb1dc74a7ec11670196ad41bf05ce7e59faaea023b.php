<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* settings/sections/_entrytypes/edit */
class __TwigTemplate_83b6afe873c9bfe1469744b5158ac9ed16eb7012913dd1849c8d6857e1c825b9 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "_layouts/cp";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("template", "settings/sections/_entrytypes/edit");
        // line 2
        $context["fullPageForm"] = true;
        // line 4
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms", "settings/sections/_entrytypes/edit", 4)->unwrap();
        // line 90
        if ( !craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entryType"]) || array_key_exists("entryType", $context) ? $context["entryType"] : (function () { throw new RuntimeError('Variable "entryType" does not exist.', 90, $this->source); })()), "handle", [])) {
            // line 91
            Craft::$app->getView()->registerJs("new Craft.HandleGenerator('#name', '#handle');", 3);
        }
        // line 1
        $this->parent = $this->loadTemplate("_layouts/cp", "settings/sections/_entrytypes/edit", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        // line 0
        craft\helpers\Template::endProfile("template", "settings/sections/_entrytypes/edit");
    }

    // line 7
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("block", "content");
        // line 8
        echo "    ";
        echo craft\helpers\Html::actionInput("sections/save-entry-type");
        echo "

    ";
        // line 10
        if ((craft\helpers\Template::attribute($this->env, $this->source, (isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 10, $this->source); })()), "type", []) == "single")) {
            // line 11
            echo "        ";
            echo craft\helpers\Html::redirectInput("settings/sections");
            echo "
    ";
        } else {
            // line 13
            echo "        ";
            echo craft\helpers\Html::redirectInput((("settings/sections/" . craft\helpers\Template::attribute($this->env, $this->source, (isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 13, $this->source); })()), "id", [])) . "/entrytypes"));
            echo "
    ";
        }
        // line 15
        echo "    ";
        echo craft\helpers\Html::hiddenInput("sectionId", craft\helpers\Template::attribute($this->env, $this->source, (isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 15, $this->source); })()), "id", []));
        echo "
    ";
        // line 16
        if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entryType"]) || array_key_exists("entryType", $context) ? $context["entryType"] : (function () { throw new RuntimeError('Variable "entryType" does not exist.', 16, $this->source); })()), "id", [])) {
            echo craft\helpers\Html::hiddenInput("entryTypeId", craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entryType"]) || array_key_exists("entryType", $context) ? $context["entryType"] : (function () { throw new RuntimeError('Variable "entryType" does not exist.', 16, $this->source); })()), "id", []));
        }
        // line 17
        echo "
    ";
        // line 18
        if ((craft\helpers\Template::attribute($this->env, $this->source, (isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 18, $this->source); })()), "type", []) != "single")) {
            // line 19
            echo "        ";
            echo twig_call_macro($macros["forms"], "macro_textField", [["first" => true, "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Name", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("What this entry type will be called in the control panel.", "app"), "id" => "name", "name" => "name", "value" => craft\helpers\Template::attribute($this->env, $this->source,             // line 25
(isset($context["entryType"]) || array_key_exists("entryType", $context) ? $context["entryType"] : (function () { throw new RuntimeError('Variable "entryType" does not exist.', 25, $this->source); })()), "name", []), "errors" => craft\helpers\Template::attribute($this->env, $this->source,             // line 26
(isset($context["entryType"]) || array_key_exists("entryType", $context) ? $context["entryType"] : (function () { throw new RuntimeError('Variable "entryType" does not exist.', 26, $this->source); })()), "getErrors", [0 => "name"], "method"), "autofocus" => true, "required" => true]], 19, $context, $this->getSourceContext());
            // line 29
            echo "

        ";
            // line 31
            echo twig_call_macro($macros["forms"], "macro_textField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Handle", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("How you’ll refer to this entry type in the templates.", "app"), "id" => "handle", "name" => "handle", "class" => "code", "autocorrect" => false, "autocapitalize" => false, "value" => craft\helpers\Template::attribute($this->env, $this->source,             // line 39
(isset($context["entryType"]) || array_key_exists("entryType", $context) ? $context["entryType"] : (function () { throw new RuntimeError('Variable "entryType" does not exist.', 39, $this->source); })()), "handle", []), "errors" => craft\helpers\Template::attribute($this->env, $this->source,             // line 40
(isset($context["entryType"]) || array_key_exists("entryType", $context) ? $context["entryType"] : (function () { throw new RuntimeError('Variable "entryType" does not exist.', 40, $this->source); })()), "getErrors", [0 => "handle"], "method"), "required" => true]], 31, $context, $this->getSourceContext());
            // line 42
            echo "

        <hr>

    ";
        }
        // line 47
        echo "
    ";
        // line 48
        echo twig_call_macro($macros["forms"], "macro_checkboxField", [["first" => (craft\helpers\Template::attribute($this->env, $this->source,         // line 49
(isset($context["section"]) || array_key_exists("section", $context) ? $context["section"] : (function () { throw new RuntimeError('Variable "section" does not exist.', 49, $this->source); })()), "type", []) == "single"), "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Show the Title field", "app"), "name" => "hasTitleField", "toggle" => "titleLabel-container", "reverseToggle" => "titleFormat-container", "checked" => craft\helpers\Template::attribute($this->env, $this->source,         // line 54
(isset($context["entryType"]) || array_key_exists("entryType", $context) ? $context["entryType"] : (function () { throw new RuntimeError('Variable "entryType" does not exist.', 54, $this->source); })()), "hasTitleField", [])]], 48, $context, $this->getSourceContext());
        // line 55
        echo "

    <div id=\"titleLabel-container\"";
        // line 57
        if ( !craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entryType"]) || array_key_exists("entryType", $context) ? $context["entryType"] : (function () { throw new RuntimeError('Variable "entryType" does not exist.', 57, $this->source); })()), "hasTitleField", [])) {
            echo " class=\"hidden\"";
        }
        echo ">
        ";
        // line 58
        echo twig_call_macro($macros["forms"], "macro_textField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Title Field Label", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("What do you want the Title field to be called?", "app"), "id" => "titleLabel", "name" => "titleLabel", "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 63
(isset($context["entryType"]) || array_key_exists("entryType", $context) ? $context["entryType"] : (function () { throw new RuntimeError('Variable "entryType" does not exist.', 63, $this->source); })()), "titleLabel", []), "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 64
(isset($context["entryType"]) || array_key_exists("entryType", $context) ? $context["entryType"] : (function () { throw new RuntimeError('Variable "entryType" does not exist.', 64, $this->source); })()), "getErrors", [0 => "titleLabel"], "method"), "required" => true]], 58, $context, $this->getSourceContext());
        // line 66
        echo "
    </div>

    <div id=\"titleFormat-container\"";
        // line 69
        if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entryType"]) || array_key_exists("entryType", $context) ? $context["entryType"] : (function () { throw new RuntimeError('Variable "entryType" does not exist.', 69, $this->source); })()), "hasTitleField", [])) {
            echo " class=\"hidden\"";
        }
        echo ">
        ";
        // line 70
        echo twig_call_macro($macros["forms"], "macro_textField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Title Format", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("What the auto-generated entry titles should look like. You can include tags that output entry properties, such as {ex}.", "app", ["ex" => "<code>{myCustomField}</code>"]), "id" => "titleFormat", "name" => "titleFormat", "class" => "code", "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 76
(isset($context["entryType"]) || array_key_exists("entryType", $context) ? $context["entryType"] : (function () { throw new RuntimeError('Variable "entryType" does not exist.', 76, $this->source); })()), "titleFormat", []), "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 77
(isset($context["entryType"]) || array_key_exists("entryType", $context) ? $context["entryType"] : (function () { throw new RuntimeError('Variable "entryType" does not exist.', 77, $this->source); })()), "getErrors", [0 => "titleFormat"], "method"), "required" => true]], 70, $context, $this->getSourceContext());
        // line 79
        echo "
    </div>

    <hr>

    ";
        // line 84
        $this->loadTemplate("_includes/fieldlayoutdesigner", "settings/sections/_entrytypes/edit", 84)->display(twig_to_array(["fieldLayout" => craft\helpers\Template::attribute($this->env, $this->source,         // line 85
(isset($context["entryType"]) || array_key_exists("entryType", $context) ? $context["entryType"] : (function () { throw new RuntimeError('Variable "entryType" does not exist.', 85, $this->source); })()), "getFieldLayout", [], "method")]));
        // line 0
        craft\helpers\Template::endProfile("block", "content");
    }

    public function getTemplateName()
    {
        return "settings/sections/_entrytypes/edit";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  166 => 0,  164 => 85,  163 => 84,  156 => 79,  154 => 77,  153 => 76,  152 => 70,  146 => 69,  141 => 66,  139 => 64,  138 => 63,  137 => 58,  131 => 57,  127 => 55,  125 => 54,  124 => 49,  123 => 48,  120 => 47,  113 => 42,  111 => 40,  110 => 39,  109 => 31,  105 => 29,  103 => 26,  102 => 25,  100 => 19,  98 => 18,  95 => 17,  91 => 16,  86 => 15,  80 => 13,  74 => 11,  72 => 10,  66 => 8,  64 => 0,  60 => 7,  56 => 0,  53 => 1,  50 => 91,  48 => 90,  46 => 4,  44 => 2,  42 => 0,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends \"_layouts/cp\" %}
{% set fullPageForm = true %}

{% import \"_includes/forms\" as forms %}


{% block content %}
    {{ actionInput('sections/save-entry-type') }}

    {% if section.type == 'single' %}
        {{ redirectInput('settings/sections') }}
    {% else %}
        {{ redirectInput('settings/sections/'~section.id~'/entrytypes') }}
    {% endif %}
    {{ hiddenInput('sectionId', section.id) }}
    {% if entryType.id %}{{ hiddenInput('entryTypeId', entryType.id) }}{% endif %}

    {% if section.type != 'single' %}
        {{ forms.textField({
            first: true,
            label: \"Name\"|t('app'),
            instructions: \"What this entry type will be called in the control panel.\"|t('app'),
            id: 'name',
            name: 'name',
            value: entryType.name,
            errors: entryType.getErrors('name'),
            autofocus: true,
            required: true
        }) }}

        {{ forms.textField({
            label: \"Handle\"|t('app'),
            instructions: \"How you’ll refer to this entry type in the templates.\"|t('app'),
            id: 'handle',
            name: 'handle',
            class: 'code',
            autocorrect: false,
            autocapitalize: false,
            value: entryType.handle,
            errors: entryType.getErrors('handle'),
            required: true
        }) }}

        <hr>

    {% endif %}

    {{ forms.checkboxField({
        first: (section.type == 'single'),
        label: \"Show the Title field\"|t('app'),
        name: 'hasTitleField',
        toggle: 'titleLabel-container',
        reverseToggle: 'titleFormat-container',
        checked: entryType.hasTitleField
    }) }}

    <div id=\"titleLabel-container\"{% if not entryType.hasTitleField %} class=\"hidden\"{% endif %}>
        {{ forms.textField({
            label: \"Title Field Label\"|t('app'),
            instructions: \"What do you want the Title field to be called?\"|t('app'),
            id: 'titleLabel',
            name: 'titleLabel',
            value: entryType.titleLabel,
            errors: entryType.getErrors('titleLabel'),
            required: true
        }) }}
    </div>

    <div id=\"titleFormat-container\"{% if entryType.hasTitleField %} class=\"hidden\"{% endif %}>
        {{ forms.textField({
            label: \"Title Format\"|t('app'),
            instructions: \"What the auto-generated entry titles should look like. You can include tags that output entry properties, such as {ex}.\"|t('app', { ex: '<code>{myCustomField}</code>' }),
            id: 'titleFormat',
            name: 'titleFormat',
            class: 'code',
            value: entryType.titleFormat,
            errors: entryType.getErrors('titleFormat'),
            required: true
        }) }}
    </div>

    <hr>

    {% include \"_includes/fieldlayoutdesigner\" with {
        fieldLayout: entryType.getFieldLayout(),
    } only %}
{% endblock %}


{% if not entryType.handle %}
    {% js \"new Craft.HandleGenerator('#name', '#handle');\" %}
{% endif %}
", "settings/sections/_entrytypes/edit", "/Applications/MAMP/htdocs/craft/smsi/vendor/craftcms/cms/src/templates/settings/sections/_entrytypes/edit.html");
    }
}
