<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _layouts */
class __TwigTemplate_089cc06ffccb7ec8f1479b8ed4798e3840404af5c337c30cf4cc0a5e75403e00 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_layouts");
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"";
        // line 2
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 2, $this->source); })()), "app", []), "language", []), "html", null, true);
        echo "\">

<head>
  <meta charset=\"utf-8\">
  <meta content=\"width=device-width, initial-scale=1.0\" name=\"viewport\">

  <title>";
        // line 8
        echo twig_escape_filter($this->env, (isset($context["siteName"]) || array_key_exists("siteName", $context) ? $context["siteName"] : (function () { throw new RuntimeError('Variable "siteName" does not exist.', 8, $this->source); })()), "html", null, true);
        echo "</title>
  <meta content=\"\" name=\"descriptison\">
  <meta content=\"\" name=\"keywords\">

  <!-- Favicons -->
  <link href=\"assets/img/favicon.png\" rel=\"icon\">
  <link href=\"assets/img/apple-touch-icon.png\" rel=\"apple-touch-icon\">

  <!-- Google Fonts -->
  <link href=\"https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i\" rel=\"stylesheet\">

  <!-- Vendor CSS Files -->
  <link href=\"assets/vendor/bootstrap/css/bootstrap.min.css\" rel=\"stylesheet\">
  <link href=\"assets/vendor/icofont/icofont.min.css\" rel=\"stylesheet\">
  <link href=\"assets/vendor/boxicons/css/boxicons.min.css\" rel=\"stylesheet\">
  <link href=\"assets/vendor/remixicon/remixicon.css\" rel=\"stylesheet\">
  <link href=\"assets/vendor/venobox/venobox.css\" rel=\"stylesheet\">
  <link href=\"assets/vendor/owl.carousel/assets/owl.carousel.min.css\" rel=\"stylesheet\">

  <!-- Template Main CSS File -->
  <link href=\"assets/css/style.css\" rel=\"stylesheet\">

  <!-- =======================================================
  * Template Name: KnightOne - v2.0.0
  * Template URL: https://bootstrapmade.com/knight-simple-one-page-bootstrap-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
";
        // line 36
        call_user_func_array($this->env->getFunction('head')->getCallable(), []);
        echo "</head>

<body>";
        // line 38
        call_user_func_array($this->env->getFunction('beginBody')->getCallable(), []);
        echo "

  <!-- ======= Header ======= -->
  ";
        // line 41
        $this->loadTemplate("partials/header", "_layouts", 41)->display($context);
        // line 42
        echo "  
  </header><!-- End Header -->

  <!-- ======= Hero Section ======= -->
  ";
        // line 46
        $this->loadTemplate("partials/hero", "_layouts", 46)->display($context);
        // line 47
        echo "  <!-- End Hero -->

  <main id=\"main\">

    ";
        // line 51
        $this->displayBlock('content', $context, $blocks);
        // line 53
        echo "
  </main>
  <!-- End #main -->

  <!-- ======= Footer ======= -->
  ";
        // line 58
        $this->loadTemplate("partials/footer", "_layouts", 58)->display($context);
        // line 59
        echo "  <!-- End Footer -->

  <div id=\"preloader\"></div>
  <a href=\"#\" class=\"back-to-top\"><i class=\"ri-arrow-up-line\"></i></a>

  <!-- Vendor JS Files -->
  <script src=\"assets/vendor/jquery/jquery.min.js\"></script>
  <script src=\"assets/vendor/bootstrap/js/bootstrap.bundle.min.js\"></script>
  <script src=\"assets/vendor/jquery.easing/jquery.easing.min.js\"></script>
  <script src=\"assets/vendor/php-email-form/validate.js\"></script>
  <script src=\"assets/vendor/waypoints/jquery.waypoints.min.js\"></script>
  <script src=\"assets/vendor/counterup/counterup.min.js\"></script>
  <script src=\"assets/vendor/isotope-layout/isotope.pkgd.min.js\"></script>
  <script src=\"assets/vendor/venobox/venobox.min.js\"></script>
  <script src=\"assets/vendor/owl.carousel/owl.carousel.min.js\"></script>

  <!-- Template Main JS File -->
  <script src=\"assets/js/main.js\"></script>

";
        // line 78
        call_user_func_array($this->env->getFunction('endBody')->getCallable(), []);
        echo "</body>

</html>";
        // line 0
        craft\helpers\Template::endProfile("template", "_layouts");
    }

    // line 51
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("block", "content");
        // line 52
        echo "    ";
        // line 0
        craft\helpers\Template::endProfile("block", "content");
    }

    public function getTemplateName()
    {
        return "_layouts";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  158 => 0,  156 => 52,  154 => 0,  150 => 51,  146 => 0,  141 => 78,  120 => 59,  118 => 58,  111 => 53,  109 => 51,  103 => 47,  101 => 46,  95 => 42,  93 => 41,  87 => 38,  82 => 36,  51 => 8,  42 => 2,  39 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<!DOCTYPE html>
<html lang=\"{{ craft.app.language }}\">

<head>
  <meta charset=\"utf-8\">
  <meta content=\"width=device-width, initial-scale=1.0\" name=\"viewport\">

  <title>{{ siteName }}</title>
  <meta content=\"\" name=\"descriptison\">
  <meta content=\"\" name=\"keywords\">

  <!-- Favicons -->
  <link href=\"assets/img/favicon.png\" rel=\"icon\">
  <link href=\"assets/img/apple-touch-icon.png\" rel=\"apple-touch-icon\">

  <!-- Google Fonts -->
  <link href=\"https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i\" rel=\"stylesheet\">

  <!-- Vendor CSS Files -->
  <link href=\"assets/vendor/bootstrap/css/bootstrap.min.css\" rel=\"stylesheet\">
  <link href=\"assets/vendor/icofont/icofont.min.css\" rel=\"stylesheet\">
  <link href=\"assets/vendor/boxicons/css/boxicons.min.css\" rel=\"stylesheet\">
  <link href=\"assets/vendor/remixicon/remixicon.css\" rel=\"stylesheet\">
  <link href=\"assets/vendor/venobox/venobox.css\" rel=\"stylesheet\">
  <link href=\"assets/vendor/owl.carousel/assets/owl.carousel.min.css\" rel=\"stylesheet\">

  <!-- Template Main CSS File -->
  <link href=\"assets/css/style.css\" rel=\"stylesheet\">

  <!-- =======================================================
  * Template Name: KnightOne - v2.0.0
  * Template URL: https://bootstrapmade.com/knight-simple-one-page-bootstrap-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Header ======= -->
  {% include \"partials/header\" %}
  
  </header><!-- End Header -->

  <!-- ======= Hero Section ======= -->
  {% include \"partials/hero\" %}
  <!-- End Hero -->

  <main id=\"main\">

    {% block content %}
    {% endblock %}

  </main>
  <!-- End #main -->

  <!-- ======= Footer ======= -->
  {% include \"partials/footer\" %}
  <!-- End Footer -->

  <div id=\"preloader\"></div>
  <a href=\"#\" class=\"back-to-top\"><i class=\"ri-arrow-up-line\"></i></a>

  <!-- Vendor JS Files -->
  <script src=\"assets/vendor/jquery/jquery.min.js\"></script>
  <script src=\"assets/vendor/bootstrap/js/bootstrap.bundle.min.js\"></script>
  <script src=\"assets/vendor/jquery.easing/jquery.easing.min.js\"></script>
  <script src=\"assets/vendor/php-email-form/validate.js\"></script>
  <script src=\"assets/vendor/waypoints/jquery.waypoints.min.js\"></script>
  <script src=\"assets/vendor/counterup/counterup.min.js\"></script>
  <script src=\"assets/vendor/isotope-layout/isotope.pkgd.min.js\"></script>
  <script src=\"assets/vendor/venobox/venobox.min.js\"></script>
  <script src=\"assets/vendor/owl.carousel/owl.carousel.min.js\"></script>

  <!-- Template Main JS File -->
  <script src=\"assets/js/main.js\"></script>

</body>

</html>", "_layouts", "/Applications/MAMP/htdocs/craft/smsi/templates/_layouts.twig");
    }
}
