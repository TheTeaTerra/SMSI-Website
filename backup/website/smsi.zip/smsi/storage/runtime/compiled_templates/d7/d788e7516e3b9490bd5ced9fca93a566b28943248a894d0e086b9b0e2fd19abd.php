<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* __string_template__ec4fe100715e73f8a1f90afe367eb7a4123a558a5ae67127b7e959084f217573 */
class __TwigTemplate_5894d7195208f67ea05b10a08d3b94db2d67cf289e308789a64a1107474f4e70 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "__string_template__ec4fe100715e73f8a1f90afe367eb7a4123a558a5ae67127b7e959084f217573");
        // line 1
        echo "blog/category/";
        echo (((craft\helpers\Template::attribute($this->env, $this->source, ($context["_variables"] ?? null), "slug", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["_variables"] ?? null), "slug", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["_variables"] ?? null), "slug", [])) : (craft\helpers\Template::attribute($this->env, $this->source, ($context["object"] ?? null), "slug", [])));
        // line 0
        craft\helpers\Template::endProfile("template", "__string_template__ec4fe100715e73f8a1f90afe367eb7a4123a558a5ae67127b7e959084f217573");
    }

    public function getTemplateName()
    {
        return "__string_template__ec4fe100715e73f8a1f90afe367eb7a4123a558a5ae67127b7e959084f217573";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  41 => 0,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("blog/category/{{ (_variables.slug ?? object.slug)|raw }}", "__string_template__ec4fe100715e73f8a1f90afe367eb7a4123a558a5ae67127b7e959084f217573", "");
    }
}
