<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _layouts/basic */
class __TwigTemplate_46123f7594ad8efdf18bce15eb3e93b8cabefc3662b27750f8a3eedfa4e3a30a extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_layouts/basic");
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"";
        // line 2
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 2, $this->source); })()), "app", []), "language", []), "html", null, true);
        echo "\">

<head>
    <meta content=\"IE-ende\" http-equiv=\"X-UA-Comptible\">
    <meta charset=\"utf-8\">
    <title>";
        // line 7
        echo twig_escape_filter($this->env, (isset($context["siteName"]) || array_key_exists("siteName", $context) ? $context["siteName"] : (function () { throw new RuntimeError('Variable "siteName" does not exist.', 7, $this->source); })()), "html", null, true);
        echo "</title>
    <meta content=\"width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover\"
        name=\"viewport\">
    <link href=\"/styles.css\" rel=\"stylesheet\">
";
        // line 11
        call_user_func_array($this->env->getFunction('head')->getCallable(), []);
        echo "</head>

<body class=\"ltr\">";
        // line 13
        call_user_func_array($this->env->getFunction('beginBody')->getCallable(), []);
        echo "
    ";
        // line 14
        $this->loadTemplate("_includes/nav", "_layouts/basic", 14)->display($context);
        // line 15
        echo "    <div class=\"container mx-auto px-4\">
        ";
        // line 16
        $this->displayBlock('content', $context, $blocks);
        // line 18
        echo "    </div>
    <footer class=\"container mx-auto mt-8 p-4 text-sm opacity-50\">
        ";
        // line 20
        echo $this->extensions['craft\web\twig\Extension']->markdownFilter(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["siteInformation"]) || array_key_exists("siteInformation", $context) ? $context["siteInformation"] : (function () { throw new RuntimeError('Variable "siteInformation" does not exist.', 20, $this->source); })()), "description", []));
        echo "
        <p>&copy; ";
        // line 21
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->dateFilter($this->env, (isset($context["now"]) || array_key_exists("now", $context) ? $context["now"] : (function () { throw new RuntimeError('Variable "now" does not exist.', 21, $this->source); })()), "Y"), "html", null, true);
        echo ", built with <a class=\"text-blue-600\"
                href=\"https://craftcms.com\">Craft CMS</a></p>
    </footer>
";
        // line 24
        call_user_func_array($this->env->getFunction('endBody')->getCallable(), []);
        echo "</body>

</html>";
        // line 0
        craft\helpers\Template::endProfile("template", "_layouts/basic");
    }

    // line 16
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("block", "content");
        // line 17
        echo "        ";
        // line 0
        craft\helpers\Template::endProfile("block", "content");
    }

    public function getTemplateName()
    {
        return "_layouts/basic";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  104 => 0,  102 => 17,  100 => 0,  96 => 16,  92 => 0,  87 => 24,  81 => 21,  77 => 20,  73 => 18,  71 => 16,  68 => 15,  66 => 14,  62 => 13,  57 => 11,  50 => 7,  42 => 2,  39 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<!DOCTYPE html>
<html lang=\"{{ craft.app.language }}\">

<head>
    <meta content=\"IE-ende\" http-equiv=\"X-UA-Comptible\">
    <meta charset=\"utf-8\">
    <title>{{ siteName }}</title>
    <meta content=\"width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover\"
        name=\"viewport\">
    <link href=\"/styles.css\" rel=\"stylesheet\">
</head>

<body class=\"ltr\">
    {% include \"_includes/nav\" %}
    <div class=\"container mx-auto px-4\">
        {% block content %}
        {% endblock %}
    </div>
    <footer class=\"container mx-auto mt-8 p-4 text-sm opacity-50\">
        {{ siteInformation.description|markdown }}
        <p>&copy; {{ now | date('Y') }}, built with <a class=\"text-blue-600\"
                href=\"https://craftcms.com\">Craft CMS</a></p>
    </footer>
</body>

</html>", "_layouts/basic", "/Applications/MAMP/htdocs/craft/smsi/templates/_layouts/basic.twig");
    }
}
