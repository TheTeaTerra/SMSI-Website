<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _includes/forms/elementSelect */
class __TwigTemplate_48264915710ba88ac69e98b40918bf5c6e49b6786f7e5c2107960ecf33bbe25d extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_includes/forms/elementSelect");
        // line 1
        if (((isset($context["name"]) || array_key_exists("name", $context)) && (isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 1, $this->source); })()))) {
            // line 2
            echo "    ";
            echo craft\helpers\Html::hiddenInput((isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 2, $this->source); })()), "");
            echo "
";
        }
        // line 5
        $context["elements"] = ((((isset($context["elements"]) || array_key_exists("elements", $context)) && (isset($context["elements"]) || array_key_exists("elements", $context) ? $context["elements"] : (function () { throw new RuntimeError('Variable "elements" does not exist.', 5, $this->source); })()))) ? ((isset($context["elements"]) || array_key_exists("elements", $context) ? $context["elements"] : (function () { throw new RuntimeError('Variable "elements" does not exist.', 5, $this->source); })())) : ([]));
        // line 6
        $context["jsClass"] = ((((isset($context["jsClass"]) || array_key_exists("jsClass", $context)) && (isset($context["jsClass"]) || array_key_exists("jsClass", $context) ? $context["jsClass"] : (function () { throw new RuntimeError('Variable "jsClass" does not exist.', 6, $this->source); })()))) ? ((isset($context["jsClass"]) || array_key_exists("jsClass", $context) ? $context["jsClass"] : (function () { throw new RuntimeError('Variable "jsClass" does not exist.', 6, $this->source); })())) : ("Craft.BaseElementSelectInput"));
        // line 7
        $context["sources"] = ((((isset($context["sources"]) || array_key_exists("sources", $context)) && (isset($context["sources"]) || array_key_exists("sources", $context) ? $context["sources"] : (function () { throw new RuntimeError('Variable "sources" does not exist.', 7, $this->source); })()))) ? ((isset($context["sources"]) || array_key_exists("sources", $context) ? $context["sources"] : (function () { throw new RuntimeError('Variable "sources" does not exist.', 7, $this->source); })())) : (null));
        // line 8
        $context["criteria"] = ((((isset($context["criteria"]) || array_key_exists("criteria", $context)) && (isset($context["criteria"]) || array_key_exists("criteria", $context) ? $context["criteria"] : (function () { throw new RuntimeError('Variable "criteria" does not exist.', 8, $this->source); })()))) ? ((isset($context["criteria"]) || array_key_exists("criteria", $context) ? $context["criteria"] : (function () { throw new RuntimeError('Variable "criteria" does not exist.', 8, $this->source); })())) : (null));
        // line 9
        $context["sourceElementId"] = ((((isset($context["sourceElementId"]) || array_key_exists("sourceElementId", $context)) && (isset($context["sourceElementId"]) || array_key_exists("sourceElementId", $context) ? $context["sourceElementId"] : (function () { throw new RuntimeError('Variable "sourceElementId" does not exist.', 9, $this->source); })()))) ? ((isset($context["sourceElementId"]) || array_key_exists("sourceElementId", $context) ? $context["sourceElementId"] : (function () { throw new RuntimeError('Variable "sourceElementId" does not exist.', 9, $this->source); })())) : (null));
        // line 10
        $context["storageKey"] = ((((isset($context["storageKey"]) || array_key_exists("storageKey", $context)) && (isset($context["storageKey"]) || array_key_exists("storageKey", $context) ? $context["storageKey"] : (function () { throw new RuntimeError('Variable "storageKey" does not exist.', 10, $this->source); })()))) ? ((isset($context["storageKey"]) || array_key_exists("storageKey", $context) ? $context["storageKey"] : (function () { throw new RuntimeError('Variable "storageKey" does not exist.', 10, $this->source); })())) : (null));
        // line 11
        $context["viewMode"] = (((isset($context["viewMode"]) || array_key_exists("viewMode", $context))) ? ((isset($context["viewMode"]) || array_key_exists("viewMode", $context) ? $context["viewMode"] : (function () { throw new RuntimeError('Variable "viewMode" does not exist.', 11, $this->source); })())) : ("list"));
        // line 12
        $context["sortable"] = (((isset($context["sortable"]) || array_key_exists("sortable", $context))) ? ((isset($context["sortable"]) || array_key_exists("sortable", $context) ? $context["sortable"] : (function () { throw new RuntimeError('Variable "sortable" does not exist.', 12, $this->source); })())) : (true));
        // line 13
        $context["prevalidate"] = (($context["prevalidate"]) ?? (false));
        // line 14
        $context["fieldId"] = (((isset($context["fieldId"]) || array_key_exists("fieldId", $context))) ? ((isset($context["fieldId"]) || array_key_exists("fieldId", $context) ? $context["fieldId"] : (function () { throw new RuntimeError('Variable "fieldId" does not exist.', 14, $this->source); })())) : (null));
        // line 15
        echo "
<div id=\"";
        // line 16
        echo twig_escape_filter($this->env, (isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 16, $this->source); })()), "html", null, true);
        echo "\" class=\"elementselect\"";
        // line 17
        if (        $this->hasBlock("attr", $context, $blocks)) {
            echo " ";
            $this->displayBlock("attr", $context, $blocks);
        }
        echo ">
    <div class=\"elements\">
        ";
        // line 19
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["elements"]) || array_key_exists("elements", $context) ? $context["elements"] : (function () { throw new RuntimeError('Variable "elements" does not exist.', 19, $this->source); })()));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["element"]) {
            // line 20
            echo "            ";
            $this->loadTemplate("_elements/element", "_includes/forms/elementSelect", 20)->display(twig_array_merge($context, ["context" => "field", "size" => (((            // line 22
(isset($context["viewMode"]) || array_key_exists("viewMode", $context) ? $context["viewMode"] : (function () { throw new RuntimeError('Variable "viewMode" does not exist.', 22, $this->source); })()) == "large")) ? ("large") : ("small"))]));
            // line 24
            echo "        ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['element'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 25
        echo "    </div>

    <div class=\"btn add icon dashed\">";
        // line 27
        echo twig_escape_filter($this->env, (((isset($context["selectionLabel"]) || array_key_exists("selectionLabel", $context))) ? ((isset($context["selectionLabel"]) || array_key_exists("selectionLabel", $context) ? $context["selectionLabel"] : (function () { throw new RuntimeError('Variable "selectionLabel" does not exist.', 27, $this->source); })())) : ($this->extensions['craft\web\twig\Extension']->translateFilter("Choose", "app"))), "html", null, true);
        echo "</div>
</div>

";
        // line 30
        $context["jsSettings"] = ["id" => call_user_func_array($this->env->getFilter('namespaceInputId')->getCallable(), [        // line 31
(isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 31, $this->source); })())]), "name" => call_user_func_array($this->env->getFilter('namespaceInputName')->getCallable(), [        // line 32
(isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 32, $this->source); })())]), "elementType" =>         // line 33
(isset($context["elementType"]) || array_key_exists("elementType", $context) ? $context["elementType"] : (function () { throw new RuntimeError('Variable "elementType" does not exist.', 33, $this->source); })()), "sources" =>         // line 34
(isset($context["sources"]) || array_key_exists("sources", $context) ? $context["sources"] : (function () { throw new RuntimeError('Variable "sources" does not exist.', 34, $this->source); })()), "criteria" =>         // line 35
(isset($context["criteria"]) || array_key_exists("criteria", $context) ? $context["criteria"] : (function () { throw new RuntimeError('Variable "criteria" does not exist.', 35, $this->source); })()), "allowSelfRelations" => ((        // line 36
$context["allowSelfRelations"]) ?? (false)), "sourceElementId" =>         // line 37
(isset($context["sourceElementId"]) || array_key_exists("sourceElementId", $context) ? $context["sourceElementId"] : (function () { throw new RuntimeError('Variable "sourceElementId" does not exist.', 37, $this->source); })()), "disabledElementIds" => ((        // line 38
$context["disabledElementIds"]) ?? (null)), "viewMode" =>         // line 39
(isset($context["viewMode"]) || array_key_exists("viewMode", $context) ? $context["viewMode"] : (function () { throw new RuntimeError('Variable "viewMode" does not exist.', 39, $this->source); })()), "limit" => ((        // line 40
$context["limit"]) ?? (null)), "showSiteMenu" => ((        // line 41
$context["showSiteMenu"]) ?? (false)), "modalStorageKey" =>         // line 42
(isset($context["storageKey"]) || array_key_exists("storageKey", $context) ? $context["storageKey"] : (function () { throw new RuntimeError('Variable "storageKey" does not exist.', 42, $this->source); })()), "fieldId" =>         // line 43
(isset($context["fieldId"]) || array_key_exists("fieldId", $context) ? $context["fieldId"] : (function () { throw new RuntimeError('Variable "fieldId" does not exist.', 43, $this->source); })()), "sortable" =>         // line 44
(isset($context["sortable"]) || array_key_exists("sortable", $context) ? $context["sortable"] : (function () { throw new RuntimeError('Variable "sortable" does not exist.', 44, $this->source); })()), "prevalidate" =>         // line 45
(isset($context["prevalidate"]) || array_key_exists("prevalidate", $context) ? $context["prevalidate"] : (function () { throw new RuntimeError('Variable "prevalidate" does not exist.', 45, $this->source); })()), "modalSettings" => ((        // line 46
$context["modalSettings"]) ?? ([]))];
        // line 48
        echo "
";
        // line 49
        ob_start();
        // line 50
        echo "    new ";
        echo twig_escape_filter($this->env, (isset($context["jsClass"]) || array_key_exists("jsClass", $context) ? $context["jsClass"] : (function () { throw new RuntimeError('Variable "jsClass" does not exist.', 50, $this->source); })()), "html", null, true);
        echo "(";
        echo $this->extensions['craft\web\twig\Extension']->jsonEncodeFilter((isset($context["jsSettings"]) || array_key_exists("jsSettings", $context) ? $context["jsSettings"] : (function () { throw new RuntimeError('Variable "jsSettings" does not exist.', 50, $this->source); })()));
        echo ");
";
        Craft::$app->getView()->registerJs(ob_get_clean(), 3);
        // line 0
        craft\helpers\Template::endProfile("template", "_includes/forms/elementSelect");
    }

    public function getTemplateName()
    {
        return "_includes/forms/elementSelect";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  156 => 0,  148 => 50,  146 => 49,  143 => 48,  141 => 46,  140 => 45,  139 => 44,  138 => 43,  137 => 42,  136 => 41,  135 => 40,  134 => 39,  133 => 38,  132 => 37,  131 => 36,  130 => 35,  129 => 34,  128 => 33,  127 => 32,  126 => 31,  125 => 30,  119 => 27,  115 => 25,  101 => 24,  99 => 22,  97 => 20,  80 => 19,  72 => 17,  69 => 16,  66 => 15,  64 => 14,  62 => 13,  60 => 12,  58 => 11,  56 => 10,  54 => 9,  52 => 8,  50 => 7,  48 => 6,  46 => 5,  40 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% if name is defined and name %}
    {{ hiddenInput(name, '') }}
{% endif -%}

{% set elements = (elements is defined and elements ? elements : []) -%}
{% set jsClass = (jsClass is defined and jsClass ? jsClass : 'Craft.BaseElementSelectInput') -%}
{% set sources = (sources is defined and sources ? sources : null) -%}
{% set criteria = (criteria is defined and criteria ? criteria : null) -%}
{% set sourceElementId = (sourceElementId is defined and sourceElementId ? sourceElementId : null) -%}
{% set storageKey = (storageKey is defined and storageKey ? storageKey : null) -%}
{% set viewMode = (viewMode is defined ? viewMode : 'list') %}
{% set sortable = (sortable is defined ? sortable : true) %}
{% set prevalidate = prevalidate ?? false %}
{% set fieldId = (fieldId is defined ? fieldId : null) %}

<div id=\"{{ id }}\" class=\"elementselect\"
        {%- if block('attr') is defined %} {{ block('attr') }}{% endif %}>
    <div class=\"elements\">
        {% for element in elements %}
            {% include \"_elements/element\" with {
                context: 'field',
                size: (viewMode == 'large' ? 'large' : 'small')
            } %}
        {% endfor %}
    </div>

    <div class=\"btn add icon dashed\">{{ selectionLabel is defined ? selectionLabel : \"Choose\"|t('app') }}</div>
</div>

{% set jsSettings = {
    id: id|namespaceInputId,
    name: name|namespaceInputName,
    elementType: elementType,
    sources: sources,
    criteria: criteria,
    allowSelfRelations: allowSelfRelations ?? false,
    sourceElementId: sourceElementId,
    disabledElementIds: disabledElementIds ?? null,
    viewMode: viewMode,
    limit: limit ?? null,
    showSiteMenu: showSiteMenu ?? false,
    modalStorageKey: storageKey,
    fieldId: fieldId,
    sortable: sortable,
    prevalidate: prevalidate,
    modalSettings: modalSettings ?? {},
} %}

{% js %}
    new {{ jsClass }}({{ jsSettings|json_encode|raw }});
{% endjs %}
", "_includes/forms/elementSelect", "/Applications/MAMP/htdocs/craft/smsi/vendor/craftcms/cms/src/templates/_includes/forms/elementSelect.html");
    }
}
