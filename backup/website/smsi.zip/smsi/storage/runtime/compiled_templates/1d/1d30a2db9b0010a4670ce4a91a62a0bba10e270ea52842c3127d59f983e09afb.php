<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* settings/users/_layout */
class __TwigTemplate_9fbe5897c9e689b5d0c27bfc19d78a61904a9d0143fc2ff1122426809b6cb689 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'sidebar' => [$this, 'block_sidebar'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 3
        return "_layouts/cp";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("template", "settings/users/_layout");
        // line 1
        Craft::$app->controller->requireAdmin();
        // line 4
        $context["title"] = $this->extensions['craft\web\twig\Extension']->translateFilter("User Settings", "app");
        // line 6
        $context["crumbs"] = [0 => ["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Settings", "app"), "url" => craft\helpers\UrlHelper::url("settings")]];
        // line 10
        $context["navItems"] = $this->extensions['craft\web\twig\Extension']->filterFilter(["groups" => (((        // line 11
(isset($context["CraftEdition"]) || array_key_exists("CraftEdition", $context) ? $context["CraftEdition"] : (function () { throw new RuntimeError('Variable "CraftEdition" does not exist.', 11, $this->source); })()) == (isset($context["CraftPro"]) || array_key_exists("CraftPro", $context) ? $context["CraftPro"] : (function () { throw new RuntimeError('Variable "CraftPro" does not exist.', 11, $this->source); })()))) ? (["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("User Groups", "app"), "url" => craft\helpers\UrlHelper::url("settings/users")]) : ("")), "fields" => ["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Fields", "app"), "url" => craft\helpers\UrlHelper::url("settings/users/fields")], "settings" => ["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Settings", "app"), "url" => craft\helpers\UrlHelper::url("settings/users/settings")]]);
        // line 16
        $context["docTitle"] = ((craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["navItems"]) || array_key_exists("navItems", $context) ? $context["navItems"] : (function () { throw new RuntimeError('Variable "navItems" does not exist.', 16, $this->source); })()), (isset($context["selectedNavItem"]) || array_key_exists("selectedNavItem", $context) ? $context["selectedNavItem"] : (function () { throw new RuntimeError('Variable "selectedNavItem" does not exist.', 16, $this->source); })()), [], "array"), "label", []) . " - ") . (isset($context["title"]) || array_key_exists("title", $context) ? $context["title"] : (function () { throw new RuntimeError('Variable "title" does not exist.', 16, $this->source); })()));
        // line 3
        $this->parent = $this->loadTemplate("_layouts/cp", "settings/users/_layout", 3);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        // line 0
        craft\helpers\Template::endProfile("template", "settings/users/_layout");
    }

    // line 18
    public function block_sidebar($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("block", "sidebar");
        // line 19
        echo "    <nav>
        ";
        // line 20
        $this->loadTemplate("_includes/nav", "settings/users/_layout", 20)->display(twig_to_array(["items" => (isset($context["navItems"]) || array_key_exists("navItems", $context) ? $context["navItems"] : (function () { throw new RuntimeError('Variable "navItems" does not exist.', 20, $this->source); })()), "selectedItem" => (isset($context["selectedNavItem"]) || array_key_exists("selectedNavItem", $context) ? $context["selectedNavItem"] : (function () { throw new RuntimeError('Variable "selectedNavItem" does not exist.', 20, $this->source); })())]));
        // line 21
        echo "    </nav>
";
        // line 0
        craft\helpers\Template::endProfile("block", "sidebar");
    }

    public function getTemplateName()
    {
        return "settings/users/_layout";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  76 => 0,  73 => 21,  71 => 20,  68 => 19,  66 => 0,  62 => 18,  58 => 0,  55 => 3,  53 => 16,  51 => 11,  50 => 10,  48 => 6,  46 => 4,  44 => 1,  42 => 0,  35 => 3,);
    }

    public function getSourceContext()
    {
        return new Source("{% requireAdmin %}

{% extends \"_layouts/cp\" %}
{% set title = \"User Settings\"|t('app') %}

{% set crumbs = [
    { label: \"Settings\"|t('app'), url: url('settings') }
] %}

{% set navItems = {
    groups: CraftEdition == CraftPro ? { label: \"User Groups\"|t('app'), url: url('settings/users') },
    fields: { label: \"Fields\"|t('app'), url: url('settings/users/fields') },
    settings: { label: \"Settings\"|t('app'), url: url('settings/users/settings') }
}|filter %}

{% set docTitle = navItems[selectedNavItem].label~' - '~title %}

{% block sidebar %}
    <nav>
        {% include \"_includes/nav\" with { items: navItems, selectedItem: selectedNavItem } only %}
    </nav>
{% endblock %}
", "settings/users/_layout", "/Applications/MAMP/htdocs/craft/smsi/vendor/craftcms/cms/src/templates/settings/users/_layout.html");
    }
}
