<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* redactor/_field_settings */
class __TwigTemplate_722db001cb2a0b47f1618bb3bb8788c3c278a935e783c3fbcf2dddbd5c05f249 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "redactor/_field_settings");
        // line 1
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms", "redactor/_field_settings", 1)->unwrap();
        // line 2
        echo "
";
        // line 3
        echo twig_call_macro($macros["forms"], "macro_selectField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Redactor Config", "redactor"), "instructions" => ((($this->extensions['craft\web\twig\Extension']->translateFilter("You can save custom {name} configs as {ext} files in {path}.", "redactor", ["name" => "Redactor", "ext" => "`.json`", "path" => "`config/redactor/`"]) . " <a href=\"http://imperavi.com/redactor/docs/settings/\" rel=\"noopener\" target=\"_blank\">") . $this->extensions['craft\web\twig\Extension']->translateFilter("View available settings", "redactor")) . "</a>"), "id" => "redactorConfig", "name" => "redactorConfig", "options" =>         // line 13
(isset($context["redactorConfigOptions"]) || array_key_exists("redactorConfigOptions", $context) ? $context["redactorConfigOptions"] : (function () { throw new RuntimeError('Variable "redactorConfigOptions" does not exist.', 13, $this->source); })()), "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 14
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 14, $this->source); })()), "redactorConfig", [])]], 3, $context, $this->getSourceContext());
        // line 15
        echo "

";
        // line 17
        echo twig_call_macro($macros["forms"], "macro_checkboxSelectField", [["id" => "availableVolumes", "name" => "availableVolumes", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Available Volumes", "redactor"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("The volumes that should be available when selecting assets (if the selected config has an Image or File button).", "redactor"), "options" =>         // line 22
(isset($context["volumeOptions"]) || array_key_exists("volumeOptions", $context) ? $context["volumeOptions"] : (function () { throw new RuntimeError('Variable "volumeOptions" does not exist.', 22, $this->source); })()), "values" => craft\helpers\Template::attribute($this->env, $this->source,         // line 23
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 23, $this->source); })()), "availableVolumes", []), "showAllOption" => ((twig_length_filter($this->env,         // line 24
(isset($context["volumeOptions"]) || array_key_exists("volumeOptions", $context) ? $context["volumeOptions"] : (function () { throw new RuntimeError('Variable "volumeOptions" does not exist.', 24, $this->source); })()))) ? (true) : (false))]], 17, $context, $this->getSourceContext());
        // line 25
        echo "

";
        // line 27
        echo twig_call_macro($macros["forms"], "macro_checkboxField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Show unpermitted volumes", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Whether to show volumes that the user doesn’t have permission to view.", "app"), "id" => "showUnpermittedVolumes", "name" => "showUnpermittedVolumes", "checked" => craft\helpers\Template::attribute($this->env, $this->source,         // line 32
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 32, $this->source); })()), "showUnpermittedVolumes", [])]], 27, $context, $this->getSourceContext());
        // line 33
        echo "

";
        // line 35
        echo twig_call_macro($macros["forms"], "macro_checkboxField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Show unpermitted files", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Whether to show files that the user doesn’t have permission to view, per the “View files uploaded by other users” permission.", "app"), "id" => "showUnpermittedFiles", "name" => "showUnpermittedFiles", "checked" => craft\helpers\Template::attribute($this->env, $this->source,         // line 40
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 40, $this->source); })()), "showUnpermittedFiles", [])]], 35, $context, $this->getSourceContext());
        // line 41
        echo "

";
        // line 43
        echo twig_call_macro($macros["forms"], "macro_checkboxSelectField", [["id" => "availableTransforms", "name" => "availableTransforms", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Available Transforms", "redactor"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("The Transforms that should be available for Image selection.", "redactor"), "options" =>         // line 48
(isset($context["transformOptions"]) || array_key_exists("transformOptions", $context) ? $context["transformOptions"] : (function () { throw new RuntimeError('Variable "transformOptions" does not exist.', 48, $this->source); })()), "values" => craft\helpers\Template::attribute($this->env, $this->source,         // line 49
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 49, $this->source); })()), "availableTransforms", []), "showAllOption" => ((twig_length_filter($this->env,         // line 50
(isset($context["transformOptions"]) || array_key_exists("transformOptions", $context) ? $context["transformOptions"] : (function () { throw new RuntimeError('Variable "transformOptions" does not exist.', 50, $this->source); })()))) ? (true) : (false))]], 43, $context, $this->getSourceContext());
        // line 51
        echo "


<hr>
<a class=\"fieldtoggle\" data-target=\"advanced\">";
        // line 55
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Advanced", "redactor"), "html", null, true);
        echo "</a>
<div id=\"advanced\" class=\"hidden\">
    <div class=\"field\">
        <div class=\"heading\">
            <label>";
        // line 59
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Clean up HTML", "redactor"), "html", null, true);
        echo "</label>
            <div class=\"instructions\">
                ";
        // line 61
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("The cleanup actions that should be executed on save.", "redactor"), "html", null, true);
        echo "
            </div>
        </div>

        <div>
            ";
        // line 66
        echo twig_call_macro($macros["forms"], "macro_checkbox", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Remove inline styles", "redactor"), "id" => "removeInlineStyles", "name" => "removeInlineStyles", "checked" => craft\helpers\Template::attribute($this->env, $this->source,         // line 70
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 70, $this->source); })()), "removeInlineStyles", [])]], 66, $context, $this->getSourceContext());
        // line 71
        echo "
        </div>

        <div>
            ";
        // line 75
        echo twig_call_macro($macros["forms"], "macro_checkbox", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Remove empty tags", "redactor"), "id" => "removeEmptyTags", "name" => "removeEmptyTags", "checked" => craft\helpers\Template::attribute($this->env, $this->source,         // line 79
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 79, $this->source); })()), "removeEmptyTags", [])]], 75, $context, $this->getSourceContext());
        // line 80
        echo "
        </div>

        <div>
            ";
        // line 84
        echo twig_call_macro($macros["forms"], "macro_checkbox", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Replace non-breaking spaces with regular spaces", "redactor"), "id" => "removeNbsp", "name" => "removeNbsp", "checked" => craft\helpers\Template::attribute($this->env, $this->source,         // line 88
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 88, $this->source); })()), "removeNbsp", [])]], 84, $context, $this->getSourceContext());
        // line 89
        echo "
        </div>
    </div>

    ";
        // line 93
        echo twig_call_macro($macros["forms"], "macro_checkboxField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Purify HTML", "redactor"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Removes any potentially-malicious code on save, by running the submitted data through <a href=\"http://htmlpurifier.org/\" rel=\"noopener\" target=\"_blank\">HTML Purifier</a>.", "redactor"), "warning" => $this->extensions['craft\web\twig\Extension']->translateFilter("Disable this at your own risk!", "redactor"), "id" => "purifyHtml", "name" => "purifyHtml", "checked" => craft\helpers\Template::attribute($this->env, $this->source,         // line 99
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 99, $this->source); })()), "purifyHtml", []), "toggle" => "purifier-config-container"]], 93, $context, $this->getSourceContext());
        // line 101
        echo "

    <div id=\"purifier-config-container\"";
        // line 103
        if ( !craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 103, $this->source); })()), "purifyHtml", [])) {
            echo " class=\"hidden\"";
        }
        echo ">
        ";
        // line 104
        echo twig_call_macro($macros["forms"], "macro_selectField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("HTML Purifier Config", "redactor"), "instructions" => ((($this->extensions['craft\web\twig\Extension']->translateFilter("You can save custom {name} configs as {ext} files in {path}.", "redactor", ["name" => "HTML Purifier Config", "ext" => "`.json`", "path" => "`config/htmlpurifier/`"]) . " <a href=\"http://htmlpurifier.org/live/configdoc/plain.html\" rel=\"noopener\" target=\"_blank\">") . $this->extensions['craft\web\twig\Extension']->translateFilter("View available settings", "redactor")) . "</a>"), "id" => "purifierConfig", "name" => "purifierConfig", "options" =>         // line 114
(isset($context["purifierConfigOptions"]) || array_key_exists("purifierConfigOptions", $context) ? $context["purifierConfigOptions"] : (function () { throw new RuntimeError('Variable "purifierConfigOptions" does not exist.', 114, $this->source); })()), "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 115
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 115, $this->source); })()), "purifierConfig", [])]], 104, $context, $this->getSourceContext());
        // line 116
        echo "
    </div>

    ";
        // line 119
        if (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 119, $this->source); })()), "app", []), "db", []), "isMysql", [])) {
            // line 120
            echo "        ";
            echo twig_call_macro($macros["forms"], "macro_selectField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Column Type", "redactor"), "id" => "column-type", "name" => "columnType", "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("The type of column this field should get in the database.", "redactor"), "options" => [0 => ["value" => "text", "label" => "text (~64KB)"], 1 => ["value" => "mediumtext", "label" => "mediumtext (~16MB)"]], "value" => craft\helpers\Template::attribute($this->env, $this->source,             // line 129
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 129, $this->source); })()), "columnType", []), "warning" => ((craft\helpers\Template::attribute($this->env, $this->source,             // line 130
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 130, $this->source); })()), "id", [])) ? ($this->extensions['craft\web\twig\Extension']->translateFilter("Changing this may result in data loss.", "redactor")) : (""))]], 120, $context, $this->getSourceContext());
            // line 131
            echo "
    ";
        }
        // line 133
        echo "</div>
";
        // line 0
        craft\helpers\Template::endProfile("template", "redactor/_field_settings");
    }

    public function getTemplateName()
    {
        return "redactor/_field_settings";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  168 => 0,  165 => 133,  161 => 131,  159 => 130,  158 => 129,  156 => 120,  154 => 119,  149 => 116,  147 => 115,  146 => 114,  145 => 104,  139 => 103,  135 => 101,  133 => 99,  132 => 93,  126 => 89,  124 => 88,  123 => 84,  117 => 80,  115 => 79,  114 => 75,  108 => 71,  106 => 70,  105 => 66,  97 => 61,  92 => 59,  85 => 55,  79 => 51,  77 => 50,  76 => 49,  75 => 48,  74 => 43,  70 => 41,  68 => 40,  67 => 35,  63 => 33,  61 => 32,  60 => 27,  56 => 25,  54 => 24,  53 => 23,  52 => 22,  51 => 17,  47 => 15,  45 => 14,  44 => 13,  43 => 3,  40 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% import '_includes/forms' as forms %}

{{ forms.selectField({
    label: \"Redactor Config\"|t('redactor'),
    instructions: \"You can save custom {name} configs as {ext} files in {path}.\"|t('redactor', {
            name: 'Redactor',
            ext: '`.json`',
            path: '`config/redactor/`'
        }) ~
        ' <a href=\"http://imperavi.com/redactor/docs/settings/\" rel=\"noopener\" target=\"_blank\">'~\"View available settings\"|t('redactor')~'</a>',
    id: 'redactorConfig',
    name: 'redactorConfig',
    options: redactorConfigOptions,
    value: field.redactorConfig
}) }}

{{ forms.checkboxSelectField({
    id: 'availableVolumes',
    name: 'availableVolumes',
    label: 'Available Volumes'|t('redactor'),
    instructions: 'The volumes that should be available when selecting assets (if the selected config has an Image or File button).'|t('redactor'),
    options: volumeOptions,
    values: field.availableVolumes,
    showAllOption: volumeOptions|length ? true : false
}) }}

{{ forms.checkboxField({
    label: 'Show unpermitted volumes'|t('app'),
    instructions: 'Whether to show volumes that the user doesn’t have permission to view.'|t('app'),
    id: 'showUnpermittedVolumes',
    name: 'showUnpermittedVolumes',
    checked: field.showUnpermittedVolumes,
}) }}

{{ forms.checkboxField({
    label: 'Show unpermitted files'|t('app'),
    instructions: 'Whether to show files that the user doesn’t have permission to view, per the “View files uploaded by other users” permission.'|t('app'),
    id: 'showUnpermittedFiles',
    name: 'showUnpermittedFiles',
    checked: field.showUnpermittedFiles,
}) }}

{{ forms.checkboxSelectField({
    id: 'availableTransforms',
    name: 'availableTransforms',
    label: 'Available Transforms'|t('redactor'),
    instructions: 'The Transforms that should be available for Image selection.'|t('redactor'),
    options: transformOptions,
    values: field.availableTransforms,
    showAllOption: transformOptions|length ? true : false
}) }}


<hr>
<a class=\"fieldtoggle\" data-target=\"advanced\">{{ \"Advanced\"|t('redactor') }}</a>
<div id=\"advanced\" class=\"hidden\">
    <div class=\"field\">
        <div class=\"heading\">
            <label>{{ \"Clean up HTML\"|t('redactor') }}</label>
            <div class=\"instructions\">
                {{ \"The cleanup actions that should be executed on save.\"|t('redactor') }}
            </div>
        </div>

        <div>
            {{ forms.checkbox({
                label: \"Remove inline styles\"|t('redactor'),
                id: 'removeInlineStyles',
                name: 'removeInlineStyles',
                checked: field.removeInlineStyles
            }) }}
        </div>

        <div>
            {{ forms.checkbox({
                label: \"Remove empty tags\"|t('redactor'),
                id: 'removeEmptyTags',
                name: 'removeEmptyTags',
                checked: field.removeEmptyTags
            }) }}
        </div>

        <div>
            {{ forms.checkbox({
                label: \"Replace non-breaking spaces with regular spaces\"|t('redactor'),
                id: 'removeNbsp',
                name: 'removeNbsp',
                checked: field.removeNbsp
            }) }}
        </div>
    </div>

    {{ forms.checkboxField({
        label: \"Purify HTML\"|t('redactor'),
        instructions: 'Removes any potentially-malicious code on save, by running the submitted data through <a href=\"http://htmlpurifier.org/\" rel=\"noopener\" target=\"_blank\">HTML Purifier</a>.'|t('redactor'),
        warning: 'Disable this at your own risk!'|t('redactor'),
        id: 'purifyHtml',
        name: 'purifyHtml',
        checked: field.purifyHtml,
        toggle: 'purifier-config-container'
    }) }}

    <div id=\"purifier-config-container\"{% if not field.purifyHtml %} class=\"hidden\"{% endif %}>
        {{ forms.selectField({
            label: \"HTML Purifier Config\"|t('redactor'),
            instructions: \"You can save custom {name} configs as {ext} files in {path}.\"|t('redactor', {
                name: 'HTML Purifier Config',
                ext: '`.json`',
                path: '`config/htmlpurifier/`'
            }) ~
            ' <a href=\"http://htmlpurifier.org/live/configdoc/plain.html\" rel=\"noopener\" target=\"_blank\">'~\"View available settings\"|t('redactor')~'</a>',
            id: 'purifierConfig',
            name: 'purifierConfig',
            options: purifierConfigOptions,
            value: field.purifierConfig
        }) }}
    </div>

    {% if craft.app.db.isMysql %}
        {{ forms.selectField({
            label: \"Column Type\"|t('redactor'),
            id: 'column-type',
            name: 'columnType',
            instructions: \"The type of column this field should get in the database.\"|t('redactor'),
            options: [
                { value: 'text', label: 'text (~64KB)' },
                { value: 'mediumtext', label: 'mediumtext (~16MB)' },
            ],
            value: field.columnType,
            warning: (field.id ? \"Changing this may result in data loss.\"|t('redactor')),
        }) }}
    {% endif %}
</div>
", "redactor/_field_settings", "/Applications/MAMP/htdocs/craft/smsi/vendor/craftcms/redactor/src/templates/_field_settings.html");
    }
}
