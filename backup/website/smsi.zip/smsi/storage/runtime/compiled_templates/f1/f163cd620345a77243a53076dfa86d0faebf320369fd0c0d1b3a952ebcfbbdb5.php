<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _includes/field */
class __TwigTemplate_2df52cbc41de0da0cbf8dafc29ff11b5fc6e7874dc9fbf6b64e271429ed33357 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_includes/field");
        // line 1
        $macros["__internal_a4ebf28b9e6116263bd7e6f1416eba99f6a4a7579e539c46be8d4da7289854bf"] = $this->macros["__internal_a4ebf28b9e6116263bd7e6f1416eba99f6a4a7579e539c46be8d4da7289854bf"] = $this->loadTemplate("_includes/forms", "_includes/field", 1)->unwrap();
        // line 2
        echo "
";
        // line 3
        $context["static"] = (($context["static"]) ?? (false));
        // line 4
        $context["element"] = (($context["element"]) ?? (null));
        // line 5
        echo "
";
        // line 6
        $context["value"] = (((isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 6, $this->source); })())) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 6, $this->source); })()), "getFieldValue", [0 => craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 6, $this->source); })()), "handle", [])], "method")) : (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 6, $this->source); })()), "normalizeValue", [0 => null], "method")));
        // line 7
        $context["errors"] = ((((isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 7, $this->source); })()) &&  !(isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new RuntimeError('Variable "static" does not exist.', 7, $this->source); })()))) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 7, $this->source); })()), "getErrors", [0 => craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 7, $this->source); })()), "handle", [])], "method")) : (null));
        // line 8
        $context["instructions"] = ((craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 8, $this->source); })()), "instructions", [])) ? ($this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 8, $this->source); })()), "instructions", []), "site")) : (""));
        // line 9
        $context["translatable"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 9, $this->source); })()), "getIsTranslatable", [0 => (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 9, $this->source); })())], "method");
        // line 10
        $context["siteId"] = ((((isset($context["translatable"]) || array_key_exists("translatable", $context) ? $context["translatable"] : (function () { throw new RuntimeError('Variable "translatable" does not exist.', 10, $this->source); })()) && (((craft\helpers\Template::attribute($this->env, $this->source, ($context["element"] ?? null), "isLocalized", [], "method", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["element"] ?? null), "isLocalized", [], "method")))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["element"] ?? null), "isLocalized", [], "method")) : (true)))) ? ((($context["siteId"]) ?? ((((craft\helpers\Template::attribute($this->env, $this->source, ($context["element"] ?? null), "siteId", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["element"] ?? null), "siteId", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["element"] ?? null), "siteId", [])) : (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 10, $this->source); })()), "app", []), "sites", []), "currentSite", []), "id", [])))))) : (""));
        // line 11
        echo "
";
        // line 12
        if ( !(isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new RuntimeError('Variable "static" does not exist.', 12, $this->source); })())) {
            // line 13
            echo "    ";
            $context["isDeltaRegistrationActive"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 13, $this->source); })()), "getIsDeltaRegistrationActive", [], "method");
            // line 14
            echo "    ";
            $context["registerDeltas"] = ((isset($context["isDeltaRegistrationActive"]) || array_key_exists("isDeltaRegistrationActive", $context) ? $context["isDeltaRegistrationActive"] : (function () { throw new RuntimeError('Variable "isDeltaRegistrationActive" does not exist.', 14, $this->source); })()) && (($context["registerDeltas"]) ?? (false)));
            // line 15
            echo "    ";
            craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 15, $this->source); })()), "setIsDeltaRegistrationActive", [0 => (isset($context["registerDeltas"]) || array_key_exists("registerDeltas", $context) ? $context["registerDeltas"] : (function () { throw new RuntimeError('Variable "registerDeltas" does not exist.', 15, $this->source); })())], "method");
            // line 16
            echo "    ";
            craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 16, $this->source); })()), "registerDeltaName", [0 => craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 16, $this->source); })()), "handle", [])], "method");
            // line 17
            echo "    ";
            if ((( !(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 17, $this->source); })()) ||  !craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 17, $this->source); })()), "id", [])) || craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 17, $this->source); })()), "isFieldEmpty", [0 => craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 17, $this->source); })()), "handle", [])], "method"))) {
                // line 18
                echo "        ";
                craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 18, $this->source); })()), "setInitialDeltaValue", [0 => craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 18, $this->source); })()), "handle", []), 1 => null], "method");
                // line 19
                echo "    ";
            }
            // line 20
            echo "    ";
            $context["input"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 20, $this->source); })()), "getInputHtml", [0 => (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 20, $this->source); })()), 1 => (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 20, $this->source); })())], "method");
            // line 21
            echo "    ";
            craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 21, $this->source); })()), "setIsDeltaRegistrationActive", [0 => (isset($context["isDeltaRegistrationActive"]) || array_key_exists("isDeltaRegistrationActive", $context) ? $context["isDeltaRegistrationActive"] : (function () { throw new RuntimeError('Variable "isDeltaRegistrationActive" does not exist.', 21, $this->source); })())], "method");
        } else {
            // line 23
            echo "    ";
            $context["input"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 23, $this->source); })()), "getStaticHtml", [0 => (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 23, $this->source); })()), 1 => (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 23, $this->source); })())], "method");
        }
        // line 25
        echo "
";
        // line 26
        if (((isset($context["instructions"]) || array_key_exists("instructions", $context) ? $context["instructions"] : (function () { throw new RuntimeError('Variable "instructions" does not exist.', 26, $this->source); })()) || (isset($context["input"]) || array_key_exists("input", $context) ? $context["input"] : (function () { throw new RuntimeError('Variable "input" does not exist.', 26, $this->source); })()))) {
            // line 27
            echo "    ";
            echo twig_call_macro($macros["__internal_a4ebf28b9e6116263bd7e6f1416eba99f6a4a7579e539c46be8d4da7289854bf"], "macro_field", [["status" => ((            // line 28
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 28, $this->source); })())) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 28, $this->source); })()), "getFieldStatus", [0 => craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 28, $this->source); })()), "handle", [])], "method")) : ("")), "label" => twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source,             // line 29
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 29, $this->source); })()), "name", []), "site")), "translatable" =>             // line 30
(isset($context["translatable"]) || array_key_exists("translatable", $context) ? $context["translatable"] : (function () { throw new RuntimeError('Variable "translatable" does not exist.', 30, $this->source); })()), "translationDescription" => craft\helpers\Template::attribute($this->env, $this->source,             // line 31
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 31, $this->source); })()), "getTranslationDescription", [0 => (isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new RuntimeError('Variable "element" does not exist.', 31, $this->source); })())], "method"), "siteId" =>             // line 32
(isset($context["siteId"]) || array_key_exists("siteId", $context) ? $context["siteId"] : (function () { throw new RuntimeError('Variable "siteId" does not exist.', 32, $this->source); })()), "required" => (( !            // line 33
(isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new RuntimeError('Variable "static" does not exist.', 33, $this->source); })())) ? ((isset($context["required"]) || array_key_exists("required", $context) ? $context["required"] : (function () { throw new RuntimeError('Variable "required" does not exist.', 33, $this->source); })())) : (false)), "instructions" => twig_escape_filter($this->env,             // line 34
(isset($context["instructions"]) || array_key_exists("instructions", $context) ? $context["instructions"] : (function () { throw new RuntimeError('Variable "instructions" does not exist.', 34, $this->source); })())), "id" => craft\helpers\Template::attribute($this->env, $this->source,             // line 35
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 35, $this->source); })()), "handle", []), "errors" =>             // line 36
(isset($context["errors"]) || array_key_exists("errors", $context) ? $context["errors"] : (function () { throw new RuntimeError('Variable "errors" does not exist.', 36, $this->source); })()), "fieldAttributes" => ["data" => ["type" => get_class(            // line 39
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 39, $this->source); })()))]]],             // line 42
(isset($context["input"]) || array_key_exists("input", $context) ? $context["input"] : (function () { throw new RuntimeError('Variable "input" does not exist.', 42, $this->source); })())], 27, $context, $this->getSourceContext());
            echo "
";
        }
        // line 0
        craft\helpers\Template::endProfile("template", "_includes/field");
    }

    public function getTemplateName()
    {
        return "_includes/field";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  119 => 0,  114 => 42,  113 => 39,  112 => 36,  111 => 35,  110 => 34,  109 => 33,  108 => 32,  107 => 31,  106 => 30,  105 => 29,  104 => 28,  102 => 27,  100 => 26,  97 => 25,  93 => 23,  89 => 21,  86 => 20,  83 => 19,  80 => 18,  77 => 17,  74 => 16,  71 => 15,  68 => 14,  65 => 13,  63 => 12,  60 => 11,  58 => 10,  56 => 9,  54 => 8,  52 => 7,  50 => 6,  47 => 5,  45 => 4,  43 => 3,  40 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% from '_includes/forms' import field %}

{% set static = static ?? false %}
{% set element = element ?? null %}

{% set value = (element ? element.getFieldValue(field.handle) : field.normalizeValue(null)) %}
{% set errors = (element and not static ? element.getErrors(field.handle) : null) %}
{% set instructions = field.instructions ? field.instructions|t('site') %}
{% set translatable = field.getIsTranslatable(element) %}
{% set siteId = (translatable and (element.isLocalized() ?? true)) ? (siteId ?? element.siteId ?? craft.app.sites.currentSite.id) %}

{% if not static %}
    {% set isDeltaRegistrationActive = view.getIsDeltaRegistrationActive() %}
    {% set registerDeltas = isDeltaRegistrationActive and (registerDeltas ?? false) %}
    {% do view.setIsDeltaRegistrationActive(registerDeltas) %}
    {% do view.registerDeltaName(field.handle) %}
    {% if not element or not element.id or element.isFieldEmpty(field.handle) %}
        {% do view.setInitialDeltaValue(field.handle, null) %}
    {% endif %}
    {% set input = field.getInputHtml(value, element) %}
    {% do view.setIsDeltaRegistrationActive(isDeltaRegistrationActive) %}
{% else %}
    {% set input = field.getStaticHtml(value, element) %}
{% endif %}

{% if instructions or input %}
    {{ field({
        status: element ? element.getFieldStatus(field.handle),
        label: field.name|t('site')|e,
        translatable: translatable,
        translationDescription: field.getTranslationDescription(element),
        siteId: siteId,
        required: (not static ? required : false),
        instructions: instructions|e,
        id: field.handle,
        errors: errors,
        fieldAttributes: {
            data: {
                type: className(field),
            },
        },
    }, input) }}
{% endif %}
", "_includes/field", "/Applications/MAMP/htdocs/craft/smsi/vendor/craftcms/cms/src/templates/_includes/field.html");
    }
}
