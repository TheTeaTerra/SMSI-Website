<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* blog */
class __TwigTemplate_e6a8076c55f1bdb1698bc3ea4c1b40b92baabf342ee2f607ba89ced185f6ec91 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "_layouts/basic";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("template", "blog");
        // line 3
        $context["posts"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 3, $this->source); })()), "entries", []), "section", [0 => "blog"], "method"), "all", [], "method");
        // line 1
        $this->parent = $this->loadTemplate("_layouts/basic", "blog", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        // line 0
        craft\helpers\Template::endProfile("template", "blog");
    }

    // line 5
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("block", "content");
        // line 6
        echo "    <h1 class=\"text-4xl text-block font-display my-4\">Blog Posts</h1>
    ";
        // line 7
        $this->loadTemplate("_includes/listing", "blog", 7)->display(twig_to_array(["posts" => (isset($context["posts"]) || array_key_exists("posts", $context) ? $context["posts"] : (function () { throw new RuntimeError('Variable "posts" does not exist.', 7, $this->source); })())]));
        echo " 
";
        // line 0
        craft\helpers\Template::endProfile("block", "content");
    }

    public function getTemplateName()
    {
        return "blog";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  66 => 0,  62 => 7,  59 => 6,  57 => 0,  53 => 5,  49 => 0,  46 => 1,  44 => 3,  42 => 0,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends \"_layouts/basic\" %}

{% set posts = craft.entries.section('blog').all() %}

{% block content %}
    <h1 class=\"text-4xl text-block font-display my-4\">Blog Posts</h1>
    {% include \"_includes/listing\" with { posts: posts } only %} 
{% endblock %}", "blog", "/Applications/MAMP/htdocs/craft/smsi/templates/blog/index.twig");
    }
}
