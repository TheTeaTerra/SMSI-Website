<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _elements/toolbar */
class __TwigTemplate_46f02d393bf2d1da8c53eeb915e8356b200f0431e6b7ebff5c854cd597d7c9ce extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_elements/toolbar");
        // line 1
        $macros["__internal_db0b0865922563def5e8ae6a0cc73ac1fe23dfec09f49f727959fb0d450330c9"] = $this->macros["__internal_db0b0865922563def5e8ae6a0cc73ac1fe23dfec09f49f727959fb0d450330c9"] = $this->loadTemplate("_includes/forms", "_elements/toolbar", 1)->unwrap();
        // line 6
        $macros["__internal_e70146702d4651d90bb0ab9d806dcf9c4d293228987e3b6018b0f9843549456f"] = $this->macros["__internal_e70146702d4651d90bb0ab9d806dcf9c4d293228987e3b6018b0f9843549456f"] = $this;
        // line 7
        craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 7, $this->source); })()), "registerTranslations", [0 => "app", 1 => [0 => "Sort by {attribute}", 1 => "Score", 2 => "Structure", 3 => "Display in a table", 4 => "Display hierarchically", 5 => "Display as thumbnails"]], "method");
        // line 15
        echo "
";
        // line 16
        $context["elementInstance"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 16, $this->source); })()), "app", []), "elements", []), "createElement", [0 => (isset($context["elementType"]) || array_key_exists("elementType", $context) ? $context["elementType"] : (function () { throw new RuntimeError('Variable "elementType" does not exist.', 16, $this->source); })())], "method");
        // line 17
        $context["context"] = (((isset($context["context"]) || array_key_exists("context", $context))) ? ((isset($context["context"]) || array_key_exists("context", $context) ? $context["context"] : (function () { throw new RuntimeError('Variable "context" does not exist.', 17, $this->source); })())) : ("index"));
        // line 18
        $context["showStatusMenu"] = ((((isset($context["showStatusMenu"]) || array_key_exists("showStatusMenu", $context)) && ((isset($context["showStatusMenu"]) || array_key_exists("showStatusMenu", $context) ? $context["showStatusMenu"] : (function () { throw new RuntimeError('Variable "showStatusMenu" does not exist.', 18, $this->source); })()) != "auto"))) ? ((isset($context["showStatusMenu"]) || array_key_exists("showStatusMenu", $context) ? $context["showStatusMenu"] : (function () { throw new RuntimeError('Variable "showStatusMenu" does not exist.', 18, $this->source); })())) : (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["elementInstance"]) || array_key_exists("elementInstance", $context) ? $context["elementInstance"] : (function () { throw new RuntimeError('Variable "elementInstance" does not exist.', 18, $this->source); })()), "hasStatuses", [], "method")));
        // line 19
        $context["showSiteMenu"] = ((craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 19, $this->source); })()), "app", []), "getIsMultiSite", [], "method")) ? ((($context["showSiteMenu"]) ?? ("auto"))) : (false));
        // line 20
        if (((isset($context["showSiteMenu"]) || array_key_exists("showSiteMenu", $context) ? $context["showSiteMenu"] : (function () { throw new RuntimeError('Variable "showSiteMenu" does not exist.', 20, $this->source); })()) == "auto")) {
            // line 21
            echo "    ";
            $context["showSiteMenu"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["elementInstance"]) || array_key_exists("elementInstance", $context) ? $context["elementInstance"] : (function () { throw new RuntimeError('Variable "elementInstance" does not exist.', 21, $this->source); })()), "isLocalized", [], "method");
        }
        // line 23
        $context["sortOptions"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["elementInstance"]) || array_key_exists("elementInstance", $context) ? $context["elementInstance"] : (function () { throw new RuntimeError('Variable "elementInstance" does not exist.', 23, $this->source); })()), "sortOptions", [], "method");
        // line 24
        echo "
";
        // line 25
        if (((isset($context["showStatusMenu"]) || array_key_exists("showStatusMenu", $context) ? $context["showStatusMenu"] : (function () { throw new RuntimeError('Variable "showStatusMenu" does not exist.', 25, $this->source); })()) || ((isset($context["context"]) || array_key_exists("context", $context) ? $context["context"] : (function () { throw new RuntimeError('Variable "context" does not exist.', 25, $this->source); })()) == "index"))) {
            // line 26
            echo "    <div>
        <div class=\"btn menubtn statusmenubtn\"><span class=\"status\"></span>";
            // line 27
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("All", "app"), "html", null, true);
            echo "</div>
        <div class=\"menu\">
            <ul class=\"padded\">
                <li><a data-status=\"\" class=\"sel\"><span class=\"status\"></span>";
            // line 30
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("All", "app"), "html", null, true);
            echo "</a></li>
                ";
            // line 31
            if ((isset($context["showStatusMenu"]) || array_key_exists("showStatusMenu", $context) ? $context["showStatusMenu"] : (function () { throw new RuntimeError('Variable "showStatusMenu" does not exist.', 31, $this->source); })())) {
                // line 32
                echo "                    ";
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["elementInstance"]) || array_key_exists("elementInstance", $context) ? $context["elementInstance"] : (function () { throw new RuntimeError('Variable "elementInstance" does not exist.', 32, $this->source); })()), "statuses", [], "method"));
                foreach ($context['_seq'] as $context["status"] => $context["info"]) {
                    // line 33
                    echo "                        ";
                    $context["label"] = (((craft\helpers\Template::attribute($this->env, $this->source, $context["info"], "label", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["info"], "label", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["info"], "label", [])) : ($context["info"]));
                    // line 34
                    echo "                        ";
                    $context["color"] = (((craft\helpers\Template::attribute($this->env, $this->source, $context["info"], "color", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["info"], "color", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["info"], "color", [])) : (""));
                    // line 35
                    echo "                        <li><a data-status=\"";
                    echo twig_escape_filter($this->env, $context["status"], "html", null, true);
                    echo "\"><span class=\"status ";
                    echo twig_escape_filter($this->env, $context["status"], "html", null, true);
                    echo " ";
                    echo twig_escape_filter($this->env, (isset($context["color"]) || array_key_exists("color", $context) ? $context["color"] : (function () { throw new RuntimeError('Variable "color" does not exist.', 35, $this->source); })()), "html", null, true);
                    echo "\"></span>";
                    echo twig_escape_filter($this->env, (isset($context["label"]) || array_key_exists("label", $context) ? $context["label"] : (function () { throw new RuntimeError('Variable "label" does not exist.', 35, $this->source); })()), "html", null, true);
                    echo "</a></li>
                    ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['status'], $context['info'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 37
                echo "                ";
            }
            // line 38
            echo "            </ul>
            ";
            // line 39
            if (((isset($context["context"]) || array_key_exists("context", $context) ? $context["context"] : (function () { throw new RuntimeError('Variable "context" does not exist.', 39, $this->source); })()) == "index")) {
                // line 40
                echo "                ";
                if ((isset($context["showStatusMenu"]) || array_key_exists("showStatusMenu", $context) ? $context["showStatusMenu"] : (function () { throw new RuntimeError('Variable "showStatusMenu" does not exist.', 40, $this->source); })())) {
                    echo "<hr class=\"padded\">";
                }
                // line 41
                echo "                <ul class=\"padded\">
                    ";
                // line 42
                $context["draftsExist"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["elementInstance"]) || array_key_exists("elementInstance", $context) ? $context["elementInstance"] : (function () { throw new RuntimeError('Variable "elementInstance" does not exist.', 42, $this->source); })()), "find", [], "method"), "draftOf", [0 => false], "method"), "anyStatus", [], "method"), "exists", [], "method");
                // line 43
                echo "                    ";
                if ((isset($context["draftsExist"]) || array_key_exists("draftsExist", $context) ? $context["draftsExist"] : (function () { throw new RuntimeError('Variable "draftsExist" does not exist.', 43, $this->source); })())) {
                    // line 44
                    echo "                        <li><a data-drafts><span class=\"icon\" data-icon=\"draft\"></span>";
                    echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Drafts", "app"), "html", null, true);
                    echo "</a></li>
                    ";
                }
                // line 46
                echo "                    <li><a data-trashed><span class=\"icon\" data-icon=\"trash\"></span>";
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Trashed", "app"), "html", null, true);
                echo "</a></li>
                </ul>
            ";
            }
            // line 49
            echo "        </div>
    </div>
";
        }
        // line 52
        if ((isset($context["showSiteMenu"]) || array_key_exists("showSiteMenu", $context) ? $context["showSiteMenu"] : (function () { throw new RuntimeError('Variable "showSiteMenu" does not exist.', 52, $this->source); })())) {
            // line 53
            echo "    ";
            $this->loadTemplate("_elements/sitemenu", "_elements/toolbar", 53)->display($context);
        }
        // line 55
        echo "<div class=\"flex-grow texticon search icon clearable\">
    ";
        // line 56
        echo twig_call_macro($macros["__internal_db0b0865922563def5e8ae6a0cc73ac1fe23dfec09f49f727959fb0d450330c9"], "macro_text", [["placeholder" => $this->extensions['craft\web\twig\Extension']->translateFilter("Search", "app")]], 56, $context, $this->getSourceContext());
        // line 58
        echo "
    <div class=\"clear hidden\" title=\"";
        // line 59
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Clear", "app"), "html", null, true);
        echo "\"></div>
</div>
<div>
    <div class=\"btn menubtn sortmenubtn\"";
        // line 62
        if ((isset($context["sortOptions"]) || array_key_exists("sortOptions", $context) ? $context["sortOptions"] : (function () { throw new RuntimeError('Variable "sortOptions" does not exist.', 62, $this->source); })())) {
            echo " title=\"";
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Sort by {attribute}", "app", ["attribute" => twig_call_macro($macros["__internal_e70146702d4651d90bb0ab9d806dcf9c4d293228987e3b6018b0f9843549456f"], "macro_sortOptionLabel", [twig_first($this->env, (isset($context["sortOptions"]) || array_key_exists("sortOptions", $context) ? $context["sortOptions"] : (function () { throw new RuntimeError('Variable "sortOptions" does not exist.', 62, $this->source); })()))], 62, $context, $this->getSourceContext())]), "html", null, true);
            echo "\"";
        }
        echo " data-icon=\"asc\">";
        echo (((isset($context["sortOptions"]) || array_key_exists("sortOptions", $context) ? $context["sortOptions"] : (function () { throw new RuntimeError('Variable "sortOptions" does not exist.', 62, $this->source); })())) ? (twig_call_macro($macros["__internal_e70146702d4651d90bb0ab9d806dcf9c4d293228987e3b6018b0f9843549456f"], "macro_sortOptionLabel", [twig_first($this->env, (isset($context["sortOptions"]) || array_key_exists("sortOptions", $context) ? $context["sortOptions"] : (function () { throw new RuntimeError('Variable "sortOptions" does not exist.', 62, $this->source); })()))], 62, $context, $this->getSourceContext())) : (""));
        echo "</div>
    <div class=\"menu\">
        <ul class=\"padded sort-attributes\">
            ";
        // line 65
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["sortOptions"]) || array_key_exists("sortOptions", $context) ? $context["sortOptions"] : (function () { throw new RuntimeError('Variable "sortOptions" does not exist.', 65, $this->source); })()));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["key"] => $context["sortOption"]) {
            // line 66
            echo "                <li><a";
            if (craft\helpers\Template::attribute($this->env, $this->source, $context["loop"], "first", [])) {
                echo " class=\"sel\"";
            }
            echo " data-attr=\"";
            echo twig_escape_filter($this->env, (((craft\helpers\Template::attribute($this->env, $this->source, $context["sortOption"], "attribute", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["sortOption"], "attribute", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["sortOption"], "attribute", [])) : ((((craft\helpers\Template::attribute($this->env, $this->source, $context["sortOption"], "orderBy", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["sortOption"], "orderBy", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["sortOption"], "orderBy", [])) : ($context["key"])))), "html", null, true);
            echo "\">";
            echo twig_call_macro($macros["__internal_e70146702d4651d90bb0ab9d806dcf9c4d293228987e3b6018b0f9843549456f"], "macro_sortOptionLabel", [$context["sortOption"]], 66, $context, $this->getSourceContext());
            echo "</a></li>
            ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['key'], $context['sortOption'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 68
        echo "        </ul>
        <hr>
        <ul class=\"padded sort-directions\">
            <li><a data-dir=\"asc\" class=\"sel\">";
        // line 71
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Ascending", "app"), "html", null, true);
        echo "</a></li>
            <li><a data-dir=\"desc\">";
        // line 72
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Descending", "app"), "html", null, true);
        echo "</a></li>
        </ul>
    </div>
</div>
";
        // line 0
        craft\helpers\Template::endProfile("template", "_elements/toolbar");
    }

    // line 3
    public function macro_sortOptionLabel($__sortOption__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "sortOption" => $__sortOption__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            // line 0
            craft\helpers\Template::beginProfile("macro", "sortOptionLabel");
            // line 4
            echo "    ";
            echo twig_escape_filter($this->env, (((craft\helpers\Template::attribute($this->env, $this->source, ($context["sortOption"] ?? null), "label", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["sortOption"] ?? null), "label", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["sortOption"] ?? null), "label", [])) : ((isset($context["sortOption"]) || array_key_exists("sortOption", $context) ? $context["sortOption"] : (function () { throw new RuntimeError('Variable "sortOption" does not exist.', 4, $this->source); })()))), "html", null, true);
            echo "
";
            // line 0
            craft\helpers\Template::endProfile("macro", "sortOptionLabel");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    public function getTemplateName()
    {
        return "_elements/toolbar";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  260 => 0,  255 => 4,  253 => 0,  240 => 3,  236 => 0,  229 => 72,  225 => 71,  220 => 68,  197 => 66,  180 => 65,  168 => 62,  162 => 59,  159 => 58,  157 => 56,  154 => 55,  150 => 53,  148 => 52,  143 => 49,  136 => 46,  130 => 44,  127 => 43,  125 => 42,  122 => 41,  117 => 40,  115 => 39,  112 => 38,  109 => 37,  94 => 35,  91 => 34,  88 => 33,  83 => 32,  81 => 31,  77 => 30,  71 => 27,  68 => 26,  66 => 25,  63 => 24,  61 => 23,  57 => 21,  55 => 20,  53 => 19,  51 => 18,  49 => 17,  47 => 16,  44 => 15,  42 => 7,  40 => 6,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% from \"_includes/forms\" import text -%}

{% macro sortOptionLabel(sortOption) %}
    {{ sortOption.label ?? sortOption  }}
{% endmacro %}
{% from _self import sortOptionLabel %}
{% do view.registerTranslations('app', [
    \"Sort by {attribute}\",
    \"Score\",
    \"Structure\",
    \"Display in a table\",
    \"Display hierarchically\",
    \"Display as thumbnails\",
]) %}

{% set elementInstance = craft.app.elements.createElement(elementType) %}
{% set context = context is defined ? context : 'index' %}
{% set showStatusMenu = (showStatusMenu is defined and showStatusMenu != 'auto' ? showStatusMenu : elementInstance.hasStatuses()) %}
{% set showSiteMenu = (craft.app.getIsMultiSite() ? (showSiteMenu ?? 'auto') : false) %}
{% if showSiteMenu == 'auto' %}
    {% set showSiteMenu = elementInstance.isLocalized() %}
{% endif %}
{% set sortOptions = elementInstance.sortOptions() %}

{% if showStatusMenu or context == 'index' %}
    <div>
        <div class=\"btn menubtn statusmenubtn\"><span class=\"status\"></span>{{ \"All\"|t('app') }}</div>
        <div class=\"menu\">
            <ul class=\"padded\">
                <li><a data-status=\"\" class=\"sel\"><span class=\"status\"></span>{{ \"All\"|t('app') }}</a></li>
                {% if showStatusMenu %}
                    {% for status, info in elementInstance.statuses() %}
                        {% set label = info.label ?? info %}
                        {% set color = info.color ?? '' %}
                        <li><a data-status=\"{{ status }}\"><span class=\"status {{ status }} {{ color }}\"></span>{{ label }}</a></li>
                    {% endfor %}
                {% endif %}
            </ul>
            {% if context == 'index' %}
                {% if showStatusMenu %}<hr class=\"padded\">{% endif %}
                <ul class=\"padded\">
                    {% set draftsExist = elementInstance.find().draftOf(false).anyStatus().exists() %}
                    {% if draftsExist %}
                        <li><a data-drafts><span class=\"icon\" data-icon=\"draft\"></span>{{ 'Drafts'|t('app') }}</a></li>
                    {% endif %}
                    <li><a data-trashed><span class=\"icon\" data-icon=\"trash\"></span>{{ \"Trashed\"|t('app') }}</a></li>
                </ul>
            {% endif %}
        </div>
    </div>
{% endif %}
{% if showSiteMenu %}
    {% include \"_elements/sitemenu\" %}
{% endif %}
<div class=\"flex-grow texticon search icon clearable\">
    {{ text({
        placeholder: \"Search\"|t('app')
    }) }}
    <div class=\"clear hidden\" title=\"{{ 'Clear'|t('app') }}\"></div>
</div>
<div>
    <div class=\"btn menubtn sortmenubtn\"{% if sortOptions %} title=\"{{ 'Sort by {attribute}'|t('app', { attribute: sortOptionLabel(sortOptions|first) }) }}\"{% endif %} data-icon=\"asc\">{{ sortOptions ? sortOptionLabel(sortOptions|first) }}</div>
    <div class=\"menu\">
        <ul class=\"padded sort-attributes\">
            {% for key, sortOption in sortOptions %}
                <li><a{% if loop.first %} class=\"sel\"{% endif %} data-attr=\"{{ sortOption.attribute ?? sortOption.orderBy ?? key }}\">{{ sortOptionLabel(sortOption) }}</a></li>
            {% endfor %}
        </ul>
        <hr>
        <ul class=\"padded sort-directions\">
            <li><a data-dir=\"asc\" class=\"sel\">{{ \"Ascending\"|t('app') }}</a></li>
            <li><a data-dir=\"desc\">{{ \"Descending\"|t('app') }}</a></li>
        </ul>
    </div>
</div>
", "_elements/toolbar", "/Applications/MAMP/htdocs/craft/smsi/vendor/craftcms/cms/src/templates/_elements/toolbar.html");
    }
}
