<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* __string_template__dd959cd03a7b0bfbe24b3d49ab4cb8414140829603e48a3f4c823b233631a061 */
class __TwigTemplate_e3139ea258760c6aed2c0b8901922c8c2eea63f4501ecdbd7d08c173fad26652 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "__string_template__dd959cd03a7b0bfbe24b3d49ab4cb8414140829603e48a3f4c823b233631a061");
        // line 1
        echo "blog/categories/";
        echo (((craft\helpers\Template::attribute($this->env, $this->source, ($context["_variables"] ?? null), "slug", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["_variables"] ?? null), "slug", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["_variables"] ?? null), "slug", [])) : (craft\helpers\Template::attribute($this->env, $this->source, ($context["object"] ?? null), "slug", [])));
        // line 0
        craft\helpers\Template::endProfile("template", "__string_template__dd959cd03a7b0bfbe24b3d49ab4cb8414140829603e48a3f4c823b233631a061");
    }

    public function getTemplateName()
    {
        return "__string_template__dd959cd03a7b0bfbe24b3d49ab4cb8414140829603e48a3f4c823b233631a061";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  41 => 0,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("blog/categories/{{ (_variables.slug ?? object.slug)|raw }}", "__string_template__dd959cd03a7b0bfbe24b3d49ab4cb8414140829603e48a3f4c823b233631a061", "");
    }
}
