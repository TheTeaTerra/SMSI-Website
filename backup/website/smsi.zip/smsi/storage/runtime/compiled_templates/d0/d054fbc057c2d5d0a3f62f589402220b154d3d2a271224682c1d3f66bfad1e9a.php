<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* categories/_edit */
class __TwigTemplate_f1ba485b6c42a7b934e4a672aba65e7f2fe43db9f761603b2b541f4e3d845bde extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'header' => [$this, 'block_header'],
            'contextMenu' => [$this, 'block_contextMenu'],
            'actionButton' => [$this, 'block_actionButton'],
            'content' => [$this, 'block_content'],
            'details' => [$this, 'block_details'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "_layouts/cp";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("template", "categories/_edit");
        // line 2
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms", "categories/_edit", 2)->unwrap();
        // line 4
        $context["fullPageForm"] = true;
        // line 5
        $context["saveShortcutRedirect"] = (isset($context["continueEditingUrl"]) || array_key_exists("continueEditingUrl", $context) ? $context["continueEditingUrl"] : (function () { throw new RuntimeError('Variable "continueEditingUrl" does not exist.', 5, $this->source); })());
        // line 6
        craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 6, $this->source); })()), "setIsDeltaRegistrationActive", [0 => true], "method");
        // line 8
        $context["groupHandle"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["group"]) || array_key_exists("group", $context) ? $context["group"] : (function () { throw new RuntimeError('Variable "group" does not exist.', 8, $this->source); })()), "handle", []);
        // line 9
        $context["isNewCategory"] = ((craft\helpers\Template::attribute($this->env, $this->source, (isset($context["category"]) || array_key_exists("category", $context) ? $context["category"] : (function () { throw new RuntimeError('Variable "category" does not exist.', 9, $this->source); })()), "id", [])) ? (false) : (true));
        // line 11
        echo \Craft::$app->getView()->invokeHook("cp.categories.edit", $context);

        // line 169
        if ( !craft\helpers\Template::attribute($this->env, $this->source, (isset($context["category"]) || array_key_exists("category", $context) ? $context["category"] : (function () { throw new RuntimeError('Variable "category" does not exist.', 169, $this->source); })()), "slug", [])) {
            // line 170
            ob_start();
            // line 171
            echo "        window.slugGenerator = new Craft.SlugGenerator('#title', '#slug', {
            charMap: ";
            // line 172
            echo $this->extensions['craft\web\twig\Extension']->jsonEncodeFilter(craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 172, $this->source); })()), "cp", []), "getAsciiCharMap", [0 => craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["category"]) || array_key_exists("category", $context) ? $context["category"] : (function () { throw new RuntimeError('Variable "category" does not exist.', 172, $this->source); })()), "site", []), "language", [])], "method"));
            echo "
        });
    ";
            Craft::$app->getView()->registerJs(ob_get_clean(), 3);
        }
        // line 1
        $this->parent = $this->loadTemplate("_layouts/cp", "categories/_edit", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        // line 0
        craft\helpers\Template::endProfile("template", "categories/_edit");
    }

    // line 13
    public function block_header($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("block", "header");
        // line 14
        echo "    <div class=\"flex flex-nowrap\">
        ";
        // line 15
        $this->displayBlock("pageTitle", $context, $blocks);
        echo "
        ";
        // line 16
        $this->displayBlock("contextMenu", $context, $blocks);
        echo "
    </div>
    <div class=\"flex\">
        ";
        // line 19
        if (((isset($context["showPreviewBtn"]) || array_key_exists("showPreviewBtn", $context) ? $context["showPreviewBtn"] : (function () { throw new RuntimeError('Variable "showPreviewBtn" does not exist.', 19, $this->source); })()) || (isset($context["shareUrl"]) || array_key_exists("shareUrl", $context)))) {
            // line 20
            echo "            <div class=\"btngroup\">
                ";
            // line 21
            if ((isset($context["showPreviewBtn"]) || array_key_exists("showPreviewBtn", $context) ? $context["showPreviewBtn"] : (function () { throw new RuntimeError('Variable "showPreviewBtn" does not exist.', 21, $this->source); })())) {
                // line 22
                echo "                    <div class=\"btn livepreviewbtn\" data-icon=\"view\">";
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Preview", "app"), "html", null, true);
                echo "</div>
                ";
            }
            // line 24
            echo "                ";
            if ((isset($context["shareUrl"]) || array_key_exists("shareUrl", $context))) {
                // line 25
                echo "                    <a href=\"";
                echo twig_escape_filter($this->env, (isset($context["shareUrl"]) || array_key_exists("shareUrl", $context) ? $context["shareUrl"] : (function () { throw new RuntimeError('Variable "shareUrl" does not exist.', 25, $this->source); })()), "html", null, true);
                echo "\" class=\"btn sharebtn\" data-icon=\"share\" rel=\"noopener\" target=\"_blank\">";
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Share", "app"), "html", null, true);
                echo "</a>
                ";
            }
            // line 27
            echo "            </div>
        ";
        }
        // line 29
        echo "        ";
        $this->displayBlock("actionButton", $context, $blocks);
        echo "
    </div>
";
        // line 0
        craft\helpers\Template::endProfile("block", "header");
    }

    // line 33
    public function block_contextMenu($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("block", "contextMenu");
        // line 34
        echo "    ";
        if (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 34, $this->source); })()), "app", []), "getIsMultiSite", [], "method")) {
            // line 35
            echo "        ";
            $context["parentIdParam"] = ((craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 35, $this->source); })()), "app", []), "request", []), "getParam", [0 => "parentId.0"], "method")) ? (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 35, $this->source); })()), "app", []), "request", []), "getParam", [0 => "parentId.0"], "method")) : (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 35, $this->source); })()), "app", []), "request", []), "getParam", [0 => "parentId"], "method")));
            // line 36
            echo "        ";
            $context["urlFormat"] = craft\helpers\UrlHelper::url((((("categories/" . (isset($context["groupHandle"]) || array_key_exists("groupHandle", $context) ? $context["groupHandle"] : (function () { throw new RuntimeError('Variable "groupHandle" does not exist.', 36, $this->source); })())) . "/") . craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 36, $this->source); })()), "app", []), "request", []), "getSegment", [0 => 3], "method")) . "/{handle}"), (((isset($context["parentIdParam"]) || array_key_exists("parentIdParam", $context) ? $context["parentIdParam"] : (function () { throw new RuntimeError('Variable "parentIdParam" does not exist.', 36, $this->source); })())) ? (["parentId" => (isset($context["parentIdParam"]) || array_key_exists("parentIdParam", $context) ? $context["parentIdParam"] : (function () { throw new RuntimeError('Variable "parentIdParam" does not exist.', 36, $this->source); })())]) : ("")));
            // line 37
            echo "        ";
            $this->loadTemplate("_elements/sitemenu", "categories/_edit", 37)->display(twig_to_array(["siteIds" =>             // line 38
(isset($context["siteIds"]) || array_key_exists("siteIds", $context) ? $context["siteIds"] : (function () { throw new RuntimeError('Variable "siteIds" does not exist.', 38, $this->source); })()), "selectedSiteId" => craft\helpers\Template::attribute($this->env, $this->source,             // line 39
(isset($context["category"]) || array_key_exists("category", $context) ? $context["category"] : (function () { throw new RuntimeError('Variable "category" does not exist.', 39, $this->source); })()), "siteId", []), "urlFormat" =>             // line 40
(isset($context["urlFormat"]) || array_key_exists("urlFormat", $context) ? $context["urlFormat"] : (function () { throw new RuntimeError('Variable "urlFormat" does not exist.', 40, $this->source); })())]));
            // line 42
            echo "    ";
        }
        // line 0
        craft\helpers\Template::endProfile("block", "contextMenu");
    }

    // line 45
    public function block_actionButton($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("block", "actionButton");
        // line 46
        echo "    <div class=\"btngroup\">
        <input type=\"submit\" class=\"btn submit\" value=\"";
        // line 47
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Save", "app"), "html", null, true);
        echo "\">

        <div class=\"btn submit menubtn\"></div>
        <div class=\"menu\">
            <ul>
                <li><a class=\"formsubmit\" data-redirect=\"";
        // line 52
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFilter('hash')->getCallable(), [(isset($context["continueEditingUrl"]) || array_key_exists("continueEditingUrl", $context) ? $context["continueEditingUrl"] : (function () { throw new RuntimeError('Variable "continueEditingUrl" does not exist.', 52, $this->source); })())]), "html", null, true);
        echo "\">
                        ";
        // line 53
        echo twig_call_macro($macros["forms"], "macro_optionShortcutLabel", ["S"], 53, $context, $this->getSourceContext());
        echo "
                        ";
        // line 54
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Save and continue editing", "app"), "html", null, true);
        echo "
                    </a></li>
                <li><a class=\"formsubmit\" data-redirect=\"";
        // line 56
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFilter('hash')->getCallable(), [((isset($context["nextCategoryUrl"]) || array_key_exists("nextCategoryUrl", $context) ? $context["nextCategoryUrl"] : (function () { throw new RuntimeError('Variable "nextCategoryUrl" does not exist.', 56, $this->source); })()) . "?parentId={parent.id}#")]), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Save and add another", "app"), "html", null, true);
        echo "</a></li>

                ";
        // line 58
        if ( !(isset($context["isNewCategory"]) || array_key_exists("isNewCategory", $context) ? $context["isNewCategory"] : (function () { throw new RuntimeError('Variable "isNewCategory" does not exist.', 58, $this->source); })())) {
            // line 59
            echo "                    <li><a class=\"formsubmit\" data-param=\"duplicate\" data-value=\"1\" data-redirect=\"";
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFilter('hash')->getCallable(), [((isset($context["continueEditingUrl"]) || array_key_exists("continueEditingUrl", $context) ? $context["continueEditingUrl"] : (function () { throw new RuntimeError('Variable "continueEditingUrl" does not exist.', 59, $this->source); })()) . "#")]), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Save as a new category", "app"), "html", null, true);
            echo "</a></li>
                ";
        }
        // line 61
        echo "            </ul>
            ";
        // line 62
        if ( !(isset($context["isNewCategory"]) || array_key_exists("isNewCategory", $context) ? $context["isNewCategory"] : (function () { throw new RuntimeError('Variable "isNewCategory" does not exist.', 62, $this->source); })())) {
            // line 63
            echo "                <hr>
                <ul>
                    <li><a class=\"formsubmit error\" data-action=\"categories/delete-category\" data-confirm=\"";
            // line 65
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Are you sure you want to delete this category?", "app"), "html", null, true);
            echo "\" data-redirect=\"";
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFilter('hash')->getCallable(), ["categories#"]), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Delete", "app"), "html", null, true);
            echo "</a></li>
                </ul>
            ";
        }
        // line 68
        echo "        </div>
    </div>
";
        // line 0
        craft\helpers\Template::endProfile("block", "actionButton");
    }

    // line 73
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("block", "content");
        // line 74
        echo "    ";
        echo craft\helpers\Html::actionInput("categories/save-category");
        echo "
    ";
        // line 75
        echo craft\helpers\Html::redirectInput(("categories/" . (isset($context["groupHandle"]) || array_key_exists("groupHandle", $context) ? $context["groupHandle"] : (function () { throw new RuntimeError('Variable "groupHandle" does not exist.', 75, $this->source); })())));
        echo "

    ";
        // line 77
        echo craft\helpers\Html::hiddenInput("groupId", craft\helpers\Template::attribute($this->env, $this->source, (isset($context["group"]) || array_key_exists("group", $context) ? $context["group"] : (function () { throw new RuntimeError('Variable "group" does not exist.', 77, $this->source); })()), "id", []));
        echo "
    ";
        // line 78
        if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["category"]) || array_key_exists("category", $context) ? $context["category"] : (function () { throw new RuntimeError('Variable "category" does not exist.', 78, $this->source); })()), "id", [])) {
            echo craft\helpers\Html::hiddenInput("categoryId", craft\helpers\Template::attribute($this->env, $this->source, (isset($context["category"]) || array_key_exists("category", $context) ? $context["category"] : (function () { throw new RuntimeError('Variable "category" does not exist.', 78, $this->source); })()), "id", []));
        }
        // line 79
        echo "    ";
        if (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 79, $this->source); })()), "app", []), "getIsMultiSite", [], "method")) {
            echo craft\helpers\Html::hiddenInput("siteId", craft\helpers\Template::attribute($this->env, $this->source, (isset($context["category"]) || array_key_exists("category", $context) ? $context["category"] : (function () { throw new RuntimeError('Variable "category" does not exist.', 79, $this->source); })()), "siteId", []));
        }
        // line 80
        echo "
    <div id=\"fields\">
        ";
        // line 82
        echo twig_call_macro($macros["forms"], "macro_textField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Title", "app"), "siteId" => craft\helpers\Template::attribute($this->env, $this->source,         // line 84
(isset($context["category"]) || array_key_exists("category", $context) ? $context["category"] : (function () { throw new RuntimeError('Variable "category" does not exist.', 84, $this->source); })()), "siteId", []), "id" => "title", "name" => "title", "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 87
(isset($context["category"]) || array_key_exists("category", $context) ? $context["category"] : (function () { throw new RuntimeError('Variable "category" does not exist.', 87, $this->source); })()), "title", []), "errors" => craft\helpers\Template::attribute($this->env, $this->source,         // line 88
(isset($context["category"]) || array_key_exists("category", $context) ? $context["category"] : (function () { throw new RuntimeError('Variable "category" does not exist.', 88, $this->source); })()), "getErrors", [0 => "title"], "method"), "first" => true, "autofocus" => true, "required" => true, "maxlength" => 255]], 82, $context, $this->getSourceContext());
        // line 93
        echo "

        <div>
            ";
        // line 96
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["group"]) || array_key_exists("group", $context) ? $context["group"] : (function () { throw new RuntimeError('Variable "group" does not exist.', 96, $this->source); })()), "getFieldLayout", [], "method"), "getTabs", [], "method"));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["tab"]) {
            // line 97
            echo "                <div id=\"";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["tab"], "getHtmlId", [], "method"), "html", null, true);
            echo "\"";
            if ( !craft\helpers\Template::attribute($this->env, $this->source, $context["loop"], "first", [])) {
                echo " class=\"hidden\"";
            }
            echo ">
                    ";
            // line 98
            $this->loadTemplate("_includes/fields", "categories/_edit", 98)->display(twig_to_array(["fields" => craft\helpers\Template::attribute($this->env, $this->source,             // line 99
$context["tab"], "getFields", [], "method"), "element" =>             // line 100
(isset($context["category"]) || array_key_exists("category", $context) ? $context["category"] : (function () { throw new RuntimeError('Variable "category" does not exist.', 100, $this->source); })()), "registerDeltas" => true]));
            // line 103
            echo "                </div>
            ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['tab'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 105
        echo "        </div>
    </div>

    ";
        // line 109
        echo "    ";
        echo \Craft::$app->getView()->invokeHook("cp.categories.edit.content", $context);

        // line 0
        craft\helpers\Template::endProfile("block", "content");
    }

    // line 112
    public function block_details($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 0
        craft\helpers\Template::beginProfile("block", "details");
        // line 113
        echo "    <div id=\"settings\" class=\"meta\">

        ";
        // line 115
        echo twig_call_macro($macros["forms"], "macro_textField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Slug", "app"), "siteId" => craft\helpers\Template::attribute($this->env, $this->source,         // line 117
(isset($context["category"]) || array_key_exists("category", $context) ? $context["category"] : (function () { throw new RuntimeError('Variable "category" does not exist.', 117, $this->source); })()), "siteId", []), "id" => "slug", "name" => "slug", "autocorrect" => false, "autocapitalize" => false, "value" => craft\helpers\Template::attribute($this->env, $this->source,         // line 122
(isset($context["category"]) || array_key_exists("category", $context) ? $context["category"] : (function () { throw new RuntimeError('Variable "category" does not exist.', 122, $this->source); })()), "slug", []), "placeholder" => $this->extensions['craft\web\twig\Extension']->translateFilter("Enter slug", "app"), "errors" => $this->extensions['craft\web\twig\Extension']->mergeFilter(craft\helpers\Template::attribute($this->env, $this->source,         // line 124
(isset($context["category"]) || array_key_exists("category", $context) ? $context["category"] : (function () { throw new RuntimeError('Variable "category" does not exist.', 124, $this->source); })()), "getErrors", [0 => "slug"], "method"), craft\helpers\Template::attribute($this->env, $this->source, (isset($context["category"]) || array_key_exists("category", $context) ? $context["category"] : (function () { throw new RuntimeError('Variable "category" does not exist.', 124, $this->source); })()), "getErrors", [0 => "uri"], "method"))]], 115, $context, $this->getSourceContext());
        // line 125
        echo "

        ";
        // line 127
        if ((isset($context["parentOptionCriteria"]) || array_key_exists("parentOptionCriteria", $context))) {
            // line 128
            echo "            ";
            echo twig_call_macro($macros["forms"], "macro_elementSelectField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Parent", "app"), "id" => "parentId", "name" => "parentId", "elementType" =>             // line 132
(isset($context["elementType"]) || array_key_exists("elementType", $context) ? $context["elementType"] : (function () { throw new RuntimeError('Variable "elementType" does not exist.', 132, $this->source); })()), "selectionLabel" => $this->extensions['craft\web\twig\Extension']->translateFilter("Choose", "app"), "sources" => [0 => ("group:" . craft\helpers\Template::attribute($this->env, $this->source,             // line 134
(isset($context["group"]) || array_key_exists("group", $context) ? $context["group"] : (function () { throw new RuntimeError('Variable "group" does not exist.', 134, $this->source); })()), "uid", []))], "criteria" =>             // line 135
(isset($context["parentOptionCriteria"]) || array_key_exists("parentOptionCriteria", $context) ? $context["parentOptionCriteria"] : (function () { throw new RuntimeError('Variable "parentOptionCriteria" does not exist.', 135, $this->source); })()), "limit" => 1, "elements" => (((            // line 137
(isset($context["parent"]) || array_key_exists("parent", $context)) && (isset($context["parent"]) || array_key_exists("parent", $context) ? $context["parent"] : (function () { throw new RuntimeError('Variable "parent" does not exist.', 137, $this->source); })()))) ? ([0 => (isset($context["parent"]) || array_key_exists("parent", $context) ? $context["parent"] : (function () { throw new RuntimeError('Variable "parent" does not exist.', 137, $this->source); })())]) : ("")), "errors" => craft\helpers\Template::attribute($this->env, $this->source,             // line 138
(isset($context["category"]) || array_key_exists("category", $context) ? $context["category"] : (function () { throw new RuntimeError('Variable "category" does not exist.', 138, $this->source); })()), "getErrors", [0 => "parent"], "method")]], 128, $context, $this->getSourceContext());
            // line 139
            echo "
        ";
        }
        // line 141
        echo "
        ";
        // line 142
        echo twig_call_macro($macros["forms"], "macro_lightswitchField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Enabled", "app"), "id" => "enabled", "name" => "enabled", "on" => craft\helpers\Template::attribute($this->env, $this->source,         // line 146
(isset($context["category"]) || array_key_exists("category", $context) ? $context["category"] : (function () { throw new RuntimeError('Variable "category" does not exist.', 146, $this->source); })()), "enabled", [])]], 142, $context, $this->getSourceContext());
        // line 147
        echo "

    </div>

    ";
        // line 151
        if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["category"]) || array_key_exists("category", $context) ? $context["category"] : (function () { throw new RuntimeError('Variable "category" does not exist.', 151, $this->source); })()), "id", [])) {
            // line 152
            echo "        <div class=\"meta read-only\">
            <div class=\"data\">
                <h5 class=\"heading\">";
            // line 154
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Date Created", "app"), "html", null, true);
            echo "</h5>
                <div class=\"value\">";
            // line 155
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->datetimeFilter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["category"]) || array_key_exists("category", $context) ? $context["category"] : (function () { throw new RuntimeError('Variable "category" does not exist.', 155, $this->source); })()), "dateCreated", []), "short"), "html", null, true);
            echo "</div>
            </div>
            <div class=\"data\">
                <h5 class=\"heading\">";
            // line 158
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Date Updated", "app"), "html", null, true);
            echo "</h5>
                <div class=\"value\">";
            // line 159
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->datetimeFilter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["category"]) || array_key_exists("category", $context) ? $context["category"] : (function () { throw new RuntimeError('Variable "category" does not exist.', 159, $this->source); })()), "dateUpdated", []), "short"), "html", null, true);
            echo "</div>
            </div>
        </div>
    ";
        }
        // line 163
        echo "
    ";
        // line 165
        echo "    ";
        echo \Craft::$app->getView()->invokeHook("cp.categories.edit.details", $context);

        // line 0
        craft\helpers\Template::endProfile("block", "details");
    }

    public function getTemplateName()
    {
        return "categories/_edit";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  423 => 0,  419 => 165,  416 => 163,  409 => 159,  405 => 158,  399 => 155,  395 => 154,  391 => 152,  389 => 151,  383 => 147,  381 => 146,  380 => 142,  377 => 141,  373 => 139,  371 => 138,  370 => 137,  369 => 135,  368 => 134,  367 => 132,  365 => 128,  363 => 127,  359 => 125,  357 => 124,  356 => 122,  355 => 117,  354 => 115,  350 => 113,  348 => 0,  344 => 112,  340 => 0,  336 => 109,  331 => 105,  316 => 103,  314 => 100,  313 => 99,  312 => 98,  303 => 97,  286 => 96,  281 => 93,  279 => 88,  278 => 87,  277 => 84,  276 => 82,  272 => 80,  267 => 79,  263 => 78,  259 => 77,  254 => 75,  249 => 74,  247 => 0,  243 => 73,  239 => 0,  235 => 68,  225 => 65,  221 => 63,  219 => 62,  216 => 61,  208 => 59,  206 => 58,  199 => 56,  194 => 54,  190 => 53,  186 => 52,  178 => 47,  175 => 46,  173 => 0,  169 => 45,  165 => 0,  162 => 42,  160 => 40,  159 => 39,  158 => 38,  156 => 37,  153 => 36,  150 => 35,  147 => 34,  145 => 0,  141 => 33,  137 => 0,  131 => 29,  127 => 27,  119 => 25,  116 => 24,  110 => 22,  108 => 21,  105 => 20,  103 => 19,  97 => 16,  93 => 15,  90 => 14,  88 => 0,  84 => 13,  80 => 0,  77 => 1,  70 => 172,  67 => 171,  65 => 170,  63 => 169,  60 => 11,  58 => 9,  56 => 8,  54 => 6,  52 => 5,  50 => 4,  48 => 2,  46 => 0,  39 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends \"_layouts/cp\" %}
{% import \"_includes/forms\" as forms %}

{% set fullPageForm = true %}
{% set saveShortcutRedirect = continueEditingUrl %}
{% do view.setIsDeltaRegistrationActive(true) %}

{% set groupHandle = group.handle %}
{% set isNewCategory = category.id ? false : true %}

{% hook \"cp.categories.edit\" %}

{% block header %}
    <div class=\"flex flex-nowrap\">
        {{ block('pageTitle') }}
        {{ block('contextMenu') }}
    </div>
    <div class=\"flex\">
        {% if showPreviewBtn or shareUrl is defined %}
            <div class=\"btngroup\">
                {% if showPreviewBtn %}
                    <div class=\"btn livepreviewbtn\" data-icon=\"view\">{{ \"Preview\"|t('app') }}</div>
                {% endif %}
                {% if shareUrl is defined %}
                    <a href=\"{{ shareUrl }}\" class=\"btn sharebtn\" data-icon=\"share\" rel=\"noopener\" target=\"_blank\">{{ 'Share'|t('app') }}</a>
                {% endif %}
            </div>
        {% endif %}
        {{ block('actionButton') }}
    </div>
{% endblock %}

{% block contextMenu %}
    {% if craft.app.getIsMultiSite() %}
        {% set parentIdParam = craft.app.request.getParam('parentId.0') ?: craft.app.request.getParam('parentId') %}
        {% set urlFormat = url(\"categories/#{groupHandle}/#{craft.app.request.getSegment(3)}/{handle}\", (parentIdParam ? { parentId: parentIdParam })) %}
        {% include \"_elements/sitemenu\" with {
            siteIds: siteIds,
            selectedSiteId: category.siteId,
            urlFormat: urlFormat
        } only %}
    {% endif %}
{% endblock %}

{% block actionButton %}
    <div class=\"btngroup\">
        <input type=\"submit\" class=\"btn submit\" value=\"{{ 'Save'|t('app') }}\">

        <div class=\"btn submit menubtn\"></div>
        <div class=\"menu\">
            <ul>
                <li><a class=\"formsubmit\" data-redirect=\"{{ continueEditingUrl|hash }}\">
                        {{ forms.optionShortcutLabel('S') }}
                        {{ \"Save and continue editing\"|t('app') }}
                    </a></li>
                <li><a class=\"formsubmit\" data-redirect=\"{{ (nextCategoryUrl~'?parentId={parent.id}#')|hash }}\">{{ \"Save and add another\"|t('app') }}</a></li>

                {% if not isNewCategory %}
                    <li><a class=\"formsubmit\" data-param=\"duplicate\" data-value=\"1\" data-redirect=\"{{ (continueEditingUrl~'#')|hash }}\">{{ \"Save as a new category\"|t('app') }}</a></li>
                {% endif %}
            </ul>
            {% if not isNewCategory %}
                <hr>
                <ul>
                    <li><a class=\"formsubmit error\" data-action=\"categories/delete-category\" data-confirm=\"{{ 'Are you sure you want to delete this category?'|t('app') }}\" data-redirect=\"{{ 'categories#'|hash }}\">{{ 'Delete'|t('app') }}</a></li>
                </ul>
            {% endif %}
        </div>
    </div>
{% endblock %}


{% block content %}
    {{ actionInput('categories/save-category') }}
    {{ redirectInput('categories/'~groupHandle) }}

    {{ hiddenInput('groupId', group.id) }}
    {% if category.id %}{{ hiddenInput('categoryId', category.id) }}{% endif %}
    {% if craft.app.getIsMultiSite() %}{{ hiddenInput('siteId', category.siteId) }}{% endif %}

    <div id=\"fields\">
        {{ forms.textField({
            label: \"Title\"|t('app'),
            siteId: category.siteId,
            id: 'title',
            name: 'title',
            value: category.title,
            errors: category.getErrors('title'),
            first: true,
            autofocus: true,
            required: true,
            maxlength: 255
        }) }}

        <div>
            {% for tab in group.getFieldLayout().getTabs() %}
                <div id=\"{{ tab.getHtmlId() }}\"{% if not loop.first %} class=\"hidden\"{% endif %}>
                    {% include \"_includes/fields\" with {
                        fields:  tab.getFields(),
                        element: category,
                        registerDeltas: true,
                    } only %}
                </div>
            {% endfor %}
        </div>
    </div>

    {# Give plugins a chance to add other things here #}
    {% hook \"cp.categories.edit.content\" %}
{% endblock %}

{% block details %}
    <div id=\"settings\" class=\"meta\">

        {{ forms.textField({
            label: \"Slug\"|t('app'),
            siteId: category.siteId,
            id: 'slug',
            name: 'slug',
            autocorrect: false,
            autocapitalize: false,
            value: category.slug,
            placeholder: \"Enter slug\"|t('app'),
            errors: (category.getErrors('slug')|merge(category.getErrors('uri')))
        }) }}

        {% if parentOptionCriteria is defined %}
            {{ forms.elementSelectField({
                label: \"Parent\"|t('app'),
                id: 'parentId',
                name: 'parentId',
                elementType: elementType,
                selectionLabel: \"Choose\"|t('app'),
                sources: ['group:'~group.uid],
                criteria: parentOptionCriteria,
                limit: 1,
                elements: (parent is defined and parent ? [parent]),
                errors: category.getErrors('parent')
            }) }}
        {% endif %}

        {{ forms.lightswitchField({
            label: \"Enabled\"|t('app'),
            id: 'enabled',
            name: 'enabled',
            on: category.enabled
        }) }}

    </div>

    {% if category.id %}
        <div class=\"meta read-only\">
            <div class=\"data\">
                <h5 class=\"heading\">{{ \"Date Created\"|t('app') }}</h5>
                <div class=\"value\">{{ category.dateCreated|datetime('short') }}</div>
            </div>
            <div class=\"data\">
                <h5 class=\"heading\">{{ \"Date Updated\"|t('app') }}</h5>
                <div class=\"value\">{{ category.dateUpdated|datetime('short') }}</div>
            </div>
        </div>
    {% endif %}

    {# Give plugins a chance to add other stuff here #}
    {% hook \"cp.categories.edit.details\" %}
{% endblock %}


{% if not category.slug %}
    {% js %}
        window.slugGenerator = new Craft.SlugGenerator('#title', '#slug', {
            charMap: {{ craft.cp.getAsciiCharMap(category.site.language)|json_encode|raw }}
        });
    {% endjs %}
{% endif %}
", "categories/_edit", "/Applications/MAMP/htdocs/craft/smsi/vendor/craftcms/cms/src/templates/categories/_edit.html");
    }
}
